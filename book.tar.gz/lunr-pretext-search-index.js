var ptx_lunr_search_style = "textbook";
var ptx_lunr_docs = [
{
  "id": "front-colophon",
  "level": "1",
  "url": "front-colophon.html",
  "type": "Impressum",
  "number": "",
  "title": "Impressum",
  "body": "  "
},
{
  "id": "wt-ds-3-4",
  "level": "1",
  "url": "wt-ds-3-4.html",
  "type": "Einleitung",
  "number": "",
  "title": "Vorwort: Wie Sie dieses Buch nutzen",
  "body": " Vorwort: Wie Sie dieses Buch nutzen  Dieses Buch begleitet die Vorlesung Wahrscheinlichkeitstheorie im Studiengang Data Science für Technik und Wirtschaft. Es führt vom Wahrscheinlichkeitsbegriff über Zufallsvariablen und ihre Verteilungen zu gemeinsamen Verteilungen, den Grenzwertsätzen und schließlich zur Parameterschätzung, in zehn Abschnitten, einem pro Vorlesungswoche.   Warum das für Data Science zentral ist. Fast jedes Verfahren, das Sie im Studium noch kennenlernen werden, ist im Kern ein wahrscheinlichkeitstheoretisches Argument. Ein Klassifikator schätzt eine bedingte Wahrscheinlichkeit. Ein Regressionsmodell unterstellt eine Verteilung für das Rauschen. Ein A\/B-Test steht und fällt mit dem zentralen Grenzwertsatz. Regularisierung ist ein Prior in anderer Schreibweise. Wer diese Vorlesung verstanden hat, liest später keine Rezepte mehr, sondern Begründungen.   Die Vorlesung ist umgedreht. Sie lesen jede Woche vor der Vorlesung den zugehörigen Abschnitt zu Hause. In der Vorlesung selbst wird der Stoff nicht noch einmal vorgetragen, sondern an Aufgaben vertieft, diskutiert und auf Fragen hin abgeklopft. Das funktioniert nur, wenn Sie vorbereitet kommen, und dafür ist dieses Buch geschrieben. Planen Sie für einen Abschnitt etwa zwei bis drei Stunden konzentriertes Lesen ein.   So ist ein Abschnitt aufgebaut. Jeder Abschnitt beginnt mit Lernzielen : Diese Liste sagt Ihnen, was Sie am Ende können sollten. Lesen Sie sie zuerst und am Ende noch einmal. Dann folgt der eigentliche Stoff: Definitionen legen Begriffe fest, Sätze halten die Rechenregeln und Zusammenhänge fest, und Beispiele zeigen, wie man damit rechnet. Die Beispiele sind das Herzstück: Rechenbeispiele führen ein Verfahren Schritt für Schritt vor, Anwendungsbeispiele zeigen, wo dasselbe Verfahren in Data Science, Wirtschaft oder Technik gebraucht wird. Eine Zusammenfassung bündelt am Ende das Wichtigste auf einer Seite, und einige kurze Übungsaufgaben lassen Sie prüfen, ob Sie den Abschnitt verstanden haben.   Lesen Sie mit Stift und Papier. Mathematik liest man nicht wie einen Roman. Die Lösungen der Beispiele sind in der Online-Version zunächst eingeklappt: Versuchen Sie jedes Beispiel erst selbst, und klappen Sie die Lösung dann zum Vergleich auf. Wenn eine Rechnung im Text einen Schritt überspringt, rechnen Sie ihn nach. Und wenn etwas unklar bleibt, notieren Sie die Frage; genau dafür ist die Vorlesung da.   Der Code im Buch. An einigen Stellen finden Sie Python-Zellen, die Sie direkt im Browser ausführen und verändern können. Sie sind kein Prüfungsstoff und ersetzen keine Rechnung von Hand. Sie sind dazu da, eine Behauptung auszuprobieren. Wie nah liegt das Stichprobenmittel nach hundert Würfen wirklich am Erwartungswert? Was passiert mit der Normalverteilungs-Näherung, wenn die Stichprobe klein wird? Ändern Sie eine Zahl und sehen Sie nach. Wer keine Lust auf Code hat, überspringt die Zellen: Jede Aussage, die eine Zelle illustriert, steht auch im Text.   Vertiefungen. Einige Beispiele, Bemerkungen und Absätze sind mit dem Wort Vertiefung überschrieben oder eingeleitet. Sie gehen über den Kern der Woche hinaus, etwa mit einem Beweis, einem Ausblick auf das maschinelle Lernen oder einem Sonderfall. Sie dürfen sie beim ersten Lesen überspringen; für die Klausur werden sie nicht vorausgesetzt.   Quellen und Lizenz. Das Buch beruht auf den Folien und Übungsblättern der Vorlesung. Wo ein Beispiel oder seine Zahlen aus einem Lehrbuch stammen und wo eine historische oder empirische Angabe einen Beleg braucht, steht die Quelle an der Stelle; gesammelt finden Sie alles in . Dort steht auch, dass und wie Sie das Buch weiterverwenden dürfen: Es steht unter der freien Lizenz CC BY 4.0.  "
},
{
  "id": "wt-ds-3-4-3",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Warum das für Data Science zentral ist. "
},
{
  "id": "wt-ds-3-4-4",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Die Vorlesung ist umgedreht. "
},
{
  "id": "wt-ds-3-4-5",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-5",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "So ist ein Abschnitt aufgebaut. "
},
{
  "id": "wt-ds-3-4-6",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Lesen Sie mit Stift und Papier. "
},
{
  "id": "wt-ds-3-4-7",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-7",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Der Code im Buch. "
},
{
  "id": "wt-ds-3-4-8",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-8",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Vertiefungen. "
},
{
  "id": "wt-ds-3-4-9",
  "level": "2",
  "url": "wt-ds-3-4.html#wt-ds-3-4-9",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Quellen und Lizenz. "
},
{
  "id": "sec-wahrscheinlichkeitsraeume-und-bayes",
  "level": "1",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html",
  "type": "Abschnitt",
  "number": "1.1",
  "title": "Wahrscheinlichkeitsräume, Kombinatorik und der Satz von Bayes",
  "body": " Wahrscheinlichkeitsräume, Kombinatorik und der Satz von Bayes    Nach diesem Abschnitt können Sie     zu einem Zufallsexperiment den Ergebnisraum angeben und sprachlich beschriebene Ereignisse als Mengen schreiben und verknüpfen,    die Axiome von Kolmogorov angeben und aus ihnen die Rechenregeln für Gegenereignis, Differenz und Vereinigung herleiten,    Laplace-Wahrscheinlichkeiten mit den Grundformeln der Kombinatorik berechnen und dabei entscheiden, ob Reihenfolge und Wiederholung eine Rolle spielen,    bedingte Wahrscheinlichkeiten aus Vierfeldertafeln und Baumdiagrammen bestimmen und die Unabhängigkeit zweier Ereignisse rechnerisch prüfen,    mit dem Satz von der totalen Wahrscheinlichkeit und dem Satz von Bayes von auf schließen,    aus Sensitivität, Spezifität und Basisrate eines Tests oder Klassifikators den positiven Vorhersagewert berechnen und erklären, warum er bei seltenen Ereignissen klein ist,    den Fehlschluss erkennen, mit zu verwechseln.      Ein Kamerasystem prüft in der Elektronikfertigung jede Lötstelle auf einer Platine. Es erkennt 99 % der fehlerhaften Lötstellen und schlägt nur bei 1 % der einwandfreien fälschlich Alarm. Wie wahrscheinlich ist eine gemeldete Lötstelle tatsächlich fehlerhaft? Die naheliegende Antwort 99 % ist gründlich falsch: Ist nur eine von tausend Lötstellen fehlerhaft, liegt die richtige Antwort bei gut 9 %.  Der Weg dahin: In bauen wir aus Ergebnisraum, Ereignissen und den Axiomen von Kolmogorov einen Wahrscheinlichkeitsraum, in folgen daraus die Rechenregeln. liefert das Abzählen für Laplace-Wahrscheinlichkeiten, bedingte Wahrscheinlichkeiten und Unabhängigkeit, und den Satz von Bayes samt der Frage vom Anfang. Die Teile, die Sie aus der Schule kennen, dürfen Sie zügig lesen; rechnen Sie aber jedes Beispiel selbst nach.    Der Wahrscheinlichkeitsraum  Was bedeutet der Satz Die Wahrscheinlichkeit, mit einem fairen Würfel eine 6 zu werfen, ist ? Zwei Antworten haben sich eingebürgert. In der frequentistischen Wahrscheinlichkeit frequentistische Sicht Sicht ist eine Wahrscheinlichkeit der Wert, dem sich die relative Häufigkeit eines Ereignisses bei sehr vielen Wiederholungen nähert: Wirft man oft genug, zeigt ungefähr jeder sechste Wurf eine 6. In der bayesschen Wahrscheinlichkeit bayessche Sicht Sicht ist eine Wahrscheinlichkeit ein Grad an Überzeugung, der Vorwissen einbezieht. Sie ergibt auch dort Sinn, wo sich nichts wiederholen lässt, etwa bei der Frage, ob ein bestimmter Kunde in den nächsten zwölf Monaten kündigt.  Beide Sichten rechnen nach denselben Regeln. Andrei Kolmogorov hat 1933 gezeigt ( ), dass sich die gesamte Wahrscheinlichkeitsrechnung auf drei Axiome gründen lässt, die gar nicht festlegen, was eine Wahrscheinlichkeit ist , sondern nur, wie man mit ihr rechnet. Die Kurzfassung lautet: Eine Wahrscheinlichkeit misst die Größe einer Menge. Dafür braucht man drei Zutaten: die Menge aller möglichen Ergebnisse, die Teilmengen, denen man eine Wahrscheinlichkeit zuordnen will, und die Zuordnung selbst. In laufen die beiden Sichten wieder auseinander; dort wird der Unterschied praktisch.   Ergebnis, Ergebnisraum  Ergebnisraum  Ergebnis  Elementarereignis  Zufallsexperiment   Ein Zufallsexperiment ist ein Vorgang, dessen Ausgang sich nicht vorhersagen lässt. Jeder mögliche Ausgang heißt Ergebnis oder Elementarereignis und wird meist mit bezeichnet. Die Menge aller möglichen Ergebnisse heißt Ergebnisraum .    Drei Beispiele zeigen die Spannweite:   Zweimal würfeln: , also Paare. Es sind Paare und keine Mengen, weil sich der erste vom zweiten Wurf unterscheiden lässt.    Anzahl der Garantiefälle unter produzierten Fahrzeugen: .    Wartezeit in Minuten bis zum nächsten Anruf in einem Callcenter: .     Der Ergebnisraum ist eine Modellierungsentscheidung. Bei der Wartezeit könnte man auf ganze Minuten runden und wählen. Der Unterschied zwischen endlichen oder abzählbaren Ergebnisräumen einerseits und Intervallen wie andererseits begleitet uns durch die ganze Vorlesung: Aus ihm werden später diskrete und stetige Zufallsvariablen.   Ereignis  Ereignis   Ein Ereignis ist eine Teilmenge . Das Ereignis  tritt ein , wenn das Ergebnis des Zufallsexperiments in liegt.    Weil Ereignisse Mengen sind, werden aus sprachlichen Verknüpfungen Mengenoperationen. ist das Wörterbuch, mit dem Sie Textaufgaben in Rechnungen übersetzen. disjunkt    Ereignisse in Worten und als Mengen      In Worten  Als Menge    oder tritt ein (mindestens eines von beiden)     und treten ein     tritt nicht ein (Gegenereignis)     tritt ein, aber nicht     und schließen einander aus  ( , disjunkt)    Wenn eintritt, tritt auch ein     sicheres Ereignis, unmögliches Ereignis  ,     Für Verneinungen sind die Regeln von De Morgan nützlich: ( nicht oder heißt weder noch ) und .  Welchen Teilmengen von soll eine Wahrscheinlichkeit zugeordnet werden? Die natürliche Antwort, nämlich allen, ist für endliche und abzählbare Ergebnisräume richtig. Der Ereignisraum ist dann die Potenzmenge Potenzmenge  , die Menge aller Teilmengen von . Für den Status eines Sensors mit sind das Ereignisse: , drei einelementige, drei zweielementige Mengen und selbst.  Für geht das nicht mehr. Die Gleichverteilung auf gibt jedem Intervall seine Länge als Wahrscheinlichkeit. Man kann beweisen, dass sich schon diese Verteilung nicht auf alle Teilmengen von ausdehnen lässt, ohne eine selbstverständliche Eigenschaft zu verlieren: dass eine Menge nicht wahrscheinlicher wird, wenn man sie nur verschiebt. Man verlangt vom Ereignisraum deshalb nur, dass er unter den Operationen abgeschlossen ist, die man tatsächlich braucht.   -Algebra, Ereignisraum  -Algebra  Ereignisraum   Ein System von Teilmengen von heißt -Algebra , wenn gilt:  ,  aus folgt ,   aus folgt .     Ein Ereignisraum zum Ergebnisraum ist eine -Algebra über ; ihre Elemente heißen Ereignisse .    Aus den drei Bedingungen folgt alles Weitere: liegt in , endliche Vereinigungen ebenfalls (man füllt mit auf), und nach De Morgan auch Durchschnitte und Differenzen. In vielen Texten heißt der Ereignisraum ; wir schreiben , weil später für Kovarianzmatrizen gebraucht wird.  Für diese Vorlesung genügt Folgendes. Bei endlichem oder abzählbarem ist der Ereignisraum immer die Potenzmenge. Bei ist es die Borel- -Algebra Borel- -Algebra , die kleinste -Algebra, die alle Intervalle enthält. Sie enthält jede Menge, der Sie in der Praxis begegnen werden. Eine -Algebra selbst konstruieren müssen Sie nie; Sie sollen nur wissen, warum es sie gibt.   Wahrscheinlichkeitsmaß, Wahrscheinlichkeitsraum  Wahrscheinlichkeitsmaß  Wahrscheinlichkeitsraum  Axiome von Kolmogorov  Kolmogorov, Axiome von   Sei ein Ereignisraum über . Eine Abbildung heißt Wahrscheinlichkeitsmaß , wenn sie die drei Axiome von Kolmogorov erfüllt:  für alle ,  ,   für paarweise disjunkte Ereignisse gilt      Das Tripel heißt Wahrscheinlichkeitsraum .    Das dritte Axiom heißt -Additivität -Additivität : Die Wahrscheinlichkeit, dass eines von mehreren einander ausschließenden Ereignissen eintritt, ist die Summe der Einzelwahrscheinlichkeiten. Auf den ersten Blick wirken die drei Axiome dürftig. Tatsächlich folgt aus ihnen jede Rechenregel, die Sie kennen; wie, zeigt . Auf den Folien der Vorlesung und in manchen Büchern heißt auch Wahrscheinlichkeitsfunktion; wir reservieren dieses Wort ab für die Funktion, die jedem Wert einer diskreten Zufallsvariablen seine Wahrscheinlichkeit zuordnet.  Wie baut man konkret ein Wahrscheinlichkeitsmaß? Bei endlichem oder abzählbarem genügt es, jedem einzelnen Ergebnis ein Gewicht zu geben.   Diskrete Wahrscheinlichkeitsräume  Wahrscheinlichkeitsraum diskreter   Sei endlich oder abzählbar, und sei eine Funktion mit . Dann ist ein Wahrscheinlichkeitsmaß auf , und es gilt .    Als Summe nichtnegativer Zahlen ist , und weil nur einen Teil der Summanden von enthält, ist . Das zweite Axiom ist die Voraussetzung. Für das dritte: Sind paarweise disjunkt, so kommt jedes der Vereinigung in genau einer der Mengen vor. Eine Summe nichtnegativer Zahlen darf man beliebig umordnen und gruppieren, also ist .    Der wichtigste Spezialfall ist der, in dem alle Ergebnisse gleich wahrscheinlich sind.   Laplace-Experiment  Laplace-Experiment   Ist endlich und für alle , so heißt das Zufallsexperiment Laplace-Experiment . Für jedes Ereignis gilt dann Dabei bezeichnet die Anzahl der Elemente von .    Dass alle Ergebnisse gleich wahrscheinlich sind, ist eine Modellannahme und keine Selbstverständlichkeit. Sie ist gerechtfertigt bei fairen Würfeln und Münzen, bei gut gemischten Karten und immer dann, wenn man rein zufällig eine Zeile aus einem Datensatz zieht. Wie leicht sie bei einem ungeschickt gewählten Ergebnisraum falsch wird, zeigt .   Zweimal würfeln   Ein fairer Würfel wird zweimal geworfen. Geben Sie den Wahrscheinlichkeitsraum an und bestimmen Sie die Wahrscheinlichkeiten der Ereignisse  : Die Augensumme ist kleiner als 5 ,  : Die Augensumme ist gerade ,  , in Worten formuliert.      Der Ergebnisraum ist mit , der Ereignisraum ist . Bei einem fairen Würfel ist jedes der Paare gleich wahrscheinlich; es liegt ein Laplace-Experiment vor.  Das Ereignis besteht aus den Paaren mit Augensumme 2, 3 oder 4:   Die Augensumme ist genau dann gerade, wenn beide Augenzahlen gerade oder beide ungerade sind. Dafür gibt es Paare, also .   heißt Die Augensumme ist 2 oder 4 : und .    Frequentistisch gelesen heißt : Wirft man sehr oft zweimal, so ist in etwa einem Sechstel der Fälle die Augensumme kleiner als 5. Das lässt sich ausprobieren.   import random # Probieren Sie n = 100, 1000, 100000. n = 100 augensummen = [random.randint(1, 6) + random.randint(1, 6) for _ in range(n)] treffer = sum(1 for s in augensummen if s < 5) print(\"relative Häufigkeit: %.4f\" % (treffer \/ n)) print(\"Laplace-Wahrscheinlichkeit: %.4f\" % (1 \/ 6))   Dass die relative Häufigkeit für wachsendes tatsächlich gegen die Wahrscheinlichkeit strebt, ist kein Axiom, sondern ein Satz: das Gesetz der großen Zahlen ( ).   Die Ausgabe eines Klassifikators   Ein Bildklassifikator ordnet ein Foto einer von vier Klassen zu und gibt dazu Wahrscheinlichkeiten aus: Katze , Hund , Fuchs , Sonstiges .   Begründen Sie, dass diese Angaben einen Wahrscheinlichkeitsraum definieren.    Mit welcher Wahrscheinlichkeit zeigt das Foto nach Einschätzung des Modells einen Hundeartigen, also Hund oder Fuchs?    Mit welcher Wahrscheinlichkeit zeigt es keine Katze?          Mit sind alle vier Gewichte in und summieren sich zu . Nach definiert ein Wahrscheinlichkeitsmaß auf .     .     . Schneller geht es mit der Komplementregel aus : .     Die sogenannte Softmax-Funktion Softmax-Funktion am Ausgang eines typischen neuronalen Klassifikators ist gerade so gebaut, dass ihre Ausgaben nichtnegativ sind und sich zu 1 summieren. Sie liefert also für jedes Eingabebild einen diskreten Wahrscheinlichkeitsraum über den Klassen. Ob diese Wahrscheinlichkeiten auch stimmen , ob also von allen Fotos, denen das Modell für Katze gibt, wirklich etwa 60 % Katzen zeigen, ist eine andere Frage. Die Axiome garantieren nur, dass man mit den Zahlen widerspruchsfrei rechnen kann.      Rechenregeln  Aus den drei Axiomen folgen alle Rechenregeln, die Sie aus der Schule kennen. Die Herleitungen einmal nachzuvollziehen lohnt sich: Sie zeigen, dass die Regeln keine Faustregeln sind, sondern für jedes Wahrscheinlichkeitsmaß gelten, für Würfel und Wartezeiten genauso wie für die Ausgabe eines neuronalen Netzes.   Rechenregeln für Wahrscheinlichkeiten  Rechenregeln für Wahrscheinlichkeiten  Additionsregel  Gegenereignis   Sei ein Wahrscheinlichkeitsraum und seien . Dann gilt:  .   Endliche Additivität: Für paarweise disjunkte ist .   Gegenereignis: .   Differenz und Monotonie: Aus folgt und damit .    Additionsregel: .       (1) Die Folge ist paarweise disjunkt mit Vereinigung . Das dritte Axiom liefert . Eine Zahl zwischen 0 und 1, die gleich einer unendlichen Summe von Kopien ihrer selbst ist, muss 0 sein.  (2) Man ergänzt und wendet das dritte Axiom und (1) an.  (3) und sind disjunkt mit Vereinigung . Nach (2) und dem zweiten Axiom ist .  (4) Für ist die disjunkte Vereinigung von und , also . Weil ist, folgt .  (5) ist die disjunkte Vereinigung von und . Mit (2) und dann (4), angewandt auf , folgt .    Die Additionsregel ist die Wahrscheinlichkeitsfassung eines einfachen Zählarguments: Wer erst die Elemente von und dann die von zählt, hat die von zweimal gezählt und muss sie einmal abziehen ( ). Für disjunkte Ereignisse entfällt der Korrekturterm.   Additionsregel: steckt sowohl in als auch in .   Venn-Diagramm zweier sich überlappender Ereignisse A und B im Ergebnisraum Omega   Ein Rechteck steht für den Ergebnisraum . Darin liegen zwei Kreise für die Ereignisse und , die sich teilweise überlappen. Die Überlappung ist grau hervorgehoben und mit beschriftet. Addiert man die Flächen beider Kreise, zählt die graue Fläche doppelt.      Die Regel für das Gegenereignis ist das wichtigste Werkzeug für Fragen der Form mindestens einer . Deren Gegenereignis keiner ist fast immer leichter zu berechnen; Beispiele folgen in und .   Kontamination von Wafern   In der Halbleiterfertigung wurden für 940 Wafer der Ort und der Grad einer Kontamination erfasst (Zahlen aus Montgomery und Runger ):         Zentrum ( )  Kante ( )  Summe    niedrige Kontamination ( )  514  68  582    hohe Kontamination ( )  112  246  358    Summe  626  314  940    Ein Wafer wird rein zufällig aus diesen 940 gezogen. Bestimmen Sie die Wahrscheinlichkeit, dass seine Kontamination hoch ist oder im Zentrum liegt, mit der Additionsregel. Wie wahrscheinlich ist das Gegenteil, und wo steht diese Zahl in der Tabelle?    Das Ziehen eines rein zufälligen Wafers ist ein Laplace-Experiment mit . Aus der Tabelle: Die Additionsregel ergibt Das Gegenteil ist , niedrige Kontamination an der Kante , mit . Das ist genau die Zelle mit 68 Wafern. Die Probe stimmt.  Wer ohne Korrektur addiert, erhält . Eine Wahrscheinlichkeit größer als 1 ist nie ein Rundungsfehler, sondern immer ein Hinweis auf Doppelzählung.  Die Tabelle und die Idee des Beispiels stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 2 ( ).    Das Beispiel zeigt ein Muster, das Ihnen in der Datenanalyse ständig begegnet. Wer rein zufällig eine Zeile aus einem Datensatz zieht, führt ein Laplace-Experiment über den Zeilen aus. Jeder Anteil, den Sie aus einer Tabelle ablesen, ist dann eine Wahrscheinlichkeit in genau diesem Sinn, und die Rechenregeln gelten für ihn. Über andere Wafer als diese 940 sagen die Anteile dagegen nur etwas, wenn man sie als Schätzung einer unbekannten Wahrscheinlichkeit auffasst. Wie gut eine solche Schätzung ist, beantworten und .    Kombinatorik  Im Laplace-Experiment ist eine Wahrscheinlichkeit ein Quotient zweier Anzahlen. Wer sie berechnen will, muss zählen können, und zwar ohne alle Möglichkeiten aufzuschreiben. Die Werkzeuge dafür kennen Sie im Wesentlichen aus der Schule. Neu ist vielleicht das Zählen von Auswahlen mit Wiederholung; wichtig ist vor allem, im Einzelfall das richtige Werkzeug zu wählen.  Alles beruht auf einem Prinzip, der Produktregel Produktregel der Kombinatorik : Wird eine Auswahl in Schritten getroffen und gibt es im -ten Schritt jeweils Möglichkeiten, gleichgültig, was vorher gewählt wurde, so gibt es insgesamt Möglichkeiten. Das Standardbild ist das Urnenmodell: eine Urne mit unterscheidbaren Kugeln, aus der -mal gezogen wird. Zwei Fragen bestimmen dann die Formel: Wird die gezogene Kugel zurückgelegt (Wiederholung möglich oder nicht)? Und kommt es auf die Reihenfolge an?   Grundformeln der Kombinatorik  Kombinatorik Grundformeln  Permutation  Binomialkoeffizient  Variation  Kombination  Urnenmodell  Ziehen mit Zurücklegen  Ziehen ohne Zurücklegen   Aus unterscheidbaren Objekten werden ausgewählt. Die Anzahl der möglichen Auswahlen ist   mit Reihenfolge, mit Wiederholung: ,    mit Reihenfolge, ohne Wiederholung ( ): ; insbesondere gibt es  Permutationen (Anordnungen) von Objekten,    ohne Reihenfolge, ohne Wiederholung ( ): , der Binomialkoeffizient  über ,    ohne Reihenfolge, mit Wiederholung: .     Außerdem gilt: Liegen Objekte in Sorten vor, mit nicht unterscheidbaren Objekten je Sorte ( ), so gibt es verschiedene Anordnungen.    (1) und (2) sind die Produktregel: Im ersten Zug gibt es Möglichkeiten, im zweiten wieder beziehungsweise nur noch , und so fort.  (3) Jede ungeordnete Auswahl von verschiedenen Objekten lässt sich auf Arten anordnen und entsteht deshalb aus genau geordneten Auswahlen. Man teilt die Anzahl aus (2) durch .  Die Aussage über Sorten folgt ebenso: Von den Anordnungen sehen jeweils gleich aus, nämlich alle, die sich nur durch Vertauschen gleichartiger Objekte unterscheiden.  (4) Eine ungeordnete Auswahl mit Wiederholung ist festgelegt, wenn man weiß, wie oft jedes der Objekte gewählt wurde. Das codiert man als Folge aus Kreuzen und Trennstrichen: Die Kreuze vor dem ersten Strich zählen Objekt 1, die zwischen erstem und zweitem Strich Objekt 2 und so weiter. Für , steht etwa für Objekt 1 zweimal, Objekt 3 einmal . Jede Folge aus Kreuzen und Strichen gehört zu genau einer Auswahl. Nach (3) gibt es solcher Folgen, denn man wählt nur aus, welche der Stellen Kreuze tragen.     Züge aus einer Urne mit unterscheidbaren Kugeln        mit Zurücklegen  ohne Zurücklegen    mit Reihenfolge (Variationen)      ohne Reihenfolge (Kombinationen)       Zwei kurze Anwendungen: Ein Zahlenschloss mit vier Ringen zu je zehn Ziffern hat Einstellungen (mit Reihenfolge, mit Wiederholung). Die Buchstaben des Wortes STATISTIK lassen sich auf Arten anordnen, denn S und I kommen je zweimal, T dreimal vor.   Ungeordnete Ergebnisse sind oft nicht gleich wahrscheinlich  Wirft man zwei Würfel und notiert nur, welche Augenzahlen fielen, ohne Reihenfolge, so gibt es nach (4) Ergebnisse. Diese sind aber nicht gleich wahrscheinlich: zwei Einsen entsteht nur aus , hat also Wahrscheinlichkeit , eine Eins und eine Zwei dagegen aus und , mit . Wer mit die Laplace-Formel anwendet, rechnet falsch. Beim Ziehen mit Zurücklegen gehört deshalb in den Nenner einer Laplace-Wahrscheinlichkeit immer die Anzahl der geordneten Ergebnisse, auch wenn nach der Reihenfolge gar nicht gefragt ist. Formel (4) ist ein Zählwerkzeug, kein Laplace-Raum.    Passwörter und Brute Force   Ein Passwort besteht aus genau acht Zeichen. Erlaubt sind die 26 Klein- und 26 Großbuchstaben sowie die zehn Ziffern.  Wie viele Passwörter gibt es?   Wie viele davon enthalten mindestens eine Ziffer? Mit welcher Wahrscheinlichkeit enthält ein rein zufällig erzeugtes Passwort mindestens eine Ziffer?    Ein Angreifer probiert Passwörter pro Sekunde. Wie lange braucht er höchstens, um alle Passwörter aus (a) durchzuprobieren? Wie lange bei zwölf Zeichen?          Acht Züge mit Reihenfolge und mit Wiederholung aus Zeichen: .    Über das Gegenereignis keine Ziffer : Solche Passwörter verwenden nur die 52 Buchstaben, davon gibt es . Also enthalten Passwörter mindestens eine Ziffer. Die Wahrscheinlichkeit ist .  Naheliegend, aber falsch wäre: Acht Möglichkeiten für die Stelle der Ziffer, zehn für die Ziffer, für den Rest , also . Das ist mehr als die Gesamtzahl aus (a) und damit sicher falsch. Der Fehler: Ein Passwort mit zwei Ziffern wird zweimal gezählt, je einmal für jede Ziffer, die man als die Ziffer auswählen kann. Das Gegenereignis umgeht dieses Problem.     Sekunden, das sind gut sechs Stunden. Bei zwölf Zeichen sind es Sekunden, rund 10 000 Jahre. Jedes zusätzliche Zeichen vervielfacht den Aufwand mit 62; die Pflicht zu einer Ziffer verkleinert die Menge der Passwörter dagegen sogar um ein Viertel. Für die Sicherheit gegen Durchprobieren zählt vor allem die Länge.     Angeregt ist das Beispiel durch eines aus der Vorlesung, das Passwörter mit Pflichtzeichen zählt, nach E. Weitz, Konkrete Mathematik (nicht nur) für Informatiker , 2. Auflage, Springer Spektrum 2021 ( ).     Stichprobenkontrolle   Eine Lieferung enthält 50 Sensoren, von denen, ohne dass der Kunde es weiß, drei defekt sind. Bei der Eingangskontrolle werden Sensoren rein zufällig ausgewählt und geprüft (ohne Zurücklegen).   Wie wahrscheinlich ist es, dass bei kein defekter Sensor gefunden wird?    Wie viele Sensoren müssen mindestens geprüft werden, damit mit einer Wahrscheinlichkeit von mindestens 90 % wenigstens ein defekter gefunden wird?       Es kommt nur darauf an, welche Sensoren geprüft werden, nicht in welcher Reihenfolge. Jede der Stichproben ist gleich wahrscheinlich; es liegt ein Laplace-Experiment vor. Günstig für kein defekter sind die Stichproben, die nur aus den 47 intakten Sensoren stammen.    Mit rund 72 % Wahrscheinlichkeit rutscht die Lieferung unbemerkt durch.    Dasselbe Kürzen wie in (a) gibt für allgemeines  Gesucht ist das kleinste mit . Für ist das Produkt , für ist es . Es müssen also mindestens 27 Sensoren geprüft werden, mehr als die Hälfte der Lieferung.     Eine kleine Stichprobe findet seltene Fehler schlecht. Das ist kein Mangel der Rechnung, sondern ihre wichtigste Aussage. Die Verteilung der Anzahl defekter Sensoren in einer solchen Stichprobe heißt hypergeometrische Verteilung; sie kommt in wieder.     Geburtstagsproblem und Hash-Kollisionen  Geburtstagsproblem      In einem Raum sind Personen. Wie wahrscheinlich ist es, dass mindestens zwei von ihnen am selben Tag Geburtstag haben? Nehmen Sie 365 gleich wahrscheinliche Geburtstage an und werten Sie für aus.    Eine Hashfunktion bildet Datensätze auf mögliche Werte ab, und jeder Datensatz erhält, so die Modellannahme, einen rein zufälligen Wert. Ab wie vielen Datensätzen ist eine Kollision, also zwei Datensätze mit gleichem Hashwert, wahrscheinlicher als keine?          Die Personen sind unterscheidbar, Geburtstage dürfen sich wiederholen: mit , ein Laplace-Experiment. Das Gegenereignis alle Geburtstage verschieden besteht aus den Auswahlen mit Reihenfolge ohne Wiederholung, davon gibt es . Also ist Für ergibt sich . Schon bei 23 Personen ist ein gemeinsamer Geburtstag wahrscheinlicher als keiner ( ).    Dieselbe Rechnung mit statt 365 ergibt . Für großes ist dieses Produkt von Hand nicht mehr auszurechnen, aber gut anzunähern: Für kleines ist , also Das ist gleich , wenn , also etwa bei . Für ergibt das . Zur Kontrolle: Für liefert die Näherung , passend zu (a).     Die Intuition sagt, eine Kollision werde erst nach einem nennenswerten Bruchteil von vier Milliarden Werten wahrscheinlich. Tatsächlich genügen rund 77 000 Datensätze, weil nicht ein bestimmtes Paar kollidieren muss, sondern irgendeines von Paaren. Diese Geburtstagsschranke Geburtstagsschranke  ist der Grund, warum Hashtabellen immer mit Kollisionen umgehen müssen und warum kryptographische Hashfunktionen wie SHA-256 so lange Hashwerte erzeugen: Bei 256 Bit werden Kollisionen erst nach etwa Versuchen wahrscheinlich.  Das Geburtstagsproblem ist ein klassisches Beispiel; die Vorlesung verweist dazu auf Meintrup . Die Anwendung auf Hash-Kollisionen ist für dieses Buch geschrieben.     Wahrscheinlichkeit für mindestens einen gemeinsamen Geburtstag unter Personen.   Kurve der Kollisionswahrscheinlichkeit beim Geburtstagsproblem, die bei 23 Personen die Marke 0,5 überschreitet   Die Kurve steigt von 0 bei einer Person S-förmig an. Bei 23 Personen überschreitet sie 0,5, markiert durch gestrichelte Hilfslinien. Bei etwa 40 Personen liegt sie bei knapp 0,9, ab etwa 57 Personen über 0,99.      Die Zahl 23 überrascht fast jeden. Die folgende Zelle stellt Personen mit zufälligen Geburtstagen viele Male zusammen und vergleicht den Anteil der Räume mit Kollision mit der Formel aus .   import random # Probieren Sie k = 10, 23, 40, 60. k = 23 versuche = 5000 kollisionen = 0 for _ in range(versuche): tage = [random.randint(1, 365) for _ in range(k)] if len(set(tage)) < k: kollisionen += 1 p_keine = 1.0 for i in range(k): p_keine = p_keine * (365 - i) \/ 365 print(\"simuliert: %.4f Formel: %.4f\" % (kollisionen \/ versuche, 1 - p_keine))    Vertiefung: Polynomielle Merkmale   Ein lineares Modell arbeitet mit zehn Merkmalen . Um auch gekrümmte Zusammenhänge abbilden zu können, ergänzt man alle Produkte von zwei Merkmalen, die Quadrate eingeschlossen: .  Wie viele solche Terme vom Grad 2 kommen hinzu?   Wie viele Terme vom Grad 3 entstehen, wenn man mit 100 Merkmalen beginnt?       Ein Term vom Grad wie ist festgelegt, wenn man weiß, welche Merkmale wie oft vorkommen. Die Reihenfolge spielt keine Rolle ( ), Wiederholung ist erlaubt. Es handelt sich also um ungeordnete Auswahlen mit Wiederholung von aus Merkmalen, deren Anzahl ist.    . Probe: zehn Quadrate und gemischte Produkte.   .    Aus 100 Merkmalen werden so mehr als 170 000. Mit so vielen Parametern passt sich ein Modell auch dem Rauschen in den Daten an. Diese kombinatorische Explosion ist ein Grund für Regularisierung, die in eine wahrscheinlichkeitstheoretische Deutung erhält.      Bedingte Wahrscheinlichkeit und Unabhängigkeit  In einer Fertigung werden 400 Teile auf sichtbare Oberflächenschäden ( ) und auf funktionale Defekte ( ) geprüft. Die folgende Vierfeldertafel Vierfeldertafel zeigt das Ergebnis (Zahlen aus Montgomery und Runger ):         Oberfläche beschädigt ( )  Oberfläche in Ordnung ( )  Summe    funktionaler Defekt ( )  10  18  28    Funktion in Ordnung ( )  30  342  372    Summe  40  360  400    Ein rein zufällig gewähltes Teil ist mit Wahrscheinlichkeit funktional defekt. Weiß man aber schon, dass seine Oberfläche beschädigt ist, kommen nur noch die 40 Teile der ersten Spalte in Frage, und von ihnen sind 10 defekt: 25 %. Die Information Oberfläche beschädigt hat die Wahrscheinlichkeit mehr als verdreifacht. Rechnet man den Anteil in Wahrscheinlichkeiten um, so ist er . Die Tafel und die Idee, die bedingte Wahrscheinlichkeit an ihr einzuführen, stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 2 ( ).   Bedingte Wahrscheinlichkeit  bedingte Wahrscheinlichkeit  Wahrscheinlichkeit bedingte   Seien und Ereignisse mit . Die bedingte Wahrscheinlichkeit von unter der Bedingung ist     Die Bedingung wird zum neuen Ergebnisraum: Man betrachtet nur noch die Ergebnisse in und misst, welchen Anteil davon einnimmt. Für festes erfüllt wieder die drei Axiome, ist also selbst ein Wahrscheinlichkeitsmaß. Deshalb gelten alle Rechenregeln auch bedingt, zum Beispiel . Vorsicht bei der Gegenrichtung: hat mit nichts zu tun. In der Tabelle ist , nicht 75 %.  Löst man die Definition nach auf, erhält man die Regel, nach der man in Baumdiagrammen entlang eines Pfades multipliziert. Baumdiagramm    Multiplikationsregel  Multiplikationsregel   Für Ereignisse mit gilt . Allgemeiner gilt für Ereignisse mit      Die erste Formel ist die Definition, mit multipliziert. Für die zweite setzt man die Definition in jeden Faktor rechts ein. Das Produkt teleskopiert: Der Zähler jedes Faktors kürzt sich gegen den Nenner des nächsten, übrig bleibt .    Oft kennt man die Wahrscheinlichkeit eines Ereignisses nur getrennt für mehrere Fälle, die einander ausschließen. Dann setzt man sie zusammen. Eine Zerlegung Zerlegung des Ergebnisraums von ist eine Familie paarweise disjunkter Ereignisse mit : In jedem Ausgang des Experiments tritt genau eines von ihnen ein.   Satz von der totalen Wahrscheinlichkeit  totale Wahrscheinlichkeit  Wahrscheinlichkeit totale  Satz von der totalen Wahrscheinlichkeit   Sei eine Zerlegung von mit für alle . Dann gilt für jedes Ereignis       ist die disjunkte Vereinigung der Mengen . Nach der endlichen Additivität ist , und nach der Multiplikationsregel ist .    Im Baumdiagramm heißt das: Man multipliziert entlang jedes Pfades, der in endet, und addiert über alle diese Pfade.   Timeouts in drei Rechenzentren   Ein Onlinedienst verteilt seine Anfragen auf drei Rechenzentren: 50 % gehen an , 30 % an und 20 % an . Aus den Protokollen ist bekannt, dass in 1 %, in 2 % und im älteren 5 % der Anfragen mit einer Zeitüberschreitung ( ) enden. Wie groß ist der Anteil der Zeitüberschreitungen insgesamt?    Die Ereignisse ( die Anfrage geht an ) bilden eine Zerlegung, gegeben sind , , sowie , , . Nach dem Satz von der totalen Wahrscheinlichkeit ist Insgesamt enden 2,1 % der Anfragen mit einer Zeitüberschreitung. zeigt die Rechnung als Baumdiagramm.     Baumdiagramm zu . Die Pfade, die in enden, werden multipliziert und dann addiert.   Baumdiagramm mit drei Rechenzentren in der ersten Stufe und Timeout ja oder nein in der zweiten Stufe   Von einem Startpunkt gehen drei Äste zu , und mit den Wahrscheinlichkeiten 0,5, 0,3 und 0,2. Von jedem Rechenzentrum gehen zwei Äste zu und . Die Äste zu tragen 0,01, 0,02 und 0,05. An den -Enden stehen die Pfadprodukte 0,005, 0,006 und 0,010, deren Summe 0,021 ist.      Im Beispiel mit den Oberflächenschäden hat die Information über die Wahrscheinlichkeit von verändert. Der entgegengesetzte Fall, in dem das Eintreten eines Ereignisses nichts über ein anderes verrät, hat einen eigenen Namen.   Unabhängigkeit zweier Ereignisse  Unabhängigkeit von Ereignissen   Zwei Ereignisse und heißen (stochastisch) unabhängig , wenn     Ist , so ist das gleichbedeutend mit : Das Wissen, dass eingetreten ist, ändert nichts an der Wahrscheinlichkeit von . Die Produktform ist trotzdem die bessere Definition, weil sie symmetrisch in und ist und auch für Sinn ergibt.   Unabhängigkeit und Gegenereignisse   Sind und unabhängig, so sind es auch und , und sowie und .     . Die beiden anderen Aussagen folgen, indem man dieselbe Rechnung mit vertauschten Rollen wiederholt.     Unabhängigkeit nachrechnen   Ein fairer Würfel wird zweimal geworfen. Sei das Ereignis Der erste Wurf zeigt eine 5 . Ist unabhängig von  : Der zweite Wurf zeigt eine 5 ,  : Die Augensumme ist 7 ,  : Die Augensumme ist 10 ?      Wie in ist das ein Laplace-Experiment mit 36 Paaren, und .    und , also . Unabhängig, wie erwartet.     , also , und mit . Ebenfalls unabhängig.     , also , aber und . Abhängig: Wer weiß, dass die Summe 10 ist, hält eine 5 im ersten Wurf für doppelt so wahrscheinlich wie vorher.     Der Unterschied zwischen (b) und (c) ist der eigentliche Punkt. Bei Summe 7 kann jeder erste Wurf passend ergänzt werden, bei Summe 10 nur die Würfe 4, 5 und 6. Unabhängigkeit sieht man einer Situation nicht an; man rechnet sie nach.     Disjunkt ist nicht unabhängig  Schließen sich und gegenseitig aus und haben beide positive Wahrscheinlichkeit, so ist , aber . Disjunkte Ereignisse sind also gerade nicht unabhängig, sondern im Gegenteil stark abhängig: Wer weiß, dass eingetreten ist, weiß sicher, dass nicht eingetreten ist.   Bei mehr als zwei Ereignissen reicht es nicht, jedes Paar zu prüfen.   Unabhängigkeit mehrerer Ereignisse  Unabhängigkeit mehrerer Ereignisse   Ereignisse heißen unabhängig , wenn für jede Auswahl von mindestens zwei verschiedenen Indizes gilt     Warum jede Auswahl? Wirft man zwei faire Münzen und betrachtet : erste Münze Kopf , : zweite Münze Kopf und : beide Münzen zeigen dasselbe , so hat jedes Ereignis Wahrscheinlichkeit , und jeder paarweise Durchschnitt hat Wahrscheinlichkeit . Die drei sind also paarweise unabhängig. Aber ist zweimal Kopf , mit Wahrscheinlichkeit : Kennt man und , ist festgelegt. In der Praxis wird Unabhängigkeit meist nicht nachgerechnet, sondern als Modellannahme vorausgesetzt: für wiederholte Würfe, für Bauteile, die einander nicht beeinflussen, für Datenpunkte, die getrennt erhoben wurden. Dann gilt die Produktformel für jede Auswahl, und mit derselben Rechnung wie in auch dann, wenn man einige der Ereignisse durch ihre Gegenereignisse ersetzt.   Verfügbarkeit einer Verarbeitungskette   Eine Datenpipeline besteht aus drei Diensten, die nacheinander durchlaufen werden: Einlesen, Transformieren, Speichern. Jeder Dienst ist zu einem zufälligen Zeitpunkt mit Wahrscheinlichkeit verfügbar ( drei Neunen ), und Ausfälle verschiedener Dienste seien unabhängig.   Mit welcher Wahrscheinlichkeit ist die ganze Pipeline verfügbar? Wie viele Stunden Ausfall pro Jahr (8760 Stunden) bedeutet das?    Jeder Dienst wird nun doppelt betrieben, und ein Dienst gilt als verfügbar, wenn mindestens eine seiner beiden Instanzen läuft. Alle sechs Instanzen fallen unabhängig voneinander aus und sind je mit Wahrscheinlichkeit verfügbar. Wie verfügbar ist die Pipeline jetzt?    Welche Annahme macht das Ergebnis aus (b) in der Praxis fragwürdig?          Die Pipeline läuft, wenn alle drei Dienste laufen. Wegen der Unabhängigkeit ist das . Die Wahrscheinlichkeit eines Ausfalls ist , das sind Stunden im Jahr, dreimal so viel wie für einen einzelnen Dienst. Eine Kette ist unzuverlässiger als jedes ihrer Glieder.    Ein doppelt betriebener Dienst fällt nur aus, wenn beide Instanzen ausfallen. Mit dem Gegenereignis und der Unabhängigkeit ist er mit Wahrscheinlichkeit verfügbar, und die Pipeline mit . Das sind im Mittel etwa 1,6 Minuten Ausfall im Jahr statt 26 Stunden.    Die Unabhängigkeit der Ausfälle. Laufen beide Instanzen im selben Rechenzentrum, am selben Stromnetz oder mit demselben fehlerhaften Software-Update, so fallen sie häufig gemeinsam aus. Dann ist viel größer als , und die Rechnung in (b) ist viel zu optimistisch. Redundanz hilft nur so weit, wie die Ausfälle tatsächlich unabhängig sind.         Der Satz von Bayes  Bedingte Wahrscheinlichkeiten haben eine Richtung, und oft kennt man die falsche. Das Kamerasystem aus der Einleitung ist durch beschrieben, gefragt ist . Die Rechenzentren aus sind durch ihre Timeout-Raten beschrieben; wer einen Timeout untersucht, will wissen. Der Satz von Bayes dreht die Bedingung um.   Satz von Bayes  Satz von Bayes  Bayes, Satz von   Für Ereignisse und mit und gilt Ist eine Zerlegung von mit für alle , so gilt für jedes      Nach Definition und Multiplikationsregel ist ; man teilt durch . In der zweiten Form ist der Nenner nach dem Satz von der totalen Wahrscheinlichkeit gerade .    Die Bestandteile haben Namen, die Sie bis zum Ende der Vorlesung begleiten. ist die A-priori-Wahrscheinlichkeit A-priori-Wahrscheinlichkeit (englisch prior ) der Hypothese , also die Einschätzung vor der Beobachtung. ist die Likelihood Likelihood : Wie gut erklärt die Hypothese die Beobachtung ? ist die A-posteriori-Wahrscheinlichkeit A-posteriori-Wahrscheinlichkeit ( posterior ), die Einschätzung nach der Beobachtung. Weil der Nenner für alle derselbe ist, passt der ganze Satz in eine Zeile: Posterior ist proportional zu Likelihood mal Prior.   Woher kommt der Timeout?   In der Situation von meldet ein Nutzer eine Zeitüberschreitung. Mit welcher Wahrscheinlichkeit wurde seine Anfrage in , beziehungsweise bearbeitet?    Den Nenner haben wir schon: . Die Zähler sind die Pfadprodukte aus : Die drei exakten Werte summieren sich zu 1, wie sie sollen. bearbeitet nur ein Fünftel der Anfragen, verursacht aber fast die Hälfte der Zeitüberschreitungen. Die Beobachtung Timeout hat die Wahrscheinlichkeit für von (Prior) auf (Posterior) angehoben. Wer Timeouts debuggt, schaut zuerst dort nach.    Die wichtigste Anwendung des Satzes von Bayes ist die Bewertung von Tests: medizinischen Tests, Prüfsystemen in der Fertigung und jedem Klassifikator, der zwischen zwei Klassen entscheidet. Dafür gibt es feste Begriffe.   Kenngrößen eines Tests  Sensitivität  Spezifität  Prävalenz  Basisrate  Vorhersagewert   Ein Test soll erkennen, ob ein Zustand vorliegt (krank, fehlerhaft, Spam, Betrug). Sei das Ereignis, dass der Test positiv ausfällt. Dann heißen  die Prävalenz oder Basisrate ,  die Sensitivität ,  die Spezifität ,  der positive Vorhersagewert ,  der negative Vorhersagewert .      Sensitivität und Spezifität beschreiben den Test selbst und werden im Labor oder auf einem Testdatensatz ermittelt. Die Vorhersagewerte sind das, was die Anwenderin wissen will, und sie hängen zusätzlich von der Basisrate ab. Im maschinellen Lernen trägt die Sensitivität den Namen Recall Recall und der positive Vorhersagewert den Namen Precision Precision . Geschätzt werden die Größen aus der Konfusionsmatrix Konfusionsmatrix ( ), die auszählt, wie oft welche Kombination aus Zustand und Testergebnis vorkam: Die Sensitivität ist , der positive Vorhersagewert . Vorsicht beim positiven Vorhersagewert: Er überträgt sich nur dann auf den Einsatz, wenn der Testdatensatz dieselbe Basisrate hat wie die Daten, auf die der Test später trifft. Eine Precision, die auf einem Datensatz mit halb Spam, halb erwünschten Mails gemessen wurde, sagt wenig über ein Postfach mit 5 % Spam.   Konfusionsmatrix eines Tests        Test positiv ( )  Test negativ ( )    Zustand liegt vor ( )  richtig positiv (RP)  falsch negativ (FN)    Zustand liegt nicht vor ( )  falsch positiv (FP)  richtig negativ (RN)      Automatische Prüfung von Lötstellen   Ein Kamerasystem prüft Lötstellen. Es hat eine Sensitivität von 99 % und eine Spezifität von 99 %. Eine von tausend Lötstellen ist fehlerhaft.   Mit welcher Wahrscheinlichkeit ist eine Lötstelle, bei der das System Alarm schlägt, tatsächlich fehlerhaft?    Rechnen Sie dasselbe mit natürlichen Häufigkeiten, also für 100 000 Lötstellen, nach.    Wie verlässlich ist umgekehrt ein ausbleibender Alarm?       Sei : Lötstelle fehlerhaft und : Alarm . Gegeben sind , und , also .   Mit der Zerlegung liefert der Satz von Bayes Nur gut 9 % der Alarme betreffen tatsächlich fehlerhafte Lötstellen.    Von 100 000 Lötstellen sind 100 fehlerhaft; davon meldet das System 99. Von den 99 900 einwandfreien meldet es 1 % fälschlich, also 999. Insgesamt gibt es Alarme, von denen 99 berechtigt sind: ( ).    Ohne Alarm bleiben Lötstellen, davon ist genau eine fehlerhaft. Der negative Vorhersagewert ist . Auf einen ausbleibenden Alarm ist Verlass.     Der Grund für die 9 % ist die kleine Basisrate. Ein Prozent Fehlalarme ist wenig, aber ein Prozent von fast hunderttausend einwandfreien Lötstellen sind zehnmal so viele Alarme, wie es fehlerhafte Lötstellen überhaupt gibt. Die Fehlalarme verdrängen die echten Treffer. Das ist keine Schwäche des Systems, sondern eine Eigenschaft jedes Tests auf ein seltenes Ereignis. In der Praxis folgt daraus ein zweistufiges Vorgehen: Das Kamerasystem sortiert vor, und nur die gemeldeten Lötstellen werden ein zweites Mal geprüft. Für diese zweite Prüfung ist die Basisrate dann nicht mehr , sondern .     Natürliche Häufigkeiten zu : Von 1098 Alarmen sind 99 berechtigt.   Häufigkeitsbaum: 100000 Lötstellen, davon 100 fehlerhaft und 99900 einwandfrei, aufgeteilt nach Alarm und kein Alarm   Von 100 000 Lötstellen führt ein Ast zu 100 fehlerhaften und einer zu 99 900 einwandfreien. Die 100 fehlerhaften teilen sich in 99 mit Alarm und 1 ohne Alarm. Die 99 900 einwandfreien teilen sich in 999 mit Alarm und 98 901 ohne Alarm. Die beiden Alarm-Enden, 99 und 999, sind hervorgehoben.      Wie stark der positive Vorhersagewert an der Basisrate hängt, zeigt die folgende Simulation. Sie erzeugt 100 000 Lötstellen, lässt das Kamerasystem prüfen und zählt, welcher Anteil der Alarme berechtigt ist.   import random # Probieren Sie basisrate = 0.001, 0.01, 0.1, 0.5. basisrate = 0.001 sensitivitaet, spezifitaet = 0.99, 0.99 zufall = random.random # True heißt fehlerhaft; Alarm mit W. sensitivitaet, sonst 1 - spezifitaet fehlerhaft = [zufall() < basisrate for _ in range(100000)] alarm = [zufall() < (sensitivitaet if f else 1 - spezifitaet) for f in fehlerhaft] alarme = sum(alarm) treffer = sum(1 for f, a in zip(fehlerhaft, alarm) if f and a) print(\"Alarme:\", alarme, \" davon berechtigt:\", treffer) print(\"Anteil berechtigter Alarme: %.3f\" % (treffer \/ alarme))   Oft stützt sich eine Entscheidung auf mehrere Beobachtungen. Dann braucht man eine Annahme darüber, wie diese zusammenhängen. Zwei Ereignisse und heißen bedingt unabhängig Unabhängigkeit bedingte bedingte Unabhängigkeit gegeben , wenn sie bezüglich des Wahrscheinlichkeitsmaßes unabhängig sind, wenn also gilt.   Ein naiver Bayes-Spamfilter  naiver Bayes-Klassifikator  Bayes-Klassifikator naiver   40 % der E-Mails an ein Postfach sind Spam ( ). Das Wort gratis kommt in 20 % der Spam-Mails und in 1 % der übrigen Mails vor, das Wort Meeting in 1 % der Spam-Mails und in 10 % der übrigen. Sei das Ereignis Die Mail enthält gratis und das Ereignis Die Mail enthält Meeting .   Eine Mail enthält gratis . Wie wahrscheinlich ist sie Spam?    Eine Mail enthält beide Wörter. Wie wahrscheinlich ist sie Spam, wenn man annimmt, dass und sowohl gegeben als auch gegeben bedingt unabhängig sind?    Warum heißt ein Filter, der auf dieser Annahme beruht, naiv ?               Wegen der bedingten Unabhängigkeit ist und . Bayes mit der Beobachtung liefert Das zweite Wort spricht gegen Spam und holt die Wahrscheinlichkeit von 93 % auf 57 % zurück.    Weil die Annahme fast nie stimmt: Wörter in Mails hängen auch innerhalb einer Klasse voneinander ab. Wer gratis schreibt, schreibt öfter auch Gewinn . Die Annahme macht das Modell aber rechenbar. Mit tausend Wörtern bräuchte man sonst für jede der Wortkombinationen eigene Wahrscheinlichkeiten; mit ihr genügen je Wort zwei Zahlen, und , die sich aus gekennzeichneten Beispielmails schätzen lassen. Trotz der falschen Annahme trifft der naive Bayes-Klassifikator oft gute Entscheidungen und war lange der Standard in Spamfiltern.       Das letzte Beispiel des Abschnitts zeigt, was passiert, wenn man die Richtung einer bedingten Wahrscheinlichkeit verwechselt. Der Fehler hat einen Namen, Fehlschluss des Anklägers Fehlschluss des Anklägers (englisch prosecutor's fallacy ), und er hat dazu beigetragen, dass eine Frau mehr als drei Jahre unschuldig im Gefängnis saß.   Der Fall Sally Clark   1999 wurde die Britin Sally Clark wegen Mordes an ihren beiden Söhnen verurteilt, die 1996 und 1998 im Alter von elf beziehungsweise acht Wochen plötzlich gestorben waren. Ein zentrales Argument der Anklage kam von dem Kinderarzt Roy Meadow: Für eine Familie wie die der Clarks liege die Wahrscheinlichkeit eines plötzlichen Kindstods bei 1 zu 8543, die zweier solcher Todesfälle also bei , rund 1 zu 73 Millionen.   Welche Annahme steckt im Quadrieren? Ist sie plausibel?    In einigen Zeitungen stand damals, die Wahrscheinlichkeit für Clarks Unschuld sei 1 zu 73 Millionen. Welche bedingte Wahrscheinlichkeit beschreibt die Zahl tatsächlich, und welche hätte das Gericht gebraucht?    Wovon hängt die Wahrscheinlichkeit ab, die das Gericht gebraucht hätte?          Sei das Ereignis, dass das -te Kind am plötzlichen Kindstod stirbt. Quadrieren heißt, und als unabhängig anzunehmen: . Das ist kaum haltbar. Genetische Veranlagung und Lebensumstände teilen Geschwister, und sie beeinflussen das Risiko. Nach einem ersten plötzlichen Kindstod ist ein zweiter in derselben Familie deutlich wahrscheinlicher als in einer beliebigen Familie, also . Die Zahl 1 zu 73 Millionen ist schon deshalb viel zu klein.    Selbst wenn sie stimmte, wäre sie die Wahrscheinlichkeit, dass in einer unschuldigen Familie zwei Kinder plötzlich sterben: . Das Gericht brauchte die umgekehrte bedingte Wahrscheinlichkeit . Beide zu verwechseln ist der Fehlschluss des Anklägers, derselbe Fehler wie die Antwort 99 % in .    Vereinfacht gibt es für zwei plötzliche Todesfälle von Säuglingen in einer Familie zwei Erklärungen, die einander ausschließen: , zweifacher plötzlicher Kindstod, und , zweifacher Mord. Die Beobachtung ist , und nach Definition der bedingten Wahrscheinlichkeit ist Entscheidend ist also nicht, dass klein ist, sondern wie sich zu verhält. Ein zweifacher Mord an Säuglingen durch die eigene Mutter ist ebenfalls äußerst selten. Der Mathematiker Ray Hill hat 2004 aus britischen Daten geschätzt, dass ein zweifacher plötzlicher Kindstod zwischen 4,5- und 9-mal so wahrscheinlich ist wie ein zweifacher Mord. Mit folgt , also ein Wert zwischen und , zwischen 10 % und 18 %. Das beweist keine Unschuld, und Hills Schätzungen sind nicht unumstritten: Der Philosoph Neven Sesardić hält die Wahl der A-priori-Wahrscheinlichkeiten und der Likelihoods für zu günstig für die Angeklagte. Aber jede dieser Rechnungen ist etwas völlig anderes als 1 zu 73 Millionen, und alle vergleichen, wie es der Satz von Bayes verlangt, die beiden Erklärungen miteinander.     Die Royal Statistical Society wies im Oktober 2001 öffentlich auf die falsche Verwendung der Statistik hin. 2003 hob das Berufungsgericht das Urteil auf, in erster Linie, weil entlastende medizinische Befunde zurückgehalten worden waren. Zur Zahl 1 zu 73 Millionen hielt es fest, sie hätte den Geschworenen nie in dieser Form vorgelegt werden dürfen.  Quellen: Royal Statistical Society, Pressemitteilung vom 23. Oktober 2001; Urteil des Court of Appeal, R v Clark [2003] EWCA Crim 1020, Randnummern 172 180; R. Hill, Multiple sudden infant deaths coincidence or beyond coincidence? , Paediatric and Perinatal Epidemiology 18 (2004), 320 326; N. Sesardić, Sudden Infant Death or Murder? A Royal Confusion About Probabilities , British Journal for the Philosophy of Science 58 (2007), 299 329. Im Literaturverzeichnis: , , , .     Die wahrscheinlichste Erklärung  Maximum-a-posteriori-Schätzung  Oft interessiert nicht die A-posteriori-Wahrscheinlichkeit einer bestimmten Hypothese, sondern die Hypothese, deren A-posteriori-Wahrscheinlichkeit am größten ist. Beim Entrauschen eines Fotos ist das gemessene, verrauschte Bild, und gesucht ist unter allen denkbaren unverrauschten Bildern dasjenige mit maximalem . Weil nicht von abhängt, genügt es, zu maximieren. Der erste Faktor misst, wie gut zur Messung passt, der zweite, wie plausibel als Bild ist, etwa weil es aus glatten Flächen statt aus Körnung besteht. Dieses Prinzip heißt Maximum-a-posteriori-Schätzung . Es kehrt in wieder, dann mit Parametern statt Bildern.     Zusammenfassung      Wahrscheinlichkeitsraum. Ein Tripel aus Ergebnisraum , Ereignisraum (einer -Algebra; bei endlichem oder abzählbarem die Potenzmenge) und Wahrscheinlichkeitsmaß . Die Axiome von Kolmogorov: , und für paarweise disjunkte      Rechenregeln.  , , und aus folgt . Fragen nach mindestens einem löst man über das Gegenereignis keiner .     Laplace-Experiment. Sind alle Ergebnisse gleich wahrscheinlich, ist . Das ist eine Modellannahme; beim Ziehen mit Zurücklegen zählt man geordnete Ergebnisse.     Kombinatorik.  aus : mit Reihenfolge (mit Wiederholung) oder (ohne), ohne Reihenfolge (mit Wiederholung) oder (ohne).     Bedingte Wahrscheinlichkeit.  . Daraus die Multiplikationsregel und für eine Zerlegung der Satz von der totalen Wahrscheinlichkeit .     Unabhängigkeit.  und sind unabhängig, wenn . Disjunkte Ereignisse mit positiver Wahrscheinlichkeit sind nicht unabhängig. Bei mehr als zwei Ereignissen muss die Produktformel für jede Auswahl gelten.     Satz von Bayes.  : Posterior ist proportional zu Likelihood mal Prior.     Tests. Sensitivität , Spezifität , positiver Vorhersagewert . Der Vorhersagewert hängt von der Basisrate ab und ist bei seltenem klein. Wer mit verwechselt, begeht den Fehlschluss des Anklägers.       Übungsaufgaben   Zuweisung im A\/B-Test   Ein A\/B-Test weist drei aufeinanderfolgende Besucher einer Website unabhängig voneinander und jeweils mit Wahrscheinlichkeit der Variante A oder der Variante B zu.  Geben Sie den Ergebnisraum an. Wie viele Elemente hat er?   Bestimmen Sie die Wahrscheinlichkeiten der Ereignisse alle drei erhalten dieselbe Variante , mindestens einer erhält B und genau zwei erhalten A .           mit Elementen. Wegen der Unabhängigkeit hat jedes Ergebnis die Wahrscheinlichkeit ; es liegt ein Laplace-Experiment vor.     Alle gleich  , Wahrscheinlichkeit . Mindestens einer B ist das Gegenereignis von , Wahrscheinlichkeit . Genau zwei A  , Wahrscheinlichkeit .        Eine Schranke ohne Unabhängigkeit   Zeigen Sie mit den Rechenregeln aus , dass für beliebige Ereignisse und  gilt. Wann gilt Gleichheit? Folgern Sie daraus .    Nach der Additionsregel ist , und nach dem ersten Axiom ist . Gleichheit gilt genau dann, wenn , insbesondere also für disjunkte Ereignisse. Für drei Ereignisse wendet man die Ungleichung zweimal an: .  Die Ungleichung heißt boolesche Ungleichung boolesche Ungleichung . Sie ist nützlich, weil sie nichts über Abhängigkeiten voraussetzt: Die Wahrscheinlichkeit, dass irgendeines von mehreren seltenen Ereignissen eintritt, ist höchstens die Summe der Einzelwahrscheinlichkeiten.     Auslosung   In einem Kurs mit 30 Teilnehmenden werden vier Personen für eine Präsentation ausgelost.  Mit welcher Wahrscheinlichkeit sind Sie dabei?   Mit welcher Wahrscheinlichkeit sind Sie und eine bestimmte Kommilitonin beide dabei?    Erklären Sie das Ergebnis aus (a) ohne Binomialkoeffizienten.       Jede der Viergruppen ist gleich wahrscheinlich.   Günstig sind die Gruppen, die Sie und drei der 29 anderen enthalten: .     .    Man denke sich die Auslosung so: Alle 30 Namen werden in eine rein zufällige Reihenfolge gebracht, und die ersten vier sind ausgelost. Ihr Name steht an jeder der 30 Positionen mit derselben Wahrscheinlichkeit , also mit Wahrscheinlichkeit auf einer der ersten vier.        Fehlalarme im Monitoring   Ein Monitoring-System überwacht einen Onlineshop mit 20 Alarmregeln. An einem Tag ohne jede Störung schlägt jede Regel mit Wahrscheinlichkeit 5 % fälschlich an, unabhängig von den anderen.   Mit welcher Wahrscheinlichkeit gibt es an einem störungsfreien Tag mindestens einen Fehlalarm?    Wie klein muss die Fehlalarmwahrscheinlichkeit je Regel sein, damit an einem störungsfreien Tag mit höchstens 10 % Wahrscheinlichkeit ein Fehlalarm auftritt?          Gegenereignis keine Regel schlägt an : wegen der Unabhängigkeit mit Wahrscheinlichkeit . Also . An fast zwei von drei störungsfreien Tagen gibt es einen Fehlalarm.    Gesucht ist , also und . Jede Regel darf nur noch in gut einem halben Prozent der Fälle fälschlich anschlagen.        Ein Schnelltest, zweimal angewandt   Ein Schnelltest hat eine Sensitivität von 80 % und eine Spezifität von 98 %. Er wird in einer Gruppe eingesetzt, in der 5 % die Krankheit haben.   Bestimmen Sie den positiven und den negativen Vorhersagewert.    Wer positiv getestet wird, macht einen zweiten Test derselben Art. Die beiden Testergebnisse seien gegeben und gegeben bedingt unabhängig. Mit welcher Wahrscheinlichkeit ist jemand krank, der zweimal positiv getestet wurde?       Gegeben: , , .        Mit für die beiden positiven Ergebnisse ist und , also Dasselbe ergibt sich, wenn man den Vorhersagewert aus (a) als neue Basisrate für den zweiten Test verwendet: Die A-posteriori-Wahrscheinlichkeit nach dem ersten Test ist die A-priori-Wahrscheinlichkeit für den zweiten.        "
},
{
  "id": "sec-wahrscheinlichkeitsraeume-und-bayes-2",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sec-wahrscheinlichkeitsraeume-und-bayes-2",
  "type": "Lernziele",
  "number": "1.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     zu einem Zufallsexperiment den Ergebnisraum angeben und sprachlich beschriebene Ereignisse als Mengen schreiben und verknüpfen,    die Axiome von Kolmogorov angeben und aus ihnen die Rechenregeln für Gegenereignis, Differenz und Vereinigung herleiten,    Laplace-Wahrscheinlichkeiten mit den Grundformeln der Kombinatorik berechnen und dabei entscheiden, ob Reihenfolge und Wiederholung eine Rolle spielen,    bedingte Wahrscheinlichkeiten aus Vierfeldertafeln und Baumdiagrammen bestimmen und die Unabhängigkeit zweier Ereignisse rechnerisch prüfen,    mit dem Satz von der totalen Wahrscheinlichkeit und dem Satz von Bayes von auf schließen,    aus Sensitivität, Spezifität und Basisrate eines Tests oder Klassifikators den positiven Vorhersagewert berechnen und erklären, warum er bei seltenen Ereignissen klein ist,    den Fehlschluss erkennen, mit zu verwechseln.    "
},
{
  "id": "sub-wahrscheinlichkeitsraum-2",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-wahrscheinlichkeitsraum-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "frequentistischen bayesschen "
},
{
  "id": "def-ergebnisraum",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-ergebnisraum",
  "type": "Definition",
  "number": "1.1.1",
  "title": "Ergebnis, Ergebnisraum.",
  "body": " Ergebnis, Ergebnisraum  Ergebnisraum  Ergebnis  Elementarereignis  Zufallsexperiment   Ein Zufallsexperiment ist ein Vorgang, dessen Ausgang sich nicht vorhersagen lässt. Jeder mögliche Ausgang heißt Ergebnis oder Elementarereignis und wird meist mit bezeichnet. Die Menge aller möglichen Ergebnisse heißt Ergebnisraum .   "
},
{
  "id": "def-ereignis",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-ereignis",
  "type": "Definition",
  "number": "1.1.2",
  "title": "Ereignis.",
  "body": " Ereignis  Ereignis   Ein Ereignis ist eine Teilmenge . Das Ereignis  tritt ein , wenn das Ergebnis des Zufallsexperiments in liegt.   "
},
{
  "id": "tab-ereignisse-mengen",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#tab-ereignisse-mengen",
  "type": "Tabelle",
  "number": "1.1.3",
  "title": "Ereignisse in Worten und als Mengen",
  "body": " Ereignisse in Worten und als Mengen      In Worten  Als Menge    oder tritt ein (mindestens eines von beiden)     und treten ein     tritt nicht ein (Gegenereignis)     tritt ein, aber nicht     und schließen einander aus  ( , disjunkt)    Wenn eintritt, tritt auch ein     sicheres Ereignis, unmögliches Ereignis  ,    "
},
{
  "id": "sub-wahrscheinlichkeitsraum-11",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-wahrscheinlichkeitsraum-11",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Potenzmenge "
},
{
  "id": "def-sigma-algebra",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-sigma-algebra",
  "type": "Definition",
  "number": "1.1.4",
  "title": "<span class=\"process-math\">\\(\\sigma\\)<\/span>-Algebra, Ereignisraum.",
  "body": " -Algebra, Ereignisraum  -Algebra  Ereignisraum   Ein System von Teilmengen von heißt -Algebra , wenn gilt:  ,  aus folgt ,   aus folgt .     Ein Ereignisraum zum Ergebnisraum ist eine -Algebra über ; ihre Elemente heißen Ereignisse .   "
},
{
  "id": "sub-wahrscheinlichkeitsraum-15",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-wahrscheinlichkeitsraum-15",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Borel- -Algebra "
},
{
  "id": "def-wahrscheinlichkeitsraum",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-wahrscheinlichkeitsraum",
  "type": "Definition",
  "number": "1.1.5",
  "title": "Wahrscheinlichkeitsmaß, Wahrscheinlichkeitsraum.",
  "body": " Wahrscheinlichkeitsmaß, Wahrscheinlichkeitsraum  Wahrscheinlichkeitsmaß  Wahrscheinlichkeitsraum  Axiome von Kolmogorov  Kolmogorov, Axiome von   Sei ein Ereignisraum über . Eine Abbildung heißt Wahrscheinlichkeitsmaß , wenn sie die drei Axiome von Kolmogorov erfüllt:  für alle ,  ,   für paarweise disjunkte Ereignisse gilt      Das Tripel heißt Wahrscheinlichkeitsraum .   "
},
{
  "id": "sub-wahrscheinlichkeitsraum-17",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-wahrscheinlichkeitsraum-17",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "-Additivität "
},
{
  "id": "thm-diskreter-wahrscheinlichkeitsraum",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-diskreter-wahrscheinlichkeitsraum",
  "type": "Satz",
  "number": "1.1.6",
  "title": "Diskrete Wahrscheinlichkeitsräume.",
  "body": " Diskrete Wahrscheinlichkeitsräume  Wahrscheinlichkeitsraum diskreter   Sei endlich oder abzählbar, und sei eine Funktion mit . Dann ist ein Wahrscheinlichkeitsmaß auf , und es gilt .    Als Summe nichtnegativer Zahlen ist , und weil nur einen Teil der Summanden von enthält, ist . Das zweite Axiom ist die Voraussetzung. Für das dritte: Sind paarweise disjunkt, so kommt jedes der Vereinigung in genau einer der Mengen vor. Eine Summe nichtnegativer Zahlen darf man beliebig umordnen und gruppieren, also ist .   "
},
{
  "id": "def-laplace-experiment",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-laplace-experiment",
  "type": "Definition",
  "number": "1.1.7",
  "title": "Laplace-Experiment.",
  "body": " Laplace-Experiment  Laplace-Experiment   Ist endlich und für alle , so heißt das Zufallsexperiment Laplace-Experiment . Für jedes Ereignis gilt dann Dabei bezeichnet die Anzahl der Elemente von .   "
},
{
  "id": "ex-zweimal-wuerfeln",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-zweimal-wuerfeln",
  "type": "Beispiel",
  "number": "1.1.8",
  "title": "Zweimal würfeln.",
  "body": " Zweimal würfeln   Ein fairer Würfel wird zweimal geworfen. Geben Sie den Wahrscheinlichkeitsraum an und bestimmen Sie die Wahrscheinlichkeiten der Ereignisse  : Die Augensumme ist kleiner als 5 ,  : Die Augensumme ist gerade ,  , in Worten formuliert.      Der Ergebnisraum ist mit , der Ereignisraum ist . Bei einem fairen Würfel ist jedes der Paare gleich wahrscheinlich; es liegt ein Laplace-Experiment vor.  Das Ereignis besteht aus den Paaren mit Augensumme 2, 3 oder 4:   Die Augensumme ist genau dann gerade, wenn beide Augenzahlen gerade oder beide ungerade sind. Dafür gibt es Paare, also .   heißt Die Augensumme ist 2 oder 4 : und .   "
},
{
  "id": "ex-klassifikator-ausgabe",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-klassifikator-ausgabe",
  "type": "Beispiel",
  "number": "1.1.9",
  "title": "Die Ausgabe eines Klassifikators.",
  "body": " Die Ausgabe eines Klassifikators   Ein Bildklassifikator ordnet ein Foto einer von vier Klassen zu und gibt dazu Wahrscheinlichkeiten aus: Katze , Hund , Fuchs , Sonstiges .   Begründen Sie, dass diese Angaben einen Wahrscheinlichkeitsraum definieren.    Mit welcher Wahrscheinlichkeit zeigt das Foto nach Einschätzung des Modells einen Hundeartigen, also Hund oder Fuchs?    Mit welcher Wahrscheinlichkeit zeigt es keine Katze?          Mit sind alle vier Gewichte in und summieren sich zu . Nach definiert ein Wahrscheinlichkeitsmaß auf .     .     . Schneller geht es mit der Komplementregel aus : .     Die sogenannte Softmax-Funktion Softmax-Funktion am Ausgang eines typischen neuronalen Klassifikators ist gerade so gebaut, dass ihre Ausgaben nichtnegativ sind und sich zu 1 summieren. Sie liefert also für jedes Eingabebild einen diskreten Wahrscheinlichkeitsraum über den Klassen. Ob diese Wahrscheinlichkeiten auch stimmen , ob also von allen Fotos, denen das Modell für Katze gibt, wirklich etwa 60 % Katzen zeigen, ist eine andere Frage. Die Axiome garantieren nur, dass man mit den Zahlen widerspruchsfrei rechnen kann.   "
},
{
  "id": "thm-rechenregeln",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-rechenregeln",
  "type": "Satz",
  "number": "1.1.10",
  "title": "Rechenregeln für Wahrscheinlichkeiten.",
  "body": " Rechenregeln für Wahrscheinlichkeiten  Rechenregeln für Wahrscheinlichkeiten  Additionsregel  Gegenereignis   Sei ein Wahrscheinlichkeitsraum und seien . Dann gilt:  .   Endliche Additivität: Für paarweise disjunkte ist .   Gegenereignis: .   Differenz und Monotonie: Aus folgt und damit .    Additionsregel: .       (1) Die Folge ist paarweise disjunkt mit Vereinigung . Das dritte Axiom liefert . Eine Zahl zwischen 0 und 1, die gleich einer unendlichen Summe von Kopien ihrer selbst ist, muss 0 sein.  (2) Man ergänzt und wendet das dritte Axiom und (1) an.  (3) und sind disjunkt mit Vereinigung . Nach (2) und dem zweiten Axiom ist .  (4) Für ist die disjunkte Vereinigung von und , also . Weil ist, folgt .  (5) ist die disjunkte Vereinigung von und . Mit (2) und dann (4), angewandt auf , folgt .   "
},
{
  "id": "fig-additionsregel",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#fig-additionsregel",
  "type": "Abbildung",
  "number": "1.1.11",
  "title": "",
  "body": " Additionsregel: steckt sowohl in als auch in .   Venn-Diagramm zweier sich überlappender Ereignisse A und B im Ergebnisraum Omega   Ein Rechteck steht für den Ergebnisraum . Darin liegen zwei Kreise für die Ereignisse und , die sich teilweise überlappen. Die Überlappung ist grau hervorgehoben und mit beschriftet. Addiert man die Flächen beider Kreise, zählt die graue Fläche doppelt.     "
},
{
  "id": "ex-wafer-kontamination",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-wafer-kontamination",
  "type": "Beispiel",
  "number": "1.1.12",
  "title": "Kontamination von Wafern.",
  "body": " Kontamination von Wafern   In der Halbleiterfertigung wurden für 940 Wafer der Ort und der Grad einer Kontamination erfasst (Zahlen aus Montgomery und Runger ):         Zentrum ( )  Kante ( )  Summe    niedrige Kontamination ( )  514  68  582    hohe Kontamination ( )  112  246  358    Summe  626  314  940    Ein Wafer wird rein zufällig aus diesen 940 gezogen. Bestimmen Sie die Wahrscheinlichkeit, dass seine Kontamination hoch ist oder im Zentrum liegt, mit der Additionsregel. Wie wahrscheinlich ist das Gegenteil, und wo steht diese Zahl in der Tabelle?    Das Ziehen eines rein zufälligen Wafers ist ein Laplace-Experiment mit . Aus der Tabelle: Die Additionsregel ergibt Das Gegenteil ist , niedrige Kontamination an der Kante , mit . Das ist genau die Zelle mit 68 Wafern. Die Probe stimmt.  Wer ohne Korrektur addiert, erhält . Eine Wahrscheinlichkeit größer als 1 ist nie ein Rundungsfehler, sondern immer ein Hinweis auf Doppelzählung.  Die Tabelle und die Idee des Beispiels stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 2 ( ).   "
},
{
  "id": "sub-kombinatorik-3",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-kombinatorik-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Produktregel "
},
{
  "id": "thm-grundformeln-kombinatorik",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-grundformeln-kombinatorik",
  "type": "Satz",
  "number": "1.1.13",
  "title": "Grundformeln der Kombinatorik.",
  "body": " Grundformeln der Kombinatorik  Kombinatorik Grundformeln  Permutation  Binomialkoeffizient  Variation  Kombination  Urnenmodell  Ziehen mit Zurücklegen  Ziehen ohne Zurücklegen   Aus unterscheidbaren Objekten werden ausgewählt. Die Anzahl der möglichen Auswahlen ist   mit Reihenfolge, mit Wiederholung: ,    mit Reihenfolge, ohne Wiederholung ( ): ; insbesondere gibt es  Permutationen (Anordnungen) von Objekten,    ohne Reihenfolge, ohne Wiederholung ( ): , der Binomialkoeffizient  über ,    ohne Reihenfolge, mit Wiederholung: .     Außerdem gilt: Liegen Objekte in Sorten vor, mit nicht unterscheidbaren Objekten je Sorte ( ), so gibt es verschiedene Anordnungen.    (1) und (2) sind die Produktregel: Im ersten Zug gibt es Möglichkeiten, im zweiten wieder beziehungsweise nur noch , und so fort.  (3) Jede ungeordnete Auswahl von verschiedenen Objekten lässt sich auf Arten anordnen und entsteht deshalb aus genau geordneten Auswahlen. Man teilt die Anzahl aus (2) durch .  Die Aussage über Sorten folgt ebenso: Von den Anordnungen sehen jeweils gleich aus, nämlich alle, die sich nur durch Vertauschen gleichartiger Objekte unterscheiden.  (4) Eine ungeordnete Auswahl mit Wiederholung ist festgelegt, wenn man weiß, wie oft jedes der Objekte gewählt wurde. Das codiert man als Folge aus Kreuzen und Trennstrichen: Die Kreuze vor dem ersten Strich zählen Objekt 1, die zwischen erstem und zweitem Strich Objekt 2 und so weiter. Für , steht etwa für Objekt 1 zweimal, Objekt 3 einmal . Jede Folge aus Kreuzen und Strichen gehört zu genau einer Auswahl. Nach (3) gibt es solcher Folgen, denn man wählt nur aus, welche der Stellen Kreuze tragen.   "
},
{
  "id": "tab-urnenmodell",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#tab-urnenmodell",
  "type": "Tabelle",
  "number": "1.1.14",
  "title": "<span class=\"process-math\">\\(k\\)<\/span> Züge aus einer Urne mit <span class=\"process-math\">\\(n\\)<\/span> unterscheidbaren Kugeln",
  "body": " Züge aus einer Urne mit unterscheidbaren Kugeln        mit Zurücklegen  ohne Zurücklegen    mit Reihenfolge (Variationen)      ohne Reihenfolge (Kombinationen)      "
},
{
  "id": "rem-laplace-ungeordnet",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#rem-laplace-ungeordnet",
  "type": "Bemerkung",
  "number": "1.1.15",
  "title": "Ungeordnete Ergebnisse sind oft nicht gleich wahrscheinlich.",
  "body": " Ungeordnete Ergebnisse sind oft nicht gleich wahrscheinlich  Wirft man zwei Würfel und notiert nur, welche Augenzahlen fielen, ohne Reihenfolge, so gibt es nach (4) Ergebnisse. Diese sind aber nicht gleich wahrscheinlich: zwei Einsen entsteht nur aus , hat also Wahrscheinlichkeit , eine Eins und eine Zwei dagegen aus und , mit . Wer mit die Laplace-Formel anwendet, rechnet falsch. Beim Ziehen mit Zurücklegen gehört deshalb in den Nenner einer Laplace-Wahrscheinlichkeit immer die Anzahl der geordneten Ergebnisse, auch wenn nach der Reihenfolge gar nicht gefragt ist. Formel (4) ist ein Zählwerkzeug, kein Laplace-Raum.  "
},
{
  "id": "ex-passwoerter",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-passwoerter",
  "type": "Beispiel",
  "number": "1.1.16",
  "title": "Passwörter und Brute Force.",
  "body": " Passwörter und Brute Force   Ein Passwort besteht aus genau acht Zeichen. Erlaubt sind die 26 Klein- und 26 Großbuchstaben sowie die zehn Ziffern.  Wie viele Passwörter gibt es?   Wie viele davon enthalten mindestens eine Ziffer? Mit welcher Wahrscheinlichkeit enthält ein rein zufällig erzeugtes Passwort mindestens eine Ziffer?    Ein Angreifer probiert Passwörter pro Sekunde. Wie lange braucht er höchstens, um alle Passwörter aus (a) durchzuprobieren? Wie lange bei zwölf Zeichen?          Acht Züge mit Reihenfolge und mit Wiederholung aus Zeichen: .    Über das Gegenereignis keine Ziffer : Solche Passwörter verwenden nur die 52 Buchstaben, davon gibt es . Also enthalten Passwörter mindestens eine Ziffer. Die Wahrscheinlichkeit ist .  Naheliegend, aber falsch wäre: Acht Möglichkeiten für die Stelle der Ziffer, zehn für die Ziffer, für den Rest , also . Das ist mehr als die Gesamtzahl aus (a) und damit sicher falsch. Der Fehler: Ein Passwort mit zwei Ziffern wird zweimal gezählt, je einmal für jede Ziffer, die man als die Ziffer auswählen kann. Das Gegenereignis umgeht dieses Problem.     Sekunden, das sind gut sechs Stunden. Bei zwölf Zeichen sind es Sekunden, rund 10 000 Jahre. Jedes zusätzliche Zeichen vervielfacht den Aufwand mit 62; die Pflicht zu einer Ziffer verkleinert die Menge der Passwörter dagegen sogar um ein Viertel. Für die Sicherheit gegen Durchprobieren zählt vor allem die Länge.     Angeregt ist das Beispiel durch eines aus der Vorlesung, das Passwörter mit Pflichtzeichen zählt, nach E. Weitz, Konkrete Mathematik (nicht nur) für Informatiker , 2. Auflage, Springer Spektrum 2021 ( ).   "
},
{
  "id": "ex-stichprobenkontrolle",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-stichprobenkontrolle",
  "type": "Beispiel",
  "number": "1.1.17",
  "title": "Stichprobenkontrolle.",
  "body": " Stichprobenkontrolle   Eine Lieferung enthält 50 Sensoren, von denen, ohne dass der Kunde es weiß, drei defekt sind. Bei der Eingangskontrolle werden Sensoren rein zufällig ausgewählt und geprüft (ohne Zurücklegen).   Wie wahrscheinlich ist es, dass bei kein defekter Sensor gefunden wird?    Wie viele Sensoren müssen mindestens geprüft werden, damit mit einer Wahrscheinlichkeit von mindestens 90 % wenigstens ein defekter gefunden wird?       Es kommt nur darauf an, welche Sensoren geprüft werden, nicht in welcher Reihenfolge. Jede der Stichproben ist gleich wahrscheinlich; es liegt ein Laplace-Experiment vor. Günstig für kein defekter sind die Stichproben, die nur aus den 47 intakten Sensoren stammen.    Mit rund 72 % Wahrscheinlichkeit rutscht die Lieferung unbemerkt durch.    Dasselbe Kürzen wie in (a) gibt für allgemeines  Gesucht ist das kleinste mit . Für ist das Produkt , für ist es . Es müssen also mindestens 27 Sensoren geprüft werden, mehr als die Hälfte der Lieferung.     Eine kleine Stichprobe findet seltene Fehler schlecht. Das ist kein Mangel der Rechnung, sondern ihre wichtigste Aussage. Die Verteilung der Anzahl defekter Sensoren in einer solchen Stichprobe heißt hypergeometrische Verteilung; sie kommt in wieder.   "
},
{
  "id": "ex-geburtstag-hash",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-geburtstag-hash",
  "type": "Beispiel",
  "number": "1.1.18",
  "title": "Geburtstagsproblem und Hash-Kollisionen.",
  "body": " Geburtstagsproblem und Hash-Kollisionen  Geburtstagsproblem      In einem Raum sind Personen. Wie wahrscheinlich ist es, dass mindestens zwei von ihnen am selben Tag Geburtstag haben? Nehmen Sie 365 gleich wahrscheinliche Geburtstage an und werten Sie für aus.    Eine Hashfunktion bildet Datensätze auf mögliche Werte ab, und jeder Datensatz erhält, so die Modellannahme, einen rein zufälligen Wert. Ab wie vielen Datensätzen ist eine Kollision, also zwei Datensätze mit gleichem Hashwert, wahrscheinlicher als keine?          Die Personen sind unterscheidbar, Geburtstage dürfen sich wiederholen: mit , ein Laplace-Experiment. Das Gegenereignis alle Geburtstage verschieden besteht aus den Auswahlen mit Reihenfolge ohne Wiederholung, davon gibt es . Also ist Für ergibt sich . Schon bei 23 Personen ist ein gemeinsamer Geburtstag wahrscheinlicher als keiner ( ).    Dieselbe Rechnung mit statt 365 ergibt . Für großes ist dieses Produkt von Hand nicht mehr auszurechnen, aber gut anzunähern: Für kleines ist , also Das ist gleich , wenn , also etwa bei . Für ergibt das . Zur Kontrolle: Für liefert die Näherung , passend zu (a).     Die Intuition sagt, eine Kollision werde erst nach einem nennenswerten Bruchteil von vier Milliarden Werten wahrscheinlich. Tatsächlich genügen rund 77 000 Datensätze, weil nicht ein bestimmtes Paar kollidieren muss, sondern irgendeines von Paaren. Diese Geburtstagsschranke Geburtstagsschranke  ist der Grund, warum Hashtabellen immer mit Kollisionen umgehen müssen und warum kryptographische Hashfunktionen wie SHA-256 so lange Hashwerte erzeugen: Bei 256 Bit werden Kollisionen erst nach etwa Versuchen wahrscheinlich.  Das Geburtstagsproblem ist ein klassisches Beispiel; die Vorlesung verweist dazu auf Meintrup . Die Anwendung auf Hash-Kollisionen ist für dieses Buch geschrieben.   "
},
{
  "id": "fig-geburtstagsproblem",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#fig-geburtstagsproblem",
  "type": "Abbildung",
  "number": "1.1.19",
  "title": "",
  "body": " Wahrscheinlichkeit für mindestens einen gemeinsamen Geburtstag unter Personen.   Kurve der Kollisionswahrscheinlichkeit beim Geburtstagsproblem, die bei 23 Personen die Marke 0,5 überschreitet   Die Kurve steigt von 0 bei einer Person S-förmig an. Bei 23 Personen überschreitet sie 0,5, markiert durch gestrichelte Hilfslinien. Bei etwa 40 Personen liegt sie bei knapp 0,9, ab etwa 57 Personen über 0,99.     "
},
{
  "id": "ex-polynomielle-merkmale",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-polynomielle-merkmale",
  "type": "Beispiel",
  "number": "1.1.20",
  "title": "Vertiefung: Polynomielle Merkmale.",
  "body": " Vertiefung: Polynomielle Merkmale   Ein lineares Modell arbeitet mit zehn Merkmalen . Um auch gekrümmte Zusammenhänge abbilden zu können, ergänzt man alle Produkte von zwei Merkmalen, die Quadrate eingeschlossen: .  Wie viele solche Terme vom Grad 2 kommen hinzu?   Wie viele Terme vom Grad 3 entstehen, wenn man mit 100 Merkmalen beginnt?       Ein Term vom Grad wie ist festgelegt, wenn man weiß, welche Merkmale wie oft vorkommen. Die Reihenfolge spielt keine Rolle ( ), Wiederholung ist erlaubt. Es handelt sich also um ungeordnete Auswahlen mit Wiederholung von aus Merkmalen, deren Anzahl ist.    . Probe: zehn Quadrate und gemischte Produkte.   .    Aus 100 Merkmalen werden so mehr als 170 000. Mit so vielen Parametern passt sich ein Modell auch dem Rauschen in den Daten an. Diese kombinatorische Explosion ist ein Grund für Regularisierung, die in eine wahrscheinlichkeitstheoretische Deutung erhält.   "
},
{
  "id": "sub-bedingte-wahrscheinlichkeit-2",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-bedingte-wahrscheinlichkeit-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Vierfeldertafel "
},
{
  "id": "def-bedingte-wahrscheinlichkeit",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-bedingte-wahrscheinlichkeit",
  "type": "Definition",
  "number": "1.1.21",
  "title": "Bedingte Wahrscheinlichkeit.",
  "body": " Bedingte Wahrscheinlichkeit  bedingte Wahrscheinlichkeit  Wahrscheinlichkeit bedingte   Seien und Ereignisse mit . Die bedingte Wahrscheinlichkeit von unter der Bedingung ist    "
},
{
  "id": "thm-multiplikationsregel",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-multiplikationsregel",
  "type": "Satz",
  "number": "1.1.22",
  "title": "Multiplikationsregel.",
  "body": " Multiplikationsregel  Multiplikationsregel   Für Ereignisse mit gilt . Allgemeiner gilt für Ereignisse mit      Die erste Formel ist die Definition, mit multipliziert. Für die zweite setzt man die Definition in jeden Faktor rechts ein. Das Produkt teleskopiert: Der Zähler jedes Faktors kürzt sich gegen den Nenner des nächsten, übrig bleibt .   "
},
{
  "id": "sub-bedingte-wahrscheinlichkeit-9",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-bedingte-wahrscheinlichkeit-9",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Zerlegung "
},
{
  "id": "thm-totale-wahrscheinlichkeit",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-totale-wahrscheinlichkeit",
  "type": "Satz",
  "number": "1.1.23",
  "title": "Satz von der totalen Wahrscheinlichkeit.",
  "body": " Satz von der totalen Wahrscheinlichkeit  totale Wahrscheinlichkeit  Wahrscheinlichkeit totale  Satz von der totalen Wahrscheinlichkeit   Sei eine Zerlegung von mit für alle . Dann gilt für jedes Ereignis       ist die disjunkte Vereinigung der Mengen . Nach der endlichen Additivität ist , und nach der Multiplikationsregel ist .   "
},
{
  "id": "ex-cloud-timeouts",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-cloud-timeouts",
  "type": "Beispiel",
  "number": "1.1.24",
  "title": "Timeouts in drei Rechenzentren.",
  "body": " Timeouts in drei Rechenzentren   Ein Onlinedienst verteilt seine Anfragen auf drei Rechenzentren: 50 % gehen an , 30 % an und 20 % an . Aus den Protokollen ist bekannt, dass in 1 %, in 2 % und im älteren 5 % der Anfragen mit einer Zeitüberschreitung ( ) enden. Wie groß ist der Anteil der Zeitüberschreitungen insgesamt?    Die Ereignisse ( die Anfrage geht an ) bilden eine Zerlegung, gegeben sind , , sowie , , . Nach dem Satz von der totalen Wahrscheinlichkeit ist Insgesamt enden 2,1 % der Anfragen mit einer Zeitüberschreitung. zeigt die Rechnung als Baumdiagramm.   "
},
{
  "id": "fig-baum-timeouts",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#fig-baum-timeouts",
  "type": "Abbildung",
  "number": "1.1.25",
  "title": "",
  "body": " Baumdiagramm zu . Die Pfade, die in enden, werden multipliziert und dann addiert.   Baumdiagramm mit drei Rechenzentren in der ersten Stufe und Timeout ja oder nein in der zweiten Stufe   Von einem Startpunkt gehen drei Äste zu , und mit den Wahrscheinlichkeiten 0,5, 0,3 und 0,2. Von jedem Rechenzentrum gehen zwei Äste zu und . Die Äste zu tragen 0,01, 0,02 und 0,05. An den -Enden stehen die Pfadprodukte 0,005, 0,006 und 0,010, deren Summe 0,021 ist.     "
},
{
  "id": "def-unabhaengigkeit",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-unabhaengigkeit",
  "type": "Definition",
  "number": "1.1.26",
  "title": "Unabhängigkeit zweier Ereignisse.",
  "body": " Unabhängigkeit zweier Ereignisse  Unabhängigkeit von Ereignissen   Zwei Ereignisse und heißen (stochastisch) unabhängig , wenn    "
},
{
  "id": "thm-unabhaengigkeit-komplement",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-unabhaengigkeit-komplement",
  "type": "Satz",
  "number": "1.1.27",
  "title": "Unabhängigkeit und Gegenereignisse.",
  "body": " Unabhängigkeit und Gegenereignisse   Sind und unabhängig, so sind es auch und , und sowie und .     . Die beiden anderen Aussagen folgen, indem man dieselbe Rechnung mit vertauschten Rollen wiederholt.   "
},
{
  "id": "ex-wuerfel-unabhaengigkeit",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-wuerfel-unabhaengigkeit",
  "type": "Beispiel",
  "number": "1.1.28",
  "title": "Unabhängigkeit nachrechnen.",
  "body": " Unabhängigkeit nachrechnen   Ein fairer Würfel wird zweimal geworfen. Sei das Ereignis Der erste Wurf zeigt eine 5 . Ist unabhängig von  : Der zweite Wurf zeigt eine 5 ,  : Die Augensumme ist 7 ,  : Die Augensumme ist 10 ?      Wie in ist das ein Laplace-Experiment mit 36 Paaren, und .    und , also . Unabhängig, wie erwartet.     , also , und mit . Ebenfalls unabhängig.     , also , aber und . Abhängig: Wer weiß, dass die Summe 10 ist, hält eine 5 im ersten Wurf für doppelt so wahrscheinlich wie vorher.     Der Unterschied zwischen (b) und (c) ist der eigentliche Punkt. Bei Summe 7 kann jeder erste Wurf passend ergänzt werden, bei Summe 10 nur die Würfe 4, 5 und 6. Unabhängigkeit sieht man einer Situation nicht an; man rechnet sie nach.   "
},
{
  "id": "rem-disjunkt-nicht-unabhaengig",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#rem-disjunkt-nicht-unabhaengig",
  "type": "Warnung",
  "number": "1.1.29",
  "title": "Disjunkt ist nicht unabhängig.",
  "body": " Disjunkt ist nicht unabhängig  Schließen sich und gegenseitig aus und haben beide positive Wahrscheinlichkeit, so ist , aber . Disjunkte Ereignisse sind also gerade nicht unabhängig, sondern im Gegenteil stark abhängig: Wer weiß, dass eingetreten ist, weiß sicher, dass nicht eingetreten ist.  "
},
{
  "id": "def-unabhaengigkeit-mehrerer",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-unabhaengigkeit-mehrerer",
  "type": "Definition",
  "number": "1.1.30",
  "title": "Unabhängigkeit mehrerer Ereignisse.",
  "body": " Unabhängigkeit mehrerer Ereignisse  Unabhängigkeit mehrerer Ereignisse   Ereignisse heißen unabhängig , wenn für jede Auswahl von mindestens zwei verschiedenen Indizes gilt    "
},
{
  "id": "ex-verfuegbarkeit",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-verfuegbarkeit",
  "type": "Beispiel",
  "number": "1.1.31",
  "title": "Verfügbarkeit einer Verarbeitungskette.",
  "body": " Verfügbarkeit einer Verarbeitungskette   Eine Datenpipeline besteht aus drei Diensten, die nacheinander durchlaufen werden: Einlesen, Transformieren, Speichern. Jeder Dienst ist zu einem zufälligen Zeitpunkt mit Wahrscheinlichkeit verfügbar ( drei Neunen ), und Ausfälle verschiedener Dienste seien unabhängig.   Mit welcher Wahrscheinlichkeit ist die ganze Pipeline verfügbar? Wie viele Stunden Ausfall pro Jahr (8760 Stunden) bedeutet das?    Jeder Dienst wird nun doppelt betrieben, und ein Dienst gilt als verfügbar, wenn mindestens eine seiner beiden Instanzen läuft. Alle sechs Instanzen fallen unabhängig voneinander aus und sind je mit Wahrscheinlichkeit verfügbar. Wie verfügbar ist die Pipeline jetzt?    Welche Annahme macht das Ergebnis aus (b) in der Praxis fragwürdig?          Die Pipeline läuft, wenn alle drei Dienste laufen. Wegen der Unabhängigkeit ist das . Die Wahrscheinlichkeit eines Ausfalls ist , das sind Stunden im Jahr, dreimal so viel wie für einen einzelnen Dienst. Eine Kette ist unzuverlässiger als jedes ihrer Glieder.    Ein doppelt betriebener Dienst fällt nur aus, wenn beide Instanzen ausfallen. Mit dem Gegenereignis und der Unabhängigkeit ist er mit Wahrscheinlichkeit verfügbar, und die Pipeline mit . Das sind im Mittel etwa 1,6 Minuten Ausfall im Jahr statt 26 Stunden.    Die Unabhängigkeit der Ausfälle. Laufen beide Instanzen im selben Rechenzentrum, am selben Stromnetz oder mit demselben fehlerhaften Software-Update, so fallen sie häufig gemeinsam aus. Dann ist viel größer als , und die Rechnung in (b) ist viel zu optimistisch. Redundanz hilft nur so weit, wie die Ausfälle tatsächlich unabhängig sind.      "
},
{
  "id": "thm-satz-von-bayes",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#thm-satz-von-bayes",
  "type": "Satz",
  "number": "1.1.32",
  "title": "Satz von Bayes.",
  "body": " Satz von Bayes  Satz von Bayes  Bayes, Satz von   Für Ereignisse und mit und gilt Ist eine Zerlegung von mit für alle , so gilt für jedes      Nach Definition und Multiplikationsregel ist ; man teilt durch . In der zweiten Form ist der Nenner nach dem Satz von der totalen Wahrscheinlichkeit gerade .   "
},
{
  "id": "sub-satz-von-bayes-4",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-satz-von-bayes-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "A-priori-Wahrscheinlichkeit Likelihood A-posteriori-Wahrscheinlichkeit "
},
{
  "id": "ex-cloud-timeouts-bayes",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-cloud-timeouts-bayes",
  "type": "Beispiel",
  "number": "1.1.33",
  "title": "Woher kommt der Timeout?",
  "body": " Woher kommt der Timeout?   In der Situation von meldet ein Nutzer eine Zeitüberschreitung. Mit welcher Wahrscheinlichkeit wurde seine Anfrage in , beziehungsweise bearbeitet?    Den Nenner haben wir schon: . Die Zähler sind die Pfadprodukte aus : Die drei exakten Werte summieren sich zu 1, wie sie sollen. bearbeitet nur ein Fünftel der Anfragen, verursacht aber fast die Hälfte der Zeitüberschreitungen. Die Beobachtung Timeout hat die Wahrscheinlichkeit für von (Prior) auf (Posterior) angehoben. Wer Timeouts debuggt, schaut zuerst dort nach.   "
},
{
  "id": "def-testguete",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#def-testguete",
  "type": "Definition",
  "number": "1.1.34",
  "title": "Kenngrößen eines Tests.",
  "body": " Kenngrößen eines Tests  Sensitivität  Spezifität  Prävalenz  Basisrate  Vorhersagewert   Ein Test soll erkennen, ob ein Zustand vorliegt (krank, fehlerhaft, Spam, Betrug). Sei das Ereignis, dass der Test positiv ausfällt. Dann heißen  die Prävalenz oder Basisrate ,  die Sensitivität ,  die Spezifität ,  der positive Vorhersagewert ,  der negative Vorhersagewert .     "
},
{
  "id": "sub-satz-von-bayes-8",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-satz-von-bayes-8",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Recall Precision Konfusionsmatrix "
},
{
  "id": "tab-konfusionsmatrix",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#tab-konfusionsmatrix",
  "type": "Tabelle",
  "number": "1.1.35",
  "title": "Konfusionsmatrix eines Tests",
  "body": " Konfusionsmatrix eines Tests        Test positiv ( )  Test negativ ( )    Zustand liegt vor ( )  richtig positiv (RP)  falsch negativ (FN)    Zustand liegt nicht vor ( )  falsch positiv (FP)  richtig negativ (RN)    "
},
{
  "id": "ex-loetstellen",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-loetstellen",
  "type": "Beispiel",
  "number": "1.1.36",
  "title": "Automatische Prüfung von Lötstellen.",
  "body": " Automatische Prüfung von Lötstellen   Ein Kamerasystem prüft Lötstellen. Es hat eine Sensitivität von 99 % und eine Spezifität von 99 %. Eine von tausend Lötstellen ist fehlerhaft.   Mit welcher Wahrscheinlichkeit ist eine Lötstelle, bei der das System Alarm schlägt, tatsächlich fehlerhaft?    Rechnen Sie dasselbe mit natürlichen Häufigkeiten, also für 100 000 Lötstellen, nach.    Wie verlässlich ist umgekehrt ein ausbleibender Alarm?       Sei : Lötstelle fehlerhaft und : Alarm . Gegeben sind , und , also .   Mit der Zerlegung liefert der Satz von Bayes Nur gut 9 % der Alarme betreffen tatsächlich fehlerhafte Lötstellen.    Von 100 000 Lötstellen sind 100 fehlerhaft; davon meldet das System 99. Von den 99 900 einwandfreien meldet es 1 % fälschlich, also 999. Insgesamt gibt es Alarme, von denen 99 berechtigt sind: ( ).    Ohne Alarm bleiben Lötstellen, davon ist genau eine fehlerhaft. Der negative Vorhersagewert ist . Auf einen ausbleibenden Alarm ist Verlass.     Der Grund für die 9 % ist die kleine Basisrate. Ein Prozent Fehlalarme ist wenig, aber ein Prozent von fast hunderttausend einwandfreien Lötstellen sind zehnmal so viele Alarme, wie es fehlerhafte Lötstellen überhaupt gibt. Die Fehlalarme verdrängen die echten Treffer. Das ist keine Schwäche des Systems, sondern eine Eigenschaft jedes Tests auf ein seltenes Ereignis. In der Praxis folgt daraus ein zweistufiges Vorgehen: Das Kamerasystem sortiert vor, und nur die gemeldeten Lötstellen werden ein zweites Mal geprüft. Für diese zweite Prüfung ist die Basisrate dann nicht mehr , sondern .   "
},
{
  "id": "fig-natuerliche-haeufigkeiten",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#fig-natuerliche-haeufigkeiten",
  "type": "Abbildung",
  "number": "1.1.37",
  "title": "",
  "body": " Natürliche Häufigkeiten zu : Von 1098 Alarmen sind 99 berechtigt.   Häufigkeitsbaum: 100000 Lötstellen, davon 100 fehlerhaft und 99900 einwandfrei, aufgeteilt nach Alarm und kein Alarm   Von 100 000 Lötstellen führt ein Ast zu 100 fehlerhaften und einer zu 99 900 einwandfreien. Die 100 fehlerhaften teilen sich in 99 mit Alarm und 1 ohne Alarm. Die 99 900 einwandfreien teilen sich in 999 mit Alarm und 98 901 ohne Alarm. Die beiden Alarm-Enden, 99 und 999, sind hervorgehoben.     "
},
{
  "id": "sub-satz-von-bayes-14",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-satz-von-bayes-14",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "bedingt unabhängig "
},
{
  "id": "ex-naiver-bayes-spam",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-naiver-bayes-spam",
  "type": "Beispiel",
  "number": "1.1.38",
  "title": "Ein naiver Bayes-Spamfilter.",
  "body": " Ein naiver Bayes-Spamfilter  naiver Bayes-Klassifikator  Bayes-Klassifikator naiver   40 % der E-Mails an ein Postfach sind Spam ( ). Das Wort gratis kommt in 20 % der Spam-Mails und in 1 % der übrigen Mails vor, das Wort Meeting in 1 % der Spam-Mails und in 10 % der übrigen. Sei das Ereignis Die Mail enthält gratis und das Ereignis Die Mail enthält Meeting .   Eine Mail enthält gratis . Wie wahrscheinlich ist sie Spam?    Eine Mail enthält beide Wörter. Wie wahrscheinlich ist sie Spam, wenn man annimmt, dass und sowohl gegeben als auch gegeben bedingt unabhängig sind?    Warum heißt ein Filter, der auf dieser Annahme beruht, naiv ?               Wegen der bedingten Unabhängigkeit ist und . Bayes mit der Beobachtung liefert Das zweite Wort spricht gegen Spam und holt die Wahrscheinlichkeit von 93 % auf 57 % zurück.    Weil die Annahme fast nie stimmt: Wörter in Mails hängen auch innerhalb einer Klasse voneinander ab. Wer gratis schreibt, schreibt öfter auch Gewinn . Die Annahme macht das Modell aber rechenbar. Mit tausend Wörtern bräuchte man sonst für jede der Wortkombinationen eigene Wahrscheinlichkeiten; mit ihr genügen je Wort zwei Zahlen, und , die sich aus gekennzeichneten Beispielmails schätzen lassen. Trotz der falschen Annahme trifft der naive Bayes-Klassifikator oft gute Entscheidungen und war lange der Standard in Spamfiltern.      "
},
{
  "id": "sub-satz-von-bayes-16",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-satz-von-bayes-16",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Fehlschluss des Anklägers "
},
{
  "id": "ex-sally-clark",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#ex-sally-clark",
  "type": "Beispiel",
  "number": "1.1.39",
  "title": "Der Fall Sally Clark.",
  "body": " Der Fall Sally Clark   1999 wurde die Britin Sally Clark wegen Mordes an ihren beiden Söhnen verurteilt, die 1996 und 1998 im Alter von elf beziehungsweise acht Wochen plötzlich gestorben waren. Ein zentrales Argument der Anklage kam von dem Kinderarzt Roy Meadow: Für eine Familie wie die der Clarks liege die Wahrscheinlichkeit eines plötzlichen Kindstods bei 1 zu 8543, die zweier solcher Todesfälle also bei , rund 1 zu 73 Millionen.   Welche Annahme steckt im Quadrieren? Ist sie plausibel?    In einigen Zeitungen stand damals, die Wahrscheinlichkeit für Clarks Unschuld sei 1 zu 73 Millionen. Welche bedingte Wahrscheinlichkeit beschreibt die Zahl tatsächlich, und welche hätte das Gericht gebraucht?    Wovon hängt die Wahrscheinlichkeit ab, die das Gericht gebraucht hätte?          Sei das Ereignis, dass das -te Kind am plötzlichen Kindstod stirbt. Quadrieren heißt, und als unabhängig anzunehmen: . Das ist kaum haltbar. Genetische Veranlagung und Lebensumstände teilen Geschwister, und sie beeinflussen das Risiko. Nach einem ersten plötzlichen Kindstod ist ein zweiter in derselben Familie deutlich wahrscheinlicher als in einer beliebigen Familie, also . Die Zahl 1 zu 73 Millionen ist schon deshalb viel zu klein.    Selbst wenn sie stimmte, wäre sie die Wahrscheinlichkeit, dass in einer unschuldigen Familie zwei Kinder plötzlich sterben: . Das Gericht brauchte die umgekehrte bedingte Wahrscheinlichkeit . Beide zu verwechseln ist der Fehlschluss des Anklägers, derselbe Fehler wie die Antwort 99 % in .    Vereinfacht gibt es für zwei plötzliche Todesfälle von Säuglingen in einer Familie zwei Erklärungen, die einander ausschließen: , zweifacher plötzlicher Kindstod, und , zweifacher Mord. Die Beobachtung ist , und nach Definition der bedingten Wahrscheinlichkeit ist Entscheidend ist also nicht, dass klein ist, sondern wie sich zu verhält. Ein zweifacher Mord an Säuglingen durch die eigene Mutter ist ebenfalls äußerst selten. Der Mathematiker Ray Hill hat 2004 aus britischen Daten geschätzt, dass ein zweifacher plötzlicher Kindstod zwischen 4,5- und 9-mal so wahrscheinlich ist wie ein zweifacher Mord. Mit folgt , also ein Wert zwischen und , zwischen 10 % und 18 %. Das beweist keine Unschuld, und Hills Schätzungen sind nicht unumstritten: Der Philosoph Neven Sesardić hält die Wahl der A-priori-Wahrscheinlichkeiten und der Likelihoods für zu günstig für die Angeklagte. Aber jede dieser Rechnungen ist etwas völlig anderes als 1 zu 73 Millionen, und alle vergleichen, wie es der Satz von Bayes verlangt, die beiden Erklärungen miteinander.     Die Royal Statistical Society wies im Oktober 2001 öffentlich auf die falsche Verwendung der Statistik hin. 2003 hob das Berufungsgericht das Urteil auf, in erster Linie, weil entlastende medizinische Befunde zurückgehalten worden waren. Zur Zahl 1 zu 73 Millionen hielt es fest, sie hätte den Geschworenen nie in dieser Form vorgelegt werden dürfen.  Quellen: Royal Statistical Society, Pressemitteilung vom 23. Oktober 2001; Urteil des Court of Appeal, R v Clark [2003] EWCA Crim 1020, Randnummern 172 180; R. Hill, Multiple sudden infant deaths coincidence or beyond coincidence? , Paediatric and Perinatal Epidemiology 18 (2004), 320 326; N. Sesardić, Sudden Infant Death or Murder? A Royal Confusion About Probabilities , British Journal for the Philosophy of Science 58 (2007), 299 329. Im Literaturverzeichnis: , , , .   "
},
{
  "id": "rem-bayes-optimierung",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#rem-bayes-optimierung",
  "type": "Bemerkung",
  "number": "1.1.40",
  "title": "Die wahrscheinlichste Erklärung.",
  "body": " Die wahrscheinlichste Erklärung  Maximum-a-posteriori-Schätzung  Oft interessiert nicht die A-posteriori-Wahrscheinlichkeit einer bestimmten Hypothese, sondern die Hypothese, deren A-posteriori-Wahrscheinlichkeit am größten ist. Beim Entrauschen eines Fotos ist das gemessene, verrauschte Bild, und gesucht ist unter allen denkbaren unverrauschten Bildern dasjenige mit maximalem . Weil nicht von abhängt, genügt es, zu maximieren. Der erste Faktor misst, wie gut zur Messung passt, der zweite, wie plausibel als Bild ist, etwa weil es aus glatten Flächen statt aus Körnung besteht. Dieses Prinzip heißt Maximum-a-posteriori-Schätzung . Es kehrt in wieder, dann mit Parametern statt Bildern.  "
},
{
  "id": "sub-zusammenfassung-1-1-2",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#sub-zusammenfassung-1-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Wahrscheinlichkeitsraum. Rechenregeln. Laplace-Experiment. Kombinatorik. Bedingte Wahrscheinlichkeit. Unabhängigkeit. Satz von Bayes. Tests. "
},
{
  "id": "exercise-buch-ab-test-zuweisung",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#exercise-buch-ab-test-zuweisung",
  "type": "Übung",
  "number": "1.1.7.1",
  "title": "Zuweisung im A\/B-Test.",
  "body": " Zuweisung im A\/B-Test   Ein A\/B-Test weist drei aufeinanderfolgende Besucher einer Website unabhängig voneinander und jeweils mit Wahrscheinlichkeit der Variante A oder der Variante B zu.  Geben Sie den Ergebnisraum an. Wie viele Elemente hat er?   Bestimmen Sie die Wahrscheinlichkeiten der Ereignisse alle drei erhalten dieselbe Variante , mindestens einer erhält B und genau zwei erhalten A .           mit Elementen. Wegen der Unabhängigkeit hat jedes Ergebnis die Wahrscheinlichkeit ; es liegt ein Laplace-Experiment vor.     Alle gleich  , Wahrscheinlichkeit . Mindestens einer B ist das Gegenereignis von , Wahrscheinlichkeit . Genau zwei A  , Wahrscheinlichkeit .      "
},
{
  "id": "exercise-buch-boolesche-ungleichung",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#exercise-buch-boolesche-ungleichung",
  "type": "Übung",
  "number": "1.1.7.2",
  "title": "Eine Schranke ohne Unabhängigkeit.",
  "body": " Eine Schranke ohne Unabhängigkeit   Zeigen Sie mit den Rechenregeln aus , dass für beliebige Ereignisse und  gilt. Wann gilt Gleichheit? Folgern Sie daraus .    Nach der Additionsregel ist , und nach dem ersten Axiom ist . Gleichheit gilt genau dann, wenn , insbesondere also für disjunkte Ereignisse. Für drei Ereignisse wendet man die Ungleichung zweimal an: .  Die Ungleichung heißt boolesche Ungleichung boolesche Ungleichung . Sie ist nützlich, weil sie nichts über Abhängigkeiten voraussetzt: Die Wahrscheinlichkeit, dass irgendeines von mehreren seltenen Ereignissen eintritt, ist höchstens die Summe der Einzelwahrscheinlichkeiten.   "
},
{
  "id": "exercise-buch-auslosung",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#exercise-buch-auslosung",
  "type": "Übung",
  "number": "1.1.7.3",
  "title": "Auslosung.",
  "body": " Auslosung   In einem Kurs mit 30 Teilnehmenden werden vier Personen für eine Präsentation ausgelost.  Mit welcher Wahrscheinlichkeit sind Sie dabei?   Mit welcher Wahrscheinlichkeit sind Sie und eine bestimmte Kommilitonin beide dabei?    Erklären Sie das Ergebnis aus (a) ohne Binomialkoeffizienten.       Jede der Viergruppen ist gleich wahrscheinlich.   Günstig sind die Gruppen, die Sie und drei der 29 anderen enthalten: .     .    Man denke sich die Auslosung so: Alle 30 Namen werden in eine rein zufällige Reihenfolge gebracht, und die ersten vier sind ausgelost. Ihr Name steht an jeder der 30 Positionen mit derselben Wahrscheinlichkeit , also mit Wahrscheinlichkeit auf einer der ersten vier.      "
},
{
  "id": "exercise-buch-fehlalarme",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#exercise-buch-fehlalarme",
  "type": "Übung",
  "number": "1.1.7.4",
  "title": "Fehlalarme im Monitoring.",
  "body": " Fehlalarme im Monitoring   Ein Monitoring-System überwacht einen Onlineshop mit 20 Alarmregeln. An einem Tag ohne jede Störung schlägt jede Regel mit Wahrscheinlichkeit 5 % fälschlich an, unabhängig von den anderen.   Mit welcher Wahrscheinlichkeit gibt es an einem störungsfreien Tag mindestens einen Fehlalarm?    Wie klein muss die Fehlalarmwahrscheinlichkeit je Regel sein, damit an einem störungsfreien Tag mit höchstens 10 % Wahrscheinlichkeit ein Fehlalarm auftritt?          Gegenereignis keine Regel schlägt an : wegen der Unabhängigkeit mit Wahrscheinlichkeit . Also . An fast zwei von drei störungsfreien Tagen gibt es einen Fehlalarm.    Gesucht ist , also und . Jede Regel darf nur noch in gut einem halben Prozent der Fälle fälschlich anschlagen.      "
},
{
  "id": "exercise-buch-schnelltest",
  "level": "2",
  "url": "sec-wahrscheinlichkeitsraeume-und-bayes.html#exercise-buch-schnelltest",
  "type": "Übung",
  "number": "1.1.7.5",
  "title": "Ein Schnelltest, zweimal angewandt.",
  "body": " Ein Schnelltest, zweimal angewandt   Ein Schnelltest hat eine Sensitivität von 80 % und eine Spezifität von 98 %. Er wird in einer Gruppe eingesetzt, in der 5 % die Krankheit haben.   Bestimmen Sie den positiven und den negativen Vorhersagewert.    Wer positiv getestet wird, macht einen zweiten Test derselben Art. Die beiden Testergebnisse seien gegeben und gegeben bedingt unabhängig. Mit welcher Wahrscheinlichkeit ist jemand krank, der zweimal positiv getestet wurde?       Gegeben: , , .        Mit für die beiden positiven Ergebnisse ist und , also Dasselbe ergibt sich, wenn man den Vorhersagewert aus (a) als neue Basisrate für den zweiten Test verwendet: Die A-posteriori-Wahrscheinlichkeit nach dem ersten Test ist die A-priori-Wahrscheinlichkeit für den zweiten.      "
},
{
  "id": "sec-diskrete-zufallsvariablen-kennzahlen",
  "level": "1",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html",
  "type": "Abschnitt",
  "number": "2.1",
  "title": "Diskrete Zufallsvariablen: Verteilung, Erwartungswert und Varianz",
  "body": " Diskrete Zufallsvariablen: Verteilung, Erwartungswert und Varianz    Nach diesem Abschnitt können Sie     eine Zufallsvariable als Funktion auf dem Ergebnisraum lesen und Ereignisse wie als Teilmengen von schreiben,    Wahrscheinlichkeitsfunktion und Verteilungsfunktion einer diskreten Zufallsvariablen aufstellen, ineinander umrechnen und Wahrscheinlichkeiten wie daraus ablesen,    Erwartungswert, Varianz und Standardabweichung aus einer Tabelle oder Formel berechnen, auch für eine Funktion ,    eine Anzahl als Summe von Indikatorvariablen schreiben und ihren Erwartungswert mit der Linearität bestimmen,    Erwartungswert und Streuung als Entscheidungsgrundlage nutzen: fairer Einsatz, erwartete Kosten, Risiko,    Erwartungswert und Varianz von , von Summen und von Mittelwerten unabhängiger Zufallsvariablen mit den Rechenregeln bestimmen, ohne die Verteilung zu kennen.      In haben wir mit einiger Mühe ausgerechnet, wie wahrscheinlich unter zufällig gehashten Datensätzen mindestens eine Kollision ist. Wer eine Hashtabelle betreibt, will oft etwas anderes wissen: Mit wie vielen Kollisionen ist zu rechnen? Bei 100 Einträgen in einer Tabelle mit 1000 Plätzen sind es im Mittel 4,95 kollidierende Paare, und die Rechnung dafür passt in eine Zeile.  Der Weg dahin: macht aus dem Ergebnis eines Experiments eine Zahl, die Zufallsvariable, und beschreibt ihre Verteilung durch die Verteilungsfunktion. spezialisiert das auf diskrete Zufallsvariablen. führt den Erwartungswert ein und beantwortet die Frage vom Anfang, misst mit der Varianz, wie stark eine Zufallsvariable um ihn streut. zeigt, was mit der Streuung passiert, wenn man unabhängige Größen addiert oder mittelt. Diese Begriffe tragen die ganze übrige Vorlesung; im stetigen Fall kommen sie mit Integralen statt Summen wieder.    Zufallsvariablen und Verteilungsfunktion  Die Ergebnisse der Zufallsexperimente in waren Paare von Augenzahlen, Passwörter, Lötstellen oder Mails. Interessiert hat aber meist nicht das Ergebnis selbst, sondern eine Zahl, die man daran abliest: die Augensumme, die Zahl der Ziffern im Passwort, die Zahl der Alarme. Solche Zahlen heißen Zufallsvariablen. Mit ihnen wandert die Rechnung von einem Ergebnisraum, der für jedes Experiment anders aussieht, auf die reellen Zahlen, und dort kann man mitteln, addieren und vergleichen.   Zufallsvariable  Zufallsvariable   Sei ein Wahrscheinlichkeitsraum. Eine Funktion heißt (reelle) Zufallsvariable , wenn für jedes die Menge ein Ereignis ist, also in liegt.    Die Bedingung stellt nur sicher, dass die Wahrscheinlichkeiten, die wir gleich hinschreiben, definiert sind. Ist endlich oder abzählbar und , so ist jede Funktion eine Zufallsvariable. Trotz des Namens ist eine Zufallsvariable also weder zufällig noch eine Variable, sondern eine gewöhnliche Funktion. Zufällig ist nur, an welcher Stelle sie ausgewertet wird.  Für Ereignisse, die über beschrieben werden, gibt es eine Kurzschrift: steht für , für , und entsprechend oder allgemein für eine Menge . Statt schreibt man .   Die Augensumme als Zufallsvariable   In der Situation von sei die Augensumme.   Schreiben Sie die Ereignisse und als Teilmengen von .    Bestimmen Sie für jeden möglichen Wert .    Mit welcher Wahrscheinlichkeit ist die Augensumme mindestens 10?           und .    Die Paare mit Augensumme liegen in der Tabelle aller 36 Paare auf einer Diagonale. Für sind es Paare, für sind es . Beides fasst die Formel zusammen:       2 3 4 5  6 7 8 9  10 11 12     1 2 3 4  5 6 5 4  3 2 1    Die elf Wahrscheinlichkeiten summieren sich zu .     .     Die Tabelle aus (b) enthält alles, was man über die Augensumme wissen kann. Für jede Frage nach braucht man danach nur noch sie, nicht mehr die 36 Paare. Genau das ist der Gewinn einer Zufallsvariablen: Man rechnet mit einer Tabelle über den Werten statt mit dem Ergebnisraum.    Die Wahrscheinlichkeiten für alle Mengen , nach denen man sinnvoll fragen kann, heißen zusammen die Verteilung Verteilung einer Zufallsvariablen von . Zwei Zufallsvariablen mit derselben Verteilung heißen identisch verteilt identisch verteilt , auch wenn sie auf ganz verschiedenen Ergebnisräumen leben. Die Zahl der Köpfe bei einem Münzwurf und eine Zufallsvariable, die bei einem Würfelwurf eine gerade Augenzahl mit 1 und eine ungerade mit 0 bewertet, nehmen beide die Werte 0 und 1 mit Wahrscheinlichkeit je an. Um eine Verteilung zu beschreiben, genügt eine einzige Funktion. Allgemein beweisen wir das nicht; für diskrete Zufallsvariablen ergibt es sich aus , Teil (2), weil sich die Wahrscheinlichkeiten der einzelnen Werte als Sprunghöhen an dieser Funktion ablesen lassen.   Verteilungsfunktion  Verteilungsfunktion   Die Verteilungsfunktion einer Zufallsvariablen ist die Funktion      Eigenschaften der Verteilungsfunktion   Sei die Verteilungsfunktion einer Zufallsvariablen . Dann gilt:  für alle .    , und für ist .   ist monoton wachsend.    und .       (1) ist das erste Axiom. (2) ist das Gegenereignis von . Für ist und ; die Differenzregel aus liefert die Behauptung. (3) folgt aus (2), weil ist.  (4) Jede reelle Zahl liegt entweder in oder in genau einem der Intervalle , Also ist die disjunkte Vereinigung von und den Ereignissen . Das dritte Axiom und (2) ergeben eine Teleskopsumme: Weil monoton wächst, folgt . Ebenso ist die disjunkte Vereinigung der Ereignisse , also , und daraus folgt .    Eigenschaft (2) ist die, mit der man arbeitet: Jede Wahrscheinlichkeit für ein Intervall der Form und für jeden Schwanz steht in schon bereit.   Artikel im Warenkorb   Ein Onlineshop hat 200 Bestellungen danach ausgewertet, wie viele Artikel sie enthalten:      Artikel  1 2 3 4 5    Bestellungen  70 60 40 20 10    Eine der 200 Bestellungen wird rein zufällig ausgewählt, und sei die Zahl ihrer Artikel.  Bestimmen Sie die Verteilung von .   Geben Sie die Verteilungsfunktion für alle an.    Welcher Anteil der Bestellungen enthält mehr als drei Artikel, welcher zwei oder drei? Lesen Sie beides an ab.          Das Ziehen ist ein Laplace-Experiment über den 200 Bestellungen, also ist der Anteil der Bestellungen mit Artikeln: , , , und für .    Man summiert von links auf: Zwischen den ganzen Zahlen kommt nichts hinzu; so ist etwa .     und . 15 % der Bestellungen enthalten mehr als drei Artikel, die Hälfte zwei oder drei.     Das Muster kennen Sie aus : Wer rein zufällig eine Zeile aus einem Datensatz zieht, macht aus jeder Spalte eine Zufallsvariable. Ihre Verteilung ist die Tabelle der relativen Häufigkeiten, und ist der Anteil der Zeilen mit einem Wert von höchstens . In der Statistik heißt diese Funktion empirische Verteilungsfunktion Verteilungsfunktion empirische empirische Verteilungsfunktion .      Diskrete Zufallsvariablen und Wahrscheinlichkeitsfunktion  Die Augensumme und die Zahl der Artikel nehmen nur endlich viele Werte an. Für solche Zufallsvariablen ist die Verteilungsfunktion eine Treppe, und die Stufenhöhen sagen schon alles.   Diskrete Zufallsvariable, Wahrscheinlichkeitsfunktion  Zufallsvariable diskrete  Wahrscheinlichkeitsfunktion  Zähldichte   Eine Zufallsvariable heißt diskret , wenn ihre Wertemenge endlich oder abzählbar ist. Die Funktion heißt Wahrscheinlichkeitsfunktion (auch Zähldichte ) von . Außerhalb der Wertemenge ist .    Auf den Folien der Vorlesung und in manchen Büchern heißt die Wahrscheinlichkeitsfunktion ; dieses Buch reserviert für die Dichte stetiger Zufallsvariablen ( ).   Eigenschaften der Wahrscheinlichkeitsfunktion   Sei eine diskrete Zufallsvariable mit Wertemenge .   Es ist für alle und .    Für jede Menge ist . Insbesondere ist     Umgekehrt gibt es zu verschiedenen Zahlen und Gewichten mit stets eine diskrete Zufallsvariable mit .       Die Ereignisse sind paarweise disjunkt, denn kann nicht zwei Werte zugleich haben. Ihre Vereinigung ist , und die über alle ist . Nichtnegativ sind die nach dem ersten Axiom; das dritte Axiom liefert (2), und mit und folgt die Summe in (1). Für (3) wählt man mit dem Maß aus und .    Teil (3) ist der Grund, warum man in der Praxis meist gar keinen Ergebnisraum hinschreibt. Man sagt einfach: nimmt die Werte mit den Wahrscheinlichkeiten an. Eine Tabelle nichtnegativer Zahlen mit Summe 1 genügt.  Nimmt endlich viele Werte an, so ist nach (2) eine Treppenfunktion Treppenfunktion : konstant zwischen zwei aufeinanderfolgenden Werten, mit einem Sprung der Höhe an jeder Stelle . Umgekehrt liest man die Wahrscheinlichkeitsfunktion als Sprunghöhen an der Verteilungsfunktion ab. Nimmt nur ganze Zahlen an, so ist    Das Maximum zweier Würfel   Zwei faire Würfel werden geworfen, und sei die größere der beiden Augenzahlen.   Bestimmen Sie für .   Bestimmen Sie daraus die Wahrscheinlichkeitsfunktion von .  Mit welcher Wahrscheinlichkeit ist ?         Das Maximum ist höchstens , wenn beide Augenzahlen höchstens sind. Dafür gibt es der 36 gleich wahrscheinlichen Paare, also .    Mit den Sprunghöhen: , also für ( und ).     .     Hier war die Verteilungsfunktion leichter zu bekommen als die Wahrscheinlichkeitsfunktion, weil das Maximum ist höchstens dasselbe heißt wie alle Werte sind höchstens . Das Argument trägt weit: Die Antwortzeit einer Anfrage, die auf mehrere Server gleichzeitig warten muss, ist das Maximum der einzelnen Antwortzeiten, und ihre Verteilungsfunktion bekommt man genauso.     Wahrscheinlichkeitsfunktion des Maximums zweier Würfel: Stäbe der Höhe .   Stabdiagramm mit sechs nach rechts gleichmäßig höher werdenden Stäben   Über den Stellen 1 bis 6 steht je ein senkrechter Stab mit Punkt an der Spitze. Die Höhen sind 1\/36, 3\/36, 5\/36, 7\/36, 9\/36 und 11\/36, sie wachsen also mit gleichem Abstand. Zwischen den Stellen ist die Wahrscheinlichkeitsfunktion null.       Verteilungsfunktion von : eine Treppe mit Sprüngen der Höhe bei .   Treppenfunktion von 0 auf 1 mit sechs Stufen bei 1 bis 6   Links von 1 ist die Funktion null. An den Stellen 1 bis 6 springt sie nach oben, auf 1\/36, 4\/36, 9\/36, 16\/36, 25\/36 und schließlich 1, und dazwischen verläuft sie waagerecht. An jeder Sprungstelle markiert ein gefüllter Punkt den oberen Wert, der zur Funktion gehört, und ein leerer Kreis den unteren.      Ein gefüllter Punkt über einem leeren Kreis zeigt, welcher Wert an der Sprungstelle gilt: Weil den Wert mitzählt, gehört dort der obere Wert zur Funktion. Deshalb kommt es bei diskreten Zufallsvariablen darauf an, ob oder gemeint ist. Für ganzzahlige ist und . Diese Verschiebung um eins ist eine der häufigsten Fehlerquellen beim Ablesen.   Bitfehler in einem digitalen Kanal   Ein digitaler Kanal überträgt Blöcke aus je vier Bits. Sei die Zahl der Bits eines Blocks, die fehlerhaft ankommen. Nach einem Modell, das herleitet, hat die Wahrscheinlichkeitsfunktion (Tabelle aus Montgomery und Runger )       0 1 2 3 4     0,6561 0,2916 0,0486 0,0036 0,0001       Prüfen Sie, dass die Tabelle eine Wahrscheinlichkeitsfunktion ist, und bestimmen Sie für .    Die vier Bits übertragen ein einzelnes Nutzbit viermal, und der Empfänger entscheidet nach Mehrheit; steht es zwei zu zwei, verwirft er den Block. So wird jeder einzelne Bitfehler je Block korrigiert. Mit welcher Wahrscheinlichkeit kommt ein Block richtig an?    Mit welcher Wahrscheinlichkeit enthält ein Block weniger als zwei Fehler, mit welcher mindestens zwei?          Alle Einträge sind nichtnegativ und . Aufsummiert ergibt sich , , , und .    Ohne Code kommt ein Block nur bei richtig an, mit Wahrscheinlichkeit . Mit dem Code genügt : . Bei steht es zwei zu zwei, und der Block wird verworfen; bei entscheidet die Mehrheit falsch.     und . Wer hier rechnet, erhält , die Wahrscheinlichkeit für mindestens drei Fehler.     Die Korrektur eines einzigen Fehlers senkt den Anteil der Blöcke, die nicht richtig ankommen, von gut einem Drittel auf gut 5 %. Allgemein kommt ein Block, dessen Code bis zu Fehler korrigiert, mit Wahrscheinlichkeit mindestens richtig an; gefragt ist also ein Wert der Verteilungsfunktion, nicht der Wahrscheinlichkeitsfunktion. Die Tabelle und das Beispiel des digitalen Kanals stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 3 ( ); die Fehlerkorrektur ist für dieses Buch ergänzt.      Der Erwartungswert  Wie viele Artikel enthält eine Bestellung aus im Durchschnitt? Man addiert alle Artikel und teilt durch 200: In der zweiten Zeile steht jeder mögliche Wert, gewichtet mit seiner Wahrscheinlichkeit. Das nimmt man als Definition.   Erwartungswert  Erwartungswert   Sei eine diskrete Zufallsvariable mit Wertemenge . Der Erwartungswert von ist sofern ist. Bei endlich vielen Werten ist diese Bedingung immer erfüllt.    Zwei Lesarten helfen. Stellt man sich als Masse vor, die an der Stelle einer Stange hängt, so ist der Schwerpunkt : Dort müsste man die Stange unterstützen, damit sie im Gleichgewicht ist. Und wiederholt man das Experiment sehr oft, so liegt der Durchschnitt der beobachteten Werte nahe bei . Das ist das Gesetz der großen Zahlen ( ). Ein möglicher Wert muss nicht sein: Keine Bestellung enthält 2,2 Artikel.   Drei Erwartungswerte   Bestimmen Sie den Erwartungswert   der Zahl der Bitfehler je Block in ,    des Maximums zweier Würfel aus ,    der Augensumme aus , und zwar ohne zu rechnen.           Im Mittel sind 0,4 der vier Bits eines Blocks fehlerhaft.     Der größere von zwei Würfen liegt im Mittel fast einen Punkt über dem Erwartungswert eines einzelnen Wurfs.    Die Tabelle aus ist symmetrisch um 7: . Die Massen links und rechts von 7 halten sich die Waage, also ist der Schwerpunkt .     Die Rechnung in (a) passt zum Modell hinter der Tabelle, in dem jedes Bit mit Wahrscheinlichkeit 0,1 verfälscht wird: Vier Bits ergeben im Mittel viermal 0,1 Fehler. Dass sich Erwartungswerte so addieren lassen, zeigt weiter unten. Eine solche Probe lohnt sich immer, bevor man mit einer Tabelle weiterrechnet.    Der Erwartungswert ist die Kennzahl, mit der man Entscheidungen unter Unsicherheit vergleicht: Welche Wahl bringt im Mittel mehr Gewinn, welche verursacht im Mittel weniger Kosten? Die folgenden beiden Beispiele zeigen das an einer Prüfungsordnung und an einem Klassifikator.   Ein fairer Multiple-Choice-Test   In einem Multiple-Choice-Test hat jede Frage vier Antworten, von denen genau eine richtig ist. Ein richtiges Kreuz bringt 3 Punkte, ein falsches kostet Punkte (Teil (a) nach Meintrup ).   Bestimmen Sie so, dass reines Raten im Mittel 0 Punkte bringt.    Eine Studentin kann bei einer Frage eine der falschen Antworten sicher ausschließen und rät zwischen den übrigen drei. Lohnt sich für sie das Kreuz?    Und wenn sie zwei falsche Antworten ausschließen kann?       Sei die Punktzahl für die Frage.   Beim reinen Raten ist mit Wahrscheinlichkeit und mit Wahrscheinlichkeit . Aus folgt .    Mit ist nun . Das Kreuz lohnt sich im Mittel.     .     Der Punktabzug neutralisiert blindes Raten, belohnt aber Teilwissen, und zwar umso mehr, je mehr falsche Antworten jemand ausschließen kann. Genau so ist er gemeint. Die Frage aus (a) stammt aus D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , 2018 ( ).     Die Schwelle eines Betrugsfilters   Ein Modell schätzt für jede Kartenzahlung die Wahrscheinlichkeit , dass sie betrügerisch ist. Das System sperrt die Zahlung oder lässt sie durch. Eine betrügerische Zahlung durchzulassen kostet im Mittel 200 €. Eine legitime Zahlung zu sperren kostet 5 € für Rückfrage und entgangenen Umsatz. Richtige Entscheidungen kosten nichts.   Eine Zahlung hat . Welche Kosten sind zu erwarten, wenn das System sie sperrt, und welche, wenn es sie durchlässt?   Ab welchem sollte das System sperren?   Viele Klassifikatoren sperren standardmäßig ab . Was ist davon zu halten?          Beim Sperren entstehen Kosten , falls die Zahlung legitim ist (Wahrscheinlichkeit ), sonst 0. Beim Durchlassen entstehen , falls sie betrügerisch ist (Wahrscheinlichkeit ), sonst 0. Für : und . Sperren ist im Mittel deutlich billiger.    Sperren ist besser, wenn ist, also und .    Die Schwelle minimiert die erwartete Zahl der Fehlentscheidungen; sie ist richtig, wenn beide Fehler gleich viel kosten. Hier ist ein verpasster Betrug vierzigmal so teuer wie eine unnötige Sperre, und die Schwelle rutscht entsprechend auf 2,4 %. Ein System mit Schwelle ließe alle Zahlungen mit durch, obwohl jede davon im Mittel mehr kostet als eine Sperre.     Ein Klassifikator liefert Wahrscheinlichkeiten, die Entscheidung daraus ist eine Frage der Kosten. Die Rechnung setzt allerdings voraus, dass die tatsächliche Betrugswahrscheinlichkeit ist. Wie leicht das an einer falschen Basisrate scheitert, hat gezeigt.     Nicht jede Zufallsvariable hat einen Erwartungswert  Eine Münze wird geworfen, bis zum ersten Mal Kopf fällt. Geschieht das im -ten Wurf, zahlt ein Spiel Euro aus. Dann ist für , und die Summe wächst über alle Grenzen. Welcher Einsatz für dieses Spiel fair wäre, lässt sich mit dem Erwartungswert also nicht beantworten. Die Frage ist als Sankt-Petersburg-Paradoxon bekannt. Bei Zufallsvariablen mit endlich vielen Werten kann das nicht passieren.   Oft interessiert nicht selbst, sondern eine Größe , die daraus berechnet wird: Kosten, die von einer Anzahl abhängen, oder das Quadrat einer Abweichung. Um ihren Erwartungswert zu bestimmen, muss man die Verteilung von nicht erst ausrechnen.   Erwartungswert einer Funktion (Transformationssatz)  Transformationssatz  Erwartungswert einer Funktion      Sei diskret mit Wertemenge und eine Funktion. Dann ist     Seien und diskret mit Wertemengen und auf demselben Wahrscheinlichkeitsraum und . Mit ist    Beides gilt, sofern die Summe mit statt endlich ist.    (1) ist diskret mit Werten , und ist die disjunkte Vereinigung der Ereignisse mit . Also ist Im letzten Schritt wurden die Summanden nur umgruppiert: Jedes kommt in genau einer der inneren Summen vor. (2) folgt wörtlich genauso, mit den Paaren an Stelle der .    Vorsicht: Im Allgemeinen ist . Für eine Augenzahl ist , aber . Gleichheit gilt, wenn die Form hat, und das ist die wichtigste Rechenregel für Erwartungswerte.   Linearität des Erwartungswerts  Erwartungswert Linearität  Linearität des Erwartungswerts   Seien und diskrete Zufallsvariablen auf demselben Wahrscheinlichkeitsraum, deren Erwartungswerte existieren, und . Dann gilt  ,  .  Insbesondere ist .    (1) Nach ist .  (2) Nach , Teil (2), mit ist Die Ereignisse sind disjunkt mit Vereinigung . Also ist die disjunkte Vereinigung der Ereignisse , und die innere Summe im ersten Term ist . Ebenso ist die innere Summe im zweiten Term . Die Aussage für Summanden folgt, indem man (1) und (2) mehrfach anwendet.    An (2) ist bemerkenswert, was nicht vorausgesetzt wird: Die Zufallsvariablen dürfen beliebig voneinander abhängen. Ihre Stärke zeigt die Linearität beim Zählen.   Indikatorvariable  Indikatorvariable   Für ein Ereignis heißt die Zufallsvariable die Indikatorvariable von . Es ist .    Zählt , wie viele der Ereignisse eintreten, so ist , und die Linearität liefert Die Verteilung von braucht man dafür nicht, und die Ereignisse dürfen voneinander abhängen.   Wie viele Kollisionen sind zu erwarten?    Datensätze erhalten unabhängig voneinander je einen rein zufälligen von Plätzen einer Hashtabelle. Sei die Zahl der Paare von Datensätzen, die auf demselben Platz landen.  Bestimmen Sie .   Werten Sie für Datensätze und Plätze aus, und für das Geburtstagsproblem mit und .    Nach ist für 23 Personen. Zeigen Sie, dass für jede Zufallsvariable mit Werten in gilt.          Für jedes der Paare sei das Ereignis, dass die Datensätze und auf demselben Platz landen. Welchen Platz auch erhält, trifft ihn mit Wahrscheinlichkeit , also ist . Mit folgt     Für und ist . Für das Geburtstagsproblem ist .     , weil jeder Summand mit dabei nur kleiner wird. Für 23 Personen: .     Die Ereignisse sind nicht unabhängig: Kollidieren 1 mit 2 und 1 mit 3, dann sicher auch 2 mit 3. Die Rechnung in (a) braucht das nicht, sie ist deshalb so viel kürzer als die für . Beide hängen trotzdem eng zusammen: Die Näherung aus lautet , und für 23 Personen ist . Für den Betrieb einer Hashtabelle ist die nützlichere Zahl: Bei 100 Einträgen auf 1000 Plätzen ist eine Kollision praktisch sicher, und es sind im Mittel fast fünf.    Die folgende Simulation verteilt Datensätze zufällig, zählt die kollidierenden Paare und mittelt über viele Versuche.   import random # Probieren Sie k, n = 23, 365 und k, n = 100, 1000. k, n = 23, 365 versuche = 1000 def paare(werte): # jedes Paar wird von beiden Seiten gezählt, daher \/\/ 2 return sum([werte.count(w) - 1 for w in werte]) \/\/ 2 zahlen = [paare([random.randint(1, n) for _ in range(k)]) for _ in range(versuche)] anteil = sum([1 for z in zahlen if z > 0]) \/ versuche print(\"mittlere Zahl kollidierender Paare: %.3f\" % (sum(zahlen) \/ versuche)) print(\"Erwartungswert k(k-1)\/(2n): %.3f\" % (k * (k - 1) \/ (2 * n))) print(\"Anteil der Versuche mit Kollision: %.3f\" % anteil)     Varianz und Standardabweichung  Zwei Zufallsvariablen können denselben Erwartungswert haben und sich trotzdem völlig verschieden verhalten. Eine Kampagne, die sicher 12 000 € Gewinn bringt, ist etwas anderes als eine, die im Mittel 12 000 € bringt, aber in jedem fünften Fall Verlust macht. Was fehlt, ist ein Maß dafür, wie weit die Werte um den Erwartungswert streuen.   Varianz und Standardabweichung  Varianz  Standardabweichung   Sei eine diskrete Zufallsvariable mit Erwartungswert . Die Varianz von ist, sofern endlich ist, die Standardabweichung ist .    Die zweite Form der Varianz ist mit . Die Varianz ist also die mittlere quadratische Abweichung vom Erwartungswert. Das Quadrat sorgt dafür, dass sich Abweichungen nach oben und unten nicht aufheben, und es gewichtet große Abweichungen stärker als kleine. Weil dabei die Einheit mitquadriert wird, gibt man zur Anschauung die Standardabweichung an: Sie hat dieselbe Einheit wie . Zum Rechnen ist meist eine andere Form bequemer.   Verschiebungssatz  Verschiebungssatz    .    Mit und der Linearität ( ) ist .    Weil eine Varianz nie negativ ist, folgt nebenbei , passend zu den Würfelzahlen von oben; die Varianz einer Augenzahl ist nach dem Verschiebungssatz . Gleichheit, also , gilt nur, wenn mit Wahrscheinlichkeit 1 einen einzigen Wert annimmt. Für eine Indikatorvariable ist , weil und ; der Verschiebungssatz ergibt    Zwei Varianzen, zwei Rechenwege   Bestimmen Sie Varianz und Standardabweichung   der Zahl der Bitfehler je Block aus mit der Definition,    des Maximums zweier Würfel aus mit dem Verschiebungssatz.          Mit aus sind die quadrierten Abweichungen für gleich , , , und . Also ist und .     , also      Bei einem nicht ganzzahligen Erwartungswert wie ist der Verschiebungssatz deutlich weniger Arbeit, weil man nur Quadrate der Werte statt Quadrate von Abweichungen braucht.     Varianz als Risiko   Ein Start-up kann sein Marketingbudget in eine von zwei Kampagnen stecken. Den Gewinn in Tausend Euro schätzt es so ein: Kampagne bringt , oder mit Wahrscheinlichkeit , und ; Kampagne bringt oder mit Wahrscheinlichkeit je .  Vergleichen Sie die erwarteten Gewinne.  Vergleichen Sie die Standardabweichungen.   Welche Kampagne würden Sie wählen, wenn ein Verlust das Start-up in Zahlungsschwierigkeiten brächte?           und . Im Mittel sind beide gleich gut.     , also und . Für weichen beide Werte um 4 vom Erwartungswert ab, also und .     : Sie macht nie Verlust, dagegen mit Wahrscheinlichkeit . Der Erwartungswert allein kann zwischen beiden nicht entscheiden.     In der Finanzwelt ist die Standardabweichung das übliche Maß für das Risiko einer Anlage, dort unter dem Namen Volatilität Volatilität . Welches Risiko man für welchen Ertrag in Kauf nimmt, ist keine mathematische Frage mehr. Die Mathematik sorgt aber dafür, dass man beide Größen kennt, bevor man entscheidet ( ).     Gewinnverteilungen der Kampagnen aus . Beide haben den Erwartungswert 12 (gestrichelt), aber sehr verschiedene Streuung.   Zwei Stabdiagramme übereinander mit gleichem Erwartungswert, oben weit, unten eng gestreut   Oben das Stabdiagramm von Kampagne A mit Stäben bei minus 10 (Höhe 0,2), 10 (Höhe 0,5) und 30 (Höhe 0,3). Darunter, mit derselben waagerechten Achse, Kampagne B mit Stäben bei 8 und 16, jeweils der Höhe 0,5. In beiden Diagrammen markiert eine gestrichelte senkrechte Linie den Erwartungswert 12. Die Stäbe von A liegen weit links und rechts davon, die von B dicht daneben.      Wie verändern sich Erwartungswert und Streuung, wenn man eine Zufallsvariable verschiebt oder streckt, etwa beim Umrechnen von Euro in Tausend Euro oder beim Aufschlagen fester Kosten?   Varianz einer linearen Transformation  Varianz einer linearen Transformation   Für ist     Nach ist , also . Quadrieren und Erwartungswert bilden ergibt .    Eine Verschiebung um ändert nichts an der Streuung, denn alle Werte und der Erwartungswert rücken gemeinsam. Eine Streckung um multipliziert die Standardabweichung mit . Ist , so hat insbesondere die standardisierte Standardisieren Zufallsvariable den Erwartungswert 0 und die Varianz 1: Man wendet die Regeln mit und an. Der Wert von sagt, um wie viele Standardabweichungen von seinem Erwartungswert abweicht. Bei der Normalverteilung in wird diese Umrechnung zum wichtigsten Werkzeug.   Merkmale standardisieren   Ein Verfahren des maschinellen Lernens soll Kunden nach Ähnlichkeit gruppieren und misst dazu den euklidischen Abstand zwischen ihren Merkmalsvektoren (Alter in Jahren, Monatseinkommen in Euro). Für einen zufällig gewählten Kunden hat das Alter den Erwartungswert 40 und die Standardabweichung 12, das Einkommen den Erwartungswert 3000 und die Standardabweichung 900. Betrachtet werden die Kunden , und .   Welcher Kunde liegt nach dem unveränderten Abstand näher bei , oder ?    Standardisieren Sie beide Merkmale und beantworten Sie die Frage erneut.    Hilft es auch, das Einkommen einfach in Tausend Euro anzugeben?           und unterscheiden sich nur im Alter, der Abstand ist 24. und haben den Abstand . Danach ist der viel nähere Nachbar, und zwar nur deshalb, weil Einkommen in Euro große Zahlen sind.    Die standardisierten Werte und sind , und . Jetzt ist der Abstand von zu gleich 2, zu gleich . ist der nähere Nachbar.    Nur zufällig. In Tausend Euro ist der Abstand von zu gleich , und jetzt dominiert das Alter. Das Ergebnis hängt von der Einheit ab. Die standardisierten Werte dagegen ändern sich bei einem Wechsel der Einheit nicht, weil Erwartungswert und Standardabweichung mit umgerechnet werden.     Deshalb standardisiert man Merkmale vor jedem abstandsbasierten Verfahren, etwa vor der Suche nach nächsten Nachbarn oder einer Clusteranalyse. In der Praxis sind Erwartungswert und Standardabweichung nicht bekannt, sondern werden aus den Trainingsdaten geschätzt.      Unabhängige Zufallsvariablen, Summen und Mittelwerte  Der Erwartungswert einer Summe ist immer die Summe der Erwartungswerte. Für die Varianz stimmt das nicht immer, und die Frage, wann es stimmt, führt auf die Unabhängigkeit von Zufallsvariablen. Sie überträgt den Begriff aus von Ereignissen auf Zufallsvariablen.   Unabhängige Zufallsvariablen  Unabhängigkeit von Zufallsvariablen   Diskrete Zufallsvariablen auf demselben Wahrscheinlichkeitsraum heißen unabhängig , wenn für alle möglichen Werte  gilt. Dabei steht das Komma links für den Schnitt der Ereignisse .    Für zwei Zufallsvariablen heißt das: Für alle sind die Ereignisse und unabhängig. Was man über erfährt, ändert nichts an den Wahrscheinlichkeiten für . Das ist die typische Modellannahme für getrennt ablaufende Wiederholungen eines Experiments und für Bauteile aus verschiedenen Fertigungen. Summiert man in der Definition über alle Werte der übrigen Variablen, bleibt die Produktformel für je zwei und stehen; sie sind also auch paarweise unabhängig.  Die Augenzahlen und zweier Würfel sind unabhängig: Jedes Paar hat die Wahrscheinlichkeit . Die erste Augenzahl und die Augensumme sind es nicht: , aber .   Produkte und Summen unabhängiger Zufallsvariablen  Varianz einer Summe unabhängiger Zufallsvariablen      Sind und unabhängig mit Erwartungswert, so ist .    Sind unabhängig mit Varianz, so ist        (1) Nach , Teil (2), mit und der Unabhängigkeit ist   (2) Sei und , also . Ausmultiplizieren ergibt Für sind und unabhängig, und mit (1) ist . Bildet man auf beiden Seiten den Erwartungswert, bleibt .    Der Ausdruck , der im Beweis wegfällt, heißt Kovarianz . Was er misst und was passiert, wenn er nicht null ist, zeigt . Dass man auf die Unabhängigkeit nicht verzichten kann, zeigt schon : Dann ist und nicht . Die Summenregel gilt auch für Differenzen: Mit und sind auch und unabhängig, denn . Mit ist deshalb für unabhängige und  Varianzen addieren sich also auch dann, wenn man die Zufallsvariablen voneinander abzieht. Standardabweichungen dagegen addiert man nicht.   Spiel zwischen Welle und Bohrung   Eine Welle soll sich in einer Bohrung drehen. Der Durchmesser der Bohrung hat den Erwartungswert 20,10 mm und die Standardabweichung 0,03 mm, der Durchmesser der Welle den Erwartungswert 20,00 mm und die Standardabweichung 0,04 mm. Beide Teile kommen aus verschiedenen Maschinen, ihre Maße schwanken unabhängig. Das Spiel ist .  Bestimmen Sie Erwartungswert und Standardabweichung von .   Ein Kollege rechnet , eine Kollegin . Was ist davon zu halten?    Die Welle klemmt, wenn ist. Um wie viele Standardabweichungen liegt dieser Wert unter dem Erwartungswert?            mm und , also  mm.    Beide Zahlen setzen eine vollständige Abhängigkeit voraus. ergäbe sich, wenn Bohrung und Welle immer gleichsinnig schwankten, sodass sich ihre Abweichungen im Spiel teilweise aufheben; , wenn sie immer gegensinnig schwankten. Bei unabhängigen Maßen heben sich die Schwankungen weder auf, noch treffen sie immer ungünstig zusammen, und die richtige Antwort liegt dazwischen.     : zwei Standardabweichungen.     In der Konstruktionslehre entspricht die Rechnung der Kollegin der arithmetischen Tolerierung Tolerierung arithmetische , die für den ungünstigsten Fall auslegt, und die Rechnung aus (a) mit der statistischen Tolerierung Tolerierung statistische . Die arithmetische Tolerierung rechnet mit Grenzmaßen statt mit Standardabweichungen und garantiert damit die Passung in jedem Fall; die Rechnung der Kollegin ist ihr Gegenstück für die Streuung. Die statistische erlaubt für dieselbe Toleranz des Spiels gröbere und damit billigere Toleranzen der Einzelteile, nimmt dafür seltene ungünstige Paarungen in Kauf und setzt die Unabhängigkeit voraus. Wie oft zwei Standardabweichungen Abstand nicht reichen, hängt von der Verteilung ab; bei normalverteilten Maßen sind es gut 2 % der Paarungen, wie zeigen wird.    Die wichtigste Folgerung betrifft Mittelwerte. Wer eine Messung wiederholt oder über viele Nutzer mittelt, bildet aus unabhängigen, gleich verteilten Zufallsvariablen.   Erwartungswert und Varianz eines Mittelwerts  Mittelwert Erwartungswert und Varianz  Stichprobenmittel Erwartungswert und Varianz   Seien unabhängig mit gemeinsamem Erwartungswert und gemeinsamer Varianz . Dann gilt für      Mit ist . Mit und ist .    Das ist das Wurzel- -Gesetz Wurzel- -Gesetz : Die Standardabweichung eines Mittelwerts fällt wie . Viermal so viele Messungen halbieren sie, hundertmal so viele teilen sie durch zehn. Den Erwartungswert ändert das Mitteln nicht. Misst ein Gerät im Mittel systematisch zu viel, so misst auch der Mittelwert aus tausend Messungen im Mittel genauso viel zu viel; kleiner wird nur die zufällige Streuung. Die folgende Simulation mittelt Würfelwürfe, deren Varianz ist, und vergleicht die beobachtete Streuung der Mittelwerte mit .   import random, math # Probieren Sie n = 1, 4, 16, 100. n = 4 wiederholungen = 1000 mittel = [sum([random.randint(1, 6) for _ in range(n)]) \/ n for _ in range(wiederholungen)] m = sum(mittel) \/ wiederholungen s = math.sqrt(sum([(x - m) ** 2 for x in mittel]) \/ wiederholungen) print(\"Durchschnitt der Mittelwerte: %.3f\" % m) print(\"Standardabweichung der Mittelwerte: %.3f\" % s) print(\"sigma \/ Wurzel(n): %.3f\" % math.sqrt(35 \/ 12 \/ n))    Antwortzeiten im Monitoring   Die Antwortzeit einer einzelnen Anfrage an einen Webdienst hat den Erwartungswert 120 ms und die Standardabweichung 40 ms. Die Antwortzeiten verschiedener Anfragen seien unabhängig. Ein Dashboard zeigt jede Minute den Mittelwert der Antwortzeiten von 100 Anfragen.   Welchen Erwartungswert und welche Standardabweichung hat der angezeigte Minutenwert?    Nach einem Update steigt der Erwartungswert um 10 ms. Warum ist das am Minutenwert gut zu sehen, an einzelnen Anfragen dagegen kaum?    Um Rechenzeit zu sparen, soll das Dashboard nur noch 25 Anfragen je Minute mitteln. Was bedeutet das für (b)?          Nach : Erwartungswert 120 ms, Standardabweichung  ms.    10 ms sind das -Fache der Standardabweichung des Minutenwerts, aber nur ein Viertel der Standardabweichung einer einzelnen Anfrage. Im Minutenwert hebt sich der Sprung deutlich vom Rauschen ab, in den Einzelwerten geht er unter.    Die Standardabweichung verdoppelt sich auf  ms, und die 10 ms sind nur noch das -Fache davon. Der Anstieg wäre im Rauschen der Minutenwerte kaum noch zu erkennen.     Dahinter steckt der Grund, warum man in der Datenanalyse fast immer mit Mittelwerten arbeitet und nicht mit Einzelwerten: Nur so werden kleine Veränderungen sichtbar. Wie viele Beobachtungen man für eine gewünschte Genauigkeit braucht, ist eine der Kernfragen von .      Zusammenfassung      Zufallsvariable und Verteilungsfunktion. Eine Zufallsvariable ist eine Funktion . Ihre Verteilungsfunktion wächst monoton von 0 nach 1, und es gilt sowie .     Wahrscheinlichkeitsfunktion. Für diskretes ist , mit und . Es ist , eine Treppe mit Sprüngen der Höhe ; bei ganzzahligem ist und .     Erwartungswert.  , der Schwerpunkt der Verteilung und das Langzeitmittel. Mit ihm vergleicht man Entscheidungen: fairer Einsatz, erwartete Kosten, Schwellen.     Funktionen und Linearität.  , im Allgemeinen ungleich . Stets gilt , und für zwei Zufallsvariablen und auf demselben Wahrscheinlichkeitsraum ist , auch wenn sie voneinander abhängen. Mit ist der Erwartungswert einer Anzahl die Summe der Wahrscheinlichkeiten der gezählten Ereignisse.     Varianz.  misst die Streuung um den Erwartungswert, hat die Einheit von . Bei gleichem Erwartungswert ist sie ein Maß für das Risiko.     Lineare Transformation.  und . Die standardisierte Größe hat Erwartungswert 0 und Varianz 1.     Unabhängigkeit.  sind unabhängig, wenn für alle Werte gilt. Dann ist . Für zwei unabhängige und ist und .     Mittelwerte. Für unabhängige mit Erwartungswert und Varianz ist und : Mitteln verringert die zufällige Streuung, nicht aber eine systematische Abweichung.       Übungsaufgaben   Eine Konstante bestimmen   Eine Zufallsvariable nimmt die Werte 1, 2 und 3 an, mit .  Bestimmen Sie .   Geben Sie , und an und bestimmen Sie .   Bestimmen Sie und .         Die Summe muss 1 sein, also .     , , und .     und , also .        Eine Treppe lesen   Eine Zufallsvariable hat die Verteilungsfunktion   Bestimmen Sie die Wahrscheinlichkeitsfunktion von .   Bestimmen Sie , und .    Nennen Sie ein einfaches Zufallsexperiment, das auf diese Verteilung führt.          Die Sprunghöhen: , , .     , und .    Die Zahl der Köpfe bei zwei Würfen einer fairen Münze: Von den vier gleich wahrscheinlichen Ergebnissen haben eines null, zwei einen und eines zwei Köpfe.        Zeilen an ihrem alten Platz   Die Zeilen eines Datensatzes werden rein zufällig umsortiert, jede der Reihenfolgen ist gleich wahrscheinlich. Wie viele Zeilen stehen danach im Mittel an ihrem alten Platz? Schreiben Sie die Anzahl als Summe von Indikatorvariablen.    Sei das Ereignis, dass Zeile an ihrem Platz bleibt. Die übrigen Zeilen dürfen dann beliebig stehen, also ist . Die Anzahl ist , und . Im Mittel bleibt genau eine Zeile an ihrem Platz, gleichgültig, wie groß der Datensatz ist.     Mittlere Zeit und mittlere Rate   Ein Server bearbeitet Aufträge. Ein Auftrag dauert oder Minuten, jeweils mit Wahrscheinlichkeit .  Bestimmen Sie .   Die Bearbeitungsrate eines Auftrags ist Aufträge je Minute. Bestimmen Sie und vergleichen Sie mit . Welche der beiden Zahlen beschreibt den Durchsatz bei vielen Aufträgen?         Minuten.    , dagegen . 100 Aufträge brauchen im Mittel 200 Minuten; der Durchsatz ist also ein halber Auftrag je Minute, nicht zwei Drittel. Die mittlere Rate überschätzt ihn, ein Beispiel für .        Die Differenz zweier Würfel   Zwei faire Würfel werden unabhängig geworfen, mit Augenzahlen und . Eine einzelne Augenzahl hat die Varianz . Sei .   Bestimmen Sie und mit den Rechenregeln.    Bestimmen Sie die Wahrscheinlichkeitsfunktion von und prüfen Sie damit nach.           und, wegen der Unabhängigkeit, .    Die Differenz entsteht aus der 36 Paare, also für . Wegen ist         "
},
{
  "id": "sec-diskrete-zufallsvariablen-kennzahlen-2",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sec-diskrete-zufallsvariablen-kennzahlen-2",
  "type": "Lernziele",
  "number": "2.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     eine Zufallsvariable als Funktion auf dem Ergebnisraum lesen und Ereignisse wie als Teilmengen von schreiben,    Wahrscheinlichkeitsfunktion und Verteilungsfunktion einer diskreten Zufallsvariablen aufstellen, ineinander umrechnen und Wahrscheinlichkeiten wie daraus ablesen,    Erwartungswert, Varianz und Standardabweichung aus einer Tabelle oder Formel berechnen, auch für eine Funktion ,    eine Anzahl als Summe von Indikatorvariablen schreiben und ihren Erwartungswert mit der Linearität bestimmen,    Erwartungswert und Streuung als Entscheidungsgrundlage nutzen: fairer Einsatz, erwartete Kosten, Risiko,    Erwartungswert und Varianz von , von Summen und von Mittelwerten unabhängiger Zufallsvariablen mit den Rechenregeln bestimmen, ohne die Verteilung zu kennen.    "
},
{
  "id": "def-zufallsvariable",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-zufallsvariable",
  "type": "Definition",
  "number": "2.1.1",
  "title": "Zufallsvariable.",
  "body": " Zufallsvariable  Zufallsvariable   Sei ein Wahrscheinlichkeitsraum. Eine Funktion heißt (reelle) Zufallsvariable , wenn für jedes die Menge ein Ereignis ist, also in liegt.   "
},
{
  "id": "ex-augensumme",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-augensumme",
  "type": "Beispiel",
  "number": "2.1.2",
  "title": "Die Augensumme als Zufallsvariable.",
  "body": " Die Augensumme als Zufallsvariable   In der Situation von sei die Augensumme.   Schreiben Sie die Ereignisse und als Teilmengen von .    Bestimmen Sie für jeden möglichen Wert .    Mit welcher Wahrscheinlichkeit ist die Augensumme mindestens 10?           und .    Die Paare mit Augensumme liegen in der Tabelle aller 36 Paare auf einer Diagonale. Für sind es Paare, für sind es . Beides fasst die Formel zusammen:       2 3 4 5  6 7 8 9  10 11 12     1 2 3 4  5 6 5 4  3 2 1    Die elf Wahrscheinlichkeiten summieren sich zu .     .     Die Tabelle aus (b) enthält alles, was man über die Augensumme wissen kann. Für jede Frage nach braucht man danach nur noch sie, nicht mehr die 36 Paare. Genau das ist der Gewinn einer Zufallsvariablen: Man rechnet mit einer Tabelle über den Werten statt mit dem Ergebnisraum.   "
},
{
  "id": "sub-zufallsvariablen-7",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-zufallsvariablen-7",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Verteilung identisch verteilt "
},
{
  "id": "def-verteilungsfunktion",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-verteilungsfunktion",
  "type": "Definition",
  "number": "2.1.3",
  "title": "Verteilungsfunktion.",
  "body": " Verteilungsfunktion  Verteilungsfunktion   Die Verteilungsfunktion einer Zufallsvariablen ist die Funktion    "
},
{
  "id": "thm-eigenschaften-verteilungsfunktion",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-eigenschaften-verteilungsfunktion",
  "type": "Satz",
  "number": "2.1.4",
  "title": "Eigenschaften der Verteilungsfunktion.",
  "body": " Eigenschaften der Verteilungsfunktion   Sei die Verteilungsfunktion einer Zufallsvariablen . Dann gilt:  für alle .    , und für ist .   ist monoton wachsend.    und .       (1) ist das erste Axiom. (2) ist das Gegenereignis von . Für ist und ; die Differenzregel aus liefert die Behauptung. (3) folgt aus (2), weil ist.  (4) Jede reelle Zahl liegt entweder in oder in genau einem der Intervalle , Also ist die disjunkte Vereinigung von und den Ereignissen . Das dritte Axiom und (2) ergeben eine Teleskopsumme: Weil monoton wächst, folgt . Ebenso ist die disjunkte Vereinigung der Ereignisse , also , und daraus folgt .   "
},
{
  "id": "ex-warenkorb",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-warenkorb",
  "type": "Beispiel",
  "number": "2.1.5",
  "title": "Artikel im Warenkorb.",
  "body": " Artikel im Warenkorb   Ein Onlineshop hat 200 Bestellungen danach ausgewertet, wie viele Artikel sie enthalten:      Artikel  1 2 3 4 5    Bestellungen  70 60 40 20 10    Eine der 200 Bestellungen wird rein zufällig ausgewählt, und sei die Zahl ihrer Artikel.  Bestimmen Sie die Verteilung von .   Geben Sie die Verteilungsfunktion für alle an.    Welcher Anteil der Bestellungen enthält mehr als drei Artikel, welcher zwei oder drei? Lesen Sie beides an ab.          Das Ziehen ist ein Laplace-Experiment über den 200 Bestellungen, also ist der Anteil der Bestellungen mit Artikeln: , , , und für .    Man summiert von links auf: Zwischen den ganzen Zahlen kommt nichts hinzu; so ist etwa .     und . 15 % der Bestellungen enthalten mehr als drei Artikel, die Hälfte zwei oder drei.     Das Muster kennen Sie aus : Wer rein zufällig eine Zeile aus einem Datensatz zieht, macht aus jeder Spalte eine Zufallsvariable. Ihre Verteilung ist die Tabelle der relativen Häufigkeiten, und ist der Anteil der Zeilen mit einem Wert von höchstens . In der Statistik heißt diese Funktion empirische Verteilungsfunktion Verteilungsfunktion empirische empirische Verteilungsfunktion .   "
},
{
  "id": "def-diskrete-zufallsvariable",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-diskrete-zufallsvariable",
  "type": "Definition",
  "number": "2.1.6",
  "title": "Diskrete Zufallsvariable, Wahrscheinlichkeitsfunktion.",
  "body": " Diskrete Zufallsvariable, Wahrscheinlichkeitsfunktion  Zufallsvariable diskrete  Wahrscheinlichkeitsfunktion  Zähldichte   Eine Zufallsvariable heißt diskret , wenn ihre Wertemenge endlich oder abzählbar ist. Die Funktion heißt Wahrscheinlichkeitsfunktion (auch Zähldichte ) von . Außerhalb der Wertemenge ist .   "
},
{
  "id": "thm-wahrscheinlichkeitsfunktion",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-wahrscheinlichkeitsfunktion",
  "type": "Satz",
  "number": "2.1.7",
  "title": "Eigenschaften der Wahrscheinlichkeitsfunktion.",
  "body": " Eigenschaften der Wahrscheinlichkeitsfunktion   Sei eine diskrete Zufallsvariable mit Wertemenge .   Es ist für alle und .    Für jede Menge ist . Insbesondere ist     Umgekehrt gibt es zu verschiedenen Zahlen und Gewichten mit stets eine diskrete Zufallsvariable mit .       Die Ereignisse sind paarweise disjunkt, denn kann nicht zwei Werte zugleich haben. Ihre Vereinigung ist , und die über alle ist . Nichtnegativ sind die nach dem ersten Axiom; das dritte Axiom liefert (2), und mit und folgt die Summe in (1). Für (3) wählt man mit dem Maß aus und .   "
},
{
  "id": "sub-wahrscheinlichkeitsfunktion-7",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-wahrscheinlichkeitsfunktion-7",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Treppenfunktion "
},
{
  "id": "ex-maximum-wuerfel",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-maximum-wuerfel",
  "type": "Beispiel",
  "number": "2.1.8",
  "title": "Das Maximum zweier Würfel.",
  "body": " Das Maximum zweier Würfel   Zwei faire Würfel werden geworfen, und sei die größere der beiden Augenzahlen.   Bestimmen Sie für .   Bestimmen Sie daraus die Wahrscheinlichkeitsfunktion von .  Mit welcher Wahrscheinlichkeit ist ?         Das Maximum ist höchstens , wenn beide Augenzahlen höchstens sind. Dafür gibt es der 36 gleich wahrscheinlichen Paare, also .    Mit den Sprunghöhen: , also für ( und ).     .     Hier war die Verteilungsfunktion leichter zu bekommen als die Wahrscheinlichkeitsfunktion, weil das Maximum ist höchstens dasselbe heißt wie alle Werte sind höchstens . Das Argument trägt weit: Die Antwortzeit einer Anfrage, die auf mehrere Server gleichzeitig warten muss, ist das Maximum der einzelnen Antwortzeiten, und ihre Verteilungsfunktion bekommt man genauso.   "
},
{
  "id": "fig-maximum-wahrscheinlichkeitsfunktion",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#fig-maximum-wahrscheinlichkeitsfunktion",
  "type": "Abbildung",
  "number": "2.1.9",
  "title": "",
  "body": " Wahrscheinlichkeitsfunktion des Maximums zweier Würfel: Stäbe der Höhe .   Stabdiagramm mit sechs nach rechts gleichmäßig höher werdenden Stäben   Über den Stellen 1 bis 6 steht je ein senkrechter Stab mit Punkt an der Spitze. Die Höhen sind 1\/36, 3\/36, 5\/36, 7\/36, 9\/36 und 11\/36, sie wachsen also mit gleichem Abstand. Zwischen den Stellen ist die Wahrscheinlichkeitsfunktion null.     "
},
{
  "id": "fig-maximum-verteilungsfunktion",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#fig-maximum-verteilungsfunktion",
  "type": "Abbildung",
  "number": "2.1.10",
  "title": "",
  "body": " Verteilungsfunktion von : eine Treppe mit Sprüngen der Höhe bei .   Treppenfunktion von 0 auf 1 mit sechs Stufen bei 1 bis 6   Links von 1 ist die Funktion null. An den Stellen 1 bis 6 springt sie nach oben, auf 1\/36, 4\/36, 9\/36, 16\/36, 25\/36 und schließlich 1, und dazwischen verläuft sie waagerecht. An jeder Sprungstelle markiert ein gefüllter Punkt den oberen Wert, der zur Funktion gehört, und ein leerer Kreis den unteren.     "
},
{
  "id": "ex-informationskanal",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-informationskanal",
  "type": "Beispiel",
  "number": "2.1.11",
  "title": "Bitfehler in einem digitalen Kanal.",
  "body": " Bitfehler in einem digitalen Kanal   Ein digitaler Kanal überträgt Blöcke aus je vier Bits. Sei die Zahl der Bits eines Blocks, die fehlerhaft ankommen. Nach einem Modell, das herleitet, hat die Wahrscheinlichkeitsfunktion (Tabelle aus Montgomery und Runger )       0 1 2 3 4     0,6561 0,2916 0,0486 0,0036 0,0001       Prüfen Sie, dass die Tabelle eine Wahrscheinlichkeitsfunktion ist, und bestimmen Sie für .    Die vier Bits übertragen ein einzelnes Nutzbit viermal, und der Empfänger entscheidet nach Mehrheit; steht es zwei zu zwei, verwirft er den Block. So wird jeder einzelne Bitfehler je Block korrigiert. Mit welcher Wahrscheinlichkeit kommt ein Block richtig an?    Mit welcher Wahrscheinlichkeit enthält ein Block weniger als zwei Fehler, mit welcher mindestens zwei?          Alle Einträge sind nichtnegativ und . Aufsummiert ergibt sich , , , und .    Ohne Code kommt ein Block nur bei richtig an, mit Wahrscheinlichkeit . Mit dem Code genügt : . Bei steht es zwei zu zwei, und der Block wird verworfen; bei entscheidet die Mehrheit falsch.     und . Wer hier rechnet, erhält , die Wahrscheinlichkeit für mindestens drei Fehler.     Die Korrektur eines einzigen Fehlers senkt den Anteil der Blöcke, die nicht richtig ankommen, von gut einem Drittel auf gut 5 %. Allgemein kommt ein Block, dessen Code bis zu Fehler korrigiert, mit Wahrscheinlichkeit mindestens richtig an; gefragt ist also ein Wert der Verteilungsfunktion, nicht der Wahrscheinlichkeitsfunktion. Die Tabelle und das Beispiel des digitalen Kanals stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 3 ( ); die Fehlerkorrektur ist für dieses Buch ergänzt.   "
},
{
  "id": "def-erwartungswert",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-erwartungswert",
  "type": "Definition",
  "number": "2.1.12",
  "title": "Erwartungswert.",
  "body": " Erwartungswert  Erwartungswert   Sei eine diskrete Zufallsvariable mit Wertemenge . Der Erwartungswert von ist sofern ist. Bei endlich vielen Werten ist diese Bedingung immer erfüllt.   "
},
{
  "id": "sub-erwartungswert-4",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-erwartungswert-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Schwerpunkt "
},
{
  "id": "ex-erwartungswerte",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-erwartungswerte",
  "type": "Beispiel",
  "number": "2.1.13",
  "title": "Drei Erwartungswerte.",
  "body": " Drei Erwartungswerte   Bestimmen Sie den Erwartungswert   der Zahl der Bitfehler je Block in ,    des Maximums zweier Würfel aus ,    der Augensumme aus , und zwar ohne zu rechnen.           Im Mittel sind 0,4 der vier Bits eines Blocks fehlerhaft.     Der größere von zwei Würfen liegt im Mittel fast einen Punkt über dem Erwartungswert eines einzelnen Wurfs.    Die Tabelle aus ist symmetrisch um 7: . Die Massen links und rechts von 7 halten sich die Waage, also ist der Schwerpunkt .     Die Rechnung in (a) passt zum Modell hinter der Tabelle, in dem jedes Bit mit Wahrscheinlichkeit 0,1 verfälscht wird: Vier Bits ergeben im Mittel viermal 0,1 Fehler. Dass sich Erwartungswerte so addieren lassen, zeigt weiter unten. Eine solche Probe lohnt sich immer, bevor man mit einer Tabelle weiterrechnet.   "
},
{
  "id": "ex-multiple-choice",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-multiple-choice",
  "type": "Beispiel",
  "number": "2.1.14",
  "title": "Ein fairer Multiple-Choice-Test.",
  "body": " Ein fairer Multiple-Choice-Test   In einem Multiple-Choice-Test hat jede Frage vier Antworten, von denen genau eine richtig ist. Ein richtiges Kreuz bringt 3 Punkte, ein falsches kostet Punkte (Teil (a) nach Meintrup ).   Bestimmen Sie so, dass reines Raten im Mittel 0 Punkte bringt.    Eine Studentin kann bei einer Frage eine der falschen Antworten sicher ausschließen und rät zwischen den übrigen drei. Lohnt sich für sie das Kreuz?    Und wenn sie zwei falsche Antworten ausschließen kann?       Sei die Punktzahl für die Frage.   Beim reinen Raten ist mit Wahrscheinlichkeit und mit Wahrscheinlichkeit . Aus folgt .    Mit ist nun . Das Kreuz lohnt sich im Mittel.     .     Der Punktabzug neutralisiert blindes Raten, belohnt aber Teilwissen, und zwar umso mehr, je mehr falsche Antworten jemand ausschließen kann. Genau so ist er gemeint. Die Frage aus (a) stammt aus D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , 2018 ( ).   "
},
{
  "id": "ex-betrugserkennung",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-betrugserkennung",
  "type": "Beispiel",
  "number": "2.1.15",
  "title": "Die Schwelle eines Betrugsfilters.",
  "body": " Die Schwelle eines Betrugsfilters   Ein Modell schätzt für jede Kartenzahlung die Wahrscheinlichkeit , dass sie betrügerisch ist. Das System sperrt die Zahlung oder lässt sie durch. Eine betrügerische Zahlung durchzulassen kostet im Mittel 200 €. Eine legitime Zahlung zu sperren kostet 5 € für Rückfrage und entgangenen Umsatz. Richtige Entscheidungen kosten nichts.   Eine Zahlung hat . Welche Kosten sind zu erwarten, wenn das System sie sperrt, und welche, wenn es sie durchlässt?   Ab welchem sollte das System sperren?   Viele Klassifikatoren sperren standardmäßig ab . Was ist davon zu halten?          Beim Sperren entstehen Kosten , falls die Zahlung legitim ist (Wahrscheinlichkeit ), sonst 0. Beim Durchlassen entstehen , falls sie betrügerisch ist (Wahrscheinlichkeit ), sonst 0. Für : und . Sperren ist im Mittel deutlich billiger.    Sperren ist besser, wenn ist, also und .    Die Schwelle minimiert die erwartete Zahl der Fehlentscheidungen; sie ist richtig, wenn beide Fehler gleich viel kosten. Hier ist ein verpasster Betrug vierzigmal so teuer wie eine unnötige Sperre, und die Schwelle rutscht entsprechend auf 2,4 %. Ein System mit Schwelle ließe alle Zahlungen mit durch, obwohl jede davon im Mittel mehr kostet als eine Sperre.     Ein Klassifikator liefert Wahrscheinlichkeiten, die Entscheidung daraus ist eine Frage der Kosten. Die Rechnung setzt allerdings voraus, dass die tatsächliche Betrugswahrscheinlichkeit ist. Wie leicht das an einer falschen Basisrate scheitert, hat gezeigt.   "
},
{
  "id": "rem-erwartungswert-unendlich",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#rem-erwartungswert-unendlich",
  "type": "Bemerkung",
  "number": "2.1.16",
  "title": "Nicht jede Zufallsvariable hat einen Erwartungswert.",
  "body": " Nicht jede Zufallsvariable hat einen Erwartungswert  Eine Münze wird geworfen, bis zum ersten Mal Kopf fällt. Geschieht das im -ten Wurf, zahlt ein Spiel Euro aus. Dann ist für , und die Summe wächst über alle Grenzen. Welcher Einsatz für dieses Spiel fair wäre, lässt sich mit dem Erwartungswert also nicht beantworten. Die Frage ist als Sankt-Petersburg-Paradoxon bekannt. Bei Zufallsvariablen mit endlich vielen Werten kann das nicht passieren.  "
},
{
  "id": "thm-transformationssatz",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-transformationssatz",
  "type": "Satz",
  "number": "2.1.17",
  "title": "Erwartungswert einer Funktion (Transformationssatz).",
  "body": " Erwartungswert einer Funktion (Transformationssatz)  Transformationssatz  Erwartungswert einer Funktion      Sei diskret mit Wertemenge und eine Funktion. Dann ist     Seien und diskret mit Wertemengen und auf demselben Wahrscheinlichkeitsraum und . Mit ist    Beides gilt, sofern die Summe mit statt endlich ist.    (1) ist diskret mit Werten , und ist die disjunkte Vereinigung der Ereignisse mit . Also ist Im letzten Schritt wurden die Summanden nur umgruppiert: Jedes kommt in genau einer der inneren Summen vor. (2) folgt wörtlich genauso, mit den Paaren an Stelle der .   "
},
{
  "id": "thm-linearitaet-erwartungswert",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-linearitaet-erwartungswert",
  "type": "Satz",
  "number": "2.1.18",
  "title": "Linearität des Erwartungswerts.",
  "body": " Linearität des Erwartungswerts  Erwartungswert Linearität  Linearität des Erwartungswerts   Seien und diskrete Zufallsvariablen auf demselben Wahrscheinlichkeitsraum, deren Erwartungswerte existieren, und . Dann gilt  ,  .  Insbesondere ist .    (1) Nach ist .  (2) Nach , Teil (2), mit ist Die Ereignisse sind disjunkt mit Vereinigung . Also ist die disjunkte Vereinigung der Ereignisse , und die innere Summe im ersten Term ist . Ebenso ist die innere Summe im zweiten Term . Die Aussage für Summanden folgt, indem man (1) und (2) mehrfach anwendet.   "
},
{
  "id": "def-indikatorvariable",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-indikatorvariable",
  "type": "Definition",
  "number": "2.1.19",
  "title": "Indikatorvariable.",
  "body": " Indikatorvariable  Indikatorvariable   Für ein Ereignis heißt die Zufallsvariable die Indikatorvariable von . Es ist .   "
},
{
  "id": "ex-kollisionen-erwartungswert",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-kollisionen-erwartungswert",
  "type": "Beispiel",
  "number": "2.1.20",
  "title": "Wie viele Kollisionen sind zu erwarten?",
  "body": " Wie viele Kollisionen sind zu erwarten?    Datensätze erhalten unabhängig voneinander je einen rein zufälligen von Plätzen einer Hashtabelle. Sei die Zahl der Paare von Datensätzen, die auf demselben Platz landen.  Bestimmen Sie .   Werten Sie für Datensätze und Plätze aus, und für das Geburtstagsproblem mit und .    Nach ist für 23 Personen. Zeigen Sie, dass für jede Zufallsvariable mit Werten in gilt.          Für jedes der Paare sei das Ereignis, dass die Datensätze und auf demselben Platz landen. Welchen Platz auch erhält, trifft ihn mit Wahrscheinlichkeit , also ist . Mit folgt     Für und ist . Für das Geburtstagsproblem ist .     , weil jeder Summand mit dabei nur kleiner wird. Für 23 Personen: .     Die Ereignisse sind nicht unabhängig: Kollidieren 1 mit 2 und 1 mit 3, dann sicher auch 2 mit 3. Die Rechnung in (a) braucht das nicht, sie ist deshalb so viel kürzer als die für . Beide hängen trotzdem eng zusammen: Die Näherung aus lautet , und für 23 Personen ist . Für den Betrieb einer Hashtabelle ist die nützlichere Zahl: Bei 100 Einträgen auf 1000 Plätzen ist eine Kollision praktisch sicher, und es sind im Mittel fast fünf.   "
},
{
  "id": "def-varianz",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-varianz",
  "type": "Definition",
  "number": "2.1.21",
  "title": "Varianz und Standardabweichung.",
  "body": " Varianz und Standardabweichung  Varianz  Standardabweichung   Sei eine diskrete Zufallsvariable mit Erwartungswert . Die Varianz von ist, sofern endlich ist, die Standardabweichung ist .   "
},
{
  "id": "thm-verschiebungssatz",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-verschiebungssatz",
  "type": "Satz",
  "number": "2.1.22",
  "title": "Verschiebungssatz.",
  "body": " Verschiebungssatz  Verschiebungssatz    .    Mit und der Linearität ( ) ist .   "
},
{
  "id": "ex-varianzen",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-varianzen",
  "type": "Beispiel",
  "number": "2.1.23",
  "title": "Zwei Varianzen, zwei Rechenwege.",
  "body": " Zwei Varianzen, zwei Rechenwege   Bestimmen Sie Varianz und Standardabweichung   der Zahl der Bitfehler je Block aus mit der Definition,    des Maximums zweier Würfel aus mit dem Verschiebungssatz.          Mit aus sind die quadrierten Abweichungen für gleich , , , und . Also ist und .     , also      Bei einem nicht ganzzahligen Erwartungswert wie ist der Verschiebungssatz deutlich weniger Arbeit, weil man nur Quadrate der Werte statt Quadrate von Abweichungen braucht.   "
},
{
  "id": "ex-zwei-kampagnen",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-zwei-kampagnen",
  "type": "Beispiel",
  "number": "2.1.24",
  "title": "Varianz als Risiko.",
  "body": " Varianz als Risiko   Ein Start-up kann sein Marketingbudget in eine von zwei Kampagnen stecken. Den Gewinn in Tausend Euro schätzt es so ein: Kampagne bringt , oder mit Wahrscheinlichkeit , und ; Kampagne bringt oder mit Wahrscheinlichkeit je .  Vergleichen Sie die erwarteten Gewinne.  Vergleichen Sie die Standardabweichungen.   Welche Kampagne würden Sie wählen, wenn ein Verlust das Start-up in Zahlungsschwierigkeiten brächte?           und . Im Mittel sind beide gleich gut.     , also und . Für weichen beide Werte um 4 vom Erwartungswert ab, also und .     : Sie macht nie Verlust, dagegen mit Wahrscheinlichkeit . Der Erwartungswert allein kann zwischen beiden nicht entscheiden.     In der Finanzwelt ist die Standardabweichung das übliche Maß für das Risiko einer Anlage, dort unter dem Namen Volatilität Volatilität . Welches Risiko man für welchen Ertrag in Kauf nimmt, ist keine mathematische Frage mehr. Die Mathematik sorgt aber dafür, dass man beide Größen kennt, bevor man entscheidet ( ).   "
},
{
  "id": "fig-zwei-kampagnen",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#fig-zwei-kampagnen",
  "type": "Abbildung",
  "number": "2.1.25",
  "title": "",
  "body": " Gewinnverteilungen der Kampagnen aus . Beide haben den Erwartungswert 12 (gestrichelt), aber sehr verschiedene Streuung.   Zwei Stabdiagramme übereinander mit gleichem Erwartungswert, oben weit, unten eng gestreut   Oben das Stabdiagramm von Kampagne A mit Stäben bei minus 10 (Höhe 0,2), 10 (Höhe 0,5) und 30 (Höhe 0,3). Darunter, mit derselben waagerechten Achse, Kampagne B mit Stäben bei 8 und 16, jeweils der Höhe 0,5. In beiden Diagrammen markiert eine gestrichelte senkrechte Linie den Erwartungswert 12. Die Stäbe von A liegen weit links und rechts davon, die von B dicht daneben.     "
},
{
  "id": "thm-varianz-lineare-transformation",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-varianz-lineare-transformation",
  "type": "Satz",
  "number": "2.1.26",
  "title": "Varianz einer linearen Transformation.",
  "body": " Varianz einer linearen Transformation  Varianz einer linearen Transformation   Für ist     Nach ist , also . Quadrieren und Erwartungswert bilden ergibt .   "
},
{
  "id": "sub-varianz-12",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-varianz-12",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "standardisierte "
},
{
  "id": "ex-merkmalsskalierung",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-merkmalsskalierung",
  "type": "Beispiel",
  "number": "2.1.27",
  "title": "Merkmale standardisieren.",
  "body": " Merkmale standardisieren   Ein Verfahren des maschinellen Lernens soll Kunden nach Ähnlichkeit gruppieren und misst dazu den euklidischen Abstand zwischen ihren Merkmalsvektoren (Alter in Jahren, Monatseinkommen in Euro). Für einen zufällig gewählten Kunden hat das Alter den Erwartungswert 40 und die Standardabweichung 12, das Einkommen den Erwartungswert 3000 und die Standardabweichung 900. Betrachtet werden die Kunden , und .   Welcher Kunde liegt nach dem unveränderten Abstand näher bei , oder ?    Standardisieren Sie beide Merkmale und beantworten Sie die Frage erneut.    Hilft es auch, das Einkommen einfach in Tausend Euro anzugeben?           und unterscheiden sich nur im Alter, der Abstand ist 24. und haben den Abstand . Danach ist der viel nähere Nachbar, und zwar nur deshalb, weil Einkommen in Euro große Zahlen sind.    Die standardisierten Werte und sind , und . Jetzt ist der Abstand von zu gleich 2, zu gleich . ist der nähere Nachbar.    Nur zufällig. In Tausend Euro ist der Abstand von zu gleich , und jetzt dominiert das Alter. Das Ergebnis hängt von der Einheit ab. Die standardisierten Werte dagegen ändern sich bei einem Wechsel der Einheit nicht, weil Erwartungswert und Standardabweichung mit umgerechnet werden.     Deshalb standardisiert man Merkmale vor jedem abstandsbasierten Verfahren, etwa vor der Suche nach nächsten Nachbarn oder einer Clusteranalyse. In der Praxis sind Erwartungswert und Standardabweichung nicht bekannt, sondern werden aus den Trainingsdaten geschätzt.   "
},
{
  "id": "def-unabhaengige-zufallsvariablen",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#def-unabhaengige-zufallsvariablen",
  "type": "Definition",
  "number": "2.1.28",
  "title": "Unabhängige Zufallsvariablen.",
  "body": " Unabhängige Zufallsvariablen  Unabhängigkeit von Zufallsvariablen   Diskrete Zufallsvariablen auf demselben Wahrscheinlichkeitsraum heißen unabhängig , wenn für alle möglichen Werte  gilt. Dabei steht das Komma links für den Schnitt der Ereignisse .   "
},
{
  "id": "thm-unabhaengige-summen",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#thm-unabhaengige-summen",
  "type": "Satz",
  "number": "2.1.29",
  "title": "Produkte und Summen unabhängiger Zufallsvariablen.",
  "body": " Produkte und Summen unabhängiger Zufallsvariablen  Varianz einer Summe unabhängiger Zufallsvariablen      Sind und unabhängig mit Erwartungswert, so ist .    Sind unabhängig mit Varianz, so ist        (1) Nach , Teil (2), mit und der Unabhängigkeit ist   (2) Sei und , also . Ausmultiplizieren ergibt Für sind und unabhängig, und mit (1) ist . Bildet man auf beiden Seiten den Erwartungswert, bleibt .   "
},
{
  "id": "sub-unabhaengige-zufallsvariablen-7",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-unabhaengige-zufallsvariablen-7",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Kovarianz "
},
{
  "id": "ex-passung",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-passung",
  "type": "Beispiel",
  "number": "2.1.30",
  "title": "Spiel zwischen Welle und Bohrung.",
  "body": " Spiel zwischen Welle und Bohrung   Eine Welle soll sich in einer Bohrung drehen. Der Durchmesser der Bohrung hat den Erwartungswert 20,10 mm und die Standardabweichung 0,03 mm, der Durchmesser der Welle den Erwartungswert 20,00 mm und die Standardabweichung 0,04 mm. Beide Teile kommen aus verschiedenen Maschinen, ihre Maße schwanken unabhängig. Das Spiel ist .  Bestimmen Sie Erwartungswert und Standardabweichung von .   Ein Kollege rechnet , eine Kollegin . Was ist davon zu halten?    Die Welle klemmt, wenn ist. Um wie viele Standardabweichungen liegt dieser Wert unter dem Erwartungswert?            mm und , also  mm.    Beide Zahlen setzen eine vollständige Abhängigkeit voraus. ergäbe sich, wenn Bohrung und Welle immer gleichsinnig schwankten, sodass sich ihre Abweichungen im Spiel teilweise aufheben; , wenn sie immer gegensinnig schwankten. Bei unabhängigen Maßen heben sich die Schwankungen weder auf, noch treffen sie immer ungünstig zusammen, und die richtige Antwort liegt dazwischen.     : zwei Standardabweichungen.     In der Konstruktionslehre entspricht die Rechnung der Kollegin der arithmetischen Tolerierung Tolerierung arithmetische , die für den ungünstigsten Fall auslegt, und die Rechnung aus (a) mit der statistischen Tolerierung Tolerierung statistische . Die arithmetische Tolerierung rechnet mit Grenzmaßen statt mit Standardabweichungen und garantiert damit die Passung in jedem Fall; die Rechnung der Kollegin ist ihr Gegenstück für die Streuung. Die statistische erlaubt für dieselbe Toleranz des Spiels gröbere und damit billigere Toleranzen der Einzelteile, nimmt dafür seltene ungünstige Paarungen in Kauf und setzt die Unabhängigkeit voraus. Wie oft zwei Standardabweichungen Abstand nicht reichen, hängt von der Verteilung ab; bei normalverteilten Maßen sind es gut 2 % der Paarungen, wie zeigen wird.   "
},
{
  "id": "cor-varianz-mittelwert",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#cor-varianz-mittelwert",
  "type": "Korollar",
  "number": "2.1.31",
  "title": "Erwartungswert und Varianz eines Mittelwerts.",
  "body": " Erwartungswert und Varianz eines Mittelwerts  Mittelwert Erwartungswert und Varianz  Stichprobenmittel Erwartungswert und Varianz   Seien unabhängig mit gemeinsamem Erwartungswert und gemeinsamer Varianz . Dann gilt für      Mit ist . Mit und ist .   "
},
{
  "id": "sub-unabhaengige-zufallsvariablen-11",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-unabhaengige-zufallsvariablen-11",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Wurzel- -Gesetz "
},
{
  "id": "ex-antwortzeiten-monitoring",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#ex-antwortzeiten-monitoring",
  "type": "Beispiel",
  "number": "2.1.32",
  "title": "Antwortzeiten im Monitoring.",
  "body": " Antwortzeiten im Monitoring   Die Antwortzeit einer einzelnen Anfrage an einen Webdienst hat den Erwartungswert 120 ms und die Standardabweichung 40 ms. Die Antwortzeiten verschiedener Anfragen seien unabhängig. Ein Dashboard zeigt jede Minute den Mittelwert der Antwortzeiten von 100 Anfragen.   Welchen Erwartungswert und welche Standardabweichung hat der angezeigte Minutenwert?    Nach einem Update steigt der Erwartungswert um 10 ms. Warum ist das am Minutenwert gut zu sehen, an einzelnen Anfragen dagegen kaum?    Um Rechenzeit zu sparen, soll das Dashboard nur noch 25 Anfragen je Minute mitteln. Was bedeutet das für (b)?          Nach : Erwartungswert 120 ms, Standardabweichung  ms.    10 ms sind das -Fache der Standardabweichung des Minutenwerts, aber nur ein Viertel der Standardabweichung einer einzelnen Anfrage. Im Minutenwert hebt sich der Sprung deutlich vom Rauschen ab, in den Einzelwerten geht er unter.    Die Standardabweichung verdoppelt sich auf  ms, und die 10 ms sind nur noch das -Fache davon. Der Anstieg wäre im Rauschen der Minutenwerte kaum noch zu erkennen.     Dahinter steckt der Grund, warum man in der Datenanalyse fast immer mit Mittelwerten arbeitet und nicht mit Einzelwerten: Nur so werden kleine Veränderungen sichtbar. Wie viele Beobachtungen man für eine gewünschte Genauigkeit braucht, ist eine der Kernfragen von .   "
},
{
  "id": "sub-zusammenfassung-2-1-2",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#sub-zusammenfassung-2-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Zufallsvariable und Verteilungsfunktion. Wahrscheinlichkeitsfunktion. Erwartungswert. Funktionen und Linearität. Varianz. Lineare Transformation. Unabhängigkeit. Mittelwerte. "
},
{
  "id": "exercise-buch-normierung",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#exercise-buch-normierung",
  "type": "Übung",
  "number": "2.1.7.1",
  "title": "Eine Konstante bestimmen.",
  "body": " Eine Konstante bestimmen   Eine Zufallsvariable nimmt die Werte 1, 2 und 3 an, mit .  Bestimmen Sie .   Geben Sie , und an und bestimmen Sie .   Bestimmen Sie und .         Die Summe muss 1 sein, also .     , , und .     und , also .      "
},
{
  "id": "exercise-buch-verteilungsfunktion-ablesen",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#exercise-buch-verteilungsfunktion-ablesen",
  "type": "Übung",
  "number": "2.1.7.2",
  "title": "Eine Treppe lesen.",
  "body": " Eine Treppe lesen   Eine Zufallsvariable hat die Verteilungsfunktion   Bestimmen Sie die Wahrscheinlichkeitsfunktion von .   Bestimmen Sie , und .    Nennen Sie ein einfaches Zufallsexperiment, das auf diese Verteilung führt.          Die Sprunghöhen: , , .     , und .    Die Zahl der Köpfe bei zwei Würfen einer fairen Münze: Von den vier gleich wahrscheinlichen Ergebnissen haben eines null, zwei einen und eines zwei Köpfe.      "
},
{
  "id": "exercise-buch-fixpunkte",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#exercise-buch-fixpunkte",
  "type": "Übung",
  "number": "2.1.7.3",
  "title": "Zeilen an ihrem alten Platz.",
  "body": " Zeilen an ihrem alten Platz   Die Zeilen eines Datensatzes werden rein zufällig umsortiert, jede der Reihenfolgen ist gleich wahrscheinlich. Wie viele Zeilen stehen danach im Mittel an ihrem alten Platz? Schreiben Sie die Anzahl als Summe von Indikatorvariablen.    Sei das Ereignis, dass Zeile an ihrem Platz bleibt. Die übrigen Zeilen dürfen dann beliebig stehen, also ist . Die Anzahl ist , und . Im Mittel bleibt genau eine Zeile an ihrem Platz, gleichgültig, wie groß der Datensatz ist.   "
},
{
  "id": "exercise-buch-kehrwert",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#exercise-buch-kehrwert",
  "type": "Übung",
  "number": "2.1.7.4",
  "title": "Mittlere Zeit und mittlere Rate.",
  "body": " Mittlere Zeit und mittlere Rate   Ein Server bearbeitet Aufträge. Ein Auftrag dauert oder Minuten, jeweils mit Wahrscheinlichkeit .  Bestimmen Sie .   Die Bearbeitungsrate eines Auftrags ist Aufträge je Minute. Bestimmen Sie und vergleichen Sie mit . Welche der beiden Zahlen beschreibt den Durchsatz bei vielen Aufträgen?         Minuten.    , dagegen . 100 Aufträge brauchen im Mittel 200 Minuten; der Durchsatz ist also ein halber Auftrag je Minute, nicht zwei Drittel. Die mittlere Rate überschätzt ihn, ein Beispiel für .      "
},
{
  "id": "exercise-buch-wuerfeldifferenz",
  "level": "2",
  "url": "sec-diskrete-zufallsvariablen-kennzahlen.html#exercise-buch-wuerfeldifferenz",
  "type": "Übung",
  "number": "2.1.7.5",
  "title": "Die Differenz zweier Würfel.",
  "body": " Die Differenz zweier Würfel   Zwei faire Würfel werden unabhängig geworfen, mit Augenzahlen und . Eine einzelne Augenzahl hat die Varianz . Sei .   Bestimmen Sie und mit den Rechenregeln.    Bestimmen Sie die Wahrscheinlichkeitsfunktion von und prüfen Sie damit nach.           und, wegen der Unabhängigkeit, .    Die Differenz entsteht aus der 36 Paare, also für . Wegen ist       "
},
{
  "id": "sec-diskrete-verteilungen",
  "level": "1",
  "url": "sec-diskrete-verteilungen.html",
  "type": "Abschnitt",
  "number": "2.2",
  "title": "Wichtige diskrete Verteilungen",
  "body": " Wichtige diskrete Verteilungen    Nach diesem Abschnitt können Sie     zu einer Situation die passende Verteilung wählen, ihre Parameter angeben und die Modellannahmen benennen: Unabhängigkeit, gleiche Erfolgswahrscheinlichkeit, konstante Rate,    Wahrscheinlichkeiten, Erwartungswert und Varianz der Binomial-, der geometrischen und der Poisson-Verteilung berechnen, auch in Rückrichtung: welcher Parameter zu einer geforderten Wahrscheinlichkeit passt,    Erwartungswert und Varianz dieser Verteilungen herleiten, bei der Binomialverteilung aus Indikatorvariablen,    die Gedächtnislosigkeit der geometrischen Verteilung erklären und anwenden,    begründen, wann die Poisson-Verteilung die Binomialverteilung annähert, und die Näherung einsetzen,    die hypergeometrische, die negative Binomial- und die Multinomialverteilung an ihrer Situation erkennen und auf die vier Grundverteilungen zurückführen.      Ein Onlineshop schaltet eine Suchanzeige, und jede Einblendung führt mit Wahrscheinlichkeit 2 % zu einem Klick, unabhängig von den anderen. Daraus entstehen drei Fragen: Wie viele Klicks bringen 500 Einblendungen? Wie viele Einblendungen vergehen bis zum ersten Klick? Wie viele Klicks kommen in einer Stunde, in der Tausende Einblendungen zu zufälligen Zeitpunkten stattfinden? Jede Frage führt auf eine eigene Verteilung, und alle drei kehren in der Praxis ständig wieder.  Die vier Grundverteilungen dazu bekommen die Zeit dieser Woche: zählt mit dem Bernoulli-Versuch als Baustein die Erfolge in Versuchen, wartet auf den ersten Erfolg, zählt seltene Ereignisse in einem Zeitraum. Die Steckbriefe , und sind zum Wiedererkennen da; wichtig ist dort, aus welcher Grundverteilung sie hervorgehen. fasst diese Verwandtschaften in einer Tabelle und einer Karte zusammen.    Bernoulli- und Binomialverteilung  Zum Einstieg ein Rückblick: Die einfachste Verteilung kennen Sie schon aus . Nimmt jeden der Werte mit derselben Wahrscheinlichkeit an, so heißt  diskret gleichverteilt Gleichverteilung diskrete , kurz . Für die Werte ergeben die Summenformeln und  für einen Würfel also und wie in . Die Verteilungen dieses Abschnitts entstehen dagegen, wenn man ein Experiment mit zwei Ausgängen wiederholt und dabei zählt.   Bernoulli-Experiment, Bernoulli-Verteilung  Bernoulli-Verteilung  Bernoulli-Experiment   Ein Zufallsexperiment mit genau zwei Ausgängen, Erfolg mit Wahrscheinlichkeit und Misserfolg mit Wahrscheinlichkeit , heißt Bernoulli-Experiment . Eine Zufallsvariable mit heißt Bernoulli-verteilt mit Parameter , kurz .     Erfolg ist dabei keine Wertung, sondern nur der Name für den gezählten Ausgang: Ein Bit kommt verfälscht an, eine Nutzerin klickt, ein Bauteil ist defekt. Eine Bernoulli-verteilte Zufallsvariable ist nichts anderes als die Indikatorvariable des Erfolgs aus . Ihre Kennzahlen sind deshalb schon bekannt.   Erwartungswert und Varianz der Bernoulli-Verteilung   Für ist und .    Mit und ist nach , und steht in .    Die Varianz ist bei am größten und bei oder null: Am unsichersten ist ein Versuch, dessen Ausgänge gleich wahrscheinlich sind.   Binomialverteilung  Binomialverteilung   Ein Bernoulli-Experiment mit Erfolgswahrscheinlichkeit wird -mal unabhängig wiederholt. Die Zahl der Erfolge heißt binomialverteilt mit Parametern und , kurz . Auf den Folien der Vorlesung steht dafür auch .    Enthalten die Parameter ein Dezimalkomma, trennen wir sie durch ein Semikolon: hat vier Versuche mit Erfolgswahrscheinlichkeit .   Wahrscheinlichkeitsfunktion der Binomialverteilung   Für ist     Das Ergebnis der Versuche ist eine Folge aus Erfolgen und Misserfolgen. Eine feste Folge mit genau Erfolgen hat wegen der Unabhängigkeit die Wahrscheinlichkeit , denn sie ist ein Produkt aus Faktoren und Faktoren , nur in anderer Reihenfolge. Die Folge ist festgelegt, sobald man weiß, an welchen der Stellen die Erfolge stehen; dafür gibt es nach  Möglichkeiten. Verschiedene Folgen schließen sich gegenseitig aus, ihre Wahrscheinlichkeiten addieren sich. Nach dem binomischen Lehrsatz ist die Summe über alle gleich , wie es sein muss.     Erwartungswert und Varianz der Binomialverteilung   Für ist     Sei die Indikatorvariable des Erfolgs im -ten Versuch. Dann ist , die sind unabhängig, weil die Versuche es sind, und jedes ist -verteilt. Mit und der Linearität ( ) ist , und nach addieren sich die Varianzen zu .    Der Beweis kommt ohne eine einzige Summe über Binomialkoeffizienten aus. Das ist der Gewinn aus : Wer eine Anzahl als Summe von Indikatoren schreibt, bekommt Erwartungswert und Varianz fast geschenkt. Mit dem Satz ist die erste Frage vom Anfang des Abschnitts beantwortet: Die Zahl der Klicks bei 500 Einblendungen ist -verteilt, im Mittel sind es Klicks, mit Varianz und Standardabweichung . zeigt zwei Binomialverteilungen. Die Stäbe steigen bis in die Nähe von und fallen dann wieder; für liegen sie symmetrisch, für kleines drängen sie sich links zusammen.   Wahrscheinlichkeitsfunktionen von (schwarz, gefüllt) und (grau, offen). Die Erwartungswerte sind 2 und 5.   Zwei Stabdiagramme über den Werten 0 bis 10, eines links schief, eines symmetrisch um 5   Über jedem Wert von 0 bis 10 stehen zwei dünne Stäbe nebeneinander. Die schwarzen Stäbe mit gefülltem Punkt gehören zu : Sie haben bei 0 bis 5 die Höhen 0,107; 0,268; 0,302; 0,201; 0,088 und 0,026 und sind danach kaum noch zu sehen. Die grauen Stäbe mit offenem Kreis gehören zu : Sie liegen symmetrisch um 5 mit der größten Höhe 0,246 bei 5 und fallen nach beiden Seiten gleich ab.       Das Modell hinter der Bitfehlertabelle   In wurde jedes der vier Bits eines Blocks mit Wahrscheinlichkeit verfälscht, unabhängig von den anderen.   Welche Verteilung hat die Zahl der fehlerhaften Bits? Leiten Sie die Tabelle aus her.    Bestimmen Sie und mit und vergleichen Sie mit und .    Ein neues Protokoll überträgt Blöcke aus acht Bits über denselben Kanal. Wie viele fehlerhafte Bits enthält ein Block im Mittel, und mit welcher Wahrscheinlichkeit kommt er fehlerfrei an?          Jedes Bit ist ein Bernoulli-Experiment mit Erfolg = verfälscht und , also und      und , dieselben Werte wie in und . Dort brauchte die Varianz fünf Produkte und eine Summe, hier eine Zeile.    Jetzt ist , also und .     Die doppelte Blocklänge verdoppelt die mittlere Fehlerzahl, aber der Anteil fehlerfreier Blöcke fällt von 66 % auf 43 %. Ohne Fehlerkorrektur käme also schon bei acht Bits die Mehrheit der Blöcke beschädigt an. Die Tabelle und das Beispiel des digitalen Kanals stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 3 ( ).     Wann ist eine Anzahl binomialverteilt?  Die Definition verlangt drei Dinge: eine feste Zahl von Versuchen, in jedem Versuch dieselbe Erfolgswahrscheinlichkeit und unabhängige Versuche. Jede dieser Annahmen kann scheitern:    Kein festes . Die Zahl der Verkehrsunfälle eines Monats zählt Ereignisse, keine Versuche. Für solche Anzahlen ist gedacht.     Kein gemeinsames . Unter 100 Besuchern eines Webshops seien 30 Stammkunden, die jeweils mit Wahrscheinlichkeit kaufen, und 70 Laufkunden mit . Die Zahl der Käufe ist dann die Summe zweier unabhängiger binomialverteilter Anzahlen, aber selbst nicht binomialverteilt: Sie hat den Erwartungswert und die Varianz , während mit demselben Erwartungswert die Varianz hätte.     Keine Unabhängigkeit. Zieht man ohne Zurücklegen aus einer kleinen Grundgesamtheit, ist jede einzelne Ziehung zwar mit derselben Wahrscheinlichkeit ein Erfolg, aber ihr Ergebnis ändert die Wahrscheinlichkeiten für die nächste. Das führt auf die hypergeometrische Verteilung ( ). Ebenso fallen Server im selben Rechenzentrum bei einem Stromausfall gemeinsam aus. Wer ihre Ausfälle als unabhängig modelliert, unterschätzt die Wahrscheinlichkeit, dass viele zugleich ausfallen, erheblich.       Überbuchung eines Flugs   Ein Flugzeug hat 250 Plätze. Aus Erfahrung erscheint jede Person mit Ticket mit Wahrscheinlichkeit zum Flug, unabhängig von den anderen; die No-Show -Quote ist also 5 %. Die Fluglinie verkauft Tickets. Sei die Zahl der Personen, die erscheinen.   Wie ist verteilt? Mit welcher Wahrscheinlichkeit muss bei jemand am Boden bleiben?    Dieselbe Frage für . Wie viele Plätze bleiben dann im Mittel leer?    Die Fluglinie will die Wahrscheinlichkeit, jemanden abweisen zu müssen, auf höchstens 0,01 % begrenzen. Wie viele Tickets darf sie verkaufen?           . Bei ist der Flug nur dann überbucht, wenn alle erscheinen: .    Bei reichen 251 oder 252 Erscheinende: Im Mittel erscheinen Personen, es bleiben also gut zehn Plätze leer.    Gesucht ist das größte mit . Diese Wahrscheinlichkeit wächst mit jedem weiteren verkauften Ticket, denn eine zusätzliche Person kann die Zahl der Erscheinenden nur erhöhen. Von Hand wird die Rechnung schnell mühsam, die Code-Zelle unten rechnet sie exakt aus. Für ist die Wahrscheinlichkeit , für schon . Die Fluglinie darf also höchstens 252 Tickets verkaufen.     Obwohl von 250 Personen mit Ticket im Mittel zwölfeinhalb fehlen, erlaubt das strenge Ziel nur zwei zusätzliche Tickets. Mit einem Ziel von 1 % wären es fünf. Wie viel Überbuchung sich lohnt, ist eine Abwägung zwischen entgangenen Ticketerlösen und den Kosten einer Abweisung; die Binomialverteilung liefert dafür die Zahlen. Die fragwürdigste Annahme ist die Unabhängigkeit: Familien und Reisegruppen erscheinen gemeinsam oder gar nicht. Zum Thema siehe auch D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , 2018 ( ).    Die Code-Zelle berechnet die Überbuchungswahrscheinlichkeit für 251 bis 260 verkaufte Tickets, als Zahl der Überbuchungen je Million Flüge; das Ziel von 0,01 % sind 100 je Million. Sie summiert über die Zahl der Personen, die nicht erscheinen, und gewinnt jeden Summanden aus dem vorigen, statt Binomialkoeffizienten mit riesigen Fakultäten auszurechnen.   plaetze, p = 250, 0.95 # Probieren Sie ziel = 0.0001 (0,01 %) und ziel = 0.01 (1 %). ziel = 0.0001 def p_ueberbucht(n): # P(höchstens n - 251 Personen fehlen), Summand für Summand term = p ** n summe = term for j in range(n - plaetze - 1): term = term * (n - j) \/ (j + 1) * (1 - p) \/ p summe = summe + term return summe for n in range(plaetze + 1, plaetze + 11): w = p_ueberbucht(n) marke = \"ok\" if w <= ziel else \"\" print(\"%d Tickets: %9.1f je Million %s\" % (n, w * 1e6, marke))     Die geometrische Verteilung  Statt die Erfolge in Versuchen zu zählen, kann man fragen, wie lange man auf den ersten Erfolg wartet: wie viele Einblendungen bis zum ersten Klick, wie viele Anmeldeversuche bis zum ersten erfolgreichen, wie viele gezogene Kandidaten, bis einer passt.   Geometrische Verteilung  geometrische Verteilung  Verteilung geometrische   Ein Bernoulli-Experiment mit Erfolgswahrscheinlichkeit wird unabhängig so lange wiederholt, bis der erste Erfolg eintritt. Die Zahl der dafür nötigen Versuche, den erfolgreichen mitgezählt, heißt geometrisch verteilt mit Parameter , kurz . Es ist     Die Formel liest man direkt ab: heißt, dass die ersten Versuche misslingen und der -te gelingt, und wegen der Unabhängigkeit multiplizieren sich die Wahrscheinlichkeiten. Die Summe über alle ist die geometrische Reihe , daher der Name.  Vorsicht beim Nachschlagen: Manche Bücher und Programme zählen nicht die Versuche, sondern die Misserfolge vor dem ersten Erfolg. Deren Zufallsvariable ist , mit Werten . In Python zählt scipy.stats.geom wie wir die Versuche, in R zählt dgeom die Misserfolge.   Kennzahlen der geometrischen Verteilung   Für gilt  für ,  ,  .      (1) heißt, dass die ersten Versuche misslingen.  (2) und (3): Für ist , und beide Formeln stimmen. Sei also und . Die geometrische Reihe darf man für gliedweise ableiten: Für die Varianz rechnen wir mit statt mit , weil gerade dazu die zweite Ableitung passt. Wegen und der Linearität ist . Mit folgt und . Nach dem Verschiebungssatz ( ) ist denn .     ist die Formel, die man erwartet: Wer bei jedem Versuch mit Wahrscheinlichkeit Erfolg hat, braucht im Mittel sechs Versuche. Weniger selbstverständlich ist die Streuung. Für kleines ist fast so groß wie der Erwartungswert selbst; Wartezeiten schwanken also stark. zeigt, warum: Der kürzeste Fall ist der wahrscheinlichste, aber die Wahrscheinlichkeiten fallen nur langsam ab.   Wahrscheinlichkeitsfunktion von . Jeder Stab ist das -Fache des vorigen; der Erwartungswert ist .   Stabdiagramm über 1 bis 12 mit gleichmäßig um den Faktor 0,7 fallenden Stäben   Über den Werten 1 bis 12 steht je ein Stab. Der erste ist mit 0,3 der höchste, danach wird jeder Stab um den Faktor 0,7 kürzer: 0,21; 0,147; 0,103; 0,072 und so weiter, bis 0,006 bei 12. Die Stäbe fallen also von links nach rechts gleichmäßig ab, ohne je ganz null zu werden.       Verwerfen und neu ziehen   Ein Programm braucht eine gleichverteilte Zufallszahl aus , hat aber nur einen fairen Würfel. Es würfelt so lange, bis keine 6 fällt, und gibt die zuletzt gewürfelte Zahl aus.  Wie viele Würfe braucht es im Mittel?  Mit welcher Wahrscheinlichkeit braucht es mehr als drei Würfe?   Ist die ausgegebene Zahl tatsächlich gleichverteilt auf ?       Ein Wurf ist ein Erfolg, wenn er keine 6 zeigt. Die Zahl der Würfe ist also -verteilt.  Würfe.    .    Die Ausgabe ist , wenn für ein die ersten Würfe eine 6 zeigen und der -te ein . Summiert über : Jede der fünf Zahlen kommt mit Wahrscheinlichkeit .     Das ist die Verwerfungsmethode Verwerfungsmethode (rejection sampling), ein Standardwerkzeug der Simulation: Man erzeugt Kandidaten aus einer bequemen Verteilung und verwirft die unpassenden. Die Zahl der Kandidaten je Ergebnis ist geometrisch verteilt, die Kosten sind im Mittel Kandidaten bei Annahmewahrscheinlichkeit . Wer gleichverteilte Punkte in der Einheitskreisscheibe braucht und dazu Punkte im umgebenden Quadrat erzeugt, hat und braucht im Mittel Versuche. Im zehndimensionalen Würfel liegt dagegen nur etwa jeder vierhundertste Punkt in der einbeschriebenen Kugel; dort ist die Methode unbrauchbar.    Die wichtigste Eigenschaft der geometrischen Verteilung betrifft bedingte Wahrscheinlichkeiten. Angenommen, die ersten Versuche sind schon misslungen. Wie lange dauert es jetzt noch?   Gedächtnislosigkeit  Gedächtnislosigkeit der geometrischen Verteilung   Für mit und ist     Wegen ist die bedingte Wahrscheinlichkeit nach gleich .    Unter der Bedingung hat die Restwartezeit  also dieselbe Verteilung wie selbst, nämlich , und im Mittel dauert es noch Versuche. Die bisherigen Misserfolge ändern daran nichts: Die Versuche haben kein Gedächtnis. Genau das übersieht der Spielerfehlschluss Spielerfehlschluss , der nach fünfmal Rot beim Roulette Schwarz für fällig hält. Die geometrische Verteilung ist die einzige Verteilung auf mit dieser Eigenschaft (ohne Beweis). Ihr stetiges Gegenstück ist die Exponentialverteilung, die in Wartezeiten in kontinuierlicher Zeit beschreibt.   Was kostet ein Klick?   Ein Werbenetzwerk berechnet 0,01 € je Einblendung einer Suchanzeige. Jede Einblendung führt unabhängig von den anderen mit Wahrscheinlichkeit zu einem Klick.   Wie viele Einblendungen braucht es im Mittel bis zum ersten Klick, und was kostet ein Klick damit im Mittel?    Mit welcher Wahrscheinlichkeit bleiben die ersten 100 Einblendungen ohne Klick?    Eine neue Kampagne hat nach 100 Einblendungen noch keinen Klick. Wie viele weitere Einblendungen braucht sie bei unveränderter Klickrate im Mittel noch bis zum ersten Klick? Die Marketingabteilung vermutet, dass die Klickrate gesunken ist. Stützt die Beobachtung diese Vermutung?       Die Zahl der Einblendungen bis zum ersten Klick ist -verteilt.    Einblendungen, also kostet ein Klick im Mittel  €. Allgemein ist der Preis je Klick der Preis je Einblendung geteilt durch die Klickrate.     .    Nach ist die Restwartezeit wieder -verteilt: im Mittel noch 50 Einblendungen, genauso viele wie am Anfang. Die 100 Einblendungen ohne Klick bringen den ersten Klick nicht näher. Nach (b) wartet gut jede achte Kampagne mit unveränderter Klickrate länger als 100 Einblendungen auf ihren ersten Klick; die Standardabweichung der Wartezeit ist mit fast so groß wie ihr Erwartungswert. Die Beobachtung ist also nicht ungewöhnlich und stützt die Vermutung kaum.     Aus einer einzelnen langen Wartezeit auf eine veränderte Rate zu schließen, wäre voreilig; dafür streut die geometrische Verteilung zu stark. In der Onlinewerbung heißt die Größe aus (a) Cost per Click , und die Rechnung zeigt, warum sie sich halbiert, wenn sich die Klickrate verdoppelt. Übrigens ist fast genau . Das ist kein Zufall, wie zeigt.      Die Poisson-Verteilung  Viele Anzahlen haben keine feste Zahl von Versuchen: die Anfragen an einen Server in einer Sekunde, die Anrufe in einem Callcenter in einer Stunde, die Fehlerstellen in einem Meter Kupferkabel. Man kann sie trotzdem mit der Binomialverteilung fassen. Enthält das Kabel im Mittel Fehler, so teilt man es in gleich lange Stücke. Bei feiner Teilung enthält jedes Stück höchstens einen Fehler, und zwar mit einer Wahrscheinlichkeit, die proportional zu seiner Länge ist, also . Sind die Stücke unabhängig, ist die Fehlerzahl -verteilt. Was passiert, wenn immer größer wird?   Poissonscher Grenzwertsatz  poissonscher Grenzwertsatz  Grenzwertsatz poissonscher  Poisson-Näherung   Sei , und für jedes sei . Dann gilt für jedes      Nach ist Der zweite Faktor ist und strebt gegen 1, ebenso der vierte. Der dritte strebt nach der aus der Analysis bekannten Grenzwertformel gegen .    Die Grenzwerte sind nichtnegativ und summieren sich wegen der Exponentialreihe zu 1. Sie bilden also selbst eine Wahrscheinlichkeitsfunktion.   Poisson-Verteilung  Poisson-Verteilung   Eine Zufallsvariable mit Werten in und heißt Poisson-verteilt mit Parameter , kurz .     Erwartungswert und Varianz der Poisson-Verteilung   Für ist und .    Im Summanden für steht der Faktor 0, und für ist . Also ist denn die letzte Summe ist die Summe aller Werte der Wahrscheinlichkeitsfunktion. Genauso ist, mit demselben Kunstgriff wie im Beweis von , und damit .    Das passt zur Herleitung: hat den Erwartungswert und die Varianz , die gegen strebt. Dass Erwartungswert und Varianz übereinstimmen, ist eine prüfbare Eigenschaft des Poisson-Modells. Streuen beobachtete Anzahlen deutlich stärker, als ihr Mittelwert erwarten lässt, so passt kein Poisson-Modell.  Wann ist eine Anzahl Poisson-verteilt? Die Herleitung zeigt es:   Die Ereignisse treten einzeln auf; zwei fallen nie auf genau denselben Zeitpunkt oder dieselbe Stelle.    Die Wahrscheinlichkeit für ein Ereignis in einem kurzen Teilstück hängt nur von dessen Länge ab, nicht von seiner Lage.    Was in verschiedenen, sich nicht überlappenden Teilstücken geschieht, ist unabhängig.   Treffen Ereignisse so ein, im Mittel je Zeiteinheit, spricht man von einem Poisson-Prozess Poisson-Prozess mit Rate Rate eines Poisson-Prozesses  . Die Zahl der Ereignisse in einem Zeitraum der Länge ist dann -verteilt: Dieselbe Herleitung, angewandt auf einen Zeitraum der Länge , liefert eine Poisson-Verteilung, und ihr Parameter ist die mittlere Anzahl . Vorsicht mit dem Buchstaben : Bisher stand er für eine mittlere Anzahl, beim Poisson-Prozess steht er für eine Rate je Zeiteinheit; der Parameter der Poisson-Verteilung bleibt die mittlere Anzahl, jetzt also . Die Anzahlen in Zeiträumen, die sich nicht überlappen, sind unabhängig. Zum Rechnen von Hand hilft für die Rekursion Man beginnt bei und multipliziert sich nach oben.   Anrufe in einem Callcenter   Die Anrufe bei einem Callcenter bilden einen Poisson-Prozess mit im Mittel 30 Anrufen je Stunde.   Mit welcher Wahrscheinlichkeit geht in drei Minuten kein Anruf ein?    Mit welcher Wahrscheinlichkeit gehen in sechs Minuten höchstens zwei Anrufe ein?    Wie lang darf eine Pause höchstens sein, damit in ihr mit Wahrscheinlichkeit mindestens 90 % kein Anruf eingeht?       Die Rate ist Anrufe je Minute.   In drei Minuten ist die Zahl der Anrufe -verteilt, und .    In sechs Minuten ist sie -verteilt. Mit der Rekursion ist     In einer Pause von Minuten geht mit Wahrscheinlichkeit kein Anruf ein. Aus folgt durch Logarithmieren Minuten, also knapp 13 Sekunden.     Für die Planung heißt (c): Schon eine Pause von 13 Sekunden verpasst in jedem zehnten Fall mindestens einen Anruf; ohne Warteschleife oder Vertretung geht es nicht. Wie unregelmäßig ein Poisson-Strom ist, zeigt ein Vergleich: Kämen die Anrufe pünktlich alle zwei Minuten, bliebe keine Pause von zwei Minuten ungestört. Beim Poisson-Strom mit derselben Rate ist das mit Wahrscheinlichkeit der Fall. Lange Lücken und kurz aufeinanderfolgende Anrufe sind beide häufiger als beim gleichmäßigen Takt.    Die Herleitung liefert zugleich eine Näherung. Ist groß und klein, so ist Das ist nützlich, weil die Binomialverteilung für großes von Hand kaum auszuwerten ist, die Poisson-Verteilung dagegen nur den Parameter braucht. Wie gut die Näherung ist, sagt der Satz von Le Cam Satz von Le Cam Le Cam, Satz von (ohne Beweis; ): Für jede Menge von Werten unterscheidet sich die Wahrscheinlichkeit von unter beiden Verteilungen um höchstens . zeigt schon für eine grobe Übereinstimmung.   Wahrscheinlichkeitsfunktionen von (grau, offen) und (schwarz, gefüllt). Beide haben den Erwartungswert 3.   Zwei ähnliche Stabdiagramme mit Gipfel bei 2 bis 3, das Poisson-Diagramm etwas breiter   Über den Werten 0 bis 10 stehen je zwei Stäbe nebeneinander. Die grauen Stäbe gehören zu und erreichen ihr Maximum 0,267 bei 3. Die schwarzen gehören zu und sind bei 2 und 3 mit je 0,224 gleich hoch. Die Poisson-Stäbe sind in der Mitte etwas niedriger und an den Rändern, bei 0 und 1 sowie ab 6, etwas höher: Die Poisson-Verteilung streut mit Varianz 3 stärker als die Binomialverteilung mit Varianz 2,1.       Bitfehler in einem Datenpaket   Ein Datenpaket besteht aus Bits. Jedes wird unabhängig von den anderen mit Wahrscheinlichkeit verfälscht.   Welche Verteilung hat die Zahl der Bitfehler im Paket exakt, und durch welche Poisson-Verteilung lässt sie sich nähern? Wie groß ist der Fehler der Näherung höchstens?    Mit welcher Wahrscheinlichkeit ist das Paket fehlerfrei? Ein Code korrigiert bis zu zwei Bitfehler je Paket. Mit welcher Wahrscheinlichkeit kommt das Paket nach der Korrektur richtig an?    Vergleichen Sie mit den exakten Werten.          Exakt ist , genähert mit . Der Fehler ist höchstens .     und     Exakt ist und . Die Werte stimmen auf vier Stellen überein; der tatsächliche Fehler liegt noch unter der Schranke aus (a).     Ohne Korrektur käme nicht einmal ein Drittel der Pakete fehlerfrei an, mit einem Code für zwei Fehler sind es 88 %. Für die Auslegung eines Codes braucht man genau solche Zahlen, und die Poisson-Näherung liefert sie mit einem einzigen Parameter, gleich wie viele Bits ein Paket hat.    Die folgende Zelle stellt die Wahrscheinlichkeiten von und nebeneinander. Beide werden mit einer Rekursion berechnet wie oben.   import math # Probieren Sie n = 10, 100, 1000. n = 10 lam = 3 p = lam \/ n binomial = (1 - p) ** n poisson = math.exp(-lam) print(\" k Binomial Poisson\") for k in range(min(9, n + 1)): print(\"%2d %.4f %.4f\" % (k, binomial, poisson)) binomial = binomial * (n - k) \/ (k + 1) * p \/ (1 - p) poisson = poisson * lam \/ (k + 1)    Seltene Ereignisse  Die Poisson-Näherung beantwortet auch die dritte Frage vom Anfang des Abschnitts. Finden in einer Stunde Einblendungen statt, von denen jede mit Wahrscheinlichkeit einen Klick bringt, so ist die Klickzahl ; bei 5000 Einblendungen also etwa . Die Schranke von Le Cam hilft hier nicht weiter, denn . Für großes ist sie grob. Es gilt auch die Schranke , die für schärfer ist (ohne Beweis; Barbour und Hall 1984), hier also . Tatsächlich weichen die Wahrscheinlichkeiten um knapp ab. Die erste Frage ist schon nach beantwortet, die zweite in .  Außerdem erklärt die Näherung zwei Zahlen aus früheren Beispielen. In war : Die Zahl der Klicks in 100 Einblendungen ist , und kein Klick hat Wahrscheinlichkeit etwa . In war für die Zahl der kollidierenden Paare. Dort sind die gezählten Ereignisse nicht einmal unabhängig, aber jedes ist selten, und die Abhängigkeit ist schwach. Unter solchen Bedingungen ist eine Anzahl oft immer noch ungefähr Poisson-verteilt (ohne Beweis). Deshalb taucht die Poisson-Verteilung überall dort auf, wo viele Gelegenheiten für ein seltenes Ereignis bestehen.  Quelle der Schranke : A. D. Barbour und P. Hall, On the rate of Poisson convergence, Mathematical Proceedings of the Cambridge Philosophical Society 95 (1984), 473 480 ( ).     Steckbrief: die hypergeometrische Verteilung  hypergeometrische Verteilung  Verteilung hypergeometrische  Die folgenden drei Verteilungen lernen Sie als Steckbrief kennen: wann sie auftreten, wie sie aus einer der vier Grundverteilungen hervorgehen, ihre Formeln und ein Beispiel. Entscheidend ist die Herkunft; die Formeln muss man nicht auswendig können, wohl aber die Situation erkennen.   Wann  Aus einer endlichen Grundgesamtheit von Stücken, von denen eine Eigenschaft haben (defekt, markiert, Gewinnzahl), werden Stücke ohne Zurücklegen gezogen. zählt die gezogenen Stücke mit der Eigenschaft. Typisch sind Stichprobenkontrollen einer Lieferung, das Lotto und das Aufteilen eines Datensatzes in Trainings- und Testdaten.  Wir schreiben : zuerst die Größe der Grundgesamtheit, dann die Zahl der Stücke mit der Eigenschaft, zuletzt den Stichprobenumfang, ganze Zahlen mit und . Die Reihenfolge und sogar die Buchstaben sind in der Literatur nicht einheitlich. scipy.stats.hypergeom etwa erwartet dieselben drei Zahlen in derselben Reihenfolge, nennt sie aber M (Grundgesamtheit), n (Stücke mit der Eigenschaft) und N (Stichprobenumfang).    Woher  Zieht man die Stücke nacheinander, so ist die Wahrscheinlichkeit, zuerst Stücke mit und dann ohne die Eigenschaft zu ziehen, Jede andere Reihenfolge hat dieselbe Wahrscheinlichkeit, nur mit vertauschten Faktoren im Zähler, und es gibt Reihenfolgen. Das ergibt die Formel unten, die man ebenso als Laplace-Wahrscheinlichkeit wie in erhält. Sind und groß gegen , so ist jeder Faktor fast bzw. fast , und es bleibt : Ohne Zurücklegen aus einer großen Grundgesamtheit zu ziehen ist fast dasselbe wie mit Zurücklegen, denn die Entnahme ändert die Anteile kaum. Tatsächlich genügt schon, dass klein gegen ist: Für jede Menge von Werten unterscheiden sich die Wahrscheinlichkeiten unter beiden Verteilungen um höchstens (ohne Beweis; die Schranke stammt von S. Holmes , hier zitiert nach Dümbgen, Samworth und Wellner ).  Den Erwartungswert liefert die Indikatormethode aus . Sei das Ereignis, dass die -te Ziehung ein Stück mit der Eigenschaft bringt. Jedes der Stücke landet mit derselben Wahrscheinlichkeit an Position , also ist . Mit und der Linearität folgt , derselbe Wert wie bei . Dass die voneinander abhängen, stört die Linearität nicht.    Formeln  Für ist für alle mit und . Die Varianz steht hier ohne Beweis. Man erhält sie wie bei der Binomialverteilung als Varianz einer Summe von Indikatoren, muss dabei aber deren Abhängigkeit berücksichtigen; wie das geht, zeigt . Der letzte Faktor, die Endlichkeitskorrektur Endlichkeitskorrektur , ist für kleiner als 1: Ohne Zurücklegen streut weniger als bei der Binomialverteilung, weil jede Ziehung etwas über die übrigen Stücke verrät. Ist klein gegen , ist er fast 1.    Noch einmal die Stichprobenkontrolle   In werden aus einer Lieferung von 50 Sensoren, von denen drei defekt sind, fünf ohne Zurücklegen geprüft. Sei die Zahl der defekten Sensoren in der Stichprobe. Geben Sie die Verteilung von und an, und vergleichen Sie und mit der Binomialnäherung.     und . Exakt ist wie in und . Die Binomialnäherung liefert und .  Die Stichprobe umfasst ein Zehntel der Lieferung. Die Näherung überschätzt um einen Prozentpunkt und die Varianz um knapp 10 %. Für eine schnelle Abschätzung reicht das; wer ein Prüfverfahren vertraglich festlegt, rechnet exakt.      Steckbrief: die negative Binomialverteilung  negative Binomialverteilung  Binomialverteilung negative   Wann  Man wartet nicht auf den ersten, sondern auf den -ten Erfolg: die Zahl der Kundengespräche bis zum dritten Abschluss, die Zahl der untersuchten Proben, bis eine Studie genug Fälle beisammen hat, die Zahl der Anfragen, bis ein Server seinen fünften Fehler meldet. Wir schreiben für die Zahl der Versuche bis einschließlich zum -ten Erfolg, bei Erfolgswahrscheinlichkeit je Versuch, mit und . Für ist das .    Woher  Sei die Zahl der Versuche bis zum ersten Erfolg, die Zahl der weiteren Versuche bis zum zweiten und so fort. Nach jedem Erfolg beginnt das Warten mit neuen, unabhängigen Versuchen von vorn. Genauer: und heißt, dass die Versuche und gelingen und alle anderen der ersten misslingen. Das hat die Wahrscheinlichkeit . Summiert man über alle , bleibt : Auch ist -verteilt, und die gemeinsame Wahrscheinlichkeit ist das Produkt . Ebenso geht es für mehr als zwei Wartezeiten. Die sind also unabhängig und -verteilt, und Aus , der Linearität und folgen sofort und . Die Wahrscheinlichkeitsfunktion liest man direkt ab: heißt, dass der -te Versuch ein Erfolg ist und unter den ersten genau Erfolge sind. Nach hat das die Wahrscheinlichkeit . Ebenso direkt ist die Verbindung zur Binomialverteilung: Höchstens Versuche bis zum -ten Erfolg braucht man genau dann, wenn unter den ersten Versuchen mindestens Erfolge sind. Mit ist also .    Formeln  Für ist Wie bei der geometrischen Verteilung zählen manche Programme statt der Versuche die Misserfolge, also . In der Statistik dient eine Variante der negativen Binomialverteilung außerdem als Modell für Zähldaten, die stärker streuen, als eine Poisson-Verteilung erlaubt.    Drei Abschlüsse   Ein Vertriebsteam braucht in diesem Monat noch drei Abschlüsse. Jedes Kundengespräch führt unabhängig von den anderen mit Wahrscheinlichkeit zum Abschluss. Wie viele Gespräche braucht es im Mittel, mit welcher Standardabweichung? Mit welcher Wahrscheinlichkeit braucht es genau vier Gespräche, mit welcher höchstens sechs?    Die Zahl der Gespräche ist -verteilt, also und . Weiter ist , und mit ist   Zwölf Gespräche im Mittel, aber mit einer Standardabweichung von sechs: Wer die Monatsplanung auf den Erwartungswert baut, sollte einen deutlichen Puffer einplanen.      Steckbrief: die Multinomialverteilung  Multinomialverteilung   Wann  Ein Versuch hat nicht zwei, sondern mögliche Ausgänge, die Klassen , mit Wahrscheinlichkeiten und . In unabhängigen Wiederholungen zählt , wie oft Klasse eintritt. Die Anzahlen heißen dann gemeinsam multinomialverteilt, kurz . Beispiele sind die Antworten auf eine Umfragefrage mit Optionen, die Klassen von eingehenden Supporttickets und die Wörter eines Textes aus einem Wortschatz.    Woher  Für ist das die Binomialverteilung: zählt die Erfolge, die Misserfolge. Allgemein hat eine feste Folge von Ausgängen, in der genau Ausgänge zur Klasse gehören, wegen der Unabhängigkeit die Wahrscheinlichkeit . Wie viele solche Folgen es gibt, sagt zu Anordnungen mit Sorten: . Betrachtet man nur eine Klasse und fasst alle übrigen zu Misserfolg zusammen, so ist . Daraus kommen Erwartungswert und Varianz jeder einzelnen Anzahl. Die Anzahlen sind aber nicht unabhängig, denn sie summieren sich zu : Kommt eine Klasse oft vor, bleibt für die anderen weniger. Wie man diesen Zusammenhang misst, zeigt .    Formeln  Für ganze Zahlen mit ist Für heißt die Verteilung auch kategorial kategoriale Verteilung Verteilung kategoriale . Ein Klassifikator mit Softmax-Ausgabe liefert für jede Eingabe genau einen solchen Vektor , wie in , und ein Sprachmodell zieht das nächste Wort aus einer kategorialen Verteilung über seinen Wortschatz. Die Kreuzentropie, mit der man solche Modelle trainiert, ist die negative Log-Likelihood dieser Verteilung; dazu mehr im Absatz Kreuzentropie von .    Supporttickets in drei Klassen   Ein eingehendes Supportticket betrifft mit Wahrscheinlichkeit die Technik, mit die Rechnung und mit etwas anderes, unabhängig von den übrigen Tickets. Mit welcher Wahrscheinlichkeit betreffen von fünf Tickets genau drei die Technik, eines die Rechnung und eines etwas anderes? Wie viele der fünf betreffen im Mittel die Technik?    Seien , und die Zahlen der Tickets zu Technik, Rechnung und Sonstigem unter den fünf. Sie sind gemeinsam -verteilt, also und .  Diese Aufteilung ist die wahrscheinlichste (die zweitwahrscheinlichste, , hat ), und doch trifft man sie nur in 15 % der Fälle. Wer ein Team nach den erwarteten Anteilen besetzt, muss mit deutlichen Schwankungen der Tagesaufteilung rechnen.      Überblick: die Karte der diskreten Verteilungen  Verteilungen diskrete, Überblick   stellt die Verteilungen dieses Abschnitts mit ihren Kennzahlen zusammen, dazu die diskrete Gleichverteilung vom Anfang; die Wahrscheinlichkeitsfunktionen stehen in den einzelnen Unterabschnitten. Wichtiger als die Tabelle ist die Karte in : Fast jede Verteilung hängt mit einer anderen zusammen, als Summe, als Wartezeit, als Grenzfall oder als Verallgemeinerung. Wer die Pfeile kennt, kann die meisten Formeln der Tabelle wieder herleiten.   Die diskrete Gleichverteilung als Rückblick, die vier Grundverteilungen und die drei Steckbriefe        Verteilung  Situation       jeder der Werte gleich wahrscheinlich       ein Versuch, bei Erfolg       Erfolge in unabhängigen Versuchen       Versuche bis zum ersten Erfolg       seltene Ereignisse in einem Zeitraum       Stichprobe ohne Zurücklegen,       Versuche bis zum -ten Erfolg       Anzahlen je Klasse in Versuchen (Kennzahlen je )        Die Verwandtschaften der diskreten Verteilungen. Fett umrandet sind die vier Grundverteilungen, dünn die Steckbriefe, gestrichelt die stetigen Verteilungen späterer Kapitel.   Diagramm aus neun Kästen mit Pfeilen, oben Bernoulli, darunter Binomial und geometrisch, daraus die übrigen Verteilungen   Oben steht der Kasten Bernoulli. Ein Pfeil mit der Beschriftung Summe von n unabhängigen führt nach links unten zu Binomial, ein zweiter mit Warten auf den ersten Erfolg nach rechts unten zu geometrisch. Links neben Binomial steht hypergeometrisch mit einem Pfeil N gegen unendlich, M durch N gegen p zu Binomial. Von Binomial führt ein Pfeil n gegen unendlich, np = lambda nach unten zu Poisson und ein Pfeil m Klassen statt 2 nach links unten zu Multinomial. Von geometrisch führt ein Pfeil Summe von r unabhängigen nach unten zu negativ binomial. Gestrichelte Pfeile führen von Binomial ( n p mal 1 minus p groß ) und von Poisson ( großes lambda ) zu einem gestrichelten Kasten Normal, Kapitel 3 und 5, und von geometrisch ( stetiges Gegenstück ) nach rechts unten zu einem gestrichelten Kasten Exponential, Kapitel 3.      Drei Verbindungen führen über dieses Kapitel hinaus. Die geometrische Verteilung hat in der Exponentialverteilung ein stetiges Gegenstück mit derselben Gedächtnislosigkeit ( ). Binomial- und Poisson-Verteilung werden für große Varianz bzw. großes glockenförmig und lassen sich dann durch die Normalverteilung nähern; das ist eine Folge des zentralen Grenzwertsatzes ( ). Und wer die Erfolgswahrscheinlichkeit einer Binomialverteilung aus Daten schätzen will, kann sein Vorwissen über mit der Betaverteilung beschreiben, beim Parameter einer Poisson-Verteilung mit der Gammaverteilung ( und ).   Welche Verteilung passt?   Geben Sie jeweils Verteilung und Parameter an und nennen Sie die Annahme, auf der das Modell beruht.   Die Zahl der Anfragen, die ein Webserver in einer Minute erhält, wenn im Mittel vier je Minute eintreffen.    Die Zahl der Spam-Mails unter den nächsten 20 E-Mails, wenn 30 % aller Mails Spam sind.    Die Zahl der Lose, die man bis zum ersten Gewinn kauft, wenn jedes Los mit Wahrscheinlichkeit gewinnt.    Die Zahl der Frauen in einem Ausschuss aus vier Personen, der aus sechs Frauen und sechs Männern ausgelost wird.    Die Zahl der Würfe mit einem fairen Würfel, bis zum zweiten Mal eine Sechs fällt.    Wie oft jede von drei Varianten einer Webseite unter 90 Besuchern gezeigt wird, wenn jeder Besucher unabhängig mit Wahrscheinlichkeit einer der Varianten zugeteilt wird.           , wenn die Anfragen von vielen Nutzern unabhängig voneinander kommen und die Rate über die Minute gleich bleibt. Ein Crawler, der zehn Anfragen auf einmal schickt, verletzt die Annahme.     , wenn jede Mail unabhängig mit derselben Wahrscheinlichkeit Spam ist. Spam kommt oft in Wellen; dann ist die Unabhängigkeit fraglich.     , wenn die Lose unabhängig gewinnen. Stammen sie aus einem festen Vorrat mit genau 10 % Gewinnen, ist das nur eine Näherung, die für einen großen Vorrat gut ist.     : Es wird ohne Zurücklegen aus einer kleinen Grundgesamtheit gezogen, eine Binomialnäherung wäre hier grob.     , weil die Würfe unabhängig sind.     für die drei Anzahlen; jede einzelne ist -verteilt.     Die Wahl der Verteilung ist eine Modellannahme, keine Rechnung. Sie steht am Anfang jeder Auswertung und verdient deshalb dieselbe Sorgfalt wie das Rechnen danach: Eine exakt ausgewertete Formel für das falsche Modell hilft niemandem.      Zusammenfassung      Bernoulli und Binomial. Ein Versuch mit Erfolg (Wahrscheinlichkeit ) oder Misserfolg ist , mit und . Die Zahl der Erfolge in unabhängigen Versuchen ist mit , und , hergeleitet als Summe von Indikatorvariablen.     Modellannahmen. Binomialverteilt ist eine Anzahl nur bei fester Versuchszahl, gleicher Erfolgswahrscheinlichkeit und unabhängigen Versuchen. Die Wahl der Verteilung ist eine Annahme, die man benennt und prüft.     Geometrisch. Die Zahl der Versuche bis einschließlich zum ersten Erfolg ist mit für , , und .     Gedächtnislosigkeit.  : Nach Misserfolgen ist die Restwartezeit wieder -verteilt.     Poisson.  hat für und . In einem Poisson-Prozess mit Rate ist die Zahl der Ereignisse in einem Zeitraum der Länge  -verteilt, und Anzahlen in Zeiträumen, die sich nicht überlappen, sind unabhängig.     Poisson-Näherung. Für großes und kleines ist ; jede Wahrscheinlichkeit weicht um höchstens ab.     Steckbriefe.  zählt beim Ziehen ohne Zurücklegen, mit , und geht für klein gegen in über. ist die Verteilung der Summe von unabhängigen -Variablen, mit Erwartungswert . zählt Klassen; jede Anzahl allein ist -verteilt.       Übungsaufgaben   Eine kleine Umfrage   Sechs zufällig ausgewählte Personen werden gefragt, ob sie einem Vorschlag zustimmen. Jede stimmt unabhängig von den anderen mit Wahrscheinlichkeit zu. Sei die Zahl der Zustimmungen.  Bestimmen Sie .  Bestimmen Sie .  Bestimmen Sie und .       , und jede der Antwortfolgen hat die Wahrscheinlichkeit .  .  .  und .       Warten auf die erste Sechs   Ein fairer Würfel wird geworfen, bis zum ersten Mal eine Sechs fällt.  Mit welcher Wahrscheinlichkeit braucht man genau drei Würfe?  Mit welcher Wahrscheinlichkeit braucht man mehr als sechs Würfe?  Bestimmen Sie die Standardabweichung der Zahl der Würfe. Was sagt sie über die Planbarkeit?      Die Zahl der Würfe ist -verteilt.  .    . In einem Drittel der Fälle reichen sechs Würfe also nicht.     , also , fast so groß wie der Erwartungswert 6. Wie lange man warten muss, ist kaum vorherzusagen.        Ein unzuverlässiger Test   Ein automatischer Test in einer Softwareentwicklung schlägt bei jedem Lauf unabhängig von den anderen Läufen mit Wahrscheinlichkeit zufällig fehl, obwohl der Code in Ordnung ist.  Wie viele Läufe vergehen im Mittel bis zum ersten Fehlschlag, diesen mitgezählt?   Seit dem letzten Fehlschlag liefen 30 Läufe fehlerfrei. Wie viele Läufe dauert es im Mittel noch bis zum nächsten Fehlschlag? Mit welcher Wahrscheinlichkeit laufen die nächsten zehn fehlerfrei?    Vom ersten Lauf an gezählt: Mit welcher Wahrscheinlichkeit fällt der erste Fehlschlag in einen der Läufe 1 bis 10, mit welcher in einen der Läufe 11 bis 20? Warum ist die zweite Wahrscheinlichkeit kleiner?         Die Zahl der Läufe bis einschließlich zum ersten Fehlschlag ist -verteilt, im Mittel .   Wegen der Gedächtnislosigkeit ist die Restwartezeit wieder -verteilt: im Mittel noch 20 Läufe. Die nächsten zehn laufen mit Wahrscheinlichkeit fehlerfrei, genauso wie zu Beginn.     und . Damit der erste Fehlschlag in die zweite Zehnergruppe fällt, muss die erste ohne Fehlschlag bleiben; danach beginnt nach der Gedächtnislosigkeit alles von vorn. Die Wahrscheinlichkeit jeder Zehnergruppe ist deshalb das -Fache, etwa das -Fache, der vorigen, wie bei den Stäben in .        Ein Gewinnspiel   Bei einem Gewinnspiel gewinnt jedes Los unabhängig mit Wahrscheinlichkeit . Jemand kauft 500 Lose.   Nähern Sie die Wahrscheinlichkeit für mindestens einen und für mindestens zwei Gewinne mit der Poisson-Verteilung.    Bis zu wie vielen Losen bleibt die Schranke von Le Cam für den Fehler der Poisson-Näherung höchstens ?          Die Zahl der Gewinne ist . Damit ist und .    Die Schranke ist ; sie bleibt bis Losen höchstens . Für die 500 Lose aus (a) ist sie . Die zweite Schranke aus ist hier für jede Zahl von Losen gleich ; erst bei mehr als 1000 Losen ist sie die bessere.        Wer streut stärker?    und haben denselben Erwartungswert. Welche der beiden Zufallsvariablen hat die größere Varianz, und um welchen Faktor unterscheiden sich die Varianzen? Wann ist der Unterschied unerheblich?     . Die Varianz von ist also um den Faktor größer, die Standardabweichung um den Faktor . Für kleines sind beide Faktoren fast 1; genau dort ist die Poisson-Näherung auch gedacht. Für dagegen hat die Poisson-Verteilung die doppelte Varianz, und die Näherung taugt nichts.     "
},
{
  "id": "sec-diskrete-verteilungen-2",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sec-diskrete-verteilungen-2",
  "type": "Lernziele",
  "number": "2.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     zu einer Situation die passende Verteilung wählen, ihre Parameter angeben und die Modellannahmen benennen: Unabhängigkeit, gleiche Erfolgswahrscheinlichkeit, konstante Rate,    Wahrscheinlichkeiten, Erwartungswert und Varianz der Binomial-, der geometrischen und der Poisson-Verteilung berechnen, auch in Rückrichtung: welcher Parameter zu einer geforderten Wahrscheinlichkeit passt,    Erwartungswert und Varianz dieser Verteilungen herleiten, bei der Binomialverteilung aus Indikatorvariablen,    die Gedächtnislosigkeit der geometrischen Verteilung erklären und anwenden,    begründen, wann die Poisson-Verteilung die Binomialverteilung annähert, und die Näherung einsetzen,    die hypergeometrische, die negative Binomial- und die Multinomialverteilung an ihrer Situation erkennen und auf die vier Grundverteilungen zurückführen.    "
},
{
  "id": "sub-bernoulli-binomial-2",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-bernoulli-binomial-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "diskret gleichverteilt "
},
{
  "id": "def-bernoulli-verteilung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#def-bernoulli-verteilung",
  "type": "Definition",
  "number": "2.2.1",
  "title": "Bernoulli-Experiment, Bernoulli-Verteilung.",
  "body": " Bernoulli-Experiment, Bernoulli-Verteilung  Bernoulli-Verteilung  Bernoulli-Experiment   Ein Zufallsexperiment mit genau zwei Ausgängen, Erfolg mit Wahrscheinlichkeit und Misserfolg mit Wahrscheinlichkeit , heißt Bernoulli-Experiment . Eine Zufallsvariable mit heißt Bernoulli-verteilt mit Parameter , kurz .   "
},
{
  "id": "thm-bernoulli-kennzahlen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-bernoulli-kennzahlen",
  "type": "Satz",
  "number": "2.2.2",
  "title": "Erwartungswert und Varianz der Bernoulli-Verteilung.",
  "body": " Erwartungswert und Varianz der Bernoulli-Verteilung   Für ist und .    Mit und ist nach , und steht in .   "
},
{
  "id": "def-binomialverteilung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#def-binomialverteilung",
  "type": "Definition",
  "number": "2.2.3",
  "title": "Binomialverteilung.",
  "body": " Binomialverteilung  Binomialverteilung   Ein Bernoulli-Experiment mit Erfolgswahrscheinlichkeit wird -mal unabhängig wiederholt. Die Zahl der Erfolge heißt binomialverteilt mit Parametern und , kurz . Auf den Folien der Vorlesung steht dafür auch .   "
},
{
  "id": "thm-binomial-wahrscheinlichkeitsfunktion",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-binomial-wahrscheinlichkeitsfunktion",
  "type": "Satz",
  "number": "2.2.4",
  "title": "Wahrscheinlichkeitsfunktion der Binomialverteilung.",
  "body": " Wahrscheinlichkeitsfunktion der Binomialverteilung   Für ist     Das Ergebnis der Versuche ist eine Folge aus Erfolgen und Misserfolgen. Eine feste Folge mit genau Erfolgen hat wegen der Unabhängigkeit die Wahrscheinlichkeit , denn sie ist ein Produkt aus Faktoren und Faktoren , nur in anderer Reihenfolge. Die Folge ist festgelegt, sobald man weiß, an welchen der Stellen die Erfolge stehen; dafür gibt es nach  Möglichkeiten. Verschiedene Folgen schließen sich gegenseitig aus, ihre Wahrscheinlichkeiten addieren sich. Nach dem binomischen Lehrsatz ist die Summe über alle gleich , wie es sein muss.   "
},
{
  "id": "thm-binomial-kennzahlen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-binomial-kennzahlen",
  "type": "Satz",
  "number": "2.2.5",
  "title": "Erwartungswert und Varianz der Binomialverteilung.",
  "body": " Erwartungswert und Varianz der Binomialverteilung   Für ist     Sei die Indikatorvariable des Erfolgs im -ten Versuch. Dann ist , die sind unabhängig, weil die Versuche es sind, und jedes ist -verteilt. Mit und der Linearität ( ) ist , und nach addieren sich die Varianzen zu .   "
},
{
  "id": "fig-binomial-stabdiagramme",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#fig-binomial-stabdiagramme",
  "type": "Abbildung",
  "number": "2.2.6",
  "title": "",
  "body": " Wahrscheinlichkeitsfunktionen von (schwarz, gefüllt) und (grau, offen). Die Erwartungswerte sind 2 und 5.   Zwei Stabdiagramme über den Werten 0 bis 10, eines links schief, eines symmetrisch um 5   Über jedem Wert von 0 bis 10 stehen zwei dünne Stäbe nebeneinander. Die schwarzen Stäbe mit gefülltem Punkt gehören zu : Sie haben bei 0 bis 5 die Höhen 0,107; 0,268; 0,302; 0,201; 0,088 und 0,026 und sind danach kaum noch zu sehen. Die grauen Stäbe mit offenem Kreis gehören zu : Sie liegen symmetrisch um 5 mit der größten Höhe 0,246 bei 5 und fallen nach beiden Seiten gleich ab.     "
},
{
  "id": "ex-bitfehler-modell",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-bitfehler-modell",
  "type": "Beispiel",
  "number": "2.2.7",
  "title": "Das Modell hinter der Bitfehlertabelle.",
  "body": " Das Modell hinter der Bitfehlertabelle   In wurde jedes der vier Bits eines Blocks mit Wahrscheinlichkeit verfälscht, unabhängig von den anderen.   Welche Verteilung hat die Zahl der fehlerhaften Bits? Leiten Sie die Tabelle aus her.    Bestimmen Sie und mit und vergleichen Sie mit und .    Ein neues Protokoll überträgt Blöcke aus acht Bits über denselben Kanal. Wie viele fehlerhafte Bits enthält ein Block im Mittel, und mit welcher Wahrscheinlichkeit kommt er fehlerfrei an?          Jedes Bit ist ein Bernoulli-Experiment mit Erfolg = verfälscht und , also und      und , dieselben Werte wie in und . Dort brauchte die Varianz fünf Produkte und eine Summe, hier eine Zeile.    Jetzt ist , also und .     Die doppelte Blocklänge verdoppelt die mittlere Fehlerzahl, aber der Anteil fehlerfreier Blöcke fällt von 66 % auf 43 %. Ohne Fehlerkorrektur käme also schon bei acht Bits die Mehrheit der Blöcke beschädigt an. Die Tabelle und das Beispiel des digitalen Kanals stammen aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 3 ( ).   "
},
{
  "id": "rem-binomial-annahmen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#rem-binomial-annahmen",
  "type": "Bemerkung",
  "number": "2.2.8",
  "title": "Wann ist eine Anzahl binomialverteilt?",
  "body": " Wann ist eine Anzahl binomialverteilt?  Die Definition verlangt drei Dinge: eine feste Zahl von Versuchen, in jedem Versuch dieselbe Erfolgswahrscheinlichkeit und unabhängige Versuche. Jede dieser Annahmen kann scheitern:    Kein festes . Die Zahl der Verkehrsunfälle eines Monats zählt Ereignisse, keine Versuche. Für solche Anzahlen ist gedacht.     Kein gemeinsames . Unter 100 Besuchern eines Webshops seien 30 Stammkunden, die jeweils mit Wahrscheinlichkeit kaufen, und 70 Laufkunden mit . Die Zahl der Käufe ist dann die Summe zweier unabhängiger binomialverteilter Anzahlen, aber selbst nicht binomialverteilt: Sie hat den Erwartungswert und die Varianz , während mit demselben Erwartungswert die Varianz hätte.     Keine Unabhängigkeit. Zieht man ohne Zurücklegen aus einer kleinen Grundgesamtheit, ist jede einzelne Ziehung zwar mit derselben Wahrscheinlichkeit ein Erfolg, aber ihr Ergebnis ändert die Wahrscheinlichkeiten für die nächste. Das führt auf die hypergeometrische Verteilung ( ). Ebenso fallen Server im selben Rechenzentrum bei einem Stromausfall gemeinsam aus. Wer ihre Ausfälle als unabhängig modelliert, unterschätzt die Wahrscheinlichkeit, dass viele zugleich ausfallen, erheblich.     "
},
{
  "id": "ex-ueberbuchung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-ueberbuchung",
  "type": "Beispiel",
  "number": "2.2.9",
  "title": "Überbuchung eines Flugs.",
  "body": " Überbuchung eines Flugs   Ein Flugzeug hat 250 Plätze. Aus Erfahrung erscheint jede Person mit Ticket mit Wahrscheinlichkeit zum Flug, unabhängig von den anderen; die No-Show -Quote ist also 5 %. Die Fluglinie verkauft Tickets. Sei die Zahl der Personen, die erscheinen.   Wie ist verteilt? Mit welcher Wahrscheinlichkeit muss bei jemand am Boden bleiben?    Dieselbe Frage für . Wie viele Plätze bleiben dann im Mittel leer?    Die Fluglinie will die Wahrscheinlichkeit, jemanden abweisen zu müssen, auf höchstens 0,01 % begrenzen. Wie viele Tickets darf sie verkaufen?           . Bei ist der Flug nur dann überbucht, wenn alle erscheinen: .    Bei reichen 251 oder 252 Erscheinende: Im Mittel erscheinen Personen, es bleiben also gut zehn Plätze leer.    Gesucht ist das größte mit . Diese Wahrscheinlichkeit wächst mit jedem weiteren verkauften Ticket, denn eine zusätzliche Person kann die Zahl der Erscheinenden nur erhöhen. Von Hand wird die Rechnung schnell mühsam, die Code-Zelle unten rechnet sie exakt aus. Für ist die Wahrscheinlichkeit , für schon . Die Fluglinie darf also höchstens 252 Tickets verkaufen.     Obwohl von 250 Personen mit Ticket im Mittel zwölfeinhalb fehlen, erlaubt das strenge Ziel nur zwei zusätzliche Tickets. Mit einem Ziel von 1 % wären es fünf. Wie viel Überbuchung sich lohnt, ist eine Abwägung zwischen entgangenen Ticketerlösen und den Kosten einer Abweisung; die Binomialverteilung liefert dafür die Zahlen. Die fragwürdigste Annahme ist die Unabhängigkeit: Familien und Reisegruppen erscheinen gemeinsam oder gar nicht. Zum Thema siehe auch D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , 2018 ( ).   "
},
{
  "id": "def-geometrische-verteilung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#def-geometrische-verteilung",
  "type": "Definition",
  "number": "2.2.10",
  "title": "Geometrische Verteilung.",
  "body": " Geometrische Verteilung  geometrische Verteilung  Verteilung geometrische   Ein Bernoulli-Experiment mit Erfolgswahrscheinlichkeit wird unabhängig so lange wiederholt, bis der erste Erfolg eintritt. Die Zahl der dafür nötigen Versuche, den erfolgreichen mitgezählt, heißt geometrisch verteilt mit Parameter , kurz . Es ist    "
},
{
  "id": "thm-geometrisch-kennzahlen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-geometrisch-kennzahlen",
  "type": "Satz",
  "number": "2.2.11",
  "title": "Kennzahlen der geometrischen Verteilung.",
  "body": " Kennzahlen der geometrischen Verteilung   Für gilt  für ,  ,  .      (1) heißt, dass die ersten Versuche misslingen.  (2) und (3): Für ist , und beide Formeln stimmen. Sei also und . Die geometrische Reihe darf man für gliedweise ableiten: Für die Varianz rechnen wir mit statt mit , weil gerade dazu die zweite Ableitung passt. Wegen und der Linearität ist . Mit folgt und . Nach dem Verschiebungssatz ( ) ist denn .   "
},
{
  "id": "fig-geometrische-verteilung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#fig-geometrische-verteilung",
  "type": "Abbildung",
  "number": "2.2.12",
  "title": "",
  "body": " Wahrscheinlichkeitsfunktion von . Jeder Stab ist das -Fache des vorigen; der Erwartungswert ist .   Stabdiagramm über 1 bis 12 mit gleichmäßig um den Faktor 0,7 fallenden Stäben   Über den Werten 1 bis 12 steht je ein Stab. Der erste ist mit 0,3 der höchste, danach wird jeder Stab um den Faktor 0,7 kürzer: 0,21; 0,147; 0,103; 0,072 und so weiter, bis 0,006 bei 12. Die Stäbe fallen also von links nach rechts gleichmäßig ab, ohne je ganz null zu werden.     "
},
{
  "id": "ex-verwerfungsmethode",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-verwerfungsmethode",
  "type": "Beispiel",
  "number": "2.2.13",
  "title": "Verwerfen und neu ziehen.",
  "body": " Verwerfen und neu ziehen   Ein Programm braucht eine gleichverteilte Zufallszahl aus , hat aber nur einen fairen Würfel. Es würfelt so lange, bis keine 6 fällt, und gibt die zuletzt gewürfelte Zahl aus.  Wie viele Würfe braucht es im Mittel?  Mit welcher Wahrscheinlichkeit braucht es mehr als drei Würfe?   Ist die ausgegebene Zahl tatsächlich gleichverteilt auf ?       Ein Wurf ist ein Erfolg, wenn er keine 6 zeigt. Die Zahl der Würfe ist also -verteilt.  Würfe.    .    Die Ausgabe ist , wenn für ein die ersten Würfe eine 6 zeigen und der -te ein . Summiert über : Jede der fünf Zahlen kommt mit Wahrscheinlichkeit .     Das ist die Verwerfungsmethode Verwerfungsmethode (rejection sampling), ein Standardwerkzeug der Simulation: Man erzeugt Kandidaten aus einer bequemen Verteilung und verwirft die unpassenden. Die Zahl der Kandidaten je Ergebnis ist geometrisch verteilt, die Kosten sind im Mittel Kandidaten bei Annahmewahrscheinlichkeit . Wer gleichverteilte Punkte in der Einheitskreisscheibe braucht und dazu Punkte im umgebenden Quadrat erzeugt, hat und braucht im Mittel Versuche. Im zehndimensionalen Würfel liegt dagegen nur etwa jeder vierhundertste Punkt in der einbeschriebenen Kugel; dort ist die Methode unbrauchbar.   "
},
{
  "id": "thm-gedaechtnislosigkeit-geometrisch",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-gedaechtnislosigkeit-geometrisch",
  "type": "Satz",
  "number": "2.2.14",
  "title": "Gedächtnislosigkeit.",
  "body": " Gedächtnislosigkeit  Gedächtnislosigkeit der geometrischen Verteilung   Für mit und ist     Wegen ist die bedingte Wahrscheinlichkeit nach gleich .   "
},
{
  "id": "sub-geometrische-verteilung-12",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-geometrische-verteilung-12",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Spielerfehlschluss "
},
{
  "id": "ex-kosten-pro-klick",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-kosten-pro-klick",
  "type": "Beispiel",
  "number": "2.2.15",
  "title": "Was kostet ein Klick?",
  "body": " Was kostet ein Klick?   Ein Werbenetzwerk berechnet 0,01 € je Einblendung einer Suchanzeige. Jede Einblendung führt unabhängig von den anderen mit Wahrscheinlichkeit zu einem Klick.   Wie viele Einblendungen braucht es im Mittel bis zum ersten Klick, und was kostet ein Klick damit im Mittel?    Mit welcher Wahrscheinlichkeit bleiben die ersten 100 Einblendungen ohne Klick?    Eine neue Kampagne hat nach 100 Einblendungen noch keinen Klick. Wie viele weitere Einblendungen braucht sie bei unveränderter Klickrate im Mittel noch bis zum ersten Klick? Die Marketingabteilung vermutet, dass die Klickrate gesunken ist. Stützt die Beobachtung diese Vermutung?       Die Zahl der Einblendungen bis zum ersten Klick ist -verteilt.    Einblendungen, also kostet ein Klick im Mittel  €. Allgemein ist der Preis je Klick der Preis je Einblendung geteilt durch die Klickrate.     .    Nach ist die Restwartezeit wieder -verteilt: im Mittel noch 50 Einblendungen, genauso viele wie am Anfang. Die 100 Einblendungen ohne Klick bringen den ersten Klick nicht näher. Nach (b) wartet gut jede achte Kampagne mit unveränderter Klickrate länger als 100 Einblendungen auf ihren ersten Klick; die Standardabweichung der Wartezeit ist mit fast so groß wie ihr Erwartungswert. Die Beobachtung ist also nicht ungewöhnlich und stützt die Vermutung kaum.     Aus einer einzelnen langen Wartezeit auf eine veränderte Rate zu schließen, wäre voreilig; dafür streut die geometrische Verteilung zu stark. In der Onlinewerbung heißt die Größe aus (a) Cost per Click , und die Rechnung zeigt, warum sie sich halbiert, wenn sich die Klickrate verdoppelt. Übrigens ist fast genau . Das ist kein Zufall, wie zeigt.   "
},
{
  "id": "thm-poisson-grenzwert",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-poisson-grenzwert",
  "type": "Satz",
  "number": "2.2.16",
  "title": "Poissonscher Grenzwertsatz.",
  "body": " Poissonscher Grenzwertsatz  poissonscher Grenzwertsatz  Grenzwertsatz poissonscher  Poisson-Näherung   Sei , und für jedes sei . Dann gilt für jedes      Nach ist Der zweite Faktor ist und strebt gegen 1, ebenso der vierte. Der dritte strebt nach der aus der Analysis bekannten Grenzwertformel gegen .   "
},
{
  "id": "def-poisson-verteilung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#def-poisson-verteilung",
  "type": "Definition",
  "number": "2.2.17",
  "title": "Poisson-Verteilung.",
  "body": " Poisson-Verteilung  Poisson-Verteilung   Eine Zufallsvariable mit Werten in und heißt Poisson-verteilt mit Parameter , kurz .   "
},
{
  "id": "thm-poisson-kennzahlen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#thm-poisson-kennzahlen",
  "type": "Satz",
  "number": "2.2.18",
  "title": "Erwartungswert und Varianz der Poisson-Verteilung.",
  "body": " Erwartungswert und Varianz der Poisson-Verteilung   Für ist und .    Im Summanden für steht der Faktor 0, und für ist . Also ist denn die letzte Summe ist die Summe aller Werte der Wahrscheinlichkeitsfunktion. Genauso ist, mit demselben Kunstgriff wie im Beweis von , und damit .   "
},
{
  "id": "sub-poisson-verteilung-8",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-poisson-verteilung-8",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Poisson-Prozess Rate "
},
{
  "id": "ex-callcenter",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-callcenter",
  "type": "Beispiel",
  "number": "2.2.19",
  "title": "Anrufe in einem Callcenter.",
  "body": " Anrufe in einem Callcenter   Die Anrufe bei einem Callcenter bilden einen Poisson-Prozess mit im Mittel 30 Anrufen je Stunde.   Mit welcher Wahrscheinlichkeit geht in drei Minuten kein Anruf ein?    Mit welcher Wahrscheinlichkeit gehen in sechs Minuten höchstens zwei Anrufe ein?    Wie lang darf eine Pause höchstens sein, damit in ihr mit Wahrscheinlichkeit mindestens 90 % kein Anruf eingeht?       Die Rate ist Anrufe je Minute.   In drei Minuten ist die Zahl der Anrufe -verteilt, und .    In sechs Minuten ist sie -verteilt. Mit der Rekursion ist     In einer Pause von Minuten geht mit Wahrscheinlichkeit kein Anruf ein. Aus folgt durch Logarithmieren Minuten, also knapp 13 Sekunden.     Für die Planung heißt (c): Schon eine Pause von 13 Sekunden verpasst in jedem zehnten Fall mindestens einen Anruf; ohne Warteschleife oder Vertretung geht es nicht. Wie unregelmäßig ein Poisson-Strom ist, zeigt ein Vergleich: Kämen die Anrufe pünktlich alle zwei Minuten, bliebe keine Pause von zwei Minuten ungestört. Beim Poisson-Strom mit derselben Rate ist das mit Wahrscheinlichkeit der Fall. Lange Lücken und kurz aufeinanderfolgende Anrufe sind beide häufiger als beim gleichmäßigen Takt.   "
},
{
  "id": "sub-poisson-verteilung-10",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-poisson-verteilung-10",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Satz von Le Cam "
},
{
  "id": "fig-poisson-naeherung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#fig-poisson-naeherung",
  "type": "Abbildung",
  "number": "2.2.20",
  "title": "",
  "body": " Wahrscheinlichkeitsfunktionen von (grau, offen) und (schwarz, gefüllt). Beide haben den Erwartungswert 3.   Zwei ähnliche Stabdiagramme mit Gipfel bei 2 bis 3, das Poisson-Diagramm etwas breiter   Über den Werten 0 bis 10 stehen je zwei Stäbe nebeneinander. Die grauen Stäbe gehören zu und erreichen ihr Maximum 0,267 bei 3. Die schwarzen gehören zu und sind bei 2 und 3 mit je 0,224 gleich hoch. Die Poisson-Stäbe sind in der Mitte etwas niedriger und an den Rändern, bei 0 und 1 sowie ab 6, etwas höher: Die Poisson-Verteilung streut mit Varianz 3 stärker als die Binomialverteilung mit Varianz 2,1.     "
},
{
  "id": "ex-bitfehler-paket",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-bitfehler-paket",
  "type": "Beispiel",
  "number": "2.2.21",
  "title": "Bitfehler in einem Datenpaket.",
  "body": " Bitfehler in einem Datenpaket   Ein Datenpaket besteht aus Bits. Jedes wird unabhängig von den anderen mit Wahrscheinlichkeit verfälscht.   Welche Verteilung hat die Zahl der Bitfehler im Paket exakt, und durch welche Poisson-Verteilung lässt sie sich nähern? Wie groß ist der Fehler der Näherung höchstens?    Mit welcher Wahrscheinlichkeit ist das Paket fehlerfrei? Ein Code korrigiert bis zu zwei Bitfehler je Paket. Mit welcher Wahrscheinlichkeit kommt das Paket nach der Korrektur richtig an?    Vergleichen Sie mit den exakten Werten.          Exakt ist , genähert mit . Der Fehler ist höchstens .     und     Exakt ist und . Die Werte stimmen auf vier Stellen überein; der tatsächliche Fehler liegt noch unter der Schranke aus (a).     Ohne Korrektur käme nicht einmal ein Drittel der Pakete fehlerfrei an, mit einem Code für zwei Fehler sind es 88 %. Für die Auslegung eines Codes braucht man genau solche Zahlen, und die Poisson-Näherung liefert sie mit einem einzigen Parameter, gleich wie viele Bits ein Paket hat.   "
},
{
  "id": "rem-seltene-ereignisse",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#rem-seltene-ereignisse",
  "type": "Bemerkung",
  "number": "2.2.22",
  "title": "Seltene Ereignisse.",
  "body": " Seltene Ereignisse  Die Poisson-Näherung beantwortet auch die dritte Frage vom Anfang des Abschnitts. Finden in einer Stunde Einblendungen statt, von denen jede mit Wahrscheinlichkeit einen Klick bringt, so ist die Klickzahl ; bei 5000 Einblendungen also etwa . Die Schranke von Le Cam hilft hier nicht weiter, denn . Für großes ist sie grob. Es gilt auch die Schranke , die für schärfer ist (ohne Beweis; Barbour und Hall 1984), hier also . Tatsächlich weichen die Wahrscheinlichkeiten um knapp ab. Die erste Frage ist schon nach beantwortet, die zweite in .  Außerdem erklärt die Näherung zwei Zahlen aus früheren Beispielen. In war : Die Zahl der Klicks in 100 Einblendungen ist , und kein Klick hat Wahrscheinlichkeit etwa . In war für die Zahl der kollidierenden Paare. Dort sind die gezählten Ereignisse nicht einmal unabhängig, aber jedes ist selten, und die Abhängigkeit ist schwach. Unter solchen Bedingungen ist eine Anzahl oft immer noch ungefähr Poisson-verteilt (ohne Beweis). Deshalb taucht die Poisson-Verteilung überall dort auf, wo viele Gelegenheiten für ein seltenes Ereignis bestehen.  Quelle der Schranke : A. D. Barbour und P. Hall, On the rate of Poisson convergence, Mathematical Proceedings of the Cambridge Philosophical Society 95 (1984), 473 480 ( ).  "
},
{
  "id": "sub-hypergeometrische-verteilung-7-2",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-hypergeometrische-verteilung-7-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Endlichkeitskorrektur "
},
{
  "id": "ex-stichprobenkontrolle-hypergeometrisch",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-stichprobenkontrolle-hypergeometrisch",
  "type": "Beispiel",
  "number": "2.2.23",
  "title": "Noch einmal die Stichprobenkontrolle.",
  "body": " Noch einmal die Stichprobenkontrolle   In werden aus einer Lieferung von 50 Sensoren, von denen drei defekt sind, fünf ohne Zurücklegen geprüft. Sei die Zahl der defekten Sensoren in der Stichprobe. Geben Sie die Verteilung von und an, und vergleichen Sie und mit der Binomialnäherung.     und . Exakt ist wie in und . Die Binomialnäherung liefert und .  Die Stichprobe umfasst ein Zehntel der Lieferung. Die Näherung überschätzt um einen Prozentpunkt und die Varianz um knapp 10 %. Für eine schnelle Abschätzung reicht das; wer ein Prüfverfahren vertraglich festlegt, rechnet exakt.   "
},
{
  "id": "ex-drei-abschluesse",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-drei-abschluesse",
  "type": "Beispiel",
  "number": "2.2.24",
  "title": "Drei Abschlüsse.",
  "body": " Drei Abschlüsse   Ein Vertriebsteam braucht in diesem Monat noch drei Abschlüsse. Jedes Kundengespräch führt unabhängig von den anderen mit Wahrscheinlichkeit zum Abschluss. Wie viele Gespräche braucht es im Mittel, mit welcher Standardabweichung? Mit welcher Wahrscheinlichkeit braucht es genau vier Gespräche, mit welcher höchstens sechs?    Die Zahl der Gespräche ist -verteilt, also und . Weiter ist , und mit ist   Zwölf Gespräche im Mittel, aber mit einer Standardabweichung von sechs: Wer die Monatsplanung auf den Erwartungswert baut, sollte einen deutlichen Puffer einplanen.   "
},
{
  "id": "sub-multinomialverteilung-5-2",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-multinomialverteilung-5-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "kategorial "
},
{
  "id": "ex-ticketklassen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-ticketklassen",
  "type": "Beispiel",
  "number": "2.2.25",
  "title": "Supporttickets in drei Klassen.",
  "body": " Supporttickets in drei Klassen   Ein eingehendes Supportticket betrifft mit Wahrscheinlichkeit die Technik, mit die Rechnung und mit etwas anderes, unabhängig von den übrigen Tickets. Mit welcher Wahrscheinlichkeit betreffen von fünf Tickets genau drei die Technik, eines die Rechnung und eines etwas anderes? Wie viele der fünf betreffen im Mittel die Technik?    Seien , und die Zahlen der Tickets zu Technik, Rechnung und Sonstigem unter den fünf. Sie sind gemeinsam -verteilt, also und .  Diese Aufteilung ist die wahrscheinlichste (die zweitwahrscheinlichste, , hat ), und doch trifft man sie nur in 15 % der Fälle. Wer ein Team nach den erwarteten Anteilen besetzt, muss mit deutlichen Schwankungen der Tagesaufteilung rechnen.   "
},
{
  "id": "tab-diskrete-verteilungen",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#tab-diskrete-verteilungen",
  "type": "Tabelle",
  "number": "2.2.26",
  "title": "Die diskrete Gleichverteilung als Rückblick, die vier Grundverteilungen und die drei Steckbriefe",
  "body": " Die diskrete Gleichverteilung als Rückblick, die vier Grundverteilungen und die drei Steckbriefe        Verteilung  Situation       jeder der Werte gleich wahrscheinlich       ein Versuch, bei Erfolg       Erfolge in unabhängigen Versuchen       Versuche bis zum ersten Erfolg       seltene Ereignisse in einem Zeitraum       Stichprobe ohne Zurücklegen,       Versuche bis zum -ten Erfolg       Anzahlen je Klasse in Versuchen (Kennzahlen je )      "
},
{
  "id": "fig-verwandtschaften",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#fig-verwandtschaften",
  "type": "Abbildung",
  "number": "2.2.27",
  "title": "",
  "body": " Die Verwandtschaften der diskreten Verteilungen. Fett umrandet sind die vier Grundverteilungen, dünn die Steckbriefe, gestrichelt die stetigen Verteilungen späterer Kapitel.   Diagramm aus neun Kästen mit Pfeilen, oben Bernoulli, darunter Binomial und geometrisch, daraus die übrigen Verteilungen   Oben steht der Kasten Bernoulli. Ein Pfeil mit der Beschriftung Summe von n unabhängigen führt nach links unten zu Binomial, ein zweiter mit Warten auf den ersten Erfolg nach rechts unten zu geometrisch. Links neben Binomial steht hypergeometrisch mit einem Pfeil N gegen unendlich, M durch N gegen p zu Binomial. Von Binomial führt ein Pfeil n gegen unendlich, np = lambda nach unten zu Poisson und ein Pfeil m Klassen statt 2 nach links unten zu Multinomial. Von geometrisch führt ein Pfeil Summe von r unabhängigen nach unten zu negativ binomial. Gestrichelte Pfeile führen von Binomial ( n p mal 1 minus p groß ) und von Poisson ( großes lambda ) zu einem gestrichelten Kasten Normal, Kapitel 3 und 5, und von geometrisch ( stetiges Gegenstück ) nach rechts unten zu einem gestrichelten Kasten Exponential, Kapitel 3.     "
},
{
  "id": "ex-welche-verteilung",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#ex-welche-verteilung",
  "type": "Beispiel",
  "number": "2.2.28",
  "title": "Welche Verteilung passt?",
  "body": " Welche Verteilung passt?   Geben Sie jeweils Verteilung und Parameter an und nennen Sie die Annahme, auf der das Modell beruht.   Die Zahl der Anfragen, die ein Webserver in einer Minute erhält, wenn im Mittel vier je Minute eintreffen.    Die Zahl der Spam-Mails unter den nächsten 20 E-Mails, wenn 30 % aller Mails Spam sind.    Die Zahl der Lose, die man bis zum ersten Gewinn kauft, wenn jedes Los mit Wahrscheinlichkeit gewinnt.    Die Zahl der Frauen in einem Ausschuss aus vier Personen, der aus sechs Frauen und sechs Männern ausgelost wird.    Die Zahl der Würfe mit einem fairen Würfel, bis zum zweiten Mal eine Sechs fällt.    Wie oft jede von drei Varianten einer Webseite unter 90 Besuchern gezeigt wird, wenn jeder Besucher unabhängig mit Wahrscheinlichkeit einer der Varianten zugeteilt wird.           , wenn die Anfragen von vielen Nutzern unabhängig voneinander kommen und die Rate über die Minute gleich bleibt. Ein Crawler, der zehn Anfragen auf einmal schickt, verletzt die Annahme.     , wenn jede Mail unabhängig mit derselben Wahrscheinlichkeit Spam ist. Spam kommt oft in Wellen; dann ist die Unabhängigkeit fraglich.     , wenn die Lose unabhängig gewinnen. Stammen sie aus einem festen Vorrat mit genau 10 % Gewinnen, ist das nur eine Näherung, die für einen großen Vorrat gut ist.     : Es wird ohne Zurücklegen aus einer kleinen Grundgesamtheit gezogen, eine Binomialnäherung wäre hier grob.     , weil die Würfe unabhängig sind.     für die drei Anzahlen; jede einzelne ist -verteilt.     Die Wahl der Verteilung ist eine Modellannahme, keine Rechnung. Sie steht am Anfang jeder Auswertung und verdient deshalb dieselbe Sorgfalt wie das Rechnen danach: Eine exakt ausgewertete Formel für das falsche Modell hilft niemandem.   "
},
{
  "id": "sub-zusammenfassung-2-2-2",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#sub-zusammenfassung-2-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Bernoulli und Binomial. Modellannahmen. Geometrisch. Gedächtnislosigkeit. Poisson. Poisson-Näherung. Steckbriefe. "
},
{
  "id": "exercise-buch-umfrage",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#exercise-buch-umfrage",
  "type": "Übung",
  "number": "2.2.9.1",
  "title": "Eine kleine Umfrage.",
  "body": " Eine kleine Umfrage   Sechs zufällig ausgewählte Personen werden gefragt, ob sie einem Vorschlag zustimmen. Jede stimmt unabhängig von den anderen mit Wahrscheinlichkeit zu. Sei die Zahl der Zustimmungen.  Bestimmen Sie .  Bestimmen Sie .  Bestimmen Sie und .       , und jede der Antwortfolgen hat die Wahrscheinlichkeit .  .  .  und .     "
},
{
  "id": "exercise-buch-erste-sechs",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#exercise-buch-erste-sechs",
  "type": "Übung",
  "number": "2.2.9.2",
  "title": "Warten auf die erste Sechs.",
  "body": " Warten auf die erste Sechs   Ein fairer Würfel wird geworfen, bis zum ersten Mal eine Sechs fällt.  Mit welcher Wahrscheinlichkeit braucht man genau drei Würfe?  Mit welcher Wahrscheinlichkeit braucht man mehr als sechs Würfe?  Bestimmen Sie die Standardabweichung der Zahl der Würfe. Was sagt sie über die Planbarkeit?      Die Zahl der Würfe ist -verteilt.  .    . In einem Drittel der Fälle reichen sechs Würfe also nicht.     , also , fast so groß wie der Erwartungswert 6. Wie lange man warten muss, ist kaum vorherzusagen.      "
},
{
  "id": "exercise-buch-unzuverlaessiger-test",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#exercise-buch-unzuverlaessiger-test",
  "type": "Übung",
  "number": "2.2.9.3",
  "title": "Ein unzuverlässiger Test.",
  "body": " Ein unzuverlässiger Test   Ein automatischer Test in einer Softwareentwicklung schlägt bei jedem Lauf unabhängig von den anderen Läufen mit Wahrscheinlichkeit zufällig fehl, obwohl der Code in Ordnung ist.  Wie viele Läufe vergehen im Mittel bis zum ersten Fehlschlag, diesen mitgezählt?   Seit dem letzten Fehlschlag liefen 30 Läufe fehlerfrei. Wie viele Läufe dauert es im Mittel noch bis zum nächsten Fehlschlag? Mit welcher Wahrscheinlichkeit laufen die nächsten zehn fehlerfrei?    Vom ersten Lauf an gezählt: Mit welcher Wahrscheinlichkeit fällt der erste Fehlschlag in einen der Läufe 1 bis 10, mit welcher in einen der Läufe 11 bis 20? Warum ist die zweite Wahrscheinlichkeit kleiner?         Die Zahl der Läufe bis einschließlich zum ersten Fehlschlag ist -verteilt, im Mittel .   Wegen der Gedächtnislosigkeit ist die Restwartezeit wieder -verteilt: im Mittel noch 20 Läufe. Die nächsten zehn laufen mit Wahrscheinlichkeit fehlerfrei, genauso wie zu Beginn.     und . Damit der erste Fehlschlag in die zweite Zehnergruppe fällt, muss die erste ohne Fehlschlag bleiben; danach beginnt nach der Gedächtnislosigkeit alles von vorn. Die Wahrscheinlichkeit jeder Zehnergruppe ist deshalb das -Fache, etwa das -Fache, der vorigen, wie bei den Stäben in .      "
},
{
  "id": "exercise-buch-gewinnspiel",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#exercise-buch-gewinnspiel",
  "type": "Übung",
  "number": "2.2.9.4",
  "title": "Ein Gewinnspiel.",
  "body": " Ein Gewinnspiel   Bei einem Gewinnspiel gewinnt jedes Los unabhängig mit Wahrscheinlichkeit . Jemand kauft 500 Lose.   Nähern Sie die Wahrscheinlichkeit für mindestens einen und für mindestens zwei Gewinne mit der Poisson-Verteilung.    Bis zu wie vielen Losen bleibt die Schranke von Le Cam für den Fehler der Poisson-Näherung höchstens ?          Die Zahl der Gewinne ist . Damit ist und .    Die Schranke ist ; sie bleibt bis Losen höchstens . Für die 500 Lose aus (a) ist sie . Die zweite Schranke aus ist hier für jede Zahl von Losen gleich ; erst bei mehr als 1000 Losen ist sie die bessere.      "
},
{
  "id": "exercise-buch-varianzvergleich",
  "level": "2",
  "url": "sec-diskrete-verteilungen.html#exercise-buch-varianzvergleich",
  "type": "Übung",
  "number": "2.2.9.5",
  "title": "Wer streut stärker?",
  "body": " Wer streut stärker?    und haben denselben Erwartungswert. Welche der beiden Zufallsvariablen hat die größere Varianz, und um welchen Faktor unterscheiden sich die Varianzen? Wann ist der Unterschied unerheblich?     . Die Varianz von ist also um den Faktor größer, die Standardabweichung um den Faktor . Für kleines sind beide Faktoren fast 1; genau dort ist die Poisson-Näherung auch gedacht. Für dagegen hat die Poisson-Verteilung die doppelte Varianz, und die Näherung taugt nichts.   "
},
{
  "id": "sec-stetige-zufallsvariablen-dichte",
  "level": "1",
  "url": "sec-stetige-zufallsvariablen-dichte.html",
  "type": "Abschnitt",
  "number": "3.1",
  "title": "Stetige Zufallsvariablen: Dichte, Verteilungsfunktion und Kennzahlen",
  "body": " Stetige Zufallsvariablen: Dichte, Verteilungsfunktion und Kennzahlen    Nach diesem Abschnitt können Sie     Wahrscheinlichkeiten als Flächen unter einer Dichte berechnen und eine Funktion mit freier Konstante zu einer Dichte normieren,    zwischen Dichte und Verteilungsfunktion wechseln, durch Integrieren in die eine Richtung und Ableiten in die andere,    Erwartungswert, Varianz und als Integrale berechnen und die Rechenregeln aus auf stetige Zufallsvariablen anwenden,    Median, Quartile und andere Quantile bestimmen, auch in Rückrichtung als Schwelle zu einer vorgegebenen Wahrscheinlichkeit, und bei schiefen Verteilungen Median und Erwartungswert gegeneinander abwägen,    Verteilungsfunktion und Dichte einer umgerechneten Größe bestimmen, auch wenn nicht monoton ist,    mit der Inversionsmethode aus Zufallszahlen im Intervall solche mit vorgegebener Verteilung erzeugen,    die Unabhängigkeit beliebiger Zufallsvariablen über ihre Verteilungsfunktionen ausdrücken und damit rechnen.      Ein Cloud-Anbieter verspricht, dass 99 % aller Anfragen an seinen Dienst in weniger als einer Sekunde beantwortet werden. Die Antwortzeit ist eine Zufallsvariable, aber keine diskrete: Sie kann jeden Wert in einem Intervall annehmen, und die Wahrscheinlichkeit, genau 0,5 Sekunden zu treffen, ist null. Trotzdem ist klar, was das Versprechen bedeutet, und nachprüfen lässt es sich auch. Man braucht dafür eine Dichte an Stelle der Wahrscheinlichkeitsfunktion und das Integral an Stelle der Summe.   führt die Dichte ein und verbindet sie mit der Verteilungsfunktion aus . überträgt Erwartungswert und Varianz, die Unabhängigkeit. Diese drei Teile wiederholen mit Integralen statt Summen, und die Rechenregeln von dort gelten unverändert weiter. Die Zeit dieser Woche gehört den beiden letzten Teilen, die im Diskreten kaum eine Rolle gespielt haben: beantwortet mit Quantilen die Frage vom Anfang, und zeigt, wie sich eine Verteilung beim Umrechnen einer Größe ändert und wie man damit Zufallszahlen mit vorgegebener Verteilung erzeugt.    Dichte und Verteilungsfunktion  Misst man an einem Standort ein Jahr lang stündlich die Windgeschwindigkeit, so kommt kein Messwert zweimal genau vor, wenn man nur genügend Nachkommastellen notiert. Eine Wahrscheinlichkeitsfunktion wie in hilft hier nicht: Jeder einzelne Wert hat die Wahrscheinlichkeit null. Sinnvoll ist nur die Frage, mit welcher Wahrscheinlichkeit die Größe in einem Intervall liegt.  Für Daten beantwortet ein Histogramm Histogramm diese Frage. Man teilt die Achse in Klassen und trägt über jeder Klasse den Anteil der Messwerte je Einheit auf, also die relative Häufigkeit geteilt durch die Klassenbreite. Dann ist der Anteil einer Klasse die Fläche ihres Balkens, auch wenn die Klassen verschieden breit sind. Mit mehr Daten und schmaleren Klassen nähert sich die Treppe einer Kurve. zeigt, wie ein solches Histogramm mit noch groben Klassen neben dieser Kurve aussieht. Sie heißt Dichte, und Wahrscheinlichkeiten sind Flächen unter ihr.   Ein Histogramm der Windgeschwindigkeit mit Klassen der Breite 2 m\/s, wie es aussähe, wenn die Daten genau der Dichte folgten. Die Balken zeigen keine Messwerte, sondern die Klassenwahrscheinlichkeiten der Dichte: Die Höhe jedes Balkens ist die Wahrscheinlichkeit der Klasse geteilt durch ihre Breite, seine Fläche also die Wahrscheinlichkeit selbst. Die Kurve ist die Dichte aus .   Fünf Histogrammbalken, darüber eine glockenförmige Parabel   Über den Klassen 0 bis 2, 2 bis 4, 4 bis 6, 6 bis 8 und 8 bis 10 stehen graue Balken der Höhen 0,052, 0,124, 0,148, 0,124 und 0,052. Eine dicke Kurve, eine nach unten geöffnete Parabel mit Nullstellen bei 0 und 10 und dem Maximum 0,15 bei 5, verläuft durch die Balken. In der Mitte ragt sie etwas über den Balken hinaus, an den Rändern bleibt sie teils darunter; die Flächen stimmen je Klasse überein.       Stetige Zufallsvariable, Dichte  Zufallsvariable stetige  Dichte   Sei eine Zufallsvariable. Gibt es eine integrierbare Funktion mit  für alle und    für alle reellen Zahlen ,   so heißt  stetige Zufallsvariable . Die Funktion heißt Wahrscheinlichkeitsdichte Wahrscheinlichkeitsdichte oder kurz Dichte von .    Meist ist eine Dichte außerhalb eines Intervalls null. Man gibt dann nur die Formel auf dem Intervall an und ergänzt sonst 0 . An einzelnen Punkten ist eine Dichte nicht festgelegt: Ändert man an endlich vielen Stellen, ändert sich kein Integral. Ob man an den Rändern eines Intervalls oder schreibt, ist deshalb gleichgültig.   Eigenschaften von Dichte und Verteilungsfunktion   Sei eine stetige Zufallsvariable mit Dichte und Verteilungsfunktion . Dann gilt:    für jedes . Für haben deshalb , , und dieselbe Wahrscheinlichkeit.     . Insbesondere ist stetig, und es ist und .     .    An jeder Stelle , an der stetig ist, ist differenzierbar mit .       (1) Für jedes ist , also . Das Integral über ein immer kürzeres Intervall geht für gegen null. Die vier Ereignisse unterscheiden sich nur um die Randpunkte und .  (2) ist die disjunkte Vereinigung der Ereignisse für Nach dem dritten Axiom und (1) ist Ein Integral mit variabler oberer Grenze ist stetig in dieser Grenze. Aus und (1) folgen und .  (3) folgt aus (2) und . Zieht man davon ab, bleibt . (4) ist der Hauptsatz der Differential- und Integralrechnung, angewandt auf (2).    Teil (1) ist der eigentliche Unterschied zum Diskreten. Jeder einzelne Wert einer stetigen Zufallsvariablen hat die Wahrscheinlichkeit null und kann trotzdem eintreten: Irgendeine Windgeschwindigkeit wird ja gemessen. Wahrscheinlichkeit null heißt also nicht unmöglich. Dafür muss man nicht mehr aufpassen, ob oder gemeint ist; bei diskreten Zufallsvariablen war genau das eine häufige Fehlerquelle.  Teil (4) gilt auch umgekehrt: Ist stetig und bis auf endlich viele Stellen stetig differenzierbar, so ist stetig mit Dichte . Denn nach dem Hauptsatz ist , auch wenn an einer solchen Stelle unbeschränkt ist wie die Ableitung von bei 0. Weil stetig ist, hat auch der Randpunkt die Wahrscheinlichkeit null. Dichte und Verteilungsfunktion bestimmen sich also gegenseitig, durch Integrieren in die eine Richtung und Ableiten in die andere.  Eine Dichte ist selbst keine Wahrscheinlichkeit. Für kleines ist die Dichte ist also Wahrscheinlichkeit je Einheit von . Sie kann deshalb Werte größer als 1 annehmen, wie das folgende Beispiel zeigt.   Elektrischer Strom   Die Stromstärke in einem dünnen Kupferdraht wird in Milliampere gemessen. Sie liegt zwischen 4,9 und 5,1 mA und hat die Dichte (Beispiel nach Montgomery und Runger )    Prüfen Sie, dass eine Dichte ist, obwohl sie Werte größer als 1 annimmt.    Mit welcher Wahrscheinlichkeit wird ein Strom von weniger als 5 mA gemessen?    Mit welcher Wahrscheinlichkeit liegt der gemessene Strom zwischen 4,95 und 5,1 mA, und mit welcher ist er genau 5 mA?           ist nichtnegativ, und die Fläche unter ihr ist ein Rechteck der Breite und der Höhe 5, also . Der Wert 5 bedeutet Wahrscheinlichkeit 5 je Milliampere; auf einem Intervall von 0,2 mA ergibt das zusammen 1.     .     und nach .     Bei einer konstanten Dichte ist jede Wahrscheinlichkeit proportional zur Länge des Intervalls; die Rechnung ist Flächenberechnung von Rechtecken. Dichten, die auf einem Intervall konstant sind, kommen in als eigene Familie wieder. Das Beispiel stammt aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 4 ( ); Teil (a) und die Frage nach genau 5 mA sind für dieses Buch ergänzt.    Oft kennt man von einer Dichte zunächst nur die Form, etwa null an den Rändern, in der Mitte am größten . Eine Konstante macht daraus eine Dichte: Man wählt sie so, dass die Gesamtfläche 1 ist. Das heißt Normieren Normieren einer Dichte .   Eine Dichte normieren   Die Windgeschwindigkeit (in m\/s) an einem Standort wird vereinfacht durch die Dichte beschrieben.  Bestimmen Sie die Konstante .   Bestimmen Sie die Verteilungsfunktion für alle .    Mit welcher Wahrscheinlichkeit weht der Wind schwächer als 3 m\/s, mit welcher zwischen 3 und 8 m\/s?          Für ist . Die Fläche ist also muss sein.    Für ist Links von 0 ist , rechts von 10 ist . Probe: .     und , also .     In gut einem Fünftel der Zeit weht der Wind schwächer als 3 m\/s; viele Windkraftanlagen liefern dann noch keinen Strom. zeigt beide Funktionen: Die Wahrscheinlichkeit aus (c) ist oben eine Fläche und unten ein Höhenunterschied. Gemessene Windgeschwindigkeiten haben meist einen längeren rechten Rand, als diese symmetrische Parabel ihn hat. Sie ist hier gewählt, weil sich mit ihr alle Integrale von Hand ausrechnen lassen.     Dichte (oben) und Verteilungsfunktion (unten) der Windgeschwindigkeit aus . Die graue Fläche ist unten der Zuwachs .   Oben eine Parabel mit grauer Fläche zwischen 3 und 8, unten eine S-förmige Kurve von 0 bis 1   Oben die Dichte, eine nach unten geöffnete Parabel über dem Intervall von 0 bis 10 mit dem Maximum 0,15 bei 5. Die Fläche unter ihr zwischen 3 und 8 ist grau gefüllt und mit 0,68 beschriftet. Darunter, mit derselben waagerechten Achse, die Verteilungsfunktion: Sie steigt S-förmig von 0 bei 0 auf 1 bei 10, am steilsten in der Mitte, und bleibt danach bei 1. Gestrichelte Linien markieren die Werte 0,216 bei 3 und 0,896 bei 8, ein Doppelpfeil rechts den Abstand 0,68 zwischen ihnen.      Manchmal ist die Verteilungsfunktion leichter zu bekommen als die Dichte, so wie beim Maximum zweier Würfel in . Dann leitet man ab.   Abstand zum Funkmast   Ein Mobilfunkmast versorgt eine kreisförmige Fläche mit dem Radius 2 km. Die Kundinnen und Kunden wohnen gleichmäßig über diese Fläche verteilt: Die Wahrscheinlichkeit, dass eine zufällig gewählte Person in einem Teilgebiet wohnt, ist dessen Anteil an der Gesamtfläche. Sei ihr Abstand zum Mast in km.  Bestimmen Sie die Verteilungsfunktion von .  Bestimmen Sie die Dichte von .   Mit welcher Wahrscheinlichkeit wohnt die Person weiter als 1 km vom Mast entfernt?           ist für die Kreisscheibe mit Radius um den Mast. Ihr Anteil an der Gesamtfläche ist mit für und für .     ist stetig und außer bei differenzierbar, also ist für und sonst. Probe: Die Fläche des Dreiecks unter ist .     .     Die Dichte wächst mit dem Abstand, weil ein schmaler Ring um den Mast umso mehr Fläche hat, je weiter außen er liegt. Drei Viertel der Kundschaft wohnen in der äußeren Hälfte des Radius, wo das Signal am schwächsten ist. Für die Netzplanung ist das die entscheidende Zahl, und sie ergibt sich ohne jede Integration, direkt aus der Verteilungsfunktion.      Erwartungswert und Varianz  Der Erwartungswert einer diskreten Zufallsvariablen ist die Summe der Werte, gewichtet mit ihren Wahrscheinlichkeiten. Für eine stetige Zufallsvariable kommt man mit einem Umweg dorthin: Man zerlegt die Achse in kleine Intervalle der Breite und rundet auf die Mitte des Intervalls, in das es fällt. Die gerundete Größe ist diskret, sie nimmt mit der Wahrscheinlichkeit an, und ihr Erwartungswert ist ungefähr . Für wird daraus ein Integral.   Erwartungswert, Varianz und Standardabweichung  Erwartungswert einer stetigen Zufallsvariablen  Varianz einer stetigen Zufallsvariablen   Sei eine stetige Zufallsvariable mit Dichte .   Der Erwartungswert von ist sofern ist.    Die Varianz von ist sofern existiert und dieses Integral endlich ist. Die Standardabweichung ist .       Die Lesarten aus bleiben: ist der Schwerpunkt der Fläche unter der Dichte und das Langzeitmittel vieler unabhängiger Beobachtungen, die mittlere quadratische Abweichung davon. Ist die Dichte symmetrisch um einen Punkt , also für alle , und existiert der Erwartungswert, so ist . Liegt mit Wahrscheinlichkeit 1 in einem beschränkten Intervall, existieren Erwartungswert und Varianz immer; dass das bei unbeschränkten Werten nicht selbstverständlich ist, zeigt .  Auch den Erwartungswert einer Funktion kann man ausrechnen, ohne erst die Verteilung von zu bestimmen.   Erwartungswert einer Funktion, stetiger Fall (Transformationssatz)  Transformationssatz stetiger Fall  Erwartungswert einer Funktion   Sei stetig mit Dichte und stückweise stetig, also stetig bis auf endlich viele Sprungstellen. Dann ist sofern das Integral mit an Stelle von endlich ist.    Die Formel ist das stetige Gegenstück zu . Einen vollständigen Beweis geben wir nicht, er braucht Hilfsmittel der Maßtheorie. Für eine Treppenfunktion , die auf Intervallen konstant gleich ist, folgt sie aber sofort: Dann ist diskret mit , und . Jede stückweise stetige Funktion lässt sich durch Treppenfunktionen beliebig gut annähern. Mit zeigt der Satz, dass die Varianz auch hier ist.  Mit dieser Übersetzung lässt sich alles aus übertragen. stellt beide Fälle nebeneinander.   Wörterbuch diskret und stetig        diskret  stetig    Verteilung durch   Dichte , dabei    Normierung            Treppe,  stetig,    zurück  , falls ganzzahlig     oder  macht einen Unterschied  gleichgültig                    Auch die Rechenregeln gelten weiter.   Rechenregeln für stetige Zufallsvariablen   Sei eine stetige Zufallsvariable, deren Erwartungswert existiert, und seien . Dann gilt  ,  ,  und .  Für (2) und (3) muss auch existieren.    (1) und (2) folgen aus : und ebenso . Für (3) setzt man in denselben Satz ein.    Das sind wörtlich , Teil (1), und . Damit gilt auch, was dort aus ihnen folgte, etwa dass die standardisierte Größe den Erwartungswert 0 und die Varianz 1 hat. Rechnet man eine Messgröße in eine andere Einheit um, so rechnet man Erwartungswert und Standardabweichung einfach mit um. Was dabei mit der Dichte selbst passiert, zeigt .  Auch die Summenregel gilt weiter, für alle Zufallsvariablen mit Erwartungswert und wie im Diskreten ohne jede Voraussetzung an ihren Zusammenhang. Beweisen können wir sie hier noch nicht: Schon die Summe zweier stetiger Zufallsvariablen muss nicht stetig sein, und der allgemeine Beweis braucht Maßtheorie. Für zwei Zufallsvariablen mit gemeinsamer Dichte holt ihn nach. Wir benutzen die Regel schon jetzt.   Erwartungswerte als Integrale   Bestimmen Sie Erwartungswert und Standardabweichung   der Stromstärke aus ,    des Abstands zum Funkmast aus .          Die Dichte ist symmetrisch um 5, also ist  mA. Zur Probe: . Weiter ist also  mA.      km. Mit dem Verschiebungssatz, der nach weiter gilt, und ist      Bei der konstanten Dichte liegt der Schwerpunkt in der Mitte, beim Funkmast weiter außen: Im Mittel wohnt die Kundschaft  km vom Mast entfernt, nicht 1 km, weil die äußeren Ringe mehr Fläche haben.    In war eine Warnung am Rand. Bei physikalischen Größen, die nicht linear von einer zufälligen Eingangsgröße abhängen, entscheidet sie über die Planung.   Mittlere Windgeschwindigkeit, mittlere Leistung   Die Leistung einer Windkraftanlage wächst unterhalb ihrer Nennleistung mit der dritten Potenz der Windgeschwindigkeit, für eine Konstante . Vereinfachend gelte das für alle Windgeschwindigkeiten bis 10 m\/s, und habe die Dichte aus .  Bestimmen Sie und .   Bestimmen Sie und vergleichen Sie mit . Um wie viel Prozent unterschätzt eine Ertragsprognose, die mit der mittleren Windgeschwindigkeit rechnet?    Welcher Anteil des mittleren Ertrags stammt aus den Stunden mit  m\/s, und welchen Anteil der Zeit machen sie aus?       Mit auf :   Die Dichte ist symmetrisch um 5, also  m\/s. Weiter ist also und  m\/s.     dagegen . Die mittlere Leistung ist , die Prognose mit der mittleren Windgeschwindigkeit ergibt und liegt um  % zu niedrig.     das sind  % von . Der Anteil der Zeit ist .     Weil die Leistung mit der dritten Potenz wächst, zählen die windstarken Stunden überproportional: Ein Zehntel der Zeit liefert gut ein Drittel der Energie, und mit der mittleren Windgeschwindigkeit gerechnet fehlt mehr als ein Drittel des Ertrags. Deshalb geben Windgutachten die Verteilung der Windgeschwindigkeit an und nicht nur ihren Mittelwert.    Die folgende Zelle rechnet den Grenzübergang vom Anfang dieses Unterabschnitts nach. Sie rundet auf die Mitte eines von gleich breiten Intervallen, bestimmt die Wahrscheinlichkeiten der gerundeten, diskreten Größe mit und bildet ihre Erwartungswerte als Summen wie in .   # Stetiger Erwartungswert als Grenzwert diskreter Erwartungswerte: # V wird auf die Mitte eines von n gleich breiten Intervallen gerundet. # Probieren Sie n = 5, 50, 500. n = 5 F = lambda v: 3 * v ** 2 \/ 100 - v ** 3 \/ 500 breite = 10 \/ n mitten = [(i + 0.5) * breite for i in range(n)] p = [F((i + 1) * breite) - F(i * breite) for i in range(n)] e1 = sum([m * q for m, q in zip(mitten, p)]) e3 = sum([m ** 3 * q for m, q in zip(mitten, p)]) print(\"Summe der Wahrscheinlichkeiten: %.4f\" % sum(p)) print(\"E(gerundet) = %.4f (E(V) = 5)\" % e1) print(\"E(gerundet^3) = %.4f (E(V^3) = 200)\" % e3)   Schon bei fünf Intervallen stimmt , weil sich die Fehler der Rundung links und rechts von 5 aufheben. Bei tun sie das nicht, und man sieht die Summen gegen das Integral laufen.    Unabhängigkeit   verlangt die Produktformel für die Wahrscheinlichkeiten . Für stetige Zufallsvariablen sind diese alle null, und die Formel sagt nichts mehr aus. Man stellt die Bedingung deshalb an die Verteilungsfunktionen.   Unabhängige Zufallsvariablen, allgemeiner Fall  Unabhängigkeit von Zufallsvariablen allgemeiner Fall   Zufallsvariablen auf demselben Wahrscheinlichkeitsraum heißen unabhängig , wenn für alle  gilt.    Die Definition gilt für Zufallsvariablen jeder Art. Für diskrete stimmt sie mit überein. In die eine Richtung sieht man das sofort: Gilt die Produktformel für die einzelnen Werte, so summiert man sie über alle Werte und erhält die Produktformel für die Verteilungsfunktionen. Für die umgekehrte Richtung braucht man, dass aus der Produktformel für Halbgeraden die für Intervalle folgt.   Unabhängigkeit für Intervalle   Sind und unabhängig, so gilt für und      Sei . Das Ereignis zerfällt in das Rechteck und die Vereinigung von und , die sich in überschneiden. Mit der Additionsregel aus ist     Dasselbe gilt für Zufallsvariablen und für Halbgeraden an Stelle von Intervallen. Was man über erfährt, ändert also nichts an den Wahrscheinlichkeiten für . Für diskrete Zufallsvariablen liefert der Satz die Definition aus zurück. Wir zeigen das für Werte, die einzeln liegen, zum Beispiel für ganzzahlige Werte: Man wählt und so nah, dass der einzige Wert von in ist und der einzige von in . Dann ist .  Die Rechenregeln aus und gelten auch für unabhängige stetige Zufallsvariablen: , die Varianz einer Summe ist die Summe der Varianzen, und der Mittelwert aus unabhängigen Messungen hat die Standardabweichung . Der Beweis braucht gemeinsame Dichten und steht in ; wir benutzen die Regeln schon jetzt.  Direkt aus der Definition folgt die Verteilung eines Maximums. Das Argument aus gilt wörtlich: Das Maximum ist höchstens , wenn alle Werte höchstens sind, und mit liefert die Definition dafür das Produkt der Verteilungsfunktionen.   Gespiegelte Festplatten   Ein Server speichert seine Daten gespiegelt auf zwei Festplatten. Verloren sind die Daten erst, wenn beide ausgefallen sind; eine ausgefallene Platte wird hier nicht ersetzt. Die Lebensdauern und der Platten (in Jahren) seien unabhängig mit der Verteilungsfunktion  für und für .   Mit welcher Wahrscheinlichkeit fällt eine einzelne Platte in den ersten zwei Jahren aus, mit welcher sind nach zwei Jahren beide ausgefallen?    Bestimmen Sie Verteilungsfunktion und Dichte der Zeit bis zum Datenverlust.   Vergleichen Sie mit .          . Nach der Definition mit ist .     , also . Die Dichte einer Platte ist auf , und mit der Kettenregel ist auf , sonst 0.    Mit der Substitution , also , , ist und mit und       Die Spiegelung verlängert die mittlere Zeit bis zum Datenverlust von 3,3 auf 4,7 Jahre und senkt das Risiko eines Datenverlusts in den ersten zwei Jahren von 36 % auf 13 %. Die Rechnung setzt voraus, dass die Platten unabhängig ausfallen. Bei zwei Platten aus derselben Fertigungscharge, die im selben Gehäuse unter derselben Last laufen, ist das fraglich; fallen sie gehäuft gemeinsam aus, ist der Gewinn kleiner.      Quantile  Die Verteilungsfunktion beantwortet die Frage Mit welcher Wahrscheinlichkeit ist höchstens ? Oft ist die umgekehrte Frage gestellt: Unter welchem Wert liegt mit Wahrscheinlichkeit 99 %? Das Versprechen vom Anfang des Abschnitts ist von dieser Art, ebenso eine Lieferfrist, die neun von zehn Bestellungen einhalten, oder die Grenze, ab der ein Messwert als auffällig gilt. Bei einer stetigen Verteilungsfunktion löst man dafür nach auf. Bei einer Treppe hat diese Gleichung oft keine Lösung oder unendlich viele, und die Definition muss sagen, welche Zahl gemeint ist.   Quantil  Quantil  Median  Quartil  Perzentil   Sei eine Zufallsvariable mit Verteilungsfunktion und . Das -Quantil von ist die kleinste Zahl, bis zu der mindestens mit Wahrscheinlichkeit reicht:  heißt Median , und heißen unteres und oberes Quartil , heißt -tes Perzentil .    Dass es eine kleinste solche Zahl gibt, sieht man für die Zufallsvariablen dieses Buchs direkt: Bei stetigen ist stetig, und bei diskreten gehört an jeder Sprungstelle der obere Wert zur Funktion. Die Funktion heißt Quantilfunktion Quantilfunktion . Perzentile schreibt man in der Praxis oft kurz als p50, p95 oder p99.   Quantil und Verteilungsfunktion   Sei .   Für alle gilt .    Steigt auf einem Intervall stetig und streng von 0 auf 1, so ist die einzige Lösung der Gleichung in . Dann ist und .       (1) Ist , so ist eine der Zahlen, deren kleinste ist, also . Ist umgekehrt , so ist , weil monoton wächst.  (2) Nach dem Zwischenwertsatz nimmt auf den Wert an, und weil dort streng wächst, genau einmal, an einer Stelle . Links davon ist , also ist die kleinste Stelle mit .    Teil (1) ist das Werkzeug für die Rückrichtung. Höchstens der Anteil überschreitet den Wert heißt , und das ist dasselbe wie . Die kleinste zulässige Grenze ist also das Quantil selbst.   Quantile einer Treppe   Bestimmen Sie für die Zahl der Artikel im Warenkorb aus den Median, das 35. Perzentil und das 90. Perzentil. Welche Zahlen lösen jeweils die Gleichung ?    Die Verteilungsfunktion hat an den Stellen 1 bis 5 die Werte 0,35, 0,65, 0,85, 0,95 und 1 und ist dazwischen konstant.   Median: Die kleinste Stelle mit ist , denn für . Die Gleichung hat keine Lösung, weil die Treppe von 0,35 auf 0,65 springt.    35. Perzentil: gilt für alle im Intervall . Die Definition wählt die kleinste, .    90. Perzentil: , also . Auch hier hat keine Lösung.     Die Hälfte der Bestellungen enthält höchstens zwei Artikel, neun von zehn höchstens vier. Weil springt, gilt sogar mehr: 65 % enthalten höchstens zwei und 95 % höchstens vier. Bei diskreten Größen ist deshalb oft größer als .    Bei stetigen Größen mit streng wachsender Verteilungsfunktion löst man einfach die Gleichung. Das folgende Beispiel zeigt auch, warum man Service-Level-Ziele mit Perzentilen formuliert und nicht mit dem Mittelwert.   Perzentile einer Antwortzeit   Die Antwortzeit eines Webdienstes (in ms) habe die Verteilungsfunktion und für .  Bestimmen Sie den Median und das 99. Perzentil.   Bestimmen Sie die Dichte und den Erwartungswert. Welcher Anteil der Anfragen ist schneller als der Erwartungswert?    Das Service-Level-Ziel lautet: Höchstens 1 % der Anfragen dauern länger als eine Sekunde. Ist es erfüllt? Wie viele von 10 000 Anfragen dauern länger?           steigt auf stetig und streng von 0 gegen 1. Aus folgt , also Der Median ist  ms, das 99. Perzentil  ms.     für . Mit ist Wegen sind drei Viertel der Anfragen schneller als der Erwartungswert; er ist hier das obere Quartil.    Nach ist das Ziel genau dann erfüllt, wenn ist, und das ist es mit 900 ms. Genauer ist  %, also dauern im Mittel etwa 83 von 10 000 Anfragen länger als eine Sekunde.     Der Mittelwert von 100 ms beschreibt hier keine typische Anfrage. Die typische ist mit 41 ms deutlich schneller, und wenige sehr langsame ziehen den Mittelwert nach oben. Deshalb formulieren Betreiber ihre Ziele mit Perzentilen wie p50, p95 und p99, so etwa B. Beyer u. a., Site Reliability Engineering , O'Reilly 2016, Kapitel 4 ( ). Bei dieser Verteilung existiert übrigens keine Varianz: Die Dichte fällt für große nur wie , und wächst wie über alle Grenzen. Das ist das Gegenstück zu eine Stufe höher.     Die Verteilungsfunktion der Antwortzeit aus , links der Ausschnitt bis 200 ms, rechts der ganze Bereich bis eine Sekunde. Ein Quantil liest man rückwärts ab: von der Höhe waagerecht zur Kurve und dann senkrecht hinunter. Median 41 ms, oberes Quartil 100 ms, 99. Perzentil 900 ms.   Zwei Ansichten einer steil ansteigenden Verteilungsfunktion mit gestrichelt abgelesenen Quantilen   Links die Kurve auf dem Bereich von 0 bis 200 Millisekunden: Sie steigt vom Ursprung aus steil an und flacht ab. Gestrichelte Linien führen von den Höhen 0,5 und 0,75 waagerecht zur Kurve und von dort senkrecht hinunter zu 41 und 100 Millisekunden. Rechts dieselbe Kurve auf dem Bereich von 0 bis 1000 Millisekunden: Nach dem steilen Anstieg nähert sie sich langsam der Höhe 1. Eine gestrichelte Linie führt von der Höhe 0,99 waagerecht zur Kurve und hinunter zu 900 Millisekunden.      Quantile haben gegenüber dem Erwartungswert noch einen Vorzug: Sie vertragen jede monotone Umrechnung, der Erwartungswert nur lineare ( ).   Quantile einer monoton umgerechneten Größe   Sei stetig, und steige auf einem Intervall mit stetig und streng von 0 auf 1. Sei auf stetig und streng monoton und .  Ist wachsend, so ist das -Quantil von gleich .  Ist fallend, so ist es .       nimmt seine Werte im Intervall an, und dort ist stetig und streng wachsend. Ist wachsend, so ist . Ist fallend, so ist . In beiden Fällen folgt die Behauptung aus , Teil (2).    Der Median der Antwortzeit in Sekunden ist also 0,0414, und der Median der logarithmierten Antwortzeiten ist der Logarithmus des Medians. Für den Erwartungswert gilt das nicht: . In der Datenanalyse logarithmiert man schiefe Größen wie Antwortzeiten, Einkommen oder Dateigrößen häufig vor der Auswertung; Mediane und Quantile kann man danach einfach zurückrechnen, Mittelwerte nicht.   Quartilsabstand  Quartilsabstand  Boxplot  Die Differenz der Quartile heißt Quartilsabstand . Zwischen den beiden Quartilen liegt die mittlere Hälfte der Werte, und der Quartilsabstand misst, wie breit sie ist. Anders als die Standardabweichung existiert er immer und reagiert kaum auf wenige extreme Werte; er ist deshalb das übliche Streuungsmaß für schiefe Größen. Ein Boxplot zeichnet ihn als Kasten mit dem Median als Strich darin. Für die Antwortzeit aus ist  ms und der Quartilsabstand etwa 84,5 ms, während die Standardabweichung nicht einmal existiert.     Transformationen  Selten wird eine Größe so ausgewertet, wie sie gemessen wurde. Man rechnet Milliampere in Ampere um und Celsius in Fahrenheit, man logarithmiert schiefe Daten, man quadriert Fehler, und aus einer Bearbeitungszeit wird als Kehrwert ein Durchsatz. Ist stetig und , so kennt man Erwartungswert und Varianz von schon aus . Manchmal braucht man aber die ganze Verteilung von , etwa für eine Wahrscheinlichkeit oder ein Quantil. Dafür gibt es einen Weg in drei Schritten:   Man schreibt und formt das Ereignis in ein Ereignis über um.   Man drückt dessen Wahrscheinlichkeit durch aus.  Man leitet nach ab und erhält die Dichte .     Einheiten wechseln      Die Stromstärke aus soll in Ampere angegeben werden, . Bestimmen Sie die Dichte von .    Allgemein sei mit . Zeigen Sie .    Die Temperatur in einem Kühlraum hat in Grad Celsius den Erwartungswert 4, die Standardabweichung 0,5 und den Median 3,8. Geben Sie die drei Kennzahlen in Grad Fahrenheit an, .           . Ableiten mit der Kettenregel ergibt , also für und 0 sonst.    Für ist und . Für dreht sich beim Teilen durch die Ungleichung um: , und die Ableitung ist .    Nach ist und . Der Median rechnet sich wie in um: Grad Fahrenheit. Für genügt dafür schon die Definition des Quantils, denn nach (b) ist .     Eine Dichte ist Wahrscheinlichkeit je Einheit und ändert sich deshalb mit der Einheit: 5 je Milliampere sind 5000 je Ampere. Die Wahrscheinlichkeiten selbst, also die Flächen, bleiben gleich, und die Kennzahlen rechnet man einfach mit um.    Für streng monotone Funktionen lassen sich die drei Schritte ein für allemal ausführen.   Dichte einer monoton umgerechneten Größe  Dichte einer umgerechneten Größe  Transformation einer Zufallsvariablen   Sei stetig mit einer stückweise stetigen Dichte , die außerhalb eines offenen Intervalls null ist. Sei stetig differenzierbar mit für alle , also streng monoton, und sei die Umkehrfunktion von auf . Dann hat die Dichte und für .    Ist wachsend, so ist für  , also , und die Kettenregel ergibt, wo stetig ist, mit . Ist fallend, so ist , also und mit . In beiden Fällen ist das . Weil stetig und bis auf endlich viele Stellen stetig differenzierbar ist, ist diese Ableitung eine Dichte von ; das ist die Umkehrung von Teil (4) in .    Anschaulich: Die Wahrscheinlichkeit in einem kleinen Intervall um landet unverändert in einem kleinen Intervall um . Dieses ist um den Faktor länger oder kürzer, und die Dichte wird um denselben Faktor dünner oder dichter. Genau das sagt der Faktor . Setzt man die Formel in ein und substituiert , erhält man ; für monotone ist also nichts anderes als die Substitutionsregel.   Wie die Leistung verteilt ist   In der Situation von sei , die Leistung in Vielfachen der Konstanten .  Bestimmen Sie die Dichte von .   Bestimmen Sie den Median von und vergleichen Sie mit .           ist auf streng wachsend mit und der Umkehrfunktion , . Nach ist für  sonst 0.    Der Median von ist 5, weil die Dichte symmetrisch um 5 ist. Nach ist der Median von gleich . Er liegt weit unter dem Erwartungswert 200, und es ist .     Die Windgeschwindigkeit ist symmetrisch verteilt, die Leistung nicht mehr: In der Hälfte der Zeit liefert die Anlage weniger als und in gut 60 % der Zeit weniger als ihren Mittelwert . Die dritte Potenz zieht die hohen Windgeschwindigkeiten weit auseinander und staucht die niedrigen zusammen. Für den Median genügt die Umrechnung , für den Erwartungswert braucht man das Integral aus .    Für nicht monotone gilt die Formel nicht, der Weg über die Verteilungsfunktion aber schon.   Der quadrierte Fehler eines Modells   Ein Regressionsmodell macht auf einem neuen Datenpunkt den Fehler (Vorhersage minus wahrer Wert, in normierten Einheiten) mit der Dichte Bewertet wird das Modell mit dem quadrierten Fehler .  Bestimmen Sie Verteilungsfunktion und Dichte von .   Bestimmen Sie auf zwei Wegen: mit und mit .    Mit welcher Wahrscheinlichkeit ist der quadrierte Fehler kleiner als ?           liegt in . Für ist , also Ableiten ergibt für , sonst 0.    Mit : . Mit : .     .      ist der mittlere quadratische Fehler (MSE) des Modells. Wer nur ihn braucht, nimmt den zweiten Weg, er ist fast immer kürzer. Die Dichte von wächst bei 0 über alle Grenzen, obwohl die von dort ihr Maximum hat: Kleine Fehler werden durch das Quadrieren noch kleiner und drängen sich bei 0 ( ). Das ist kein Widerspruch, eine Dichte muss nur integrierbar sein. Weil auf nicht monoton ist, hätte hier nicht geholfen: Zu jedem gehören die beiden Urbilder .     Links die Dichte des Fehlers , rechts die des quadrierten Fehlers aus . Die rechte Dichte wächst bei 0 über alle Grenzen und ist im Bild abgeschnitten.   Links eine Parabel über minus 1 bis 1, rechts eine bei 0 steil fallende Kurve   Links eine nach unten geöffnete Parabel über dem Intervall von minus 1 bis 1 mit dem Maximum 0,75 bei 0 und Nullstellen bei minus 1 und 1. Rechts, auf dem Intervall von 0 bis 1, eine Kurve, die am linken Rand oberhalb des Bildes beginnt, steil abfällt, bei 0,5 ungefähr den Wert 0,53 hat und bei 1 auf null sinkt.      Transformationen sind auch der Schlüssel zu einer ganz praktischen Frage. Simulationen brauchen Zufallszahlen mit vorgegebener Verteilung: künstliche Antwortzeiten für einen Lasttest, Schadenhöhen für ein Risikomodell, Lebensdauern für die Planung von Ersatzteilen. Ein Zufallszahlengenerator erzeugt im Kern aber nur eine Sorte, und alles andere wird daraus umgerechnet. In Python gibt random.random() Zahlen aus aus, mit für , also mit der konstanten Dichte 1 auf . Eine passende Funktion macht daraus jede andere Verteilung.   Inversionsmethode  Inversionsmethode   Sei eine Verteilungsfunktion mit den Quantilen für , und sei eine Zufallsvariable mit für . Dann hat die Verteilungsfunktion . Steigt auf einem Intervall stetig und streng von 0 auf 1, so ist .     liegt mit Wahrscheinlichkeit 1 in . Nach , Teil (1), ist genau dann, wenn ist. Also ist . Der Zusatz ist Teil (2) desselben Satzes.    Die Inversionsmethode setzt also eine zufällige Höhe in die Quantilfunktion ein: Man liest rückwärts ab, von einer zufälligen Höhe aus. Weil die Definition des Quantils auch für Treppen gilt, funktioniert das ebenso für diskrete Verteilungen. Auch die Umkehrung ist nützlich: Steigt stetig und streng, so ist . Setzt man Messwerte in die Verteilungsfunktion eines Modells ein, so müssen die Ergebnisse also gleichmäßig über streuen, wenn das Modell stimmt. Das ist eine gängige Probe für Modelle, die ganze Verteilungen vorhersagen.   Antwortzeiten für einen Lasttest   Ein Lasttest soll Antwortzeiten mit der Verteilungsfunktion aus erzeugen.   Geben Sie eine Funktion an, sodass diese Verteilung hat.    Welche Antwortzeiten erzeugen die Werte , und ?    Welcher Anteil der erzeugten Antwortzeiten ist länger als 100 ms? Warum sieht man das, ohne auszuwerten?           steigt auf stetig und streng von 0 gegen 1. Die Umkehrfunktion ist die Quantilfunktion aus , .     , und , also der Median, das obere Quartil und das 99. Perzentil.     ist streng wachsend, also ist genau dann, wenn ist. Das hat die Wahrscheinlichkeit , passend zu .     Die Höhe ist der Anteil der Antwortzeiten, die unter dem erzeugten Wert liegen. Wer im Lasttest gezielt nur langsame Anfragen braucht, zieht deshalb nur aus dem oberen Teil des Intervalls, etwa aus für das langsamste Prozent.    Die folgende Zelle erzeugt auf diese Weise Antwortzeiten und vergleicht Median, 99. Perzentil und Mittelwert der Stichprobe mit dem Modell.   import random # Antwortzeiten nach der Inversionsmethode, g(u) = 100 \/ Wurzel(1 - u) - 100. # Probieren Sie n = 1000, 10000, 100000, jeweils mehrmals. n = 1000 x = sorted([100 \/ (1 - random.random()) ** 0.5 - 100 for _ in range(n)]) print(\"Median: %7.1f ms (Modell: 41.4)\" % x[n \/\/ 2 - 1]) print(\"99. Perzentil: %7.1f ms (Modell: 900.0)\" % x[int(0.99 * n) - 1]) print(\"Mittelwert: %7.1f ms (Modell: 100.0)\" % (sum(x) \/ n))   Der Median schwankt schon bei 1000 Werten nur um wenige Millisekunden. Das 99. Perzentil und der Mittelwert schwanken von Lauf zu Lauf deutlich stärker, weil sie von wenigen sehr großen Werten abhängen. Auch das spricht dafür, Antwortzeiten mit dem Median zu beschreiben, und dafür, ein 99. Perzentil nur aus vielen Messungen zu schätzen.    Zusammenfassung      Dichte.  ist stetig mit Dichte , wenn für alle gilt; dann ist . Jeder einzelne Wert hat die Wahrscheinlichkeit ; ob oder gemeint ist, spielt deshalb keine Rolle. Die Dichte ist Wahrscheinlichkeit je Einheit und kann größer als 1 sein. Eine Form mit freier Konstante normiert man, indem man die Gesamtfläche gleich 1 setzt.     Verteilungsfunktion.  ist stetig, und . Umgekehrt ist , wo stetig ist. Ist die Verteilungsfunktion leichter zu bekommen, bestimmt man sie zuerst und leitet ab.     Erwartungswert und Varianz.  , und , im Allgemeinen ungleich . Die Rechenregeln , , und gelten wie im Diskreten.     Unabhängigkeit.  sind unabhängig, wenn für alle gilt. Das Produkt gilt dann auch für Intervalle, und die Varianz einer Summe ist die Summe der Varianzen. Das Maximum unabhängiger Größen mit derselben Verteilungsfunktion hat die Verteilungsfunktion .     Quantile.  ; der Median ist , die Quartile sind und . Es gilt . Steigt stetig und streng, so ist die Lösung von ; bei einer Treppe nimmt man die kleinste Stelle, an der die Höhe erreicht.     Median und Erwartungswert. Bei schiefen Verteilungen können sie weit auseinanderliegen, und wenige extreme Werte bestimmen den Erwartungswert. Quantile und der Quartilsabstand reagieren darauf kaum und existieren immer. Ist stetig mit streng wachsender Verteilungsfunktion, so ist für stetiges, streng wachsendes das -Quantil von gleich , für streng fallendes .     Transformationen. Für schreibt man als Wahrscheinlichkeit über und leitet ab. Ist stetig differenzierbar mit , also streng monoton, und die Umkehrfunktion, so ist , insbesondere .     Inversionsmethode. Gilt für , so hat die Verteilungsfunktion ; bei stetig und streng wachsendem ist das . So erzeugt man aus random.random() Zufallszahlen mit jeder gewünschten Verteilung.       Übungsaufgaben   Eine Wartungsdauer   Die Dauer einer Wartung (in Stunden) habe die Dichte für und 0 sonst.  Bestimmen Sie .   Mit welcher Wahrscheinlichkeit ist die Wartung nach einer Stunde erledigt?   Bestimmen Sie .          , also . Auf ist .     .     Stunden.        Eine Wurzel als Verteilungsfunktion   Eine Zufallsvariable habe die Verteilungsfunktion für , mit für und für .   Bestimmen Sie die Dichte. Wie verhält sie sich in der Nähe von 0?   Bestimmen Sie den Median und das 90. Perzentil.   Bestimmen Sie und vergleichen Sie mit dem Median.    Wie erzeugt man aus random.random() Zufallszahlen mit dieser Verteilung?           für , sonst 0. Sie wächst bei 0 über alle Grenzen, ist aber integrierbar, und ihre Fläche ist .    Aus folgt : Median , 90. Perzentil .     . Der Erwartungswert liegt über dem Median, weil die meiste Wahrscheinlichkeit nahe bei 0 liegt und die wenigen größeren Werte den Mittelwert nach oben ziehen.    Mit der Inversionsmethode: Die Umkehrfunktion von ist , also hat die gewünschte Verteilung, in Python random.random() ** 2 . Probe: .        Der Median eines Würfels   Sei die Augenzahl eines fairen Würfels.   Welche Zahlen lösen die Gleichung ? Welche davon ist der Median?    Wie erzeugt die Inversionsmethode aus einer Zahl von random.random() einen Würfelwurf?           gilt für alle mit . Der Median ist die kleinste Stelle mit , also . Im Alltag nennt man bei einer geraden Zahl gleich wahrscheinlicher Werte oft die Mitte 3,5; das ist eine andere Konvention.    Sie gibt das -Quantil aus, also die kleinste Zahl mit . Das ist die kleinste ganze Zahl : eine 1 für , eine 2 für und so weiter. Jede Augenzahl gehört zu einem Intervall der Länge und kommt deshalb mit Wahrscheinlichkeit . In Python leistet int(6 * random.random()) + 1 dasselbe; die beiden Vorschriften unterscheiden sich nur, wenn ganzzahlig ist, und das hat die Wahrscheinlichkeit null.        Zwei Bauteile in Reihe   Ein Gerät enthält zwei Bauteile und fällt aus, sobald eines von beiden ausfällt. Die Lebensdauern und der Bauteile (in Jahren) seien unabhängig, jede mit der Dichte auf und 0 sonst.   Mit welcher Wahrscheinlichkeit halten beide Bauteile länger als ein Jahr?    Bestimmen Sie Verteilungsfunktion und Dichte der Lebensdauer des Geräts.    Welche Garantiezeit überstehen 90 % der Geräte?          Ein Bauteil hat auf , also . Weil das Produkt bei unabhängigen Zufallsvariablen auch für Halbgeraden gilt, ist .    Das Minimum ist größer als , wenn beide Lebensdauern größer als sind. Für ist also , und damit auf ; außerhalb ist .    Gesucht ist mit , also und Jahre, rund acht Wochen. Das ist das 10. Perzentil von . Ein einzelnes Bauteil übersteht mit derselben Wahrscheinlichkeit Jahre, fast doppelt so lange.        Radius und Fläche   Der Radius eines Kreises habe die Dichte für und 0 sonst. Sei die Fläche des Kreises als Anteil der Fläche des Einheitskreises.   Bestimmen Sie Verteilungsfunktion und Dichte von .    Bestimmen Sie und . Warum stimmen sie überein?          Für ist , denn . Also ist auf : Die Fläche hat eine konstante Dichte.     und . Es ist dasselbe Ereignis, denn heißt . Bis auf den Maßstab ist der Abstand aus , und die konstante Dichte von ist die Annahme von dort, dass die Wahrscheinlichkeit eines Gebiets sein Flächenanteil ist.        "
},
{
  "id": "sec-stetige-zufallsvariablen-dichte-2",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#sec-stetige-zufallsvariablen-dichte-2",
  "type": "Lernziele",
  "number": "3.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     Wahrscheinlichkeiten als Flächen unter einer Dichte berechnen und eine Funktion mit freier Konstante zu einer Dichte normieren,    zwischen Dichte und Verteilungsfunktion wechseln, durch Integrieren in die eine Richtung und Ableiten in die andere,    Erwartungswert, Varianz und als Integrale berechnen und die Rechenregeln aus auf stetige Zufallsvariablen anwenden,    Median, Quartile und andere Quantile bestimmen, auch in Rückrichtung als Schwelle zu einer vorgegebenen Wahrscheinlichkeit, und bei schiefen Verteilungen Median und Erwartungswert gegeneinander abwägen,    Verteilungsfunktion und Dichte einer umgerechneten Größe bestimmen, auch wenn nicht monoton ist,    mit der Inversionsmethode aus Zufallszahlen im Intervall solche mit vorgegebener Verteilung erzeugen,    die Unabhängigkeit beliebiger Zufallsvariablen über ihre Verteilungsfunktionen ausdrücken und damit rechnen.    "
},
{
  "id": "fig-histogramm-dichte",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#fig-histogramm-dichte",
  "type": "Abbildung",
  "number": "3.1.1",
  "title": "",
  "body": " Ein Histogramm der Windgeschwindigkeit mit Klassen der Breite 2 m\/s, wie es aussähe, wenn die Daten genau der Dichte folgten. Die Balken zeigen keine Messwerte, sondern die Klassenwahrscheinlichkeiten der Dichte: Die Höhe jedes Balkens ist die Wahrscheinlichkeit der Klasse geteilt durch ihre Breite, seine Fläche also die Wahrscheinlichkeit selbst. Die Kurve ist die Dichte aus .   Fünf Histogrammbalken, darüber eine glockenförmige Parabel   Über den Klassen 0 bis 2, 2 bis 4, 4 bis 6, 6 bis 8 und 8 bis 10 stehen graue Balken der Höhen 0,052, 0,124, 0,148, 0,124 und 0,052. Eine dicke Kurve, eine nach unten geöffnete Parabel mit Nullstellen bei 0 und 10 und dem Maximum 0,15 bei 5, verläuft durch die Balken. In der Mitte ragt sie etwas über den Balken hinaus, an den Rändern bleibt sie teils darunter; die Flächen stimmen je Klasse überein.     "
},
{
  "id": "def-stetige-zufallsvariable",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#def-stetige-zufallsvariable",
  "type": "Definition",
  "number": "3.1.2",
  "title": "Stetige Zufallsvariable, Dichte.",
  "body": " Stetige Zufallsvariable, Dichte  Zufallsvariable stetige  Dichte   Sei eine Zufallsvariable. Gibt es eine integrierbare Funktion mit  für alle und    für alle reellen Zahlen ,   so heißt  stetige Zufallsvariable . Die Funktion heißt Wahrscheinlichkeitsdichte Wahrscheinlichkeitsdichte oder kurz Dichte von .   "
},
{
  "id": "thm-eigenschaften-dichte",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-eigenschaften-dichte",
  "type": "Satz",
  "number": "3.1.3",
  "title": "Eigenschaften von Dichte und Verteilungsfunktion.",
  "body": " Eigenschaften von Dichte und Verteilungsfunktion   Sei eine stetige Zufallsvariable mit Dichte und Verteilungsfunktion . Dann gilt:    für jedes . Für haben deshalb , , und dieselbe Wahrscheinlichkeit.     . Insbesondere ist stetig, und es ist und .     .    An jeder Stelle , an der stetig ist, ist differenzierbar mit .       (1) Für jedes ist , also . Das Integral über ein immer kürzeres Intervall geht für gegen null. Die vier Ereignisse unterscheiden sich nur um die Randpunkte und .  (2) ist die disjunkte Vereinigung der Ereignisse für Nach dem dritten Axiom und (1) ist Ein Integral mit variabler oberer Grenze ist stetig in dieser Grenze. Aus und (1) folgen und .  (3) folgt aus (2) und . Zieht man davon ab, bleibt . (4) ist der Hauptsatz der Differential- und Integralrechnung, angewandt auf (2).   "
},
{
  "id": "ex-elektrischer-strom",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-elektrischer-strom",
  "type": "Beispiel",
  "number": "3.1.4",
  "title": "Elektrischer Strom.",
  "body": " Elektrischer Strom   Die Stromstärke in einem dünnen Kupferdraht wird in Milliampere gemessen. Sie liegt zwischen 4,9 und 5,1 mA und hat die Dichte (Beispiel nach Montgomery und Runger )    Prüfen Sie, dass eine Dichte ist, obwohl sie Werte größer als 1 annimmt.    Mit welcher Wahrscheinlichkeit wird ein Strom von weniger als 5 mA gemessen?    Mit welcher Wahrscheinlichkeit liegt der gemessene Strom zwischen 4,95 und 5,1 mA, und mit welcher ist er genau 5 mA?           ist nichtnegativ, und die Fläche unter ihr ist ein Rechteck der Breite und der Höhe 5, also . Der Wert 5 bedeutet Wahrscheinlichkeit 5 je Milliampere; auf einem Intervall von 0,2 mA ergibt das zusammen 1.     .     und nach .     Bei einer konstanten Dichte ist jede Wahrscheinlichkeit proportional zur Länge des Intervalls; die Rechnung ist Flächenberechnung von Rechtecken. Dichten, die auf einem Intervall konstant sind, kommen in als eigene Familie wieder. Das Beispiel stammt aus D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley 2018, Kapitel 4 ( ); Teil (a) und die Frage nach genau 5 mA sind für dieses Buch ergänzt.   "
},
{
  "id": "sub-dichte-12",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#sub-dichte-12",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Normieren "
},
{
  "id": "ex-windgeschwindigkeit",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-windgeschwindigkeit",
  "type": "Beispiel",
  "number": "3.1.5",
  "title": "Eine Dichte normieren.",
  "body": " Eine Dichte normieren   Die Windgeschwindigkeit (in m\/s) an einem Standort wird vereinfacht durch die Dichte beschrieben.  Bestimmen Sie die Konstante .   Bestimmen Sie die Verteilungsfunktion für alle .    Mit welcher Wahrscheinlichkeit weht der Wind schwächer als 3 m\/s, mit welcher zwischen 3 und 8 m\/s?          Für ist . Die Fläche ist also muss sein.    Für ist Links von 0 ist , rechts von 10 ist . Probe: .     und , also .     In gut einem Fünftel der Zeit weht der Wind schwächer als 3 m\/s; viele Windkraftanlagen liefern dann noch keinen Strom. zeigt beide Funktionen: Die Wahrscheinlichkeit aus (c) ist oben eine Fläche und unten ein Höhenunterschied. Gemessene Windgeschwindigkeiten haben meist einen längeren rechten Rand, als diese symmetrische Parabel ihn hat. Sie ist hier gewählt, weil sich mit ihr alle Integrale von Hand ausrechnen lassen.   "
},
{
  "id": "fig-dichte-verteilungsfunktion",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#fig-dichte-verteilungsfunktion",
  "type": "Abbildung",
  "number": "3.1.6",
  "title": "",
  "body": " Dichte (oben) und Verteilungsfunktion (unten) der Windgeschwindigkeit aus . Die graue Fläche ist unten der Zuwachs .   Oben eine Parabel mit grauer Fläche zwischen 3 und 8, unten eine S-förmige Kurve von 0 bis 1   Oben die Dichte, eine nach unten geöffnete Parabel über dem Intervall von 0 bis 10 mit dem Maximum 0,15 bei 5. Die Fläche unter ihr zwischen 3 und 8 ist grau gefüllt und mit 0,68 beschriftet. Darunter, mit derselben waagerechten Achse, die Verteilungsfunktion: Sie steigt S-förmig von 0 bei 0 auf 1 bei 10, am steilsten in der Mitte, und bleibt danach bei 1. Gestrichelte Linien markieren die Werte 0,216 bei 3 und 0,896 bei 8, ein Doppelpfeil rechts den Abstand 0,68 zwischen ihnen.     "
},
{
  "id": "ex-funkmast",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-funkmast",
  "type": "Beispiel",
  "number": "3.1.7",
  "title": "Abstand zum Funkmast.",
  "body": " Abstand zum Funkmast   Ein Mobilfunkmast versorgt eine kreisförmige Fläche mit dem Radius 2 km. Die Kundinnen und Kunden wohnen gleichmäßig über diese Fläche verteilt: Die Wahrscheinlichkeit, dass eine zufällig gewählte Person in einem Teilgebiet wohnt, ist dessen Anteil an der Gesamtfläche. Sei ihr Abstand zum Mast in km.  Bestimmen Sie die Verteilungsfunktion von .  Bestimmen Sie die Dichte von .   Mit welcher Wahrscheinlichkeit wohnt die Person weiter als 1 km vom Mast entfernt?           ist für die Kreisscheibe mit Radius um den Mast. Ihr Anteil an der Gesamtfläche ist mit für und für .     ist stetig und außer bei differenzierbar, also ist für und sonst. Probe: Die Fläche des Dreiecks unter ist .     .     Die Dichte wächst mit dem Abstand, weil ein schmaler Ring um den Mast umso mehr Fläche hat, je weiter außen er liegt. Drei Viertel der Kundschaft wohnen in der äußeren Hälfte des Radius, wo das Signal am schwächsten ist. Für die Netzplanung ist das die entscheidende Zahl, und sie ergibt sich ohne jede Integration, direkt aus der Verteilungsfunktion.   "
},
{
  "id": "def-erwartungswert-stetig",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#def-erwartungswert-stetig",
  "type": "Definition",
  "number": "3.1.8",
  "title": "Erwartungswert, Varianz und Standardabweichung.",
  "body": " Erwartungswert, Varianz und Standardabweichung  Erwartungswert einer stetigen Zufallsvariablen  Varianz einer stetigen Zufallsvariablen   Sei eine stetige Zufallsvariable mit Dichte .   Der Erwartungswert von ist sofern ist.    Die Varianz von ist sofern existiert und dieses Integral endlich ist. Die Standardabweichung ist .      "
},
{
  "id": "thm-transformationssatz-stetig",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-transformationssatz-stetig",
  "type": "Satz",
  "number": "3.1.9",
  "title": "Erwartungswert einer Funktion, stetiger Fall (Transformationssatz).",
  "body": " Erwartungswert einer Funktion, stetiger Fall (Transformationssatz)  Transformationssatz stetiger Fall  Erwartungswert einer Funktion   Sei stetig mit Dichte und stückweise stetig, also stetig bis auf endlich viele Sprungstellen. Dann ist sofern das Integral mit an Stelle von endlich ist.   "
},
{
  "id": "tab-diskret-stetig",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#tab-diskret-stetig",
  "type": "Tabelle",
  "number": "3.1.10",
  "title": "Wörterbuch diskret und stetig",
  "body": " Wörterbuch diskret und stetig        diskret  stetig    Verteilung durch   Dichte , dabei    Normierung            Treppe,  stetig,    zurück  , falls ganzzahlig     oder  macht einen Unterschied  gleichgültig                   "
},
{
  "id": "thm-rechenregeln-stetig",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-rechenregeln-stetig",
  "type": "Satz",
  "number": "3.1.11",
  "title": "Rechenregeln für stetige Zufallsvariablen.",
  "body": " Rechenregeln für stetige Zufallsvariablen   Sei eine stetige Zufallsvariable, deren Erwartungswert existiert, und seien . Dann gilt  ,  ,  und .  Für (2) und (3) muss auch existieren.    (1) und (2) folgen aus : und ebenso . Für (3) setzt man in denselben Satz ein.   "
},
{
  "id": "ex-kennzahlen-stetig",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-kennzahlen-stetig",
  "type": "Beispiel",
  "number": "3.1.12",
  "title": "Erwartungswerte als Integrale.",
  "body": " Erwartungswerte als Integrale   Bestimmen Sie Erwartungswert und Standardabweichung   der Stromstärke aus ,    des Abstands zum Funkmast aus .          Die Dichte ist symmetrisch um 5, also ist  mA. Zur Probe: . Weiter ist also  mA.      km. Mit dem Verschiebungssatz, der nach weiter gilt, und ist      Bei der konstanten Dichte liegt der Schwerpunkt in der Mitte, beim Funkmast weiter außen: Im Mittel wohnt die Kundschaft  km vom Mast entfernt, nicht 1 km, weil die äußeren Ringe mehr Fläche haben.   "
},
{
  "id": "ex-windleistung",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-windleistung",
  "type": "Beispiel",
  "number": "3.1.13",
  "title": "Mittlere Windgeschwindigkeit, mittlere Leistung.",
  "body": " Mittlere Windgeschwindigkeit, mittlere Leistung   Die Leistung einer Windkraftanlage wächst unterhalb ihrer Nennleistung mit der dritten Potenz der Windgeschwindigkeit, für eine Konstante . Vereinfachend gelte das für alle Windgeschwindigkeiten bis 10 m\/s, und habe die Dichte aus .  Bestimmen Sie und .   Bestimmen Sie und vergleichen Sie mit . Um wie viel Prozent unterschätzt eine Ertragsprognose, die mit der mittleren Windgeschwindigkeit rechnet?    Welcher Anteil des mittleren Ertrags stammt aus den Stunden mit  m\/s, und welchen Anteil der Zeit machen sie aus?       Mit auf :   Die Dichte ist symmetrisch um 5, also  m\/s. Weiter ist also und  m\/s.     dagegen . Die mittlere Leistung ist , die Prognose mit der mittleren Windgeschwindigkeit ergibt und liegt um  % zu niedrig.     das sind  % von . Der Anteil der Zeit ist .     Weil die Leistung mit der dritten Potenz wächst, zählen die windstarken Stunden überproportional: Ein Zehntel der Zeit liefert gut ein Drittel der Energie, und mit der mittleren Windgeschwindigkeit gerechnet fehlt mehr als ein Drittel des Ertrags. Deshalb geben Windgutachten die Verteilung der Windgeschwindigkeit an und nicht nur ihren Mittelwert.   "
},
{
  "id": "def-unabhaengigkeit-allgemein",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#def-unabhaengigkeit-allgemein",
  "type": "Definition",
  "number": "3.1.14",
  "title": "Unabhängige Zufallsvariablen, allgemeiner Fall.",
  "body": " Unabhängige Zufallsvariablen, allgemeiner Fall  Unabhängigkeit von Zufallsvariablen allgemeiner Fall   Zufallsvariablen auf demselben Wahrscheinlichkeitsraum heißen unabhängig , wenn für alle  gilt.   "
},
{
  "id": "thm-unabhaengigkeit-intervalle",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-unabhaengigkeit-intervalle",
  "type": "Satz",
  "number": "3.1.15",
  "title": "Unabhängigkeit für Intervalle.",
  "body": " Unabhängigkeit für Intervalle   Sind und unabhängig, so gilt für und      Sei . Das Ereignis zerfällt in das Rechteck und die Vereinigung von und , die sich in überschneiden. Mit der Additionsregel aus ist    "
},
{
  "id": "ex-gespiegelte-festplatten",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-gespiegelte-festplatten",
  "type": "Beispiel",
  "number": "3.1.16",
  "title": "Gespiegelte Festplatten.",
  "body": " Gespiegelte Festplatten   Ein Server speichert seine Daten gespiegelt auf zwei Festplatten. Verloren sind die Daten erst, wenn beide ausgefallen sind; eine ausgefallene Platte wird hier nicht ersetzt. Die Lebensdauern und der Platten (in Jahren) seien unabhängig mit der Verteilungsfunktion  für und für .   Mit welcher Wahrscheinlichkeit fällt eine einzelne Platte in den ersten zwei Jahren aus, mit welcher sind nach zwei Jahren beide ausgefallen?    Bestimmen Sie Verteilungsfunktion und Dichte der Zeit bis zum Datenverlust.   Vergleichen Sie mit .          . Nach der Definition mit ist .     , also . Die Dichte einer Platte ist auf , und mit der Kettenregel ist auf , sonst 0.    Mit der Substitution , also , , ist und mit und       Die Spiegelung verlängert die mittlere Zeit bis zum Datenverlust von 3,3 auf 4,7 Jahre und senkt das Risiko eines Datenverlusts in den ersten zwei Jahren von 36 % auf 13 %. Die Rechnung setzt voraus, dass die Platten unabhängig ausfallen. Bei zwei Platten aus derselben Fertigungscharge, die im selben Gehäuse unter derselben Last laufen, ist das fraglich; fallen sie gehäuft gemeinsam aus, ist der Gewinn kleiner.   "
},
{
  "id": "def-quantil",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#def-quantil",
  "type": "Definition",
  "number": "3.1.17",
  "title": "Quantil.",
  "body": " Quantil  Quantil  Median  Quartil  Perzentil   Sei eine Zufallsvariable mit Verteilungsfunktion und . Das -Quantil von ist die kleinste Zahl, bis zu der mindestens mit Wahrscheinlichkeit reicht:  heißt Median , und heißen unteres und oberes Quartil , heißt -tes Perzentil .   "
},
{
  "id": "sub-quantile-4",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#sub-quantile-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Quantilfunktion "
},
{
  "id": "thm-quantil-eigenschaften",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-quantil-eigenschaften",
  "type": "Satz",
  "number": "3.1.18",
  "title": "Quantil und Verteilungsfunktion.",
  "body": " Quantil und Verteilungsfunktion   Sei .   Für alle gilt .    Steigt auf einem Intervall stetig und streng von 0 auf 1, so ist die einzige Lösung der Gleichung in . Dann ist und .       (1) Ist , so ist eine der Zahlen, deren kleinste ist, also . Ist umgekehrt , so ist , weil monoton wächst.  (2) Nach dem Zwischenwertsatz nimmt auf den Wert an, und weil dort streng wächst, genau einmal, an einer Stelle . Links davon ist , also ist die kleinste Stelle mit .   "
},
{
  "id": "ex-quantile-treppe",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-quantile-treppe",
  "type": "Beispiel",
  "number": "3.1.19",
  "title": "Quantile einer Treppe.",
  "body": " Quantile einer Treppe   Bestimmen Sie für die Zahl der Artikel im Warenkorb aus den Median, das 35. Perzentil und das 90. Perzentil. Welche Zahlen lösen jeweils die Gleichung ?    Die Verteilungsfunktion hat an den Stellen 1 bis 5 die Werte 0,35, 0,65, 0,85, 0,95 und 1 und ist dazwischen konstant.   Median: Die kleinste Stelle mit ist , denn für . Die Gleichung hat keine Lösung, weil die Treppe von 0,35 auf 0,65 springt.    35. Perzentil: gilt für alle im Intervall . Die Definition wählt die kleinste, .    90. Perzentil: , also . Auch hier hat keine Lösung.     Die Hälfte der Bestellungen enthält höchstens zwei Artikel, neun von zehn höchstens vier. Weil springt, gilt sogar mehr: 65 % enthalten höchstens zwei und 95 % höchstens vier. Bei diskreten Größen ist deshalb oft größer als .   "
},
{
  "id": "ex-antwortzeiten-perzentile",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-antwortzeiten-perzentile",
  "type": "Beispiel",
  "number": "3.1.20",
  "title": "Perzentile einer Antwortzeit.",
  "body": " Perzentile einer Antwortzeit   Die Antwortzeit eines Webdienstes (in ms) habe die Verteilungsfunktion und für .  Bestimmen Sie den Median und das 99. Perzentil.   Bestimmen Sie die Dichte und den Erwartungswert. Welcher Anteil der Anfragen ist schneller als der Erwartungswert?    Das Service-Level-Ziel lautet: Höchstens 1 % der Anfragen dauern länger als eine Sekunde. Ist es erfüllt? Wie viele von 10 000 Anfragen dauern länger?           steigt auf stetig und streng von 0 gegen 1. Aus folgt , also Der Median ist  ms, das 99. Perzentil  ms.     für . Mit ist Wegen sind drei Viertel der Anfragen schneller als der Erwartungswert; er ist hier das obere Quartil.    Nach ist das Ziel genau dann erfüllt, wenn ist, und das ist es mit 900 ms. Genauer ist  %, also dauern im Mittel etwa 83 von 10 000 Anfragen länger als eine Sekunde.     Der Mittelwert von 100 ms beschreibt hier keine typische Anfrage. Die typische ist mit 41 ms deutlich schneller, und wenige sehr langsame ziehen den Mittelwert nach oben. Deshalb formulieren Betreiber ihre Ziele mit Perzentilen wie p50, p95 und p99, so etwa B. Beyer u. a., Site Reliability Engineering , O'Reilly 2016, Kapitel 4 ( ). Bei dieser Verteilung existiert übrigens keine Varianz: Die Dichte fällt für große nur wie , und wächst wie über alle Grenzen. Das ist das Gegenstück zu eine Stufe höher.   "
},
{
  "id": "fig-quantile-antwortzeit",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#fig-quantile-antwortzeit",
  "type": "Abbildung",
  "number": "3.1.21",
  "title": "",
  "body": " Die Verteilungsfunktion der Antwortzeit aus , links der Ausschnitt bis 200 ms, rechts der ganze Bereich bis eine Sekunde. Ein Quantil liest man rückwärts ab: von der Höhe waagerecht zur Kurve und dann senkrecht hinunter. Median 41 ms, oberes Quartil 100 ms, 99. Perzentil 900 ms.   Zwei Ansichten einer steil ansteigenden Verteilungsfunktion mit gestrichelt abgelesenen Quantilen   Links die Kurve auf dem Bereich von 0 bis 200 Millisekunden: Sie steigt vom Ursprung aus steil an und flacht ab. Gestrichelte Linien führen von den Höhen 0,5 und 0,75 waagerecht zur Kurve und von dort senkrecht hinunter zu 41 und 100 Millisekunden. Rechts dieselbe Kurve auf dem Bereich von 0 bis 1000 Millisekunden: Nach dem steilen Anstieg nähert sie sich langsam der Höhe 1. Eine gestrichelte Linie führt von der Höhe 0,99 waagerecht zur Kurve und hinunter zu 900 Millisekunden.     "
},
{
  "id": "thm-quantil-monoton",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-quantil-monoton",
  "type": "Satz",
  "number": "3.1.22",
  "title": "Quantile einer monoton umgerechneten Größe.",
  "body": " Quantile einer monoton umgerechneten Größe   Sei stetig, und steige auf einem Intervall mit stetig und streng von 0 auf 1. Sei auf stetig und streng monoton und .  Ist wachsend, so ist das -Quantil von gleich .  Ist fallend, so ist es .       nimmt seine Werte im Intervall an, und dort ist stetig und streng wachsend. Ist wachsend, so ist . Ist fallend, so ist . In beiden Fällen folgt die Behauptung aus , Teil (2).   "
},
{
  "id": "rem-quartilsabstand",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#rem-quartilsabstand",
  "type": "Bemerkung",
  "number": "3.1.23",
  "title": "Quartilsabstand.",
  "body": " Quartilsabstand  Quartilsabstand  Boxplot  Die Differenz der Quartile heißt Quartilsabstand . Zwischen den beiden Quartilen liegt die mittlere Hälfte der Werte, und der Quartilsabstand misst, wie breit sie ist. Anders als die Standardabweichung existiert er immer und reagiert kaum auf wenige extreme Werte; er ist deshalb das übliche Streuungsmaß für schiefe Größen. Ein Boxplot zeichnet ihn als Kasten mit dem Median als Strich darin. Für die Antwortzeit aus ist  ms und der Quartilsabstand etwa 84,5 ms, während die Standardabweichung nicht einmal existiert.  "
},
{
  "id": "ex-einheitenwechsel",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-einheitenwechsel",
  "type": "Beispiel",
  "number": "3.1.24",
  "title": "Einheiten wechseln.",
  "body": " Einheiten wechseln      Die Stromstärke aus soll in Ampere angegeben werden, . Bestimmen Sie die Dichte von .    Allgemein sei mit . Zeigen Sie .    Die Temperatur in einem Kühlraum hat in Grad Celsius den Erwartungswert 4, die Standardabweichung 0,5 und den Median 3,8. Geben Sie die drei Kennzahlen in Grad Fahrenheit an, .           . Ableiten mit der Kettenregel ergibt , also für und 0 sonst.    Für ist und . Für dreht sich beim Teilen durch die Ungleichung um: , und die Ableitung ist .    Nach ist und . Der Median rechnet sich wie in um: Grad Fahrenheit. Für genügt dafür schon die Definition des Quantils, denn nach (b) ist .     Eine Dichte ist Wahrscheinlichkeit je Einheit und ändert sich deshalb mit der Einheit: 5 je Milliampere sind 5000 je Ampere. Die Wahrscheinlichkeiten selbst, also die Flächen, bleiben gleich, und die Kennzahlen rechnet man einfach mit um.   "
},
{
  "id": "thm-dichtetransformation",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-dichtetransformation",
  "type": "Satz",
  "number": "3.1.25",
  "title": "Dichte einer monoton umgerechneten Größe.",
  "body": " Dichte einer monoton umgerechneten Größe  Dichte einer umgerechneten Größe  Transformation einer Zufallsvariablen   Sei stetig mit einer stückweise stetigen Dichte , die außerhalb eines offenen Intervalls null ist. Sei stetig differenzierbar mit für alle , also streng monoton, und sei die Umkehrfunktion von auf . Dann hat die Dichte und für .    Ist wachsend, so ist für  , also , und die Kettenregel ergibt, wo stetig ist, mit . Ist fallend, so ist , also und mit . In beiden Fällen ist das . Weil stetig und bis auf endlich viele Stellen stetig differenzierbar ist, ist diese Ableitung eine Dichte von ; das ist die Umkehrung von Teil (4) in .   "
},
{
  "id": "ex-verteilung-windleistung",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-verteilung-windleistung",
  "type": "Beispiel",
  "number": "3.1.26",
  "title": "Wie die Leistung verteilt ist.",
  "body": " Wie die Leistung verteilt ist   In der Situation von sei , die Leistung in Vielfachen der Konstanten .  Bestimmen Sie die Dichte von .   Bestimmen Sie den Median von und vergleichen Sie mit .           ist auf streng wachsend mit und der Umkehrfunktion , . Nach ist für  sonst 0.    Der Median von ist 5, weil die Dichte symmetrisch um 5 ist. Nach ist der Median von gleich . Er liegt weit unter dem Erwartungswert 200, und es ist .     Die Windgeschwindigkeit ist symmetrisch verteilt, die Leistung nicht mehr: In der Hälfte der Zeit liefert die Anlage weniger als und in gut 60 % der Zeit weniger als ihren Mittelwert . Die dritte Potenz zieht die hohen Windgeschwindigkeiten weit auseinander und staucht die niedrigen zusammen. Für den Median genügt die Umrechnung , für den Erwartungswert braucht man das Integral aus .   "
},
{
  "id": "ex-quadrierter-fehler",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-quadrierter-fehler",
  "type": "Beispiel",
  "number": "3.1.27",
  "title": "Der quadrierte Fehler eines Modells.",
  "body": " Der quadrierte Fehler eines Modells   Ein Regressionsmodell macht auf einem neuen Datenpunkt den Fehler (Vorhersage minus wahrer Wert, in normierten Einheiten) mit der Dichte Bewertet wird das Modell mit dem quadrierten Fehler .  Bestimmen Sie Verteilungsfunktion und Dichte von .   Bestimmen Sie auf zwei Wegen: mit und mit .    Mit welcher Wahrscheinlichkeit ist der quadrierte Fehler kleiner als ?           liegt in . Für ist , also Ableiten ergibt für , sonst 0.    Mit : . Mit : .     .      ist der mittlere quadratische Fehler (MSE) des Modells. Wer nur ihn braucht, nimmt den zweiten Weg, er ist fast immer kürzer. Die Dichte von wächst bei 0 über alle Grenzen, obwohl die von dort ihr Maximum hat: Kleine Fehler werden durch das Quadrieren noch kleiner und drängen sich bei 0 ( ). Das ist kein Widerspruch, eine Dichte muss nur integrierbar sein. Weil auf nicht monoton ist, hätte hier nicht geholfen: Zu jedem gehören die beiden Urbilder .   "
},
{
  "id": "fig-quadrierter-fehler",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#fig-quadrierter-fehler",
  "type": "Abbildung",
  "number": "3.1.28",
  "title": "",
  "body": " Links die Dichte des Fehlers , rechts die des quadrierten Fehlers aus . Die rechte Dichte wächst bei 0 über alle Grenzen und ist im Bild abgeschnitten.   Links eine Parabel über minus 1 bis 1, rechts eine bei 0 steil fallende Kurve   Links eine nach unten geöffnete Parabel über dem Intervall von minus 1 bis 1 mit dem Maximum 0,75 bei 0 und Nullstellen bei minus 1 und 1. Rechts, auf dem Intervall von 0 bis 1, eine Kurve, die am linken Rand oberhalb des Bildes beginnt, steil abfällt, bei 0,5 ungefähr den Wert 0,53 hat und bei 1 auf null sinkt.     "
},
{
  "id": "thm-inversionsmethode",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#thm-inversionsmethode",
  "type": "Satz",
  "number": "3.1.29",
  "title": "Inversionsmethode.",
  "body": " Inversionsmethode  Inversionsmethode   Sei eine Verteilungsfunktion mit den Quantilen für , und sei eine Zufallsvariable mit für . Dann hat die Verteilungsfunktion . Steigt auf einem Intervall stetig und streng von 0 auf 1, so ist .     liegt mit Wahrscheinlichkeit 1 in . Nach , Teil (1), ist genau dann, wenn ist. Also ist . Der Zusatz ist Teil (2) desselben Satzes.   "
},
{
  "id": "ex-inversionsmethode",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#ex-inversionsmethode",
  "type": "Beispiel",
  "number": "3.1.30",
  "title": "Antwortzeiten für einen Lasttest.",
  "body": " Antwortzeiten für einen Lasttest   Ein Lasttest soll Antwortzeiten mit der Verteilungsfunktion aus erzeugen.   Geben Sie eine Funktion an, sodass diese Verteilung hat.    Welche Antwortzeiten erzeugen die Werte , und ?    Welcher Anteil der erzeugten Antwortzeiten ist länger als 100 ms? Warum sieht man das, ohne auszuwerten?           steigt auf stetig und streng von 0 gegen 1. Die Umkehrfunktion ist die Quantilfunktion aus , .     , und , also der Median, das obere Quartil und das 99. Perzentil.     ist streng wachsend, also ist genau dann, wenn ist. Das hat die Wahrscheinlichkeit , passend zu .     Die Höhe ist der Anteil der Antwortzeiten, die unter dem erzeugten Wert liegen. Wer im Lasttest gezielt nur langsame Anfragen braucht, zieht deshalb nur aus dem oberen Teil des Intervalls, etwa aus für das langsamste Prozent.   "
},
{
  "id": "sub-zusammenfassung-3-1-2",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#sub-zusammenfassung-3-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Dichte. Verteilungsfunktion. Erwartungswert und Varianz. Unabhängigkeit. Quantile. Median und Erwartungswert. Transformationen. Inversionsmethode. "
},
{
  "id": "exercise-buch-dichte-normieren",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#exercise-buch-dichte-normieren",
  "type": "Übung",
  "number": "3.1.7.1",
  "title": "Eine Wartungsdauer.",
  "body": " Eine Wartungsdauer   Die Dauer einer Wartung (in Stunden) habe die Dichte für und 0 sonst.  Bestimmen Sie .   Mit welcher Wahrscheinlichkeit ist die Wartung nach einer Stunde erledigt?   Bestimmen Sie .          , also . Auf ist .     .     Stunden.      "
},
{
  "id": "exercise-buch-wurzel-verteilungsfunktion",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#exercise-buch-wurzel-verteilungsfunktion",
  "type": "Übung",
  "number": "3.1.7.2",
  "title": "Eine Wurzel als Verteilungsfunktion.",
  "body": " Eine Wurzel als Verteilungsfunktion   Eine Zufallsvariable habe die Verteilungsfunktion für , mit für und für .   Bestimmen Sie die Dichte. Wie verhält sie sich in der Nähe von 0?   Bestimmen Sie den Median und das 90. Perzentil.   Bestimmen Sie und vergleichen Sie mit dem Median.    Wie erzeugt man aus random.random() Zufallszahlen mit dieser Verteilung?           für , sonst 0. Sie wächst bei 0 über alle Grenzen, ist aber integrierbar, und ihre Fläche ist .    Aus folgt : Median , 90. Perzentil .     . Der Erwartungswert liegt über dem Median, weil die meiste Wahrscheinlichkeit nahe bei 0 liegt und die wenigen größeren Werte den Mittelwert nach oben ziehen.    Mit der Inversionsmethode: Die Umkehrfunktion von ist , also hat die gewünschte Verteilung, in Python random.random() ** 2 . Probe: .      "
},
{
  "id": "exercise-buch-wuerfel-median",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#exercise-buch-wuerfel-median",
  "type": "Übung",
  "number": "3.1.7.3",
  "title": "Der Median eines Würfels.",
  "body": " Der Median eines Würfels   Sei die Augenzahl eines fairen Würfels.   Welche Zahlen lösen die Gleichung ? Welche davon ist der Median?    Wie erzeugt die Inversionsmethode aus einer Zahl von random.random() einen Würfelwurf?           gilt für alle mit . Der Median ist die kleinste Stelle mit , also . Im Alltag nennt man bei einer geraden Zahl gleich wahrscheinlicher Werte oft die Mitte 3,5; das ist eine andere Konvention.    Sie gibt das -Quantil aus, also die kleinste Zahl mit . Das ist die kleinste ganze Zahl : eine 1 für , eine 2 für und so weiter. Jede Augenzahl gehört zu einem Intervall der Länge und kommt deshalb mit Wahrscheinlichkeit . In Python leistet int(6 * random.random()) + 1 dasselbe; die beiden Vorschriften unterscheiden sich nur, wenn ganzzahlig ist, und das hat die Wahrscheinlichkeit null.      "
},
{
  "id": "exercise-buch-serienschaltung",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#exercise-buch-serienschaltung",
  "type": "Übung",
  "number": "3.1.7.4",
  "title": "Zwei Bauteile in Reihe.",
  "body": " Zwei Bauteile in Reihe   Ein Gerät enthält zwei Bauteile und fällt aus, sobald eines von beiden ausfällt. Die Lebensdauern und der Bauteile (in Jahren) seien unabhängig, jede mit der Dichte auf und 0 sonst.   Mit welcher Wahrscheinlichkeit halten beide Bauteile länger als ein Jahr?    Bestimmen Sie Verteilungsfunktion und Dichte der Lebensdauer des Geräts.    Welche Garantiezeit überstehen 90 % der Geräte?          Ein Bauteil hat auf , also . Weil das Produkt bei unabhängigen Zufallsvariablen auch für Halbgeraden gilt, ist .    Das Minimum ist größer als , wenn beide Lebensdauern größer als sind. Für ist also , und damit auf ; außerhalb ist .    Gesucht ist mit , also und Jahre, rund acht Wochen. Das ist das 10. Perzentil von . Ein einzelnes Bauteil übersteht mit derselben Wahrscheinlichkeit Jahre, fast doppelt so lange.      "
},
{
  "id": "exercise-buch-quadrat-radius",
  "level": "2",
  "url": "sec-stetige-zufallsvariablen-dichte.html#exercise-buch-quadrat-radius",
  "type": "Übung",
  "number": "3.1.7.5",
  "title": "Radius und Fläche.",
  "body": " Radius und Fläche   Der Radius eines Kreises habe die Dichte für und 0 sonst. Sei die Fläche des Kreises als Anteil der Fläche des Einheitskreises.   Bestimmen Sie Verteilungsfunktion und Dichte von .    Bestimmen Sie und . Warum stimmen sie überein?          Für ist , denn . Also ist auf : Die Fläche hat eine konstante Dichte.     und . Es ist dasselbe Ereignis, denn heißt . Bis auf den Maßstab ist der Abstand aus , und die konstante Dichte von ist die Annahme von dort, dass die Wahrscheinlichkeit eines Gebiets sein Flächenanteil ist.      "
},
{
  "id": "sec-stetige-verteilungen",
  "level": "1",
  "url": "sec-stetige-verteilungen.html",
  "type": "Abschnitt",
  "number": "3.2",
  "title": "Wichtige stetige Verteilungen",
  "body": " Wichtige stetige Verteilungen    Nach diesem Abschnitt können Sie     zu einer stetigen Größe die passende Verteilung wählen, ihre Parameter angeben und die Annahmen benennen, auf denen das Modell beruht: gleich wahrscheinliche Lage, konstante Ausfallrate, viele kleine Einflüsse,    Wahrscheinlichkeiten, Quantile, Erwartungswert und Varianz der Gleich-, der Exponential- und der Normalverteilung berechnen, auch in Rückrichtung: welcher Parameter zu einer geforderten Wahrscheinlichkeit passt,    die Exponentialverteilung aus dem Poisson-Prozess und als Grenzfall der geometrischen Verteilung herleiten und ihre Gedächtnislosigkeit erklären und anwenden,    normalverteilte Größen standardisieren, mit der Verteilungsfunktion rechnen und -Werte sowie die 68-95-99,7-Regel deuten,    Erwartungswert und Varianz der drei Grundverteilungen herleiten,    die Gamma- und Erlang-, die Weibull-, die Lognormal- und die Betaverteilung an ihrer Situation erkennen und auf die drei Grundverteilungen zurückführen.      Ein Temperatursensor überwacht eine Maschine. Er zeigt ganze Zehntelgrad an, seine Elektronik rauscht, und irgendwann fällt er aus. Dahinter stehen drei stetige Zufallsgrößen: der Fehler, der beim Runden auf die Anzeige entsteht, die Abweichung durch das Rauschen und die Zeit bis zum Ausfall. Jede folgt einer anderen Verteilung, und alle drei kehren in Technik und Datenanalyse ständig wieder.   und behandeln die konstante Dichte und die Wartezeit ohne Gedächtnis. Die meiste Zeit gehört , dem Standardisieren und dem Rechnen mit . Die Steckbriefe , , und sind wie in zum Wiedererkennen da; wichtig ist dort, wie jede aus einer Grundverteilung hervorgeht. zeigt, wie alle Verteilungen zusammenhängen.    Die stetige Gleichverteilung  Die einfachste Dichte ist konstant. In lag die Stromstärke irgendwo zwischen 4,9 und 5,1 mA, und kein Teilbereich war bevorzugt. Dasselbe Modell passt immer dann, wenn man von einer Größe nur weiß, in welchem Intervall sie liegt: der Fehler beim Runden eines Messwerts, der Zeitpunkt innerhalb eines Takts, zu dem jemand an der Haltestelle eintrifft, die Ausgabe von random.random() .   Stetige Gleichverteilung  Gleichverteilung stetige   Seien reelle Zahlen. Eine Zufallsvariable mit der Dichte heißt gleichverteilt auf dem Intervall , kurz .    Die Höhe ist dadurch festgelegt, dass das Rechteck unter der Dichte die Fläche 1 haben muss. Die Stromstärke aus ist -verteilt, und random.random() liefert Werte mit der Verteilung . Diskret gleichverteilt wie in ist etwas anderes: Dort sind endlich viele Werte gleich wahrscheinlich, hier hat jeder einzelne Wert die Wahrscheinlichkeit null, und gleich wahrscheinlich sind gleich lange Teilintervalle.   Kennzahlen der Gleichverteilung   Für gilt    für , und für ist ,   ,    und ,     für .       (1) Das Integral einer konstanten Dichte über ein Intervall ist Höhe mal Länge. (4) folgt, indem man nach auflöst ( ).  (2) und (3): Für ist Nach der Formel für lineare Umrechnungen aus hat die Dichte , also auf . Es ist deshalb keine Einschränkung, zu schreiben, und mit folgt und .    Der Erwartungswert ist die Mitte des Intervalls, wie es die Symmetrie verlangt. Die Standardabweichung ist mit knapp 29 % der Intervalllänge. Der Beweis zeigt außerdem ein Muster, das bei der Normalverteilung wiederkehrt: Jede Gleichverteilung ist eine verschobene und gestreckte Fassung der einen Verteilung . In Python erzeugt deshalb a + (b - a) * random.random() eine -verteilte Zahl; random.uniform(a, b) rechnet genau das. Aus entsteht mit der Inversionsmethode ( ) sogar jede andere Verteilung.   Der Fehler eines Analog-Digital-Wandlers   Ein Analog-Digital-Wandler mit Bit teilt den Messbereich von 0 bis 10 Volt in gleich breite Stufen und gibt zu jeder Spannung die Mitte ihrer Stufe aus. Schwankt das Signal über viele Stufen, so ist der Fehler (Ausgabe minus wahre Spannung) gleichverteilt auf , wobei die Stufenbreite ist.   Bestimmen Sie für die Stufenbreite, den Erwartungswert und die Standardabweichung des Fehlers.    Mit welcher Wahrscheinlichkeit ist der Fehler bei 8 Bit dem Betrag nach größer als 15 mV?    Wie viele Bit braucht der Wandler mindestens, damit die Standardabweichung des Fehlers höchstens 1 mV beträgt?            mV, also . Nach ist und  mV.     , also .    Gefordert ist , also  mV und . Wegen und braucht man 12 Bit. Dann ist  mV und  mV.     Der Fehler ist im Mittel null, der Wandler verfälscht also nicht systematisch. Seine Streuung hängt nur von der Stufenbreite ab, und jedes zusätzliche Bit halbiert sie. In der Signalverarbeitung heißt Quantisierungsrauschen, und ist die Formel, mit der man die nötige Auflösung eines Wandlers festlegt. Das Modell setzt voraus, dass das Signal die Stufen gleichmäßig überstreicht; bei einem konstanten Signal wäre der Fehler immer derselbe.      Die Exponentialverteilung  Die Poisson-Verteilung zählt, wie viele Ereignisse in einen Zeitraum fallen. Oft fragt man umgekehrt, wie lange es bis zum nächsten Ereignis dauert: bis zur nächsten Anfrage an einen Server, bis zum nächsten Ausfall einer Maschine, oder entlang eines Kupferkabels bis zur nächsten Fehlerstelle. Die Antwort steckt schon im Poisson-Prozess aus .  Treffen Ereignisse als Poisson-Prozess mit Rate ein, so ist die Zahl der Ereignisse in einem Zeitraum der Länge  -verteilt. Sei die Zeit vom Beginn der Beobachtung bis zum ersten Ereignis. Dann ist genau dann, wenn in den ersten Zeiteinheiten nichts geschieht: Also ist für , und Ableiten ergibt die Dichte . Die Rechnung hängt nicht davon ab, wann die Beobachtung beginnt. Man kann zeigen, dass sie auch dann gilt, wenn die Beobachtung mit einem Ereignis beginnt (ohne Beweis): Auch der Abstand zwischen zwei aufeinanderfolgenden Ereignissen hat diese Verteilung.   Exponentialverteilung  Exponentialverteilung   Eine Zufallsvariable mit der Dichte heißt exponentialverteilt mit Parameter , kurz .     Kennzahlen der Exponentialverteilung   Für gilt    und für ,   ,    und ,     für ; der Median ist .       (1) . Für geht das gegen 1, die Dichte ist also normiert. (4) Man löst nach auf.  (2) und (3) mit partieller Integration. Weil und für gegen null gehen, ist Der Verschiebungssatz ergibt .    Der Parameter ist eine Rate , Ereignisse je Zeiteinheit, und die mittlere Wartezeit ist ihr Kehrwert: Bei vier Anfragen je Sekunde wartet man im Mittel eine Viertelsekunde auf die nächste. Beim Nachschlagen lohnt ein Blick in die Dokumentation: random.expovariate erwartet die Rate , numpy.random.exponential und scipy.stats.expon erwarten als scale den Erwartungswert .  Drei Dinge unterscheiden die Exponentialverteilung von einer symmetrischen Verteilung ( ). Die Dichte ist bei 0 am größten: Kurze Wartezeiten sind am wahrscheinlichsten. Die Standardabweichung ist so groß wie der Erwartungswert: Wartezeiten schwanken stark, wie schon bei der geometrischen Verteilung. Und der Median liegt mit deutlich unter dem Erwartungswert; länger als dauert es nur mit Wahrscheinlichkeit .   Dichten der Exponentialverteilung für (durchgezogen), (gestrichelt) und (gepunktet). Jede beginnt bei der Höhe und fällt auf jeder Strecke der Länge auf die Hälfte.   Drei fallende Kurven, die bei den Höhen 2, 1 und 0,5 beginnen und sich der Achse nähern   Über dem Bereich von 0 bis 4 stehen drei fallende Kurven. Die durchgezogene für Lambda gleich 2 beginnt bei der Höhe 2 und ist bei 1 schon auf 0,27 gefallen. Die gestrichelte für Lambda gleich 1 beginnt bei 1 und hat bei 1 den Wert 0,37. Die gepunktete für Lambda gleich 0,5 beginnt bei 0,5 und fällt am langsamsten; bei 4 hat sie noch den Wert 0,07. Je größer Lambda, desto höher beginnt die Kurve und desto schneller fällt sie.      Wechselt man die Zeiteinheit, so rechnet man die Rate mit um. Für ist , also : Eine Wartezeit mit der Rate 4 je Sekunde hat in Millisekunden die Rate 0,004. Alle Exponentialverteilungen sind deshalb gestreckte Fassungen der einen Verteilung , so wie alle Gleichverteilungen aus hervorgehen.   Ein solarbetriebenes Fahrzeug   Der Prototyp eines kleinen solarbetriebenen Fahrzeugs wird im Dauerbetrieb getestet. Seine Ausfälle bilden einen Poisson-Prozess mit der Rate je Betriebsstunde.   Mit welcher Wahrscheinlichkeit treten in 1000 Stunden vier oder mehr Ausfälle auf?    Mit welcher Wahrscheinlichkeit dauert es länger als 500 Stunden bis zum ersten Ausfall? Wie lange dauert es im Mittel, und mit welcher Wahrscheinlichkeit dauert es länger als dieser Mittelwert?    Mit welcher Wahrscheinlichkeit tritt der zweite Ausfall innerhalb der ersten 1000 Stunden ein?          Die Zahl der Ausfälle in 1000 Stunden ist -verteilt, denn . Also ist     Die Zeit bis zum ersten Ausfall ist -verteilt. Also ist und Stunden. Länger als 400 Stunden dauert es mit Wahrscheinlichkeit .    Der zweite Ausfall liegt genau dann in den ersten 1000 Stunden, wenn es dort mindestens zwei Ausfälle gibt:      Eine mittlere Zeit von 400 Stunden bis zum Ausfall klingt beruhigend, aber nur 37 % der Testläufe erreichen sie; die Hälfte ist schon nach Stunden unterbrochen. Wer eine Wartung plant, rechnet deshalb besser mit dem Median oder einem kleinen Quantil als mit dem Mittelwert. Teil (c) hat eine Frage über eine Wartezeit mit einer Anzahl beantwortet, ohne die Verteilung dieser Wartezeit zu kennen. gibt ihr einen Namen.  Das Beispiel stammt aus den Folien der Vorlesung; eine ältere Quelle ist dort nicht vermerkt.    Die wichtigste Eigenschaft der Exponentialverteilung kennen Sie von der geometrischen Verteilung.   Gedächtnislosigkeit  Gedächtnislosigkeit der Exponentialverteilung   Für und ist     Wegen ist die bedingte Wahrscheinlichkeit gleich .    Hat man schon Zeiteinheiten gewartet, so ist die restliche Wartezeit wieder -verteilt, und im Mittel dauert es noch einmal . Anders gesagt: Für kleines ist , gleich wie groß ist. Ein Bauteil mit exponentialverteilter Lebensdauer fällt in der nächsten Stunde immer mit derselben Wahrscheinlichkeit aus, ob es neu ist oder seit Jahren läuft. Es altert nicht; man sagt, es habe eine konstante Ausfallrate Ausfallrate . Die Exponentialverteilung ist die einzige stetige Verteilung mit dieser Eigenschaft (ohne Beweis).  Ob eine Größe kein Gedächtnis hat, ist eine Modellannahme, die man prüfen muss. Für die Zeit bis zur nächsten Anfrage vieler unabhängiger Nutzer trifft sie gut zu, ebenso für elektronische Bauteile in der Mitte ihrer Lebensdauer. Andere Wartezeiten haben ein Gedächtnis, und zwar in beide Richtungen. Wer an einer Haltestelle mit festem Takt schon lange wartet, hat es bald geschafft. Bei der Antwortzeit aus ist es umgekehrt: Dort ist , aber . Eine Anfrage, die schon lange läuft, braucht mit hoher Wahrscheinlichkeit noch lange.   Abbrechen und neu anfragen?   Die Antwortzeit eines Dienstes sei exponentialverteilt mit dem Erwartungswert 0,2 Sekunden.   Mit welcher Wahrscheinlichkeit dauert eine Anfrage länger als eine Sekunde?    Eine Anfrage läuft schon seit 0,6 Sekunden. Mit welcher Wahrscheinlichkeit dauert sie noch länger als weitere 0,4 Sekunden?    Ein Programm bricht jede Anfrage nach 0,6 Sekunden ab und stellt sie neu. Kommt es so schneller zu einer Antwort?       Die Rate ist je Sekunde.    .    Nach ist . Das ist zwanzigmal so viel wie in (a): Dass die Anfrage die ersten 0,6 Sekunden überdauert hat, war der unwahrscheinliche Teil.    Nein. Die Restzeit der alten Anfrage ist -verteilt, die Dauer der neuen auch. Der Neustart ändert an der Verteilung der verbleibenden Wartezeit nichts und kostet zusätzlich den Aufwand für die neue Anfrage.     In der Praxis helfen Zeitüberschreitungen mit Neuversuch sehr wohl. Das zeigt, dass echte Antwortzeiten ein Gedächtnis haben: Eine Anfrage, die ungewöhnlich lange läuft, ist oft hängen geblieben, und ein neuer Versuch hat bessere Aussichten. Die Exponentialverteilung beschreibt den Grenzfall dazwischen, in dem die verstrichene Zeit nichts über die restliche verrät.    Die geometrische Verteilung zählt Versuche bis zum ersten Erfolg, die Exponentialverteilung misst die Zeit bis zum ersten Ereignis. Dass beide dieselbe Gedächtnislosigkeit haben, ist kein Zufall: Teilt man die Zeit in immer kürzere Schritte, geht die eine in die andere über.   Von der geometrischen zur Exponentialverteilung   Sei . Jede Zeiteinheit werde in gleich lange Schritte geteilt, und in jedem Schritt trete unabhängig von den anderen mit Wahrscheinlichkeit ein Ereignis ein. Sei die Nummer des Schritts mit dem ersten Ereignis und der Zeitpunkt, zu dem er endet. Dann gilt für jedes       heißt , und weil ganzzahlig ist, heißt das für die größte ganze Zahl . Nach ist . Wegen liegt dieser Wert zwischen und . Beide streben nach der Grenzwertformel gegen , denn , und der zweite Wert unterscheidet sich davon nur um den Faktor , der gegen 1 strebt.    Das ist derselbe Grenzübergang wie in : viele kurze Schritte, in jedem eine kleine Erfolgswahrscheinlichkeit. Dort wurde aus der Binomial- die Poisson-Verteilung, hier wird aus der geometrischen die Exponentialverteilung. Anzahl und Wartezeit gehören im Diskreten wie im Stetigen zusammen.  Zufallszahlen mit Exponentialverteilung liefert die Inversionsmethode ( ). Die Umkehrfunktion von ist die Quantilfunktion aus , also ist für exponentialverteilt mit Parameter . Die folgende Zelle erzeugt so Wartezeiten mit und misst die Gedächtnislosigkeit nach.   import math import random # Unter den Wartezeiten, die länger als s dauern: # Welcher Anteil dauert noch mindestens eine weitere Zeiteinheit? # Probieren Sie s = 0, 1, 2, 3. s = 1 n = 100000 x = [-math.log(1 - random.random()) for _ in range(n)] lang = [w for w in x if w > s] noch = [w for w in lang if w > s + 1] print(\"Anteil mit X > s: %.4f\" % (len(lang) \/ n)) print(\"davon mit X > s + 1: %.4f\" % (len(noch) \/ len(lang))) print(\"P(X > 1) = e^(-1) = %.4f\" % math.exp(-1))   Der erste Anteil fällt mit wachsendem schnell, der zweite bleibt bei 0,37. Für schwankt er von Lauf zu Lauf etwas stärker, weil nur noch etwa 5000 der Wartezeiten so lange dauern.    Die Normalverteilung  Misst man dieselbe Größe viele Male, so streuen die Messwerte um einen mittleren Wert: kleine Abweichungen sind häufig, große selten, und nach oben und unten gleich oft. Das Histogramm solcher Messungen hat fast immer dieselbe Glockenform, ob es um das Rauschen eines Sensors geht, um das Füllgewicht einer Packung oder um die Körpergröße in einer Bevölkerung. Der Grund: Wo sich viele kleine, voneinander unabhängige Einflüsse addieren, entsteht diese Form, weitgehend unabhängig davon, wie die einzelnen Einflüsse verteilt sind. Das ist die Aussage des zentralen Grenzwertsatzes ( ). Hier lernen Sie die Verteilung selbst kennen und mit ihr rechnen. Das ganze Rechnen beruht auf einem einzigen Spezialfall.   Standardnormalverteilung  Standardnormalverteilung   Eine Zufallsvariable mit der Dichte heißt standardnormalverteilt . Ihre Verteilungsfunktion bezeichnet man mit     Zwei Dinge an dieser Definition lassen sich mit unseren Mitteln nicht nachrechnen, und das soll offen gesagt sein. Erstens muss die Fläche unter gleich 1 sein, also . Der übliche Beweis berechnet das Quadrat dieses Integrals als Doppelintegral in Polarkoordinaten; wir übernehmen das Ergebnis ohne Beweis. Zweitens hat keine Stammfunktion, die sich mit den bekannten Funktionen hinschreiben ließe. ist deshalb eine neue Funktion, deren Werte man einer Tabelle oder einem Programm entnimmt. Die Code-Zelle weiter unten berechnet beide Flächen numerisch.   Eigenschaften der Standardnormalverteilung   Für eine standardnormalverteilte Zufallsvariable gilt    und für alle , insbesondere ,   ,  .      (1) In kommt nur als vor. Wegen dieser Symmetrie ist die Fläche links von so groß wie die Fläche rechts von , also .  (2) Wegen ist endlich, und das Integral von über die negative Halbachse hat wegen der Symmetrie denselben Wert. Also ist endlich, der Erwartungswert existiert, und weil die Dichte symmetrisch um 0 ist, ist er 0.  (3) Partielle Integration mit und derselben Stammfunktion von : Also ist .     Die Dichte der Standardnormalverteilung. Die Fläche links von ist , die gleich große Fläche rechts von ist ; gezeichnet ist .   Glockenkurve um 0 mit zwei gleich großen grauen Flächen an den Rändern   Eine symmetrische Glockenkurve über dem Bereich von minus 3,6 bis 3,6 mit dem Maximum 0,4 bei 0. Die Fläche unter der Kurve links von minus 1 ist grau gefüllt und mit Phi von minus z beschriftet, die Fläche rechts von 1 ist ebenfalls grau gefüllt und mit 1 minus Phi von z beschriftet. Beide Flächen sind Spiegelbilder voneinander. Auf der waagerechten Achse sind minus z, 0 und z markiert.      Die allgemeine Normalverteilung entsteht, indem man die Glocke verschiebt und streckt.   Normalverteilung  Normalverteilung   Seien und . Eine Zufallsvariable mit der Dichte heißt normalverteilt mit den Parametern und , kurz . Die Standardnormalverteilung ist .     Standardisierung  Standardisieren einer normalverteilten Größe      Ist und sind und reelle Zahlen, so ist .    Ist , so ist die standardisierte Zufallsvariable standardnormalverteilt. Umgekehrt ist für jedes standardnormalverteilte .    Für ist und .    Für ist , also für         (1) Nach der Formel für lineare Umrechnungen aus hat die Dichte denn . Das ist die Dichte von mit der Standardabweichung .  (2) ist (1) mit und , für die Umkehrung mit und , angewandt auf . (3) Mit , und ist und . (4) Weil ist, gilt genau dann, wenn ist.    Die beiden Parameter sind also Erwartungswert und Varianz, und ist die Standardabweichung. Der zweite Parameter in ist die Varianz: Eine Größe mit Erwartungswert 100 und Standardabweichung 15 ist -verteilt. Manche Bücher und fast alle Programme geben stattdessen die Standardabweichung an, so random.gauss(mu, sigma) und scipy.stats.norm(loc, scale) .   zeigt, was die Parameter tun: verschiebt die Glocke, streckt sie. Weil die Fläche 1 bleibt, wird eine breitere Glocke niedriger; ihr höchster Punkt liegt bei . Die Kurve ist symmetrisch um , Erwartungswert und Median fallen also zusammen, und ihre Wendepunkte liegen bei , denn wechselt bei das Vorzeichen.   Dichten von (durchgezogen), (gestrichelt) und (gepunktet). Der Erwartungswert legt die Lage fest, die Standardabweichung die Breite.   Drei Glockenkurven: zwei um 0 mit verschiedener Breite, eine schmale um 4   Über dem Bereich von minus 6 bis 8 stehen drei Glockenkurven. Die durchgezogene hat ihr Maximum 0,4 bei 0. Die gestrichelte liegt ebenfalls um 0, ist aber doppelt so breit und mit dem Maximum 0,2 halb so hoch. Die gepunktete hat dieselbe Form wie die durchgezogene, ist aber um 4 nach rechts verschoben.      Teil (4) des Satzes ist das Werkzeug, das angekündigt hat: Jede Wahrscheinlichkeit einer normalverteilten Größe lässt sich auf zurückführen. Man rechnet die Grenze in den -Wert -Wert  um, der sagt, um wie viele Standardabweichungen über oder unter dem Erwartungswert liegt, und schlägt an dieser Stelle nach. Eine einzige Tabelle genügt für alle Normalverteilungen. Standardnormalverteilung Tabelle Tabelle der Standardnormalverteilung  enthält die Werte in Schritten von 0,1. Für negative Argumente benutzt man , für die Fläche rechts von den Wert .   Verteilungsfunktion der Standardnormalverteilung. Für negative Argumente ist .                                                                                                                   Drei Werte der Tabelle sollte man kennen. Sie beantworten die Frage, wie weit eine normalverteilte Größe von ihrem Erwartungswert abweicht.   Die 68-95-99,7-Regel  68-95-99,7-Regel  Drei-Sigma-Regel   Für und ist , insbesondere     Nach ist die Wahrscheinlichkeit gleich .     Die 68-95-99,7-Regel. Gut zwei Drittel der Werte einer normalverteilten Größe liegen höchstens eine Standardabweichung vom Erwartungswert entfernt, gut 95 % höchstens zwei, fast alle höchstens drei. Aufbau nach einer Abbildung in Montgomery und Runger .   Glockenkurve mit drei ineinanderliegenden Bereichen um den Erwartungswert   Eine Glockenkurve über einer Achse mit den Markierungen mü minus 3 sigma bis mü plus 3 sigma. Der Bereich zwischen mü minus sigma und mü plus sigma ist dunkelgrau gefüllt, der Bereich bis mü plus und minus 2 sigma hellgrau. Unter der Achse stehen drei waagerechte Doppelpfeile übereinander: der kürzeste von mü minus sigma bis mü plus sigma mit der Beschriftung 68,27 Prozent, der mittlere von mü minus 2 sigma bis mü plus 2 sigma mit 95,45 Prozent, der längste von mü minus 3 sigma bis mü plus 3 sigma mit 99,73 Prozent.      So liest man -Werte: Ein Wert, der mehr als zwei Standardabweichungen vom Erwartungswert entfernt liegt, ist ungewöhnlich (knapp 5 % aller Werte, je zur Hälfte oben und unten), einer jenseits von drei Standardabweichungen selten (knapp 0,3 %).  Für die Rückrichtung braucht man Quantile. Die Funktion wächst streng, nach ist das -Quantil von also wobei das -Quantil der Standardnormalverteilung ist, die Lösung von . enthält die gebräuchlichen Werte. Ein um symmetrisches Intervall, in dem mit Wahrscheinlichkeit liegt, reicht von bis , denn heißt . Für 95 % ist das ; die 2 aus der Faustregel ist eine gerundete 1,96. Standardnormalverteilung Quantile    Quantile der Standardnormalverteilung: . Für ist .                                  Die Verteilung des Intelligenzquotienten   Intelligenztests werden so konstruiert, dass ihr Ergebnis in der Bevölkerung normalverteilt ist mit dem Erwartungswert 100 und der Standardabweichung 15 (Situation und Teil (a) nach Meintrup ).   Beschreiben Sie die Verteilung mit der 68-95-99,7-Regel.    Welcher Anteil der Bevölkerung erreicht mehr als 130, welcher weniger als 91, welcher einen Wert zwischen 85 und 130?    Welchen Wert muss man mindestens erreichen, um zum besten Prozent zu gehören?       Sei das Testergebnis einer zufällig gewählten Person.   Gut zwei Drittel der Bevölkerung liegen zwischen 85 und 115, gut 95 % zwischen 70 und 130 und fast alle zwischen 55 und 145.    Die -Werte sind , und . Mit ist     Gesucht ist das 99. Perzentil: .     Der Intelligenzquotient ist damit kein Messwert wie eine Länge, sondern ein verkleideter -Wert: Er sagt, wo jemand innerhalb der Bevölkerung steht, und ist nur eine bequeme Skala dafür. Dass die Verteilung normal ist, ist hier keine Beobachtung, sondern eine Festlegung bei der Konstruktion des Tests. Die Situation und die Frage aus (a) stammen aus D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , 2018 ( ); die Teile (b) und (c) sind für dieses Buch ergänzt.     hat offen gelassen, wie oft eine Welle klemmt, wenn die Grenze zwei Standardabweichungen unter dem Erwartungswert liegt. Jetzt lässt sich das beantworten.   Noch einmal Welle und Bohrung   In hat das Spiel zwischen Bohrung und Welle den Erwartungswert 0,10 mm und die Standardabweichung 0,05 mm. Nehmen Sie an, dass normalverteilt ist.  Bei welchem Anteil der Paarungen klemmt die Welle, ist also ?   Brauchbar ist eine Paarung, wenn das Spiel zwischen 0,02 und 0,20 mm liegt. Welcher Anteil ist brauchbar?    Durch genauere Fertigung sinkt die Standardabweichung des Spiels auf 0,04 mm, der Erwartungswert bleibt. Bei welchem Anteil der Paarungen klemmt die Welle jetzt?           .    Die -Werte der Grenzen sind und 2, also ist der Anteil .    Jetzt liegt die Grenze 0 um Standardabweichungen unter dem Erwartungswert: .     Das sind die gut 2 % , die angekündigt hat: Bei zwei Standardabweichungen Abstand klemmt jede 44. Paarung. Wird die Streuung um ein Fünftel kleiner, klemmt nur noch etwa jede 160., fast viermal seltener: Weit draußen im Rand der Glockenkurve wirkt eine kleine Änderung der Streuung stark. Die Annahme, dass normalverteilt ist, ist naheliegend, wenn die Durchmesser von Bohrung und Welle es sind; dass die Differenz zweier unabhängiger normalverteilter Größen wieder normalverteilt ist, zeigt .     Wie viele Fehlalarme erzeugt die Drei-Sigma-Regel?   Ein Überwachungssystem misst jede Minute die Antwortzeit eines Dienstes. Im Normalbetrieb sind die Messwerte unabhängig und normalverteilt mit dem Erwartungswert 120 ms und der Standardabweichung 15 ms. Das System schlägt Alarm, wenn ein Messwert um mehr als drei Standardabweichungen vom Erwartungswert abweicht.   Zwischen welchen Grenzen bleibt das System still, und mit welcher Wahrscheinlichkeit löst eine einzelne Messung im Normalbetrieb einen Alarm aus?    Wie viele Fehlalarme sind an einem Tag mit 1440 Messungen zu erwarten?    Im Mittel soll es höchstens einen Fehlalarm je Tag geben. Auf welches Vielfache der Standardabweichung muss die Schwelle gesetzt werden, und welche Grenzen ergibt das?          Die Grenzen sind , also 75 und 165 ms. Nach liegt ein Messwert mit Wahrscheinlichkeit außerhalb.    Die Zahl der Fehlalarme ist eine Summe von 1440 Indikatorvariablen mit je dem Erwartungswert 0,0027. Nach der Linearität sind Fehlalarme je Tag zu erwarten.    Mit der Schwelle ist die Wahrscheinlichkeit eines Fehlalarms . Gefordert ist , also . In ist zu klein. Bei reichen die vier Stellen der Tabelle für die Entscheidung nicht aus; der genauere Wert erfüllt die Schranke knapp. Die Schwelle gehört also auf etwa 3,4 Standardabweichungen, das sind die Grenzen , also 69 und 171 ms.     Drei Standardabweichungen klingen streng, und für eine einzelne Messung sind sie es auch. Wer aber 1440-mal am Tag prüft, bekommt trotzdem täglich etwa vier grundlose Alarme, und bei hundert überwachten Diensten vierhundert. Wie beim Vorhersagewert in entscheidet die Zahl der Gelegenheiten, nicht nur die Fehlerquote je Gelegenheit. Echte Antwortzeiten haben zudem meist einen schwereren rechten Rand als die Normalverteilung ( ); dann sind es noch mehr grundlose Alarme. Eine höhere Schwelle senkt die Fehlalarme, erkennt echte Störungen aber später.     Die Ausreißerregel des Boxplots  Ausreißerregel  Ein Boxplot markiert einen Wert üblicherweise als Ausreißer, wenn er um mehr als das Anderthalbfache des Quartilsabstands ( ) über dem oberen oder unter dem unteren Quartil liegt. Für sind die Quartile , der Quartilsabstand ist , und die Grenzen liegen bei . Außerhalb liegen  % der Werte. Für diese Verteilung ist die Regel gemacht: Sie markiert, was bei normalverteilten Daten wirklich selten ist.   Die folgende Zelle berechnet als Fläche unter , näherungsweise als Summe vieler schmaler Rechtecke. Sie liefert auch Werte, die nicht in stehen, und zeigt in der zweiten Zeile, dass die Gesamtfläche 1 ist.   import math # Phi(z) als Fläche unter der Glockenkurve, links von z. # Probieren Sie z = 1, 1.96, 3.4, -0.6. z = 1 n = 20000 phi = lambda t: math.exp(-t * t \/ 2) \/ math.sqrt(2 * math.pi) def flaeche(a, b): h = (b - a) \/ n return h * sum([phi(a + (i + 0.5) * h) for i in range(n)]) print(\"Phi(%.2f) = %.4f\" % (z, flaeche(-8, z))) print(\"Fläche von -8 bis 8: %.6f\" % flaeche(-8, 8))   Links von und rechts von 8 liegt zusammen weniger als der Fläche; deshalb genügt es, bei zu beginnen.   Woher die Normalverteilung kommt und wo sie endet  Die Normalverteilung ist das Standardmodell für Messfehler und für Merkmale, die aus vielen kleinen Beiträgen entstehen. Drei Gründe dafür folgen in : Summen unabhängiger normalverteilter Größen sind wieder normalverteilt ( ), Mittelwerte vieler unabhängiger Größen sind es näherungsweise ( ), und auch Binomial- und Poisson-Verteilung nähern sich der Glockenform, wie angekündigt hat ( ).  Zwei Grenzen des Modells sollte man kennen. Erstens nimmt eine normalverteilte Größe jeden reellen Wert an, auch negative. Für eine Größe, die nicht negativ sein kann, taugt das Modell deshalb nur, wenn der Erwartungswert mehrere Standardabweichungen über null liegt. Zweitens fallen die Ränder der Glocke extrem schnell: Weiter als fünf Standardabweichungen vom Erwartungswert liegt ein Wert nur mit Wahrscheinlichkeit . Bei Antwortzeiten, Schadenhöhen oder Kursänderungen kommen so große Abweichungen in Wirklichkeit viel öfter vor. Wer dort mit der Normalverteilung rechnet, unterschätzt gerade die Ereignisse, auf die es ankommt.     Steckbrief: Erlang- und Gammaverteilung  Erlang-Verteilung  Gammaverteilung  Die folgenden vier Verteilungen lernen Sie wie in als Steckbrief kennen: wann sie auftreten, wie sie aus einer der drei Grundverteilungen hervorgehen, ihre Formeln und ein Beispiel. Entscheidend ist wieder die Herkunft; die Formeln muss man nicht auswendig können, wohl aber die Situation erkennen.   Wann  Man wartet nicht auf das nächste, sondern auf das -te Ereignis eines Poisson-Prozesses: die Zeit bis zum dritten Ausfall, die Zeit, bis hundert Anfragen eingegangen sind und ein Stapel verarbeitet werden kann, die Strecke bis zur fünften Fehlerstelle im Kabel. Das ist das stetige Gegenstück zur negativen Binomialverteilung aus . Wir schreiben für die Wartezeit bis zum -ten Ereignis bei der Rate , mit . Für ist das . Die Gammaverteilung lässt statt jede positive Zahl zu und ist damit ein anpassungsfähiges Modell für positive, rechtsschiefe Größen wie Niederschlagsmengen oder Schadenhöhen.    Woher  Sei der Zeitpunkt des -ten Ereignisses und die Zahl der Ereignisse bis zur Zeit . Das -te Ereignis liegt genau dann nach , wenn bis höchstens Ereignisse eingetreten sind: So wurde schon Teil (c) von gerechnet. Leitet man den Summanden zu mit der Produktregel ab, entstehen und, für , . In der Summe heben sich diese Terme paarweise auf, und es bleibt nur der erste Term zu . Mit umgekehrtem Vorzeichen, weil die Dichte die Ableitung von ist, ergibt das  ist die Summe der Abstände zwischen aufeinanderfolgenden Ereignissen, und jeder Abstand ist nach  -verteilt. Nach der Linearität ist deshalb . Die Abstände sind außerdem unabhängig (ohne Beweis), also addieren sich auch die Varianzen zu . Beides kann man ebenso aus der Dichte nachrechnen, mit der Formel , die aus wiederholter partieller Integration folgt. Dass umgekehrt die Summe von unabhängigen -verteilten Größen immer diese Dichte hat, zeigt .  Die Gammaverteilung entsteht, indem man durch die Gammafunktion Gammafunktion  ersetzt. Sie setzt die Fakultät auf alle positiven Zahlen fort: Partielle Integration ergibt , und mit folgt für . Erwartungswert und Varianz der Gammaverteilung haben dieselbe Gestalt wie bei der Erlang-Verteilung, mit statt und statt ; für nicht ganzzahliges stehen sie unten ohne Beweis.    Formeln  Für mit dem Formparameter und der Rate ist Es ist und . Mit elementaren Funktionen lässt sich die Verteilungsfunktion nur für ganzzahliges hinschreiben, nämlich als die Summe oben. zeigt, wie sich die Dichte mit wachsendem von der Exponentialverteilung weg zu einer Glockenform entwickelt.  Der zweite Parameter ist bei uns eine Rate wie . Viele Programme erwarten stattdessen die Skala , so scipy.stats.gamma(a, scale=...) . Auch Pythons random.gammavariate(alpha, beta) versteht unter beta die Skala; mit unseren Parametern ruft man es als random.gammavariate(alpha, 1 \/ beta) auf. Zwei Mitglieder der Familie kommen später wieder: heißt Chi-Quadrat-Verteilung und tritt in als Verteilung einer Summe von Quadraten auf, und in beschreibt eine Gammaverteilung das Vorwissen über die Rate einer Poisson-Verteilung.    Dichten von für . Für ist es die Exponentialverteilung; mit wachsendem wandert der Gipfel nach rechts, und die Kurve wird symmetrischer.   Vier Dichtekurven, die erste fallend, die übrigen mit einem Gipfel, der mit k nach rechts wandert   Über dem Bereich von 0 bis 11 stehen vier Kurven. Die für k gleich 1 fällt von der Höhe 1 exponentiell ab. Die für k gleich 2 beginnt bei 0, erreicht bei 1 ihr Maximum 0,37 und fällt dann. Die für k gleich 3 hat ihr Maximum 0,27 bei 2, die für k gleich 5 ihr Maximum 0,20 bei 4. Je größer k, desto weiter rechts, niedriger und breiter ist der Gipfel, und desto ähnlicher wird die Kurve einer Glocke.       Drei Ersatzteile   Für das Fahrzeug aus liegen drei Ersatzteile bereit, sodass es erst mit dem vierten Ausfall stillsteht. Welche Verteilung hat die Zeit bis dahin, mit welchem Erwartungswert und welcher Standardabweichung? Mit welcher Wahrscheinlichkeit läuft das Fahrzeug länger als 1000 Stunden?    Die Zeit bis zum vierten Ausfall ist -verteilt, also Stunden und Stunden. Länger als 1000 Stunden läuft das Fahrzeug, wenn bis dahin höchstens drei Ausfälle eintreten. Mit ist das Gegenstück zu Teil (a) von .  Die Standardabweichung ist hier halb so groß wie der Erwartungswert, bei der Wartezeit auf den ersten Ausfall waren beide gleich. Allgemein ist das Verhältnis : Je mehr Ereignisse man abwartet, desto besser lässt sich die Gesamtzeit planen, weil sich lange und kurze Abstände ausgleichen.      Steckbrief: die Weibull-Verteilung  Weibull-Verteilung   Wann  Eine Lebensdauer, bei der das Alter eine Rolle spielt: Kugellager, Reifen und Dichtungen verschleißen und fallen umso eher aus, je älter sie sind; bei neuen elektronischen Geräten ist es oft umgekehrt, weil Fertigungsfehler sich früh zeigen. Die Exponentialverteilung kann beides nicht abbilden, denn sie hat kein Gedächtnis. Wir schreiben mit dem Formparameter und der Rate . Auch gemessene Windgeschwindigkeiten beschreibt man üblicherweise mit einer Weibull-Verteilung; sie hat den längeren rechten Rand, der der Parabel aus fehlt.    Woher  Wie schnell ein Bauteil im Alter ausfällt, misst die Ausfallrate aus , allgemein definiert als Für kleines ist : die Wahrscheinlichkeit, dass ein Bauteil, das bis gehalten hat, im nächsten Augenblick ausfällt, je Zeiteinheit. Für ist konstant. Eine Ausfallrate, die mit dem Alter steigt oder fällt, erhält man, indem man die Zeitachse verzerrt. Sei und . Dann ist für  Ableiten ergibt die Dichte unten, und die Ausfallrate ist . Sie steigt für (Verschleiß), ist für konstant (dann ist ) und fällt für (Frühausfälle). zeigt die drei Fälle.    Ausfallraten der Weibull-Verteilung mit : fallend für , konstant für (Exponentialverteilung), steigend für .   Eine fallende, eine waagerechte und eine steigende Kurve   Über dem Bereich von 0 bis 2,5 stehen drei Kurven. Die gestrichelte für k gleich 0,5 beginnt links oben bei etwa 3,2, fällt steil und ist bei 2,5 auf etwa 0,3 gesunken. Die gepunktete für k gleich 1 ist eine waagerechte Gerade auf der Höhe 1. Die durchgezogene für k gleich 2 ist eine Ursprungsgerade mit der Steigung 2.       Formeln  Für ist Die Quantile ergeben sich durch Auflösen von . Der Erwartungswert folgt aus der Herleitung: , und ist gerade die Gammafunktion aus . Ebenso ist , und der Verschiebungssatz ergibt die Varianz. Für jedes ist ; deshalb heißt charakteristische Lebensdauer, und technische Literatur und Software geben meist sie an statt der Rate, so scipy.stats.weibull_min(c, scale=...) .    Ein Lager, das altert   Die Lebensdauer eines Kugellagers (in Jahren) sei -verteilt. Mit welcher Wahrscheinlichkeit hält ein neues Lager länger als fünf Jahre? Mit welcher hält ein Lager, das schon fünf Jahre läuft, noch weitere fünf? Nach welcher Zeit sind 10 % der Lager ausgefallen?     und Das 10-%-Quantil ist Jahre.  Ein neues Lager übersteht die nächsten fünf Jahre mit 78 %, ein fünf Jahre altes nur noch mit 47 %: Das Lager hat ein Gedächtnis, es altert. Bei einer exponentialverteilten Lebensdauer wären beide Wahrscheinlichkeiten gleich. Das 10-%-Quantil ist die Größe, die Hersteller von Wälzlagern als nominelle Lebensdauer angeben: die Zeit, die neun von zehn Lagern erreichen.      Steckbrief: die Lognormalverteilung  Lognormalverteilung   Wann  Eine positive Größe, bei der sich viele Einflüsse nicht addieren, sondern multiplizieren: Einkommen, Dateigrößen, Antwortzeiten, Partikelgrößen, Aktienkurse. Gehaltserhöhungen etwa werden in Prozent vereinbart, nicht in Euro. Solche Größen sind rechtsschief, mit vielen kleinen und wenigen sehr großen Werten. Wir schreiben , wenn normalverteilt ist mit den Parametern und . Die Parameter gehören also zum Logarithmus, nicht zu selbst.    Woher  Sei und . Die Funktion wächst streng, ihre Umkehrfunktion ist mit . Nach hat die Dichte für , und nach sind die Quantile von einfach . Insbesondere ist der Median . Für den Erwartungswert gilt das nicht, denn . Mit und der Umformung ist also . Der Erwartungswert liegt um den Faktor über dem Median, umso mehr, je stärker der Logarithmus streut.  Die Normalverteilung entsteht unter schwachen Voraussetzungen, wo sich viele kleine unabhängige Einflüsse addieren. Multiplizieren sie sich, so addieren sich ihre Logarithmen; der Logarithmus des Produkts ist dann ungefähr normalverteilt ( ) und das Produkt selbst ungefähr lognormalverteilt. Das ist der Grund, warum man schiefe Daten vor der Auswertung logarithmiert: Auf der logarithmischen Skala wird aus der schiefen Verteilung eine Glocke.    Formeln  Für ist Die Varianz steht hier ohne Beweis; man erhält sie mit derselben Rechnung für .    Dichte von . Der Median ist 1, der Erwartungswert ; rechts vom Erwartungswert liegen nur noch 31 % der Fläche.   Rechtsschiefe Dichte mit einem steilen Gipfel links und einem langen rechten Rand, Median und Erwartungswert markiert   Über dem Bereich von 0 bis 6 steht eine Kurve, die bei 0 mit der Höhe 0 beginnt, steil auf ihr Maximum 0,66 bei etwa 0,37 steigt und dann langsam fällt; bei 6 hat sie noch den Wert 0,013. Eine gestrichelte senkrechte Linie markiert den Median bei 1, eine zweite den Erwartungswert bei 1,65.       Dateigrößen auf einem Server   Die Größe einer Datei auf einem Dateiserver (in kB) sei lognormalverteilt: hat den Erwartungswert und die Standardabweichung 1. Bestimmen Sie Median und Erwartungswert von . Welcher Anteil der Dateien ist größer als der Erwartungswert, welcher größer als 1000 kB? Unter welcher Größe bleiben 95 % der Dateien?    Der Median ist  kB, der Erwartungswert  kB. Mit ist und das 95. Perzentil ist  kB.  Die typische Datei hat 100 kB, aber der Mittelwert liegt um zwei Drittel höher, und nur 31 % der Dateien erreichen ihn. Wenige große Dateien tragen den Speicherbedarf. Wer den Speicher plant, braucht den Mittelwert; wer wissen will, was ein Nutzer typischerweise hochlädt, den Median.      Steckbrief: die Betaverteilung  Betaverteilung   Wann  Eine zufällige Größe, die zwischen 0 und 1 liegt: ein Anteil, eine Auslastung, eine Trefferquote. Vor allem beschreibt man mit ihr, was man über eine unbekannte Wahrscheinlichkeit weiß, etwa über die Klickrate einer Anzeige nach den ersten hundert Einblendungen. Wir schreiben mit zwei Formparametern .    Woher  Seien unabhängig und -verteilt, und sei der -kleinste dieser Werte: das Minimum, das Maximum. Der -kleinste Wert ist genau dann höchstens , wenn mindestens der Werte höchstens sind. Jeder einzelne ist das mit Wahrscheinlichkeit , unabhängig von den anderen, die Anzahl ist also -verteilt: Das ist zum dritten Mal derselbe Gedanke, nach der negativen Binomialverteilung und der Erlang-Verteilung: Eine Frage nach einer Position wird mit einer Anzahl beantwortet. Beim Ableiten liefert der Summand zu die beiden Terme und ; der zweite hebt sich gegen den ersten Term des Summanden zu auf, und für entfällt er. Übrig bleibt der erste Term zu : Die Formel lässt sich auch direkt lesen: Einer der Werte liegt bei , von den übrigen liegen links davon und rechts. Das ist die Betaverteilung mit und . Die allgemeine Betaverteilung ersetzt die Fakultäten durch die Gammafunktion und lässt so beliebige positive Parameter zu. Dass die Fläche unter der Dichte dann weiter 1 ist, folgt für ganzzahlige Parameter aus der Herleitung; für beliebige übernehmen wir es ohne Beweis. Die Herleitung über sortierte Zufallszahlen folgt einem Arbeitsblatt der Vorlesung nach A. Adhikari und J. Pitman, Probability for Data Science ( ).    Formeln  Für ist  ist die Gleichverteilung . Der Erwartungswert folgt daraus, dass jede dieser Dichten die Fläche 1 hat: ist bis auf den Vorfaktor die Dichte von , und das Verhältnis der Vorfaktoren ist wegen gleich . Die Varianz steht hier ohne Beweis. Für den -kleinsten von Werten ist : Die sortierten Werte teilen das Intervall im Mittel in gleich lange Stücke. zeigt, wie verschieden die Dichten aussehen können.    Dichten von (gepunktet, die Gleichverteilung), (durchgezogen) und (gestrichelt). Der Erwartungswert ist , und .   Eine waagerechte Gerade, eine symmetrische Parabel und eine nach rechts verschobene Kurve mit Gipfel bei 0,8   Über dem Intervall von 0 bis 1 stehen drei Kurven. Die gepunktete ist eine waagerechte Gerade auf der Höhe 1. Die durchgezogene ist eine nach unten geöffnete Parabel mit Nullstellen bei 0 und 1 und dem Maximum 1,5 bei 0,5. Die gestrichelte bleibt bis etwa 0,25 nahe null, steigt dann auf ihr Maximum 2,46 bei 0,8 und fällt bis 1 wieder auf null.       Der mittlere von drei Werten   Um einzelne Ausreißer zu unterdrücken, verwendet ein Messprogramm von je drei unabhängigen Messungen nur die mittlere. Als Modell dafür seien unabhängig und -verteilt, und sei der mittlere der drei Werte. Welche Verteilung hat ? Vergleichen Sie Varianz und mit den Werten für eine einzelne Messung.     mit der Dichte auf . Also ist und , gegenüber für einen einzelnen Wert. Die Verteilungsfunktion ist , also gegenüber für einen einzelnen Wert.  Der mittlere von drei Werten liegt also deutlich öfter in der Mitte als ein einzelner. Das gilt nicht nur für gleichverteilte Messungen. Setzt man Messwerte mit stetiger, streng wachsender Verteilungsfunktion in ein, so entstehen nach gleichverteilte Werte, und die Reihenfolge bleibt erhalten. Der mittlere von drei unabhängigen Messwerten liegt deshalb bei jeder solchen Verteilung mit Wahrscheinlichkeit zwischen ihren beiden Quartilen. Wie eine Betaverteilung das Wissen über eine unbekannte Wahrscheinlichkeit beschreibt, zeigt .      Überblick: die Karte der stetigen Verteilungen  Verteilungen stetige, Überblick   stellt die Verteilungen dieses Abschnitts mit ihren Kennzahlen zusammen; die Dichten stehen in den einzelnen Unterabschnitten. In der Zeile der Weibull-Verteilung steht kurz für . Wichtiger als die Tabelle ist wie in die Karte: zeigt, wie jede Verteilung aus einer anderen hervorgeht, als Wartezeit, durch Umrechnen oder als Grenzfall. Jeder durchgezogene Pfeil steht für eine Herleitung aus diesem Abschnitt, und die meisten benutzen ein Werkzeug aus .   Die drei Grundverteilungen und die vier Steckbriefe        Verteilung  Situation       Lage in einem Intervall, kein Teil bevorzugt       Wartezeit bis zum nächsten Ereignis, ohne Gedächtnis       Messfehler, Summe vieler kleiner Einflüsse       Wartezeit bis zum Ereignis       positive, rechtsschiefe Größen       Lebensdauer mit steigender oder fallender Ausfallrate       Produkt vieler Einflüsse; ist normalverteilt       Anteil oder unbekannte Wahrscheinlichkeit in        Die Verwandtschaften der stetigen Verteilungen. Fett umrandet sind die drei Grundverteilungen, dünn die Steckbriefe, gestrichelt, was aus anderen Kapiteln stammt.   Diagramm aus elf Kästen mit Pfeilen: Normal-, Gleich- und Exponentialverteilung in der Mitte, darunter die vier Steckbriefe   In der mittleren Reihe stehen von links nach rechts die fett umrandeten Kästen Normal, Gleich und Exponential, rechts daneben ein gestrichelter Kasten Poisson-Prozess, Kapitel 2. Über Normal steht ein gestrichelter Kasten Binomial, Poisson, Mittelwerte mit einem gestrichelten Pfeil Grenzwertsatz, Kapitel 5 zu Normal. Über Exponential steht ein gestrichelter Kasten geometrisch, Kapitel 2, mit einem Pfeil immer kürzere Schritte zu Exponential. Vom Poisson-Prozess führt ein Pfeil erstes Ereignis zu Exponential, von Gleich ein Pfeil Inversionsmethode . In der unteren Reihe stehen die dünn umrandeten Steckbriefe: unter Normal der Kasten Lognormal mit einem Pfeil e hoch X von Normal, unter Gleich der Kasten Beta mit einem Pfeil k-kleinster von n Werten von Gleich, unter Exponential der Kasten Erlang und Gamma mit einem Pfeil k-tes Ereignis von Exponential, und rechts der Kasten Weibull mit einem Pfeil Potenz einer Exp(1)-Größe von Exponential. Von Erlang und Gamma führt ein gestrichelter Pfeil alpha gleich n halbe, beta gleich ein halb nach unten zu einem gestrichelten Kasten Chi-Quadrat, Kapitel 5.      Drei Muster kehren in der Karte wieder. Das erste ist das Paar aus Anzahl und Wartezeit: Poisson-Verteilung und Exponentialverteilung beschreiben denselben Prozess von zwei Seiten, ebenso Poisson- und Erlang-Verteilung, so wie im Diskreten Binomial- und geometrische Verteilung. Das zweite ist das Umrechnen: Aus der Gleichverteilung entsteht durch die Inversionsmethode jede andere Verteilung, aus der Exponentialverteilung durch eine Potenz die Weibull-Verteilung, aus der Normalverteilung durch die Exponentialfunktion die Lognormalverteilung. Das dritte sind Lage und Skala: Jede Gleich-, Exponential- und Normalverteilung ist eine verschobene oder gestreckte Fassung von , bzw. . Deshalb genügt eine Tabelle von für alle Normalverteilungen.  Mehrere Fäden führen über dieses Kapitel hinaus. In geht es darum, wie zwei Zufallsvariablen zusammenhängen, etwa zwei normalverteilte Messgrößen. behandelt Summen: zeigt, dass Summen unabhängiger normalverteilter Größen wieder normalverteilt sind, dass die Erlang-Verteilung eine Summe von Exponentialverteilungen ist und woher die Chi-Quadrat-Verteilung kommt, und der zentrale Grenzwertsatz in erklärt, warum die Normalverteilung so oft passt. In beschreiben Beta- und Gammaverteilung das Vorwissen über einen unbekannten Parameter.   Welche stetige Verteilung passt?   Geben Sie jeweils eine passende Verteilung an, soweit möglich mit Parametern, und nennen Sie die Annahme, auf der das Modell beruht.   Die Zeit bis zur nächsten Anfrage an einen Webserver, der im Mittel vier Anfragen je Sekunde erhält.    Die Zeit, bis derselbe Server hundert Anfragen erhalten hat.    Der Fehler, der entsteht, wenn ein Rechnungsbetrag auf ganze Euro gerundet wird.    Die Abweichung des Füllgewichts einer Packung vom eingestellten Wert.   Die Laufleistung eines Reifens bis zum Verschleiß.  Das Monatseinkommen einer zufällig gewählten Person.   Die unbekannte Klickrate einer neuen Anzeige, nachdem man ihre ersten Einblendungen beobachtet hat.           mit der Zeit in Sekunden, wenn die Anfragen einen Poisson-Prozess bilden, also von vielen Nutzern unabhängig voneinander kommen.     unter derselben Annahme, mit dem Erwartungswert 25 Sekunden.     in Euro, wenn die Centbeträge gleichmäßig verteilt sind. Enden viele Preise auf 99 Cent, stimmt das nicht.    Eine Normalverteilung mit dem Erwartungswert 0, wenn sich viele kleine, unabhängige Störungen addieren. Die Standardabweichung muss gemessen werden.    Eine Weibull-Verteilung mit , denn der Reifen verschleißt: Seine Ausfallrate steigt mit der Laufleistung.    Eine Lognormalverteilung: Einkommen sind positiv und rechtsschief, und Unterschiede entstehen eher durch Faktoren als durch feste Beträge.    Eine Betaverteilung, denn die Klickrate ist eine Zahl zwischen 0 und 1, über die man nur ungefähr Bescheid weiß. Wie die Beobachtungen dieses Wissen verändern, zeigt .     Wie in ist die Wahl der Verteilung eine Modellannahme. Bei stetigen Größen lässt sie sich oft an den Daten prüfen: Ist das Histogramm symmetrisch oder schief? Ist die Standardabweichung etwa so groß wie der Mittelwert, wie bei der Exponentialverteilung? Liegen gut zwei Drittel der Werte innerhalb einer Standardabweichung, wie bei der Normalverteilung?      Zusammenfassung      Gleichverteilung.  hat die Dichte auf . Wahrscheinlichkeiten sind Längenverhältnisse, , und es ist , und .     Exponentialverteilung.  hat die Dichte für , mit , , und dem Median . In einem Poisson-Prozess mit Rate ist die Wartezeit bis zum nächsten Ereignis -verteilt, denn .     Gedächtnislosigkeit.  : Nach der Wartezeit ist die Restwartezeit wieder -verteilt, die Ausfallrate ist konstant. Die Exponentialverteilung ist der Grenzfall der geometrischen Verteilung für immer kürzere Zeitschritte.     Normalverteilung.  hat die Dichte , mit und . Mit ist für auch normalverteilt, nämlich .     Standardisieren.  ist -verteilt mit der Dichte und der Verteilungsfunktion . Damit ist , und . Der -Wert sagt, um wie viele Standardabweichungen ein Wert vom Erwartungswert abweicht.     68-95-99,7-Regel und Quantile.  , also , und für . Das -Quantil ist mit .     Steckbriefe.  ist die Verteilung der Wartezeit bis zum -ten Ereignis eines Poisson-Prozesses, mit und ; lässt beliebige zu. entsteht aus der Exponentialverteilung durch eine Potenz und hat ; die Ausfallrate steigt für und fällt für . heißt, dass normalverteilt ist; der Median ist , der Erwartungswert . lebt auf mit ; der -kleinste von unabhängigen -verteilten Werten ist -verteilt.       Übungsaufgaben   Eine Störung in der Schicht   In einer Schicht von acht Stunden tritt genau eine Störung auf, zu einem Zeitpunkt (in Stunden nach Schichtbeginn).  Mit welcher Wahrscheinlichkeit fällt die Störung in die letzte Stunde der Schicht?  Bestimmen Sie und .  Wie erzeugt man einen solchen Zeitpunkt mit random.random() ?        , die Länge des Intervalls geteilt durch die Länge der Schicht.    Stunden und Stunden.   Mit 8 * random.random() , denn für .       Anrufe bei einer Hotline   Die Zeit zwischen zwei Anrufen bei einer Hotline sei exponentialverteilt mit dem Erwartungswert 3 Minuten.  Mit welcher Wahrscheinlichkeit kommt der nächste Anruf innerhalb einer Minute?  Bestimmen Sie den Median der Wartezeit.   Seit fünf Minuten hat niemand angerufen. Mit welcher Wahrscheinlichkeit dauert es noch länger als drei weitere Minuten?    Wie ist die Zahl der Anrufe in einer halben Stunde verteilt, wenn die Anrufe einen Poisson-Prozess bilden?       Die Rate ist je Minute.  .  Minuten, deutlich weniger als der Erwartungswert.   Wegen der Gedächtnislosigkeit ist das ; die fünf Minuten ändern nichts.    Die Rate je Minute ergibt in 30 Minuten im Mittel 10 Anrufe; die Anzahl ist -verteilt.        Eine normalverteilte Bearbeitungszeit   Die Bearbeitungszeit eines Auftrags (in Minuten) sei -verteilt.  Mit welcher Wahrscheinlichkeit dauert ein Auftrag länger als 52 Minuten?  Mit welcher Wahrscheinlichkeit dauert er zwischen 36 und 52 Minuten?   Ein Auftrag ist nach 48 Minuten noch nicht erledigt. Mit welcher Wahrscheinlichkeit dauert er länger als 52 Minuten? Vergleichen Sie mit (a).           , also .     .    48 Minuten sind eine Standardabweichung über dem Erwartungswert, also ist . Ein Auftrag, der schon so lange läuft, überschreitet die 52 Minuten sechsmal so oft wie ein neuer. Die Bearbeitungszeit hat, anders als eine exponentialverteilte, ein Gedächtnis.        Toleranz eines Widerstands   Der Widerstand eines Bauteils (in Ohm) sei -verteilt.   Zwischen welchen Grenzen, symmetrisch um 100, liegen 99 % der Bauteile?    Welcher Anteil der Bauteile weicht um mehr als 5 Ohm vom Nennwert 100 ab?          Für 99 % braucht man . Die Grenzen sind , also etwa 94,85 und 105,15 Ohm.    5 Ohm sind 2,5 Standardabweichungen: .        Die 68-95-99,7-Regel gilt nur für die Normalverteilung   Bestimmen Sie für und für jeweils die Wahrscheinlichkeit, dass die Zufallsvariable um höchstens eine bzw. höchstens zwei Standardabweichungen von ihrem Erwartungswert abweicht. Vergleichen Sie mit der Normalverteilung.    Für ist und . Also ist , und weil größer als 3 ist, ist . Für ist , also und .  Bei der Normalverteilung sind es 0,6827 und 0,9545. Die Gleichverteilung hat keine auslaufenden Ränder und liegt ganz innerhalb von zwei Standardabweichungen; bei der Exponentialverteilung liegt alles, was weiter abweicht, auf der rechten Seite. An solchen Anteilen kann man in Daten erkennen, welches Modell nicht passt.     "
},
{
  "id": "sec-stetige-verteilungen-2",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#sec-stetige-verteilungen-2",
  "type": "Lernziele",
  "number": "3.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     zu einer stetigen Größe die passende Verteilung wählen, ihre Parameter angeben und die Annahmen benennen, auf denen das Modell beruht: gleich wahrscheinliche Lage, konstante Ausfallrate, viele kleine Einflüsse,    Wahrscheinlichkeiten, Quantile, Erwartungswert und Varianz der Gleich-, der Exponential- und der Normalverteilung berechnen, auch in Rückrichtung: welcher Parameter zu einer geforderten Wahrscheinlichkeit passt,    die Exponentialverteilung aus dem Poisson-Prozess und als Grenzfall der geometrischen Verteilung herleiten und ihre Gedächtnislosigkeit erklären und anwenden,    normalverteilte Größen standardisieren, mit der Verteilungsfunktion rechnen und -Werte sowie die 68-95-99,7-Regel deuten,    Erwartungswert und Varianz der drei Grundverteilungen herleiten,    die Gamma- und Erlang-, die Weibull-, die Lognormal- und die Betaverteilung an ihrer Situation erkennen und auf die drei Grundverteilungen zurückführen.    "
},
{
  "id": "def-gleichverteilung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#def-gleichverteilung",
  "type": "Definition",
  "number": "3.2.1",
  "title": "Stetige Gleichverteilung.",
  "body": " Stetige Gleichverteilung  Gleichverteilung stetige   Seien reelle Zahlen. Eine Zufallsvariable mit der Dichte heißt gleichverteilt auf dem Intervall , kurz .   "
},
{
  "id": "thm-gleichverteilung-kennzahlen",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#thm-gleichverteilung-kennzahlen",
  "type": "Satz",
  "number": "3.2.2",
  "title": "Kennzahlen der Gleichverteilung.",
  "body": " Kennzahlen der Gleichverteilung   Für gilt    für , und für ist ,   ,    und ,     für .       (1) Das Integral einer konstanten Dichte über ein Intervall ist Höhe mal Länge. (4) folgt, indem man nach auflöst ( ).  (2) und (3): Für ist Nach der Formel für lineare Umrechnungen aus hat die Dichte , also auf . Es ist deshalb keine Einschränkung, zu schreiben, und mit folgt und .   "
},
{
  "id": "ex-quantisierungsfehler",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-quantisierungsfehler",
  "type": "Beispiel",
  "number": "3.2.3",
  "title": "Der Fehler eines Analog-Digital-Wandlers.",
  "body": " Der Fehler eines Analog-Digital-Wandlers   Ein Analog-Digital-Wandler mit Bit teilt den Messbereich von 0 bis 10 Volt in gleich breite Stufen und gibt zu jeder Spannung die Mitte ihrer Stufe aus. Schwankt das Signal über viele Stufen, so ist der Fehler (Ausgabe minus wahre Spannung) gleichverteilt auf , wobei die Stufenbreite ist.   Bestimmen Sie für die Stufenbreite, den Erwartungswert und die Standardabweichung des Fehlers.    Mit welcher Wahrscheinlichkeit ist der Fehler bei 8 Bit dem Betrag nach größer als 15 mV?    Wie viele Bit braucht der Wandler mindestens, damit die Standardabweichung des Fehlers höchstens 1 mV beträgt?            mV, also . Nach ist und  mV.     , also .    Gefordert ist , also  mV und . Wegen und braucht man 12 Bit. Dann ist  mV und  mV.     Der Fehler ist im Mittel null, der Wandler verfälscht also nicht systematisch. Seine Streuung hängt nur von der Stufenbreite ab, und jedes zusätzliche Bit halbiert sie. In der Signalverarbeitung heißt Quantisierungsrauschen, und ist die Formel, mit der man die nötige Auflösung eines Wandlers festlegt. Das Modell setzt voraus, dass das Signal die Stufen gleichmäßig überstreicht; bei einem konstanten Signal wäre der Fehler immer derselbe.   "
},
{
  "id": "def-exponentialverteilung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#def-exponentialverteilung",
  "type": "Definition",
  "number": "3.2.4",
  "title": "Exponentialverteilung.",
  "body": " Exponentialverteilung  Exponentialverteilung   Eine Zufallsvariable mit der Dichte heißt exponentialverteilt mit Parameter , kurz .   "
},
{
  "id": "thm-exponential-kennzahlen",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#thm-exponential-kennzahlen",
  "type": "Satz",
  "number": "3.2.5",
  "title": "Kennzahlen der Exponentialverteilung.",
  "body": " Kennzahlen der Exponentialverteilung   Für gilt    und für ,   ,    und ,     für ; der Median ist .       (1) . Für geht das gegen 1, die Dichte ist also normiert. (4) Man löst nach auf.  (2) und (3) mit partieller Integration. Weil und für gegen null gehen, ist Der Verschiebungssatz ergibt .   "
},
{
  "id": "sub-exponentialverteilung-6",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#sub-exponentialverteilung-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Rate "
},
{
  "id": "fig-exponentialverteilung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-exponentialverteilung",
  "type": "Abbildung",
  "number": "3.2.6",
  "title": "",
  "body": " Dichten der Exponentialverteilung für (durchgezogen), (gestrichelt) und (gepunktet). Jede beginnt bei der Höhe und fällt auf jeder Strecke der Länge auf die Hälfte.   Drei fallende Kurven, die bei den Höhen 2, 1 und 0,5 beginnen und sich der Achse nähern   Über dem Bereich von 0 bis 4 stehen drei fallende Kurven. Die durchgezogene für Lambda gleich 2 beginnt bei der Höhe 2 und ist bei 1 schon auf 0,27 gefallen. Die gestrichelte für Lambda gleich 1 beginnt bei 1 und hat bei 1 den Wert 0,37. Die gepunktete für Lambda gleich 0,5 beginnt bei 0,5 und fällt am langsamsten; bei 4 hat sie noch den Wert 0,07. Je größer Lambda, desto höher beginnt die Kurve und desto schneller fällt sie.     "
},
{
  "id": "ex-solarfahrzeug",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-solarfahrzeug",
  "type": "Beispiel",
  "number": "3.2.7",
  "title": "Ein solarbetriebenes Fahrzeug.",
  "body": " Ein solarbetriebenes Fahrzeug   Der Prototyp eines kleinen solarbetriebenen Fahrzeugs wird im Dauerbetrieb getestet. Seine Ausfälle bilden einen Poisson-Prozess mit der Rate je Betriebsstunde.   Mit welcher Wahrscheinlichkeit treten in 1000 Stunden vier oder mehr Ausfälle auf?    Mit welcher Wahrscheinlichkeit dauert es länger als 500 Stunden bis zum ersten Ausfall? Wie lange dauert es im Mittel, und mit welcher Wahrscheinlichkeit dauert es länger als dieser Mittelwert?    Mit welcher Wahrscheinlichkeit tritt der zweite Ausfall innerhalb der ersten 1000 Stunden ein?          Die Zahl der Ausfälle in 1000 Stunden ist -verteilt, denn . Also ist     Die Zeit bis zum ersten Ausfall ist -verteilt. Also ist und Stunden. Länger als 400 Stunden dauert es mit Wahrscheinlichkeit .    Der zweite Ausfall liegt genau dann in den ersten 1000 Stunden, wenn es dort mindestens zwei Ausfälle gibt:      Eine mittlere Zeit von 400 Stunden bis zum Ausfall klingt beruhigend, aber nur 37 % der Testläufe erreichen sie; die Hälfte ist schon nach Stunden unterbrochen. Wer eine Wartung plant, rechnet deshalb besser mit dem Median oder einem kleinen Quantil als mit dem Mittelwert. Teil (c) hat eine Frage über eine Wartezeit mit einer Anzahl beantwortet, ohne die Verteilung dieser Wartezeit zu kennen. gibt ihr einen Namen.  Das Beispiel stammt aus den Folien der Vorlesung; eine ältere Quelle ist dort nicht vermerkt.   "
},
{
  "id": "thm-gedaechtnislosigkeit-exponential",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#thm-gedaechtnislosigkeit-exponential",
  "type": "Satz",
  "number": "3.2.8",
  "title": "Gedächtnislosigkeit.",
  "body": " Gedächtnislosigkeit  Gedächtnislosigkeit der Exponentialverteilung   Für und ist     Wegen ist die bedingte Wahrscheinlichkeit gleich .   "
},
{
  "id": "sub-exponentialverteilung-13",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#sub-exponentialverteilung-13",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Ausfallrate "
},
{
  "id": "ex-zeitueberschreitung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-zeitueberschreitung",
  "type": "Beispiel",
  "number": "3.2.9",
  "title": "Abbrechen und neu anfragen?",
  "body": " Abbrechen und neu anfragen?   Die Antwortzeit eines Dienstes sei exponentialverteilt mit dem Erwartungswert 0,2 Sekunden.   Mit welcher Wahrscheinlichkeit dauert eine Anfrage länger als eine Sekunde?    Eine Anfrage läuft schon seit 0,6 Sekunden. Mit welcher Wahrscheinlichkeit dauert sie noch länger als weitere 0,4 Sekunden?    Ein Programm bricht jede Anfrage nach 0,6 Sekunden ab und stellt sie neu. Kommt es so schneller zu einer Antwort?       Die Rate ist je Sekunde.    .    Nach ist . Das ist zwanzigmal so viel wie in (a): Dass die Anfrage die ersten 0,6 Sekunden überdauert hat, war der unwahrscheinliche Teil.    Nein. Die Restzeit der alten Anfrage ist -verteilt, die Dauer der neuen auch. Der Neustart ändert an der Verteilung der verbleibenden Wartezeit nichts und kostet zusätzlich den Aufwand für die neue Anfrage.     In der Praxis helfen Zeitüberschreitungen mit Neuversuch sehr wohl. Das zeigt, dass echte Antwortzeiten ein Gedächtnis haben: Eine Anfrage, die ungewöhnlich lange läuft, ist oft hängen geblieben, und ein neuer Versuch hat bessere Aussichten. Die Exponentialverteilung beschreibt den Grenzfall dazwischen, in dem die verstrichene Zeit nichts über die restliche verrät.   "
},
{
  "id": "thm-geometrisch-exponential",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#thm-geometrisch-exponential",
  "type": "Satz",
  "number": "3.2.10",
  "title": "Von der geometrischen zur Exponentialverteilung.",
  "body": " Von der geometrischen zur Exponentialverteilung   Sei . Jede Zeiteinheit werde in gleich lange Schritte geteilt, und in jedem Schritt trete unabhängig von den anderen mit Wahrscheinlichkeit ein Ereignis ein. Sei die Nummer des Schritts mit dem ersten Ereignis und der Zeitpunkt, zu dem er endet. Dann gilt für jedes       heißt , und weil ganzzahlig ist, heißt das für die größte ganze Zahl . Nach ist . Wegen liegt dieser Wert zwischen und . Beide streben nach der Grenzwertformel gegen , denn , und der zweite Wert unterscheidet sich davon nur um den Faktor , der gegen 1 strebt.   "
},
{
  "id": "def-standardnormalverteilung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#def-standardnormalverteilung",
  "type": "Definition",
  "number": "3.2.11",
  "title": "Standardnormalverteilung.",
  "body": " Standardnormalverteilung  Standardnormalverteilung   Eine Zufallsvariable mit der Dichte heißt standardnormalverteilt . Ihre Verteilungsfunktion bezeichnet man mit    "
},
{
  "id": "thm-standardnormal-eigenschaften",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#thm-standardnormal-eigenschaften",
  "type": "Satz",
  "number": "3.2.12",
  "title": "Eigenschaften der Standardnormalverteilung.",
  "body": " Eigenschaften der Standardnormalverteilung   Für eine standardnormalverteilte Zufallsvariable gilt    und für alle , insbesondere ,   ,  .      (1) In kommt nur als vor. Wegen dieser Symmetrie ist die Fläche links von so groß wie die Fläche rechts von , also .  (2) Wegen ist endlich, und das Integral von über die negative Halbachse hat wegen der Symmetrie denselben Wert. Also ist endlich, der Erwartungswert existiert, und weil die Dichte symmetrisch um 0 ist, ist er 0.  (3) Partielle Integration mit und derselben Stammfunktion von : Also ist .   "
},
{
  "id": "fig-phi-symmetrie",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-phi-symmetrie",
  "type": "Abbildung",
  "number": "3.2.13",
  "title": "",
  "body": " Die Dichte der Standardnormalverteilung. Die Fläche links von ist , die gleich große Fläche rechts von ist ; gezeichnet ist .   Glockenkurve um 0 mit zwei gleich großen grauen Flächen an den Rändern   Eine symmetrische Glockenkurve über dem Bereich von minus 3,6 bis 3,6 mit dem Maximum 0,4 bei 0. Die Fläche unter der Kurve links von minus 1 ist grau gefüllt und mit Phi von minus z beschriftet, die Fläche rechts von 1 ist ebenfalls grau gefüllt und mit 1 minus Phi von z beschriftet. Beide Flächen sind Spiegelbilder voneinander. Auf der waagerechten Achse sind minus z, 0 und z markiert.     "
},
{
  "id": "def-normalverteilung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#def-normalverteilung",
  "type": "Definition",
  "number": "3.2.14",
  "title": "Normalverteilung.",
  "body": " Normalverteilung  Normalverteilung   Seien und . Eine Zufallsvariable mit der Dichte heißt normalverteilt mit den Parametern und , kurz . Die Standardnormalverteilung ist .   "
},
{
  "id": "thm-standardisierung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#thm-standardisierung",
  "type": "Satz",
  "number": "3.2.15",
  "title": "Standardisierung.",
  "body": " Standardisierung  Standardisieren einer normalverteilten Größe      Ist und sind und reelle Zahlen, so ist .    Ist , so ist die standardisierte Zufallsvariable standardnormalverteilt. Umgekehrt ist für jedes standardnormalverteilte .    Für ist und .    Für ist , also für         (1) Nach der Formel für lineare Umrechnungen aus hat die Dichte denn . Das ist die Dichte von mit der Standardabweichung .  (2) ist (1) mit und , für die Umkehrung mit und , angewandt auf . (3) Mit , und ist und . (4) Weil ist, gilt genau dann, wenn ist.   "
},
{
  "id": "fig-normalverteilung-dichten",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-normalverteilung-dichten",
  "type": "Abbildung",
  "number": "3.2.16",
  "title": "",
  "body": " Dichten von (durchgezogen), (gestrichelt) und (gepunktet). Der Erwartungswert legt die Lage fest, die Standardabweichung die Breite.   Drei Glockenkurven: zwei um 0 mit verschiedener Breite, eine schmale um 4   Über dem Bereich von minus 6 bis 8 stehen drei Glockenkurven. Die durchgezogene hat ihr Maximum 0,4 bei 0. Die gestrichelte liegt ebenfalls um 0, ist aber doppelt so breit und mit dem Maximum 0,2 halb so hoch. Die gepunktete hat dieselbe Form wie die durchgezogene, ist aber um 4 nach rechts verschoben.     "
},
{
  "id": "sub-normalverteilung-13",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#sub-normalverteilung-13",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "-Wert "
},
{
  "id": "tab-phi",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#tab-phi",
  "type": "Tabelle",
  "number": "3.2.17",
  "title": "Verteilungsfunktion <span class=\"process-math\">\\(\\Phi\\)<\/span> der Standardnormalverteilung. Für negative Argumente ist <span class=\"process-math\">\\(\\Phi(-z) = 1 - \\Phi(z)\\text{.}\\)<\/span>",
  "body": " Verteilungsfunktion der Standardnormalverteilung. Für negative Argumente ist .                                                                                                                  "
},
{
  "id": "cor-sigma-regeln",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#cor-sigma-regeln",
  "type": "Korollar",
  "number": "3.2.18",
  "title": "Die 68-95-99,7-Regel.",
  "body": " Die 68-95-99,7-Regel  68-95-99,7-Regel  Drei-Sigma-Regel   Für und ist , insbesondere     Nach ist die Wahrscheinlichkeit gleich .   "
},
{
  "id": "fig-sigma-regel",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-sigma-regel",
  "type": "Abbildung",
  "number": "3.2.19",
  "title": "",
  "body": " Die 68-95-99,7-Regel. Gut zwei Drittel der Werte einer normalverteilten Größe liegen höchstens eine Standardabweichung vom Erwartungswert entfernt, gut 95 % höchstens zwei, fast alle höchstens drei. Aufbau nach einer Abbildung in Montgomery und Runger .   Glockenkurve mit drei ineinanderliegenden Bereichen um den Erwartungswert   Eine Glockenkurve über einer Achse mit den Markierungen mü minus 3 sigma bis mü plus 3 sigma. Der Bereich zwischen mü minus sigma und mü plus sigma ist dunkelgrau gefüllt, der Bereich bis mü plus und minus 2 sigma hellgrau. Unter der Achse stehen drei waagerechte Doppelpfeile übereinander: der kürzeste von mü minus sigma bis mü plus sigma mit der Beschriftung 68,27 Prozent, der mittlere von mü minus 2 sigma bis mü plus 2 sigma mit 95,45 Prozent, der längste von mü minus 3 sigma bis mü plus 3 sigma mit 99,73 Prozent.     "
},
{
  "id": "tab-phi-quantile",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#tab-phi-quantile",
  "type": "Tabelle",
  "number": "3.2.20",
  "title": "Quantile <span class=\"process-math\">\\(z_\\alpha\\)<\/span> der Standardnormalverteilung: <span class=\"process-math\">\\(\\Phi(z_\\alpha) = \\alpha\\text{.}\\)<\/span> Für <span class=\"process-math\">\\(\\alpha \\lt 1\/2\\)<\/span> ist <span class=\"process-math\">\\(z_\\alpha = -z_{1 - \\alpha}\\text{.}\\)<\/span>",
  "body": " Quantile der Standardnormalverteilung: . Für ist .                                "
},
{
  "id": "ex-intelligenzquotient",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-intelligenzquotient",
  "type": "Beispiel",
  "number": "3.2.21",
  "title": "Die Verteilung des Intelligenzquotienten.",
  "body": " Die Verteilung des Intelligenzquotienten   Intelligenztests werden so konstruiert, dass ihr Ergebnis in der Bevölkerung normalverteilt ist mit dem Erwartungswert 100 und der Standardabweichung 15 (Situation und Teil (a) nach Meintrup ).   Beschreiben Sie die Verteilung mit der 68-95-99,7-Regel.    Welcher Anteil der Bevölkerung erreicht mehr als 130, welcher weniger als 91, welcher einen Wert zwischen 85 und 130?    Welchen Wert muss man mindestens erreichen, um zum besten Prozent zu gehören?       Sei das Testergebnis einer zufällig gewählten Person.   Gut zwei Drittel der Bevölkerung liegen zwischen 85 und 115, gut 95 % zwischen 70 und 130 und fast alle zwischen 55 und 145.    Die -Werte sind , und . Mit ist     Gesucht ist das 99. Perzentil: .     Der Intelligenzquotient ist damit kein Messwert wie eine Länge, sondern ein verkleideter -Wert: Er sagt, wo jemand innerhalb der Bevölkerung steht, und ist nur eine bequeme Skala dafür. Dass die Verteilung normal ist, ist hier keine Beobachtung, sondern eine Festlegung bei der Konstruktion des Tests. Die Situation und die Frage aus (a) stammen aus D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , 2018 ( ); die Teile (b) und (c) sind für dieses Buch ergänzt.   "
},
{
  "id": "ex-passung-normal",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-passung-normal",
  "type": "Beispiel",
  "number": "3.2.22",
  "title": "Noch einmal Welle und Bohrung.",
  "body": " Noch einmal Welle und Bohrung   In hat das Spiel zwischen Bohrung und Welle den Erwartungswert 0,10 mm und die Standardabweichung 0,05 mm. Nehmen Sie an, dass normalverteilt ist.  Bei welchem Anteil der Paarungen klemmt die Welle, ist also ?   Brauchbar ist eine Paarung, wenn das Spiel zwischen 0,02 und 0,20 mm liegt. Welcher Anteil ist brauchbar?    Durch genauere Fertigung sinkt die Standardabweichung des Spiels auf 0,04 mm, der Erwartungswert bleibt. Bei welchem Anteil der Paarungen klemmt die Welle jetzt?           .    Die -Werte der Grenzen sind und 2, also ist der Anteil .    Jetzt liegt die Grenze 0 um Standardabweichungen unter dem Erwartungswert: .     Das sind die gut 2 % , die angekündigt hat: Bei zwei Standardabweichungen Abstand klemmt jede 44. Paarung. Wird die Streuung um ein Fünftel kleiner, klemmt nur noch etwa jede 160., fast viermal seltener: Weit draußen im Rand der Glockenkurve wirkt eine kleine Änderung der Streuung stark. Die Annahme, dass normalverteilt ist, ist naheliegend, wenn die Durchmesser von Bohrung und Welle es sind; dass die Differenz zweier unabhängiger normalverteilter Größen wieder normalverteilt ist, zeigt .   "
},
{
  "id": "ex-fehlalarme",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-fehlalarme",
  "type": "Beispiel",
  "number": "3.2.23",
  "title": "Wie viele Fehlalarme erzeugt die Drei-Sigma-Regel?",
  "body": " Wie viele Fehlalarme erzeugt die Drei-Sigma-Regel?   Ein Überwachungssystem misst jede Minute die Antwortzeit eines Dienstes. Im Normalbetrieb sind die Messwerte unabhängig und normalverteilt mit dem Erwartungswert 120 ms und der Standardabweichung 15 ms. Das System schlägt Alarm, wenn ein Messwert um mehr als drei Standardabweichungen vom Erwartungswert abweicht.   Zwischen welchen Grenzen bleibt das System still, und mit welcher Wahrscheinlichkeit löst eine einzelne Messung im Normalbetrieb einen Alarm aus?    Wie viele Fehlalarme sind an einem Tag mit 1440 Messungen zu erwarten?    Im Mittel soll es höchstens einen Fehlalarm je Tag geben. Auf welches Vielfache der Standardabweichung muss die Schwelle gesetzt werden, und welche Grenzen ergibt das?          Die Grenzen sind , also 75 und 165 ms. Nach liegt ein Messwert mit Wahrscheinlichkeit außerhalb.    Die Zahl der Fehlalarme ist eine Summe von 1440 Indikatorvariablen mit je dem Erwartungswert 0,0027. Nach der Linearität sind Fehlalarme je Tag zu erwarten.    Mit der Schwelle ist die Wahrscheinlichkeit eines Fehlalarms . Gefordert ist , also . In ist zu klein. Bei reichen die vier Stellen der Tabelle für die Entscheidung nicht aus; der genauere Wert erfüllt die Schranke knapp. Die Schwelle gehört also auf etwa 3,4 Standardabweichungen, das sind die Grenzen , also 69 und 171 ms.     Drei Standardabweichungen klingen streng, und für eine einzelne Messung sind sie es auch. Wer aber 1440-mal am Tag prüft, bekommt trotzdem täglich etwa vier grundlose Alarme, und bei hundert überwachten Diensten vierhundert. Wie beim Vorhersagewert in entscheidet die Zahl der Gelegenheiten, nicht nur die Fehlerquote je Gelegenheit. Echte Antwortzeiten haben zudem meist einen schwereren rechten Rand als die Normalverteilung ( ); dann sind es noch mehr grundlose Alarme. Eine höhere Schwelle senkt die Fehlalarme, erkennt echte Störungen aber später.   "
},
{
  "id": "rem-ausreisserregel",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#rem-ausreisserregel",
  "type": "Bemerkung",
  "number": "3.2.24",
  "title": "Die Ausreißerregel des Boxplots.",
  "body": " Die Ausreißerregel des Boxplots  Ausreißerregel  Ein Boxplot markiert einen Wert üblicherweise als Ausreißer, wenn er um mehr als das Anderthalbfache des Quartilsabstands ( ) über dem oberen oder unter dem unteren Quartil liegt. Für sind die Quartile , der Quartilsabstand ist , und die Grenzen liegen bei . Außerhalb liegen  % der Werte. Für diese Verteilung ist die Regel gemacht: Sie markiert, was bei normalverteilten Daten wirklich selten ist.  "
},
{
  "id": "rem-normalverteilung-grenzen",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#rem-normalverteilung-grenzen",
  "type": "Bemerkung",
  "number": "3.2.25",
  "title": "Woher die Normalverteilung kommt und wo sie endet.",
  "body": " Woher die Normalverteilung kommt und wo sie endet  Die Normalverteilung ist das Standardmodell für Messfehler und für Merkmale, die aus vielen kleinen Beiträgen entstehen. Drei Gründe dafür folgen in : Summen unabhängiger normalverteilter Größen sind wieder normalverteilt ( ), Mittelwerte vieler unabhängiger Größen sind es näherungsweise ( ), und auch Binomial- und Poisson-Verteilung nähern sich der Glockenform, wie angekündigt hat ( ).  Zwei Grenzen des Modells sollte man kennen. Erstens nimmt eine normalverteilte Größe jeden reellen Wert an, auch negative. Für eine Größe, die nicht negativ sein kann, taugt das Modell deshalb nur, wenn der Erwartungswert mehrere Standardabweichungen über null liegt. Zweitens fallen die Ränder der Glocke extrem schnell: Weiter als fünf Standardabweichungen vom Erwartungswert liegt ein Wert nur mit Wahrscheinlichkeit . Bei Antwortzeiten, Schadenhöhen oder Kursänderungen kommen so große Abweichungen in Wirklichkeit viel öfter vor. Wer dort mit der Normalverteilung rechnet, unterschätzt gerade die Ereignisse, auf die es ankommt.  "
},
{
  "id": "sub-gamma-erlang-verteilung-6-3",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#sub-gamma-erlang-verteilung-6-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Gammafunktion "
},
{
  "id": "fig-erlang-dichten",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-erlang-dichten",
  "type": "Abbildung",
  "number": "3.2.26",
  "title": "",
  "body": " Dichten von für . Für ist es die Exponentialverteilung; mit wachsendem wandert der Gipfel nach rechts, und die Kurve wird symmetrischer.   Vier Dichtekurven, die erste fallend, die übrigen mit einem Gipfel, der mit k nach rechts wandert   Über dem Bereich von 0 bis 11 stehen vier Kurven. Die für k gleich 1 fällt von der Höhe 1 exponentiell ab. Die für k gleich 2 beginnt bei 0, erreicht bei 1 ihr Maximum 0,37 und fällt dann. Die für k gleich 3 hat ihr Maximum 0,27 bei 2, die für k gleich 5 ihr Maximum 0,20 bei 4. Je größer k, desto weiter rechts, niedriger und breiter ist der Gipfel, und desto ähnlicher wird die Kurve einer Glocke.     "
},
{
  "id": "ex-ersatzteile",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-ersatzteile",
  "type": "Beispiel",
  "number": "3.2.27",
  "title": "Drei Ersatzteile.",
  "body": " Drei Ersatzteile   Für das Fahrzeug aus liegen drei Ersatzteile bereit, sodass es erst mit dem vierten Ausfall stillsteht. Welche Verteilung hat die Zeit bis dahin, mit welchem Erwartungswert und welcher Standardabweichung? Mit welcher Wahrscheinlichkeit läuft das Fahrzeug länger als 1000 Stunden?    Die Zeit bis zum vierten Ausfall ist -verteilt, also Stunden und Stunden. Länger als 1000 Stunden läuft das Fahrzeug, wenn bis dahin höchstens drei Ausfälle eintreten. Mit ist das Gegenstück zu Teil (a) von .  Die Standardabweichung ist hier halb so groß wie der Erwartungswert, bei der Wartezeit auf den ersten Ausfall waren beide gleich. Allgemein ist das Verhältnis : Je mehr Ereignisse man abwartet, desto besser lässt sich die Gesamtzeit planen, weil sich lange und kurze Abstände ausgleichen.   "
},
{
  "id": "fig-weibull-ausfallrate",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-weibull-ausfallrate",
  "type": "Abbildung",
  "number": "3.2.28",
  "title": "",
  "body": " Ausfallraten der Weibull-Verteilung mit : fallend für , konstant für (Exponentialverteilung), steigend für .   Eine fallende, eine waagerechte und eine steigende Kurve   Über dem Bereich von 0 bis 2,5 stehen drei Kurven. Die gestrichelte für k gleich 0,5 beginnt links oben bei etwa 3,2, fällt steil und ist bei 2,5 auf etwa 0,3 gesunken. Die gepunktete für k gleich 1 ist eine waagerechte Gerade auf der Höhe 1. Die durchgezogene für k gleich 2 ist eine Ursprungsgerade mit der Steigung 2.     "
},
{
  "id": "ex-lagerlebensdauer",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-lagerlebensdauer",
  "type": "Beispiel",
  "number": "3.2.29",
  "title": "Ein Lager, das altert.",
  "body": " Ein Lager, das altert   Die Lebensdauer eines Kugellagers (in Jahren) sei -verteilt. Mit welcher Wahrscheinlichkeit hält ein neues Lager länger als fünf Jahre? Mit welcher hält ein Lager, das schon fünf Jahre läuft, noch weitere fünf? Nach welcher Zeit sind 10 % der Lager ausgefallen?     und Das 10-%-Quantil ist Jahre.  Ein neues Lager übersteht die nächsten fünf Jahre mit 78 %, ein fünf Jahre altes nur noch mit 47 %: Das Lager hat ein Gedächtnis, es altert. Bei einer exponentialverteilten Lebensdauer wären beide Wahrscheinlichkeiten gleich. Das 10-%-Quantil ist die Größe, die Hersteller von Wälzlagern als nominelle Lebensdauer angeben: die Zeit, die neun von zehn Lagern erreichen.   "
},
{
  "id": "fig-lognormal-dichte",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-lognormal-dichte",
  "type": "Abbildung",
  "number": "3.2.30",
  "title": "",
  "body": " Dichte von . Der Median ist 1, der Erwartungswert ; rechts vom Erwartungswert liegen nur noch 31 % der Fläche.   Rechtsschiefe Dichte mit einem steilen Gipfel links und einem langen rechten Rand, Median und Erwartungswert markiert   Über dem Bereich von 0 bis 6 steht eine Kurve, die bei 0 mit der Höhe 0 beginnt, steil auf ihr Maximum 0,66 bei etwa 0,37 steigt und dann langsam fällt; bei 6 hat sie noch den Wert 0,013. Eine gestrichelte senkrechte Linie markiert den Median bei 1, eine zweite den Erwartungswert bei 1,65.     "
},
{
  "id": "ex-dateigroessen",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-dateigroessen",
  "type": "Beispiel",
  "number": "3.2.31",
  "title": "Dateigrößen auf einem Server.",
  "body": " Dateigrößen auf einem Server   Die Größe einer Datei auf einem Dateiserver (in kB) sei lognormalverteilt: hat den Erwartungswert und die Standardabweichung 1. Bestimmen Sie Median und Erwartungswert von . Welcher Anteil der Dateien ist größer als der Erwartungswert, welcher größer als 1000 kB? Unter welcher Größe bleiben 95 % der Dateien?    Der Median ist  kB, der Erwartungswert  kB. Mit ist und das 95. Perzentil ist  kB.  Die typische Datei hat 100 kB, aber der Mittelwert liegt um zwei Drittel höher, und nur 31 % der Dateien erreichen ihn. Wenige große Dateien tragen den Speicherbedarf. Wer den Speicher plant, braucht den Mittelwert; wer wissen will, was ein Nutzer typischerweise hochlädt, den Median.   "
},
{
  "id": "fig-beta-dichten",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-beta-dichten",
  "type": "Abbildung",
  "number": "3.2.32",
  "title": "",
  "body": " Dichten von (gepunktet, die Gleichverteilung), (durchgezogen) und (gestrichelt). Der Erwartungswert ist , und .   Eine waagerechte Gerade, eine symmetrische Parabel und eine nach rechts verschobene Kurve mit Gipfel bei 0,8   Über dem Intervall von 0 bis 1 stehen drei Kurven. Die gepunktete ist eine waagerechte Gerade auf der Höhe 1. Die durchgezogene ist eine nach unten geöffnete Parabel mit Nullstellen bei 0 und 1 und dem Maximum 1,5 bei 0,5. Die gestrichelte bleibt bis etwa 0,25 nahe null, steigt dann auf ihr Maximum 2,46 bei 0,8 und fällt bis 1 wieder auf null.     "
},
{
  "id": "ex-median-von-drei",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-median-von-drei",
  "type": "Beispiel",
  "number": "3.2.33",
  "title": "Der mittlere von drei Werten.",
  "body": " Der mittlere von drei Werten   Um einzelne Ausreißer zu unterdrücken, verwendet ein Messprogramm von je drei unabhängigen Messungen nur die mittlere. Als Modell dafür seien unabhängig und -verteilt, und sei der mittlere der drei Werte. Welche Verteilung hat ? Vergleichen Sie Varianz und mit den Werten für eine einzelne Messung.     mit der Dichte auf . Also ist und , gegenüber für einen einzelnen Wert. Die Verteilungsfunktion ist , also gegenüber für einen einzelnen Wert.  Der mittlere von drei Werten liegt also deutlich öfter in der Mitte als ein einzelner. Das gilt nicht nur für gleichverteilte Messungen. Setzt man Messwerte mit stetiger, streng wachsender Verteilungsfunktion in ein, so entstehen nach gleichverteilte Werte, und die Reihenfolge bleibt erhalten. Der mittlere von drei unabhängigen Messwerten liegt deshalb bei jeder solchen Verteilung mit Wahrscheinlichkeit zwischen ihren beiden Quartilen. Wie eine Betaverteilung das Wissen über eine unbekannte Wahrscheinlichkeit beschreibt, zeigt .   "
},
{
  "id": "tab-stetige-verteilungen",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#tab-stetige-verteilungen",
  "type": "Tabelle",
  "number": "3.2.34",
  "title": "Die drei Grundverteilungen und die vier Steckbriefe",
  "body": " Die drei Grundverteilungen und die vier Steckbriefe        Verteilung  Situation       Lage in einem Intervall, kein Teil bevorzugt       Wartezeit bis zum nächsten Ereignis, ohne Gedächtnis       Messfehler, Summe vieler kleiner Einflüsse       Wartezeit bis zum Ereignis       positive, rechtsschiefe Größen       Lebensdauer mit steigender oder fallender Ausfallrate       Produkt vieler Einflüsse; ist normalverteilt       Anteil oder unbekannte Wahrscheinlichkeit in      "
},
{
  "id": "fig-verwandtschaften-stetig",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#fig-verwandtschaften-stetig",
  "type": "Abbildung",
  "number": "3.2.35",
  "title": "",
  "body": " Die Verwandtschaften der stetigen Verteilungen. Fett umrandet sind die drei Grundverteilungen, dünn die Steckbriefe, gestrichelt, was aus anderen Kapiteln stammt.   Diagramm aus elf Kästen mit Pfeilen: Normal-, Gleich- und Exponentialverteilung in der Mitte, darunter die vier Steckbriefe   In der mittleren Reihe stehen von links nach rechts die fett umrandeten Kästen Normal, Gleich und Exponential, rechts daneben ein gestrichelter Kasten Poisson-Prozess, Kapitel 2. Über Normal steht ein gestrichelter Kasten Binomial, Poisson, Mittelwerte mit einem gestrichelten Pfeil Grenzwertsatz, Kapitel 5 zu Normal. Über Exponential steht ein gestrichelter Kasten geometrisch, Kapitel 2, mit einem Pfeil immer kürzere Schritte zu Exponential. Vom Poisson-Prozess führt ein Pfeil erstes Ereignis zu Exponential, von Gleich ein Pfeil Inversionsmethode . In der unteren Reihe stehen die dünn umrandeten Steckbriefe: unter Normal der Kasten Lognormal mit einem Pfeil e hoch X von Normal, unter Gleich der Kasten Beta mit einem Pfeil k-kleinster von n Werten von Gleich, unter Exponential der Kasten Erlang und Gamma mit einem Pfeil k-tes Ereignis von Exponential, und rechts der Kasten Weibull mit einem Pfeil Potenz einer Exp(1)-Größe von Exponential. Von Erlang und Gamma führt ein gestrichelter Pfeil alpha gleich n halbe, beta gleich ein halb nach unten zu einem gestrichelten Kasten Chi-Quadrat, Kapitel 5.     "
},
{
  "id": "ex-welche-stetige-verteilung",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#ex-welche-stetige-verteilung",
  "type": "Beispiel",
  "number": "3.2.36",
  "title": "Welche stetige Verteilung passt?",
  "body": " Welche stetige Verteilung passt?   Geben Sie jeweils eine passende Verteilung an, soweit möglich mit Parametern, und nennen Sie die Annahme, auf der das Modell beruht.   Die Zeit bis zur nächsten Anfrage an einen Webserver, der im Mittel vier Anfragen je Sekunde erhält.    Die Zeit, bis derselbe Server hundert Anfragen erhalten hat.    Der Fehler, der entsteht, wenn ein Rechnungsbetrag auf ganze Euro gerundet wird.    Die Abweichung des Füllgewichts einer Packung vom eingestellten Wert.   Die Laufleistung eines Reifens bis zum Verschleiß.  Das Monatseinkommen einer zufällig gewählten Person.   Die unbekannte Klickrate einer neuen Anzeige, nachdem man ihre ersten Einblendungen beobachtet hat.           mit der Zeit in Sekunden, wenn die Anfragen einen Poisson-Prozess bilden, also von vielen Nutzern unabhängig voneinander kommen.     unter derselben Annahme, mit dem Erwartungswert 25 Sekunden.     in Euro, wenn die Centbeträge gleichmäßig verteilt sind. Enden viele Preise auf 99 Cent, stimmt das nicht.    Eine Normalverteilung mit dem Erwartungswert 0, wenn sich viele kleine, unabhängige Störungen addieren. Die Standardabweichung muss gemessen werden.    Eine Weibull-Verteilung mit , denn der Reifen verschleißt: Seine Ausfallrate steigt mit der Laufleistung.    Eine Lognormalverteilung: Einkommen sind positiv und rechtsschief, und Unterschiede entstehen eher durch Faktoren als durch feste Beträge.    Eine Betaverteilung, denn die Klickrate ist eine Zahl zwischen 0 und 1, über die man nur ungefähr Bescheid weiß. Wie die Beobachtungen dieses Wissen verändern, zeigt .     Wie in ist die Wahl der Verteilung eine Modellannahme. Bei stetigen Größen lässt sie sich oft an den Daten prüfen: Ist das Histogramm symmetrisch oder schief? Ist die Standardabweichung etwa so groß wie der Mittelwert, wie bei der Exponentialverteilung? Liegen gut zwei Drittel der Werte innerhalb einer Standardabweichung, wie bei der Normalverteilung?   "
},
{
  "id": "sub-zusammenfassung-3-2-2",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#sub-zusammenfassung-3-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Gleichverteilung. Exponentialverteilung. Gedächtnislosigkeit. Normalverteilung. Standardisieren. 68-95-99,7-Regel und Quantile. Steckbriefe. "
},
{
  "id": "exercise-buch-stoerung-in-der-schicht",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#exercise-buch-stoerung-in-der-schicht",
  "type": "Übung",
  "number": "3.2.10.1",
  "title": "Eine Störung in der Schicht.",
  "body": " Eine Störung in der Schicht   In einer Schicht von acht Stunden tritt genau eine Störung auf, zu einem Zeitpunkt (in Stunden nach Schichtbeginn).  Mit welcher Wahrscheinlichkeit fällt die Störung in die letzte Stunde der Schicht?  Bestimmen Sie und .  Wie erzeugt man einen solchen Zeitpunkt mit random.random() ?        , die Länge des Intervalls geteilt durch die Länge der Schicht.    Stunden und Stunden.   Mit 8 * random.random() , denn für .     "
},
{
  "id": "exercise-buch-anrufe-hotline",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#exercise-buch-anrufe-hotline",
  "type": "Übung",
  "number": "3.2.10.2",
  "title": "Anrufe bei einer Hotline.",
  "body": " Anrufe bei einer Hotline   Die Zeit zwischen zwei Anrufen bei einer Hotline sei exponentialverteilt mit dem Erwartungswert 3 Minuten.  Mit welcher Wahrscheinlichkeit kommt der nächste Anruf innerhalb einer Minute?  Bestimmen Sie den Median der Wartezeit.   Seit fünf Minuten hat niemand angerufen. Mit welcher Wahrscheinlichkeit dauert es noch länger als drei weitere Minuten?    Wie ist die Zahl der Anrufe in einer halben Stunde verteilt, wenn die Anrufe einen Poisson-Prozess bilden?       Die Rate ist je Minute.  .  Minuten, deutlich weniger als der Erwartungswert.   Wegen der Gedächtnislosigkeit ist das ; die fünf Minuten ändern nichts.    Die Rate je Minute ergibt in 30 Minuten im Mittel 10 Anrufe; die Anzahl ist -verteilt.      "
},
{
  "id": "exercise-buch-bearbeitungszeit-normal",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#exercise-buch-bearbeitungszeit-normal",
  "type": "Übung",
  "number": "3.2.10.3",
  "title": "Eine normalverteilte Bearbeitungszeit.",
  "body": " Eine normalverteilte Bearbeitungszeit   Die Bearbeitungszeit eines Auftrags (in Minuten) sei -verteilt.  Mit welcher Wahrscheinlichkeit dauert ein Auftrag länger als 52 Minuten?  Mit welcher Wahrscheinlichkeit dauert er zwischen 36 und 52 Minuten?   Ein Auftrag ist nach 48 Minuten noch nicht erledigt. Mit welcher Wahrscheinlichkeit dauert er länger als 52 Minuten? Vergleichen Sie mit (a).           , also .     .    48 Minuten sind eine Standardabweichung über dem Erwartungswert, also ist . Ein Auftrag, der schon so lange läuft, überschreitet die 52 Minuten sechsmal so oft wie ein neuer. Die Bearbeitungszeit hat, anders als eine exponentialverteilte, ein Gedächtnis.      "
},
{
  "id": "exercise-buch-widerstaende",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#exercise-buch-widerstaende",
  "type": "Übung",
  "number": "3.2.10.4",
  "title": "Toleranz eines Widerstands.",
  "body": " Toleranz eines Widerstands   Der Widerstand eines Bauteils (in Ohm) sei -verteilt.   Zwischen welchen Grenzen, symmetrisch um 100, liegen 99 % der Bauteile?    Welcher Anteil der Bauteile weicht um mehr als 5 Ohm vom Nennwert 100 ab?          Für 99 % braucht man . Die Grenzen sind , also etwa 94,85 und 105,15 Ohm.    5 Ohm sind 2,5 Standardabweichungen: .      "
},
{
  "id": "exercise-buch-regel-nur-normal",
  "level": "2",
  "url": "sec-stetige-verteilungen.html#exercise-buch-regel-nur-normal",
  "type": "Übung",
  "number": "3.2.10.5",
  "title": "Die 68-95-99,7-Regel gilt nur für die Normalverteilung.",
  "body": " Die 68-95-99,7-Regel gilt nur für die Normalverteilung   Bestimmen Sie für und für jeweils die Wahrscheinlichkeit, dass die Zufallsvariable um höchstens eine bzw. höchstens zwei Standardabweichungen von ihrem Erwartungswert abweicht. Vergleichen Sie mit der Normalverteilung.    Für ist und . Also ist , und weil größer als 3 ist, ist . Für ist , also und .  Bei der Normalverteilung sind es 0,6827 und 0,9545. Die Gleichverteilung hat keine auslaufenden Ränder und liegt ganz innerhalb von zwei Standardabweichungen; bei der Exponentialverteilung liegt alles, was weiter abweicht, auf der rechten Seite. An solchen Anteilen kann man in Daten erkennen, welches Modell nicht passt.   "
},
{
  "id": "sec-gemeinsame-verteilungen-randverteilungen",
  "level": "1",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html",
  "type": "Abschnitt",
  "number": "4.1",
  "title": "Gemeinsame Verteilungen, Randverteilungen und Unabhängigkeit",
  "body": " Gemeinsame Verteilungen, Randverteilungen und Unabhängigkeit    Nach diesem Abschnitt können Sie     die gemeinsame Verteilung zweier diskreter Zufallsvariablen als Tabelle aufstellen und daraus Wahrscheinlichkeiten von Ereignissen bestimmen, in denen beide vorkommen,    Randverteilungen aus einer gemeinsamen Wahrscheinlichkeitsfunktion oder Dichte bestimmen und begründen, warum die Ränder die gemeinsame Verteilung im Allgemeinen nicht festlegen,    die Wahrscheinlichkeit eines Gebiets wie als Doppelintegral über eine gemeinsame Dichte aufstellen und als zwei einfache Integrale nacheinander ausrechnen,    mit der gemeinsamen Verteilungsfunktion rechnen: Rechtecke über Ein- und Ausschließen, Ränder als Grenzwert,    die Unabhängigkeit zweier Zufallsvariablen am Produkt der Ränder prüfen und umgekehrt aus unabhängigen Rändern die gemeinsame Dichte bilden,    Erwartungswerte von Funktionen zweier Zufallsvariablen berechnen und die Regeln für , und samt ihren Voraussetzungen anwenden.      Ein Klassifikator ordnet Supporttickets einer Abteilung zu. Wie gut er ist, sagt keine der beiden Spalten des Datensatzes allein, weder die wahre Abteilung noch die vorhergesagte. Es kommt darauf an, wie oft beide zusammenpassen, und das ist eine Frage nach der gemeinsamen Verteilung zweier Zufallsvariablen. Dasselbe gilt für die Auslastungen zweier Server zur selben Zeit, für Signal und Rauschen eines Sensors und für jede Annahme, die Daten seien unabhängig erhoben.   beginnt mit Tabellen: Die gemeinsame Wahrscheinlichkeitsfunktion zweier diskreter Zufallsvariablen, und an ihrem Rand die Verteilungen der einzelnen. Das ist die totale Wahrscheinlichkeit aus in neuer Form. überträgt das auf Dichten über der Ebene; hier liegt die eigentliche neue Rechentechnik der Woche, das Integrieren über ein Gebiet. beschreibt jedes Paar von Zufallsvariablen, ob diskret oder stetig, durch eine einzige Funktion zweier Variablen. In wird die Unabhängigkeit aus und zu einem Produktkriterium, mit dem man gemeinsame Verteilungen prüfen und bauen kann. beweist schließlich die Rechenregeln für Summen und Produkte, die wir für stetige Zufallsvariablen bisher nur benutzt haben.    Die gemeinsame Wahrscheinlichkeitsfunktion  Zwei Zufallsvariablen und auf demselben Wahrscheinlichkeitsraum hängen über das Ergebnis zusammen, aus dem beide ihren Wert beziehen. Die Wahrscheinlichkeitsfunktionen und beschreiben jede für sich, aber nicht diesen Zusammenhang. Für Fragen wie Mit welcher Wahrscheinlichkeit ist ? braucht man die Wahrscheinlichkeiten der Paare. Sie standen schon in , Teil (2), und bekommen jetzt einen Namen.   Gemeinsame Wahrscheinlichkeitsfunktion  gemeinsame Wahrscheinlichkeitsfunktion  Wahrscheinlichkeitsfunktion gemeinsame  gemeinsame Verteilung  Verteilung gemeinsame   Seien und diskrete Zufallsvariablen auf demselben Wahrscheinlichkeitsraum. Die gemeinsame Wahrscheinlichkeitsfunktion von und ist Die Wahrscheinlichkeiten für Mengen bilden die gemeinsame Verteilung von und .    Auf den Folien der Vorlesung heißt die gemeinsame Wahrscheinlichkeitsfunktion ; dieses Buch schreibt und behält der gemeinsamen Dichte vor ( ). Nehmen die Werte und die Werte an, so schreibt man als Tabelle mit einer Zeile je Wert von und einer Spalte je Wert von . Die Ereignisse sind paarweise disjunkt und füllen zusammen aus. Deshalb ist die Summe aller Einträge 1, und die Wahrscheinlichkeit eines Ereignisses, das von und abhängt, ist die Summe der passenden Felder: Für sind das die Felder oberhalb der Diagonale, wenn Zeilen und Spalten gleich beschriftet sind.  Aus der Tabelle bekommt man auch die Verteilungen der einzelnen Zufallsvariablen zurück. Man schreibt sie an den Rand, daher der Name.   Randverteilungen  Randverteilung   Seien und diskret mit gemeinsamer Wahrscheinlichkeitsfunktion und Werten bzw. . Dann sind  und heißen in diesem Zusammenhang Randwahrscheinlichkeitsfunktionen Randwahrscheinlichkeitsfunktion , ihre Verteilungen die Randverteilungen .    Die Ereignisse bilden eine Zerlegung von . Wie im Beweis von ist die disjunkte Vereinigung der Mengen , also . Für vertauscht man die Rollen.    Man summiert also jede Zeile für und jede Spalte für . Schreibt man in der Summe , so steht dort wörtlich der Satz von der totalen Wahrscheinlichkeit.   Minimum und Maximum zweier Würfel   Zwei faire Würfel werden geworfen. Sei die kleinere, die größere der beiden Augenzahlen.  Stellen Sie die gemeinsame Wahrscheinlichkeitsfunktion von und auf.   Bestimmen Sie die Randverteilungen. Vergleichen Sie mit .    Mit welcher Wahrscheinlichkeit liegen die beiden Augenzahlen mindestens 3 auseinander, ist also ?       (a) Von den 36 gleich wahrscheinlichen Paaren führt als einziges auf . Für führen und auf , . ist unmöglich. Also ist für , für und 0 für . Die Tabelle zeigt , am Rand die Summen:       \\  1 2 3 4 5 6  Summe    1  1 2 2 2 2 2  11    2  0 1 2 2 2 2  9    3  0 0 1 2 2 2  7    4  0 0 0 1 2 2  5    5  0 0 0 0 1 2  3    6  0 0 0 0 0 1  1    Summe  1 3 5 7 9 11  36    (b) Die Zeilensummen ergeben , die Spaltensummen . Das ist die Wahrscheinlichkeitsfunktion aus , diesmal ohne den Umweg über die Verteilungsfunktion.  (c) gilt in den Feldern mit : drei, zwei und ein Feld, jedes mit . Also ist .  Die Randverteilungen allein hätten (c) nicht beantwortet: Dafür muss man wissen, welche Werte von und zusammen auftreten. Die Nullen unterhalb der Diagonale sagen zum Beispiel, dass ein großes Minimum nie zusammen mit einem kleinen Maximum auftritt.  Minimum und Maximum zweier Würfel ist das Beispiel der Vorlesung zur gemeinsamen Verteilung; die Folien zeigen dazu eine Abbildung aus Arens u. a. .    Umgekehrt lässt sich die gemeinsame Verteilung nicht aus den Randverteilungen zurückgewinnen. Seien und beide gleichverteilt auf . Das gilt für zwei getrennte Münzwürfe, bei denen jedes der vier Paare die Wahrscheinlichkeit hat. Es gilt aber auch für , wo nur und vorkommen, und für , wo nur und vorkommen. Drei verschiedene Tabellen mit denselben Rändern: Die Ränder legen fest, wie oft jeder Wert vorkommt, aber nicht, mit welchem Wert der anderen Variablen er zusammen auftritt.  In Data Science ist eine solche Tabelle meist eine Kreuztabelle Kreuztabelle aus Häufigkeiten: Man zählt in einem Datensatz, wie oft jede Kombination zweier Merkmale vorkommt, und teilt durch die Zahl der Datensätze. Wählt man einen Datensatz rein zufällig aus, sind die relativen Häufigkeiten genau die gemeinsame Wahrscheinlichkeitsfunktion der beiden Merkmale. Das bekannteste Beispiel ist die Konfusionsmatrix eines Klassifikators.   Eine Konfusionsmatrix mit drei Klassen   Ein Klassifikator ordnet Supporttickets einer der Abteilungen Rechnung (R), Technik (T) oder Sonstiges (S) zu. Auf 1000 Tickets mit bekannter Abteilung ergab sich die folgende Kreuztabelle; die Zeilen sind die wahre Abteilung , die Spalten die vorhergesagte eines zufällig gewählten Tickets.      \\  R T S    R  240 20 40    T  30 330 40    S  50 30 220       Bestimmen Sie die Randverteilungen von und . Was beschreiben sie?    Mit welcher Wahrscheinlichkeit wird ein Ticket richtig zugeordnet?    Wie viel Prozent der Technik-Tickets landen in der Abteilung Rechnung, und wie viel Prozent der Tickets, die dort landen, gehören eigentlich zur Technik?          Zeilensummen durch 1000: für R, T, S. Spaltensummen: . Die erste Randverteilung beschreibt, wie sich die Tickets tatsächlich verteilen, die zweite, wie der Klassifikator sie verteilt.    Richtig sind die Felder auf der Diagonale: .    Mit der bedingten Wahrscheinlichkeit aus :  % der Technik-Tickets werden falsch an die Rechnung geschickt, und  % der Tickets in der Rechnungsabteilung gehören zur Technik.     Die beiden Randverteilungen sind fast gleich, und doch landet mehr als jedes fünfte Ticket falsch. Wer nur prüft, ob der Klassifikator die Tickets im richtigen Verhältnis verteilt, prüft die Ränder, nicht die Treffer. Die Fehler stehen außerhalb der Diagonale, und welche dort am häufigsten sind, sagt, wo sich ein besseres Modell lohnt: Hier gehen 50 Tickets aus Sonstiges fälschlich an die Rechnung.    Alles bisher Gesagte gilt genauso für mehr als zwei Zufallsvariablen. Die gemeinsame Wahrscheinlichkeitsfunktion von , und ist , und die gemeinsame Verteilung von und erhält man als Rand, indem man über alle Werte von summiert. Dass dabei Information verloren geht, kann zu einem bekannten Fehlschluss führen.   Zwei Rechenzentren und das Simpson-Paradoxon  Simpson-Paradoxon   Ein Dienst läuft in zwei Rechenzentren A und B. Eine Anfrage gilt als schnell, wenn sie in weniger als 100 ms beantwortet wird. Ein Tag Protokoll ergibt, aufgeschlüsselt nach Lese- und Schreibanfragen:       A: Anfragen A: schnell  B: Anfragen B: schnell    lesen  200 190 800 720    schreiben  800 600 200 140       Welcher Anteil der Anfragen ist in A schnell, welcher in B?    Vergleichen Sie die Anteile getrennt für Lese- und Schreibanfragen.    Welches Rechenzentrum ist schneller? Wie vergleicht man fair?       Sei das Rechenzentrum, der Typ und der Indikator für schnell einer zufällig gewählten Anfrage. Aus der Tabelle liest man die gemeinsame Verteilung von in Anzahlen ab: Die Zahl der langsamen Anfragen ist jeweils die Zahl der Anfragen minus die der schnellen.   Summiert man über , bleibt die gemeinsame Verteilung von und : In A sind von 1000 Anfragen schnell, also 79 %, in B , also 86 %.    Lesen: A 95 %, B 90 %. Schreiben: A 75 %, B 70 %. Bei jedem Typ ist A schneller.    A ist schneller. B wirkt nur besser, weil es vor allem Leseanfragen bekommt, die überall schnell sind, während A vier Fünftel Schreibanfragen beantwortet. Fair vergleicht man bei derselben Mischung, etwa halb und halb, wie es der Last beider Rechenzentren zusammen entspricht: A erreicht dann  %, B  %.     Dass sich ein Vergleich umkehrt, wenn man über eine dritte Größe summiert, heißt Simpson-Paradoxon . Der Rand über vermischt zwei Dinge, die Qualität der Rechenzentren und die Zusammensetzung ihrer Last. Wer Kennzahlen aus einem Dashboard vergleicht, sollte deshalb fragen, über welche Merkmale dort schon summiert wurde.      Gemeinsame Dichten und Randdichten  Für stetige Zufallsvariablen ist jede Wahrscheinlichkeit null, und eine Tabelle hilft nicht weiter. An ihre Stelle tritt, wie in , eine Dichte, jetzt aber über der Ebene: Man stellt sich das Paar als zufälligen Punkt vor und die Dichte als Gebirge über den möglichen Lagen. Die Wahrscheinlichkeit, dass der Punkt in einem Gebiet landet, ist das Volumen unter dem Gebirge über diesem Gebiet.   Gemeinsame Dichte  gemeinsame Dichte  Dichte gemeinsame   Seien und Zufallsvariablen auf demselben Wahrscheinlichkeitsraum. Eine Funktion heißt gemeinsame Dichte von und , wenn für jedes Gebiet  gilt. Mit Gebiet sind hier Rechtecke, Dreiecke, Kreisscheiben und allgemein alle Mengen gemeint, über die sich integrieren lässt.    Mit folgt : Das ganze Gebirge hat das Volumen 1. Umgekehrt ist jede Funktion mit Gesamtvolumen 1 die gemeinsame Dichte eines zufälligen Punktes. Der einfachste Fall ist die Gleichverteilung auf einem Gebiet Gleichverteilung auf einem Gebiet  mit Flächeninhalt : Die Dichte ist auf und 0 sonst, und die Wahrscheinlichkeit eines Teilgebiets ist sein Anteil an der Fläche von . So war schon die Lage der Kundschaft in beschrieben.   Integrieren über ein Gebiet  Ein Doppelintegral rechnet man als zwei gewöhnliche Integrale nacheinander aus. Liegt das Gebiet zwischen und und für jedes feste zwischen einer unteren Kurve und einer oberen , so ist Das innere Integral sammelt das Volumen über einem schmalen senkrechten Streifen bei , das äußere addiert die Streifen. Ebenso kann man das Gebiet in waagerechte Streifen zerlegen und zuerst über integrieren. Links steht nur für das Integral über die Fläche; im iterierten Integral rechts gehört das innere Differential zum inneren Integral. Dass beide Reihenfolgen dasselbe ergeben, sagt der Satz von Fubini Satz von Fubini Fubini, Satz von , den wir ohne Beweis benutzen. Die Grenzen liest man an einer Skizze des Gebiets ab ( ). Sie ist der wichtigste Schritt: Die meisten Fehler entstehen nicht beim Integrieren, sondern bei den Grenzen.    Das Dreieck zerlegt in senkrechte Streifen (bei festem läuft von bis 1) oder in waagerechte (bei festem läuft von 0 bis ).   Ein Dreieck im Einheitsquadrat mit einem senkrechten und einem waagerechten Streifen   Ein Einheitsquadrat mit Achsen und . Grau gefüllt ist das Dreieck oberhalb der Diagonale mit den Ecken , und . Ein dunkler senkrechter Streifen bei reicht von der Diagonale bis zur oberen Kante, ein dunkler waagerechter Streifen bei reicht von der -Achse bis zur Diagonale.      Aus der gemeinsamen Dichte erhält man die Dichten der einzelnen Zufallsvariablen, indem man die jeweils andere herausintegriert . Das ist das stetige Gegenstück zum Summieren über eine Zeile.   Randdichten  Randdichte   Haben und die gemeinsame Dichte , so sind und stetig mit den Dichten Sie heißen in diesem Zusammenhang Randdichten .    Das Ereignis ist für den Streifen . Integriert man zuerst über , ist Nach ist die Klammer eine Dichte von . Für nimmt man den waagerechten Streifen.    Ist die Dichte nur auf einem Teil der Ebene positiv, laufen die Integrale nur über diesen Teil, und ihre Grenzen hängen dann oft vom festen Wert der anderen Variablen ab.   Erste und letzte Anfrage   Ein Dienst sammelt Anfragen und verarbeitet sie gebündelt. In einer Sekunde gehen drei Anfragen ein, jede zu einem auf gleichverteilten Zeitpunkt und unabhängig voneinander. Sei der Zeitpunkt der ersten, der der letzten Anfrage. Wie zeigen wird, haben sie die gemeinsame Dichte und 0 sonst.  Prüfen Sie, dass eine Dichte ist.  Bestimmen Sie die Randdichten.   Mit welcher Wahrscheinlichkeit kommt die erste Anfrage in der ersten, die letzte in der zweiten Hälfte der Sekunde?       Das Gebiet, auf dem positiv ist, ist das Dreieck aus .    , und mit senkrechten Streifen ist     Das innere Integral aus (a) ist schon die Randdichte von : Auf ist . Für hält man fest; dann läuft von 0 bis : Außerhalb von sind beide 0.    Das Ereignis ist das Quadrat , das ganz im Dreieck liegt:      Zwei Proben ohne Integral: ist die Dichte des Maximums dreier unabhängiger gleichverteilter Zeitpunkte, denn nach ist . Und das Gegenereignis von (c) heißt, dass alle drei Anfragen in dieselbe Hälfte fallen, mit Wahrscheinlichkeit . In drei von vier Sekunden überspannt ein Bündel also die Mitte der Sekunde.     Die gemeinsame Dichte aus als Fläche über dem Einheitsquadrat. Unterhalb der Diagonale ist sie 0, darüber steigt sie zur Ecke hin an: Am wahrscheinlichsten liegen erste und letzte Anfrage weit auseinander.   Eine schräge Ebene über einem Dreieck, daneben eine flache Fläche auf Höhe 0   Eine dreidimensionale Darstellung über dem Einheitsquadrat in der - -Ebene. Über dem Dreieck mit ist die Dichte eine schräge Ebene, die auf der Diagonale bei 0 beginnt und zur Ecke , auf die Höhe 6 ansteigt. Über dem übrigen Dreieck liegt die Fläche flach auf Höhe 0.      Die folgende Zelle erzeugt viele solcher Sekunden und zählt, wie oft die erste Anfrage vor und die letzte nach der Mitte kommt. Zum Vergleich schätzt sie auch .   import random # Erste und letzte von drei Anfragen in einer Sekunde. # Probieren Sie n = 100, 1000, 100000. n = 1000 sekunden = [[random.random() for _ in range(3)] for _ in range(n)] paare = [(min(t), max(t)) for t in sekunden] mitte = sum([1 for x, y in paare if x < 0.5 < y]) \/ n spaet = sum([1 for x, y in paare if y > 0.9]) \/ n print(\"Anteil mit X < 1\/2 < Y: %.4f (exakt 0.7500)\" % mitte) print(\"Anteil mit Y > 0.9: %.4f (exakt %.4f)\" % (spaet, 1 - 0.9 ** 3))   Gleichverteilungen auf Gebieten kommen in der Technik oft vor, etwa als Modell für die Lage eines Fehlers auf einer Fläche. Dass die einzelnen Koordinaten dann nicht gleichverteilt sein müssen, zeigt das nächste Beispiel.   Defekte auf einem Wafer   Ein Inspektionssystem erfasst die Lage von Defekten auf einem kreisrunden Wafer mit Radius 10 cm, gemessen vom Mittelpunkt aus. Die Defekte seien gleichmäßig über die Fläche verteilt.  Geben Sie die gemeinsame Dichte von und an.   Bestimmen Sie die Randdichte von . Ist auf gleichverteilt?    Zeigen Sie mit dem Ereignis , dass und nicht unabhängig sind.          Der Wafer ist die Kreisscheibe mit der Fläche . Also ist auf der Scheibe und 0 außerhalb.    Bei festem mit läuft von bis , also Das ist die Länge der Sehne bei , geteilt durch die Fläche. Gleichverteilt ist nicht: In der Mitte ist , bei nur , während eine Gleichverteilung überall hätte ( ).    Für und ist : Das Gebiet liegt ganz außerhalb des Wafers, also ist . Dagegen sind und positiv, weil die Randdichten auf bzw. positiv sind. Wären und unabhängig, müsste nach  sein.     Wer die -Koordinaten aller Defekte in einem Histogramm aufträgt, sieht einen Buckel in der Mitte, auch wenn die Defekte völlig gleichmäßig verteilt sind. Das ist reine Geometrie: In der Mitte sind die Sehnen des Wafers länger. Ein Hinweis auf ein Problem in der Mitte des Wafers wäre erst eine Abweichung von der Form . Teil (c) zeigt außerdem, dass und zusammenhängen, obwohl kein Mechanismus sie verbindet; der runde Rand genügt: Ein Defekt weit oben kann nicht zugleich weit rechts liegen.     Links der Wafer mit der Sehne bei , rechts die Randdichte von (durchgezogen) im Vergleich zur Gleichverteilung auf (gestrichelt).   Ein Kreis mit senkrechter Sehne, daneben eine Halbellipse über einer gestrichelten waagerechten Linie   Links ein Kreis mit Radius 10 um den Ursprung, darin eine dicke senkrechte Sehne bei von bis . Rechts ein Diagramm über von bis 10: Die Randdichte ist eine Halbellipse mit Höchstwert etwa 0,064 bei 0, die an den Rändern auf 0 fällt. Eine gestrichelte waagerechte Linie auf Höhe 0,05 zeigt die Gleichverteilung; sie liegt in der Mitte unter, an den Rändern über der Halbellipse.        Die gemeinsame Verteilungsfunktion  Tabellen gibt es nur für diskrete Zufallsvariablen, gemeinsame Dichten nur für manche stetigen; dass zwei stetige Zufallsvariablen keine gemeinsame Dichte haben müssen, wird zeigen. Wie für eine einzelne Zufallsvariable gibt es auch für ein Paar eine Beschreibung, die immer existiert.   Gemeinsame Verteilungsfunktion  Verteilungsfunktion gemeinsame  gemeinsame Verteilungsfunktion   Die gemeinsame Verteilungsfunktion zweier Zufallsvariablen und ist     Sie stand schon in : Dort verlangte die Unabhängigkeit, dass sie das Produkt ist.  Teil (3) des folgenden Satzes benutzt partielle Ableitungen partielle Ableitung . ist die Ableitung nach , bei der man wie eine Konstante behandelt, und entsteht, wenn man nacheinander nach und nach ableitet. Für etwa ist und . Bei den Funktionen dieses Buchs spielt die Reihenfolge der beiden Ableitungen keine Rolle, solange sie sich in beiden Reihenfolgen bilden lassen.   Rechnen mit der gemeinsamen Verteilungsfunktion   Sei .   Für und ist     Die Ränder sind Grenzwerte: und .    Haben und eine gemeinsame Dichte, so ist und an jeder Stelle, an der stetig ist und sich die beiden Ableitungen bilden lassen, gilt .       (1) Das ist die Rechnung aus dem Beweis von , nur ohne das Produkt am Ende: Vom Quadranten nimmt man die Quadranten bei und weg und gibt ihren doppelt abgezogenen Schnitt bei zurück.  (2) ist die disjunkte Vereinigung von und den Ereignissen für Wie im Beweis von ergibt das dritte Axiom eine Teleskopsumme: Weil in wächst, ist das auch der Grenzwert für .  (3) Die erste Formel ist die Definition der gemeinsamen Dichte mit dem Quadranten . Leitet man sie nach ab, liefert der Hauptsatz der Differential- und Integralrechnung das innere Integral an der Stelle , also ; leitet man das nach ab, liefert er , wie in für eine Variable. Beide Schritte brauchen, dass der jeweilige Integrand an der Stelle stetig ist. Springt er dort, lässt sich die Ableitung nicht bilden. Bei den Dichten dieses Buchs gibt es solche Sprünge nur am Rand des Gebiets, auf dem die Dichte positiv ist, und oberhalb von Randstücken, die senkrecht verlaufen.     Erste und letzte Anfrage: woher die Dichte kommt   In der Situation von :   Bestimmen Sie für . Zerlegen Sie dazu danach, ob ist oder nicht. Was gilt für ?   Leiten Sie daraus die gemeinsame Dichte her.   Bestimmen Sie die Randverteilungsfunktionen und .    Mit welcher Wahrscheinlichkeit kommt die erste Anfrage im zweiten, die letzte im dritten Viertel der Sekunde, ist also und ? Rechnen Sie mit .           heißt, dass alle drei Anfragen bis kommen; wegen der Unabhängigkeit hat das die Wahrscheinlichkeit . heißt, dass alle drei in fallen, mit Wahrscheinlichkeit . Also ist Für folgt schon aus , also ist dort .    Für ist und . Für hängt nicht von ab, die Ableitung ist 0. Das ist die Dichte aus .    Für ist , denn für ändert sich nicht mehr, und . Ableiten ergibt die Randdichten aus . Weiter ist wie in , Teil (c), diesmal ohne Integral.    Gesucht ist die Wahrscheinlichkeit des Rechtecks . An seinen vier Ecken ist , dort gilt also die Formel aus (a), zum Beispiel . Mit ist nach , Teil (1), In knapp jeder zehnten Sekunde fallen also alle drei Anfragen in die mittlere halbe Sekunde und überspannen dabei die Mitte der Sekunde. Das Doppelintegral der Dichte über ergibt dasselbe; mit genügen vier Funktionswerte.     Wie in war die Verteilungsfunktion leichter zu bekommen als die Dichte, weil sich ihre Ereignisse direkt in Worte über die drei Anfragen übersetzen lassen. Die Dichte folgt dann durch Ableiten.      Unabhängigkeit und das Produktkriterium  Unabhängige Zufallsvariablen kennen wir aus zwei Definitionen. verlangt für diskrete Zufallsvariablen , in der Sprache dieses Abschnitts also Die Tabelle ist dann das Produkt ihrer Ränder: Jedes Feld ist Zeilensumme mal Spaltensumme, und alle Zeilen sind zueinander proportional. Bei zwei getrennt geworfenen Würfeln ist das so, bei Minimum und Maximum in nicht: Dort ist , aber .   stellt die Bedingung an die gemeinsame Verteilungsfunktion. Für Zufallsvariablen mit gemeinsamer Dichte wird daraus eine Bedingung an die Dichte.   Produktkriterium für Dichten  Produktkriterium   Seien und stetig mit den Dichten und .   Sind und unabhängig, so ist eine gemeinsame Dichte von und .    Ist umgekehrt eine gemeinsame Dichte von und , so sind sie unabhängig.   Kurz: Zwei stetige Zufallsvariablen sind genau dann unabhängig, wenn das Produkt ihrer Randdichten eine gemeinsame Dichte ist.    (2) Integriert man die Produktdichte über den Quadranten , zerfällt das Doppelintegral: Das ist .  (1) Für ein Rechteck ist nach  Die Produktdichte liefert also für jedes Rechteck die richtige Wahrscheinlichkeit. Jedes Gebiet lässt sich beliebig genau durch Vereinigungen kleiner, disjunkter Rechtecke annähern, wie bei den Treppenfunktionen nach . Den Grenzübergang führen wir nicht aus.    Teil (1) ist die Richtung, die man beim Modellieren braucht: Wer zwei Größen für unabhängig hält und ihre Verteilungen kennt, bekommt die gemeinsame Dichte als Produkt geschenkt. Teil (2) prüft eine gegebene gemeinsame Dichte. Dafür muss man die Randdichten nicht immer ausrechnen.   Faktorisierung   Lässt sich eine gemeinsame Dichte für alle  als mit Funktionen schreiben, so sind und unabhängig, und die Randdichten sind und .    Nach ist und , und das Gesamtvolumen 1 heißt . Also ist , und Teil (2) des Satzes liefert die Unabhängigkeit.    Das für alle ist ernst gemeint: Die Grenzen des Gebiets, auf dem die Dichte positiv ist, gehören zur Formel. Ist auf einem Intervall und auf einem Intervall positiv, so ist das Produkt auf dem ganzen Rechteck positiv. Eine gemeinsame Dichte, die nur auf einem Dreieck oder einer Kreisscheibe positiv ist, kann deshalb nie zu unabhängigen Zufallsvariablen gehören, wie einfach ihre Formel auch aussieht. Das war der Grund für die Abhängigkeit in .   Produkt oder nicht   Entscheiden Sie, ob und unabhängig sind, und bestimmen Sie die Randdichten.    für , , sonst 0.     für , , , sonst 0.          Mit auf und auf , jeweils 0 sonst, ist auf ganz , denn das Quadrat ist ein Rechteck. Also sind und unabhängig mit und auf .    Die Formel ist ein Produkt, das Gebiet aber ein Dreieck. Die Randdichte ist und ebenso . An der Stelle außerhalb des Dreiecks ist , aber . In einer Umgebung dieser Stelle gilt dasselbe, also ist das Produkt keine gemeinsame Dichte, und und sind abhängig.     In (b) ist die Abhängigkeit anschaulich klar: Ist fast 1, muss fast 0 sein. Wer nur auf die Formel schaut und das Gebiet vergisst, kommt zum falschen Schluss.    Die Rechentechnik aus und Teil (1) des Produktkriteriums zusammen beantworten eine Frage, die in Technik und Logistik ständig auftaucht: Welcher von zwei zufälligen Zeitpunkten kommt zuerst?   Vor dem Regen zurück?   Ein Lieferroboter übernimmt einen Auftrag, dessen Dauer (in Stunden) auf gleichverteilt ist. Bei Regen muss er die Fahrt abbrechen. Die Zeit bis zum nächsten Regenschauer sei exponentialverteilt mit Erwartungswert 2 Stunden und unabhängig von .  Geben Sie die gemeinsame Dichte von und an.   Mit welcher Wahrscheinlichkeit schafft der Roboter den Auftrag, bevor es regnet?    Für die Rückfahrt ins Depot braucht er danach eine Stunde. Mit welcher Wahrscheinlichkeit kommt er vor dem Regen zurück?          Nach , Teil (1), ist für und , sonst 0.    Gesucht ist , das Volumen über dem Gebiet oberhalb der Diagonale. Bei festem läuft von bis . Den Faktor zieht man vor das innere Integral; übrig bleibt . Also ist     Gesucht ist , das Gebiet oberhalb der um 1 nach oben verschobenen Diagonale. Bei festem bleibt nach dem Herausziehen von jetzt , also      Mehr als jeder dritte Auftrag wird vom Regen unterbrochen, und nur gut jede dritte Fahrt endet trocken im Depot. Wer solche Touren plant, braucht die gemeinsame Verteilung von Fahrzeit und Wetter, nicht nur die beiden Mittelwerte: Im Mittel dauert ein Auftrag eine Stunde, und im Mittel regnet es erst nach zwei.    Die Rechnung in , Teil (b), hat eine allgemeine Form. Für unabhängige und mit Dichten ist Man hält den Wert von fest, fragt, wie wahrscheinlich darüber liegt, und mittelt über . Das ist die totale Wahrscheinlichkeit, mit einem Integral statt einer Summe.  Ohne die Unabhängigkeit hätten wir im Beispiel schon in (a) nicht weiterrechnen können. Die Randverteilungen legen die gemeinsame Verteilung im Allgemeinen nicht fest, das galt schon für Tabellen, und es gilt genauso für Dichten. Die folgende Zelle zeigt die Folgen an zwei Servern, deren Auslastungen jede für sich auf gleichverteilt sind. Sie schätzt die Wahrscheinlichkeit, dass beide zugleich über 80 % ausgelastet sind, für drei Arten des Zusammenhangs: unabhängig, im Gleichschritt ( ) und gegenläufig ( ). Die beiden letzten haben keine gemeinsame Dichte, weil der Punkt auf einer Strecke liegt, die keine Fläche hat; ihre gemeinsamen Verteilungen gibt es trotzdem.   import random # Auslastungen X, Y zweier Server, jede für sich gleichverteilt auf [0, 1]. # Probieren Sie kopplung = \"unabhaengig\", \"gleichschritt\", \"gegenlaeufig\". kopplung = \"unabhaengig\" n = 20000 xs = [random.random() for _ in range(n)] if kopplung == \"gleichschritt\": ys = xs elif kopplung == \"gegenlaeufig\": ys = [1 - x for x in xs] else: ys = [random.random() for _ in range(n)] paare = list(zip(xs, ys)) beide = [1 for x, y in paare if x > 0.8 and y > 0.8] print(\"P(X > 0.8) ~ %.3f\" % (sum([1 for x in xs if x > 0.8]) \/ n)) print(\"P(Y > 0.8) ~ %.3f\" % (sum([1 for y in ys if y > 0.8]) \/ n)) print(\"P(X > 0.8, Y > 0.8) ~ %.3f\" % (sum(beide) \/ n))   Die Ränder sind in allen drei Fällen gleich, die gemeinsame Überlastung aber nicht: etwa 4 % bei Unabhängigkeit, 20 % im Gleichschritt, 0 bei gegenläufiger Last. Wer das Risiko zweier Systeme aus ihren Einzelrisiken abschätzt, trifft stillschweigend eine Annahme über ihren Zusammenhang.  Alles gilt entsprechend für mehr als zwei Zufallsvariablen. Eine gemeinsame Dichte von ist eine Funktion , deren Integral über ein Gebiet im die Wahrscheinlichkeit angibt, dass darin liegt, und die Zufallsvariablen sind genau dann unabhängig, wenn eine gemeinsame Dichte ist. Aus dem Produkt folgt außerdem für alle Intervalle und Vereinigungen von Intervallen und , weil das Integral über zerfällt. Insbesondere sind mit und auch und unabhängig, sobald sich die Ereignisse und als und mit solchen Mengen und schreiben lassen, etwa und .  Der wichtigste Fall in der Datenanalyse ist die Stichprobe Stichprobe unabhängig und identisch verteilt : Messungen , die unabhängig sind und dieselbe Dichte haben, kurz ( unabhängig und identisch verteilt ). Ihre gemeinsame Dichte ist Die Annahme, die Daten seien unabhängig und identisch verteilt, steht hinter fast jedem Verfahren des maschinellen Lernens. Sie ist eine Aussage über eine gemeinsame Verteilung, und zwar eine sehr starke. Sie ist verletzt, wenn mehrere Datensätze von derselben Person stammen, wenn aufeinanderfolgende Messungen einer Zeitreihe zusammenhängen oder wenn dieselben Fälle sowohl in den Trainings- als auch in den Testdaten landen. Fehlerabschätzungen, die auf ihr beruhen, sind dann zu optimistisch.   Wie gut passt ein Modell zu drei Messwerten?   Drei gemessene Antwortzeiten eines Dienstes betragen 0,5; 1,2 und 0,3 Sekunden. Als Modell nehmen wir an, dass sie unabhängig und alle -verteilt sind.  Stellen Sie die gemeinsame Dichte der drei Antwortzeiten auf.   Werten Sie sie an den gemessenen Werten für , und aus.   Welche Eigenschaft der Daten geht in das Ergebnis ein?         Für ist sonst 0.    Die Summe der Messwerte ist 2,0, also ist die gemeinsame Dichte an den Daten : für etwa 0,135, für etwa 0,168 und für etwa 0,147.    Nur die Summe der Messwerte. Drei andere Antwortzeiten mit derselben Summe, etwa 0,7; 0,7 und 0,6, ergäben genau dieselben Werte.     Hohe gemeinsame Dichte an den beobachteten Daten heißt: Das Modell hätte diese Daten eher hervorgebracht. Unter den drei Parametern erklärt die Messungen am besten, also eine mittlere Antwortzeit von  s, und das ist genau der Mittelwert der Daten. Die gemeinsame Dichte als Funktion des Parameters heißt Likelihood , und den besten Parameter systematisch zu finden ist der Gegenstand von .      Erwartungswerte von Funktionen zweier Zufallsvariablen  Für diskrete Zufallsvariablen haben wir in , Teil (2), als Doppelsumme über die gemeinsame Wahrscheinlichkeitsfunktion berechnet. Mit einer gemeinsamen Dichte wird daraus ein Doppelintegral.   Erwartungswert einer Funktion zweier Zufallsvariablen (Transformationssatz)  Erwartungswert einer Funktion zweier Zufallsvariablen  Transformationssatz für zwei Zufallsvariablen   Haben und die gemeinsame Dichte und ist stückweise stetig, so ist sofern das Integral mit an Stelle von endlich ist.    Wie bei geben wir keinen vollständigen Beweis. Für eine Funktion , die auf endlich vielen disjunkten Gebieten konstant gleich ist, ist diskret, und ist genau das Doppelintegral. Jede stückweise stetige Funktion lässt sich durch solche Funktionen annähern. Mit dem Satz lösen wir jetzt die Versprechen aus und ein.   Summen und Produkte, stetiger Fall   Seien und Zufallsvariablen mit gemeinsamer Dichte, deren Erwartungswerte existieren.  .   Sind und unabhängig, so ist für stückweise stetige und , für die beide Seiten existieren, insbesondere .    Sind und unabhängig und existieren ihre Varianzen, so ist .       (1) Mit und den Randdichten aus :   (2) Nach ist eine gemeinsame Dichte. Welche gemeinsame Dichte man in einsetzt, ist gleichgültig, weil jede dieselben Wahrscheinlichkeiten und damit dieselben Erwartungswerte liefert. Mit dem Produkt zerfällt das Doppelintegral:   (3) Wie im Beweis von , Teil (2): Mit und ist nach (1) . Man multipliziert aus; weil der Erwartungswert nach ein Integral ist, darf man ihn gliedweise bilden: und nach (2) ist der letzte Erwartungswert .    Die Voraussetzung einer gemeinsamen Dichte ist für unabhängige stetige Zufallsvariablen immer erfüllt, nach , Teil (1). Die Teile (2) und (3) gelten also für alle unabhängigen stetigen und , wie in versprochen. Für unabhängige stetige Zufallsvariablen rechnet man ebenso mit ihrer gemeinsamen Dichte, dem Produkt der Randdichten: Der Erwartungswert der Summe ist die Summe der Erwartungswerte, und multipliziert man das Quadrat der zentrierten Summe aus, hat jedes gemischte Glied wie in (2) den Erwartungswert 0. Damit sind die Regeln für Produkte und Summen, die für diskrete Zufallsvariablen bewiesen hat, auch für unabhängige stetige bewiesen, ebenso : Der Mittelwert aus unabhängigen Messungen mit Standardabweichung hat die Standardabweichung , ob die Messungen nun diskret oder stetig sind.  Teil (1) braucht keine Unabhängigkeit, nur die gemeinsame Dichte. Die Teile (2) und (3) setzen die Unabhängigkeit voraus. Was bei abhängigen Zufallsvariablen an ihre Stelle tritt, zeigt . Dort wird der Ausdruck , den schon Kovarianz genannt hat, zum Maß für den Zusammenhang zweier Zufallsvariablen.   heißt gemeinsamer Erwartungswert gemeinsamer Erwartungswert Erwartungswert gemeinsamer von und ; in der Signalverarbeitung nennt man ihn auch die Korrelation von und . Mit dem Korrelationskoeffizienten, den einführt, ist er nicht zu verwechseln.   Wie lange wartet die erste Anfrage?   In der Situation von wird das Bündel verarbeitet, sobald die letzte Anfrage da ist. Die erste Anfrage wartet also .   Bestimmen Sie einmal über und , einmal als Doppelintegral.   Vergleichen Sie mit .   Bestimmen Sie und vergleichen Sie mit .          Mit den Randdichten und ist und , also nach , Teil (1), mit statt : . Als Doppelintegral, mit :      dagegen . Die Produktregel gilt hier nicht, wie zu erwarten: und sind abhängig.     , also . Aus den Randdichten ist und , also und . Die Varianz der Differenz ist kleiner.     Im Mittel wartet die erste Anfrage eine halbe Sekunde. Den Erwartungswert durfte man über die Ränder ausrechnen, die Varianz nicht: Kommt die erste Anfrage spät, kommt auch die letzte spät, die beiden schwanken also teilweise gemeinsam, und in der Differenz hebt sich das auf. Mit der Formel für unabhängige Zufallsvariablen hätte man die Varianz der Wartezeit um die Hälfte überschätzt.    Das wichtigste Modell mit unabhängigen Summanden ist Signal plus Rauschen Signal plus Rauschen : Ein Messwert ist die gesuchte Größe plus ein Messfehler, der mit ihr nichts zu tun hat.   Mitteln über mehrere Sensoren   Die Temperatur in einer Halle schwankt im Lauf des Tages mit Erwartungswert 20  C und Standardabweichung 2  C. Ein Sensor zeigt an, wobei der Messfehler den Erwartungswert 0 und die Standardabweichung 1  C hat. Temperatur und Messfehler seien stetige Zufallsvariablen, und und seien unabhängig.   Bestimmen Sie Erwartungswert und Varianz der Anzeige. Welcher Anteil ihrer Varianz stammt von der Temperatur selbst?    Vier Sensoren mit Messfehlern dieser Art messen gleichzeitig, wobei unabhängig sind, und man mittelt ihre Anzeigen. Welche Varianz hat der Mittelwert, und welche sein Messfehler?    Was ändert sich, wenn man über sehr viele Sensoren mittelt?             C und nach , Teil (3), , also eine Standardabweichung von etwa 2,24  C. Der Anteil der Temperatur an der Varianz ist  %.    Der Mittelwert ist mit . Nach ist , und weil als Funktion von unabhängig von ist, hat der Mittelwert die Varianz . Sein Messfehler hat die Varianz , also die Standardabweichung   C.    Bei Sensoren ist die Varianz des Mittelwerts , die des Messfehlers . Der Messfehler verschwindet, die Varianz des Mittelwerts sinkt aber nie unter 4.     Mitteln beseitigt das Rauschen, nicht die Schwankung des Signals. Mehr Sensoren messen die momentane Temperatur immer genauer, aber die Anzeige schwankt weiter, weil die Temperatur selbst schwankt. Wer aus der Streuung der Anzeigen auf die Güte der Sensoren schließen will, muss beides trennen. Das Verhältnis der Varianzen von Signal und Rauschen, hier , heißt Signal-Rausch-Verhältnis Signal-Rausch-Verhältnis ; durch Mitteln über Sensoren steigt es auf .    Die Zelle simuliert die Sensoren und vergleicht die beobachteten Standardabweichungen mit und .   import random, math # Anzeige = Temperatur + Messfehler, gemittelt über k Sensoren. # Probieren Sie k = 1, 4, 25. k = 4 def ablesung(): x = random.gauss(20, 2) return (x, x + sum([random.gauss(0, 1) for _ in range(k)]) \/ k) werte = [ablesung() for _ in range(4000)] def streuung(liste): m = sum(liste) \/ len(liste) return math.sqrt(sum([(v - m) ** 2 for v in liste]) \/ len(liste)) print(\"Mittelwert der Sensoren: %.3f (Formel %.3f)\" % (streuung([a for x, a in werte]), math.sqrt(4 + 1 \/ k))) print(\"Messfehler: %.3f (Formel %.3f)\" % (streuung([a - x for x, a in werte]), 1 \/ math.sqrt(k)))     Zusammenfassung      Gemeinsame Wahrscheinlichkeitsfunktion. Für diskrete und ist , als Tabelle mit Summe 1. Die Wahrscheinlichkeit eines Ereignisses, das von beiden abhängt, ist die Summe der passenden Felder: . Eine Kreuztabelle relativer Häufigkeiten, etwa eine Konfusionsmatrix, ist genau das.     Gemeinsame Dichte. Haben und eine gemeinsame Dichte , so ist , das Volumen über , und das Gesamtvolumen ist 1. Bei der Gleichverteilung auf einem Gebiet ist die Wahrscheinlichkeit der Flächenanteil. Man rechnet das Doppelintegral als zwei Integrale nacheinander und liest die Grenzen an einer Skizze ab.     Randverteilungen.  (Zeilensumme, totale Wahrscheinlichkeit) und , ebenso für . Die Ränder legen die gemeinsame Verteilung im Allgemeinen nicht fest, und ein Vergleich über einen Rand kann sich gegenüber dem Vergleich in jeder Gruppe umkehren (Simpson-Paradoxon).     Gemeinsame Verteilungsfunktion.  . Rechtecke durch Ein- und Ausschließen: . Ränder als Grenzwert, , und , wo stetig ist und sich beide Ableitungen bilden lassen.     Unabhängigkeit. Diskret: für alle . Stetig: ist eine gemeinsame Dichte. Lässt sich auf ganz schreiben, sind und unabhängig. Ist die Dichte nur auf einem Dreieck oder einer Kreisscheibe positiv, sind sie abhängig, wie einfach die Formel auch aussieht. Eine Stichprobe hat die gemeinsame Dichte .     Welcher Wert kommt zuerst? Für unabhängige und ist : das Doppelintegral über das Gebiet oberhalb der Diagonale, innen über integriert.     Erwartungswerte.  . Wie im Diskreten gilt mit gemeinsamer Dichte , auch ohne Unabhängigkeit. Bei Unabhängigkeit gilt außerdem , insbesondere , und . Ohne Unabhängigkeit gelten die beiden letzten Regeln im Allgemeinen nicht.       Übungsaufgaben   Code-Review und Release   Sei die Zahl der schweren Fehler, die ein Code-Review in einer Änderung findet, und , wenn das Release danach verschoben wird, sonst . Die gemeinsame Wahrscheinlichkeitsfunktion ist      \\ 0 1   0 0,40 0,05  1 0,20 0,10  2 0,05 0,20     Bestimmen Sie die Randverteilungen und .   Mit welcher Wahrscheinlichkeit wird ein Release verschoben, wenn das Review mindestens einen schweren Fehler gefunden hat?   Sind und unabhängig?         Zeilensummen: , , ; Spaltensummen: , . .     .    Nein: , aber .        Eine Dichte auf einem Dreieck    und haben die gemeinsame Dichte für und 0 sonst.  Bestimmen Sie . Skizzieren Sie das Gebiet.  Bestimmen Sie die Randdichten.  Bestimmen Sie .   Bestimmen Sie , und . Gilt ?          Das Gebiet ist das Dreieck unterhalb der Diagonale. , also .     und , jeweils für Werte in .     .     , und . Dagegen ist : und sind abhängig, und die Produktregel gilt nicht.        Zwei Zufallszahlen    und seien unabhängig und beide auf gleichverteilt, etwa zwei Aufrufe von random.random() .  Geben Sie die gemeinsame Dichte an.  Bestimmen Sie .   Bestimmen Sie . Ein Taschenrechner ist erlaubt.          Nach : 1 auf dem Einheitsquadrat, 0 sonst. Wahrscheinlichkeiten sind Flächen.    Die Fläche unter der Parabel: .    Für ist für jedes ; für muss sein. Also         Eine gemeinsame Verteilungsfunktion    und haben die gemeinsame Verteilungsfunktion für und sonst.   Bestimmen Sie die Randverteilungsfunktionen. Welche Verteilungen sind das?   Sind und unabhängig? Bestimmen Sie die gemeinsame Dichte.   Bestimmen Sie mit Hilfe von .           und für : , .    Ja, denn , das ist . Die gemeinsame Dichte ist für , das Produkt der Randdichten.     .        "
},
{
  "id": "sec-gemeinsame-verteilungen-randverteilungen-2",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sec-gemeinsame-verteilungen-randverteilungen-2",
  "type": "Lernziele",
  "number": "4.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     die gemeinsame Verteilung zweier diskreter Zufallsvariablen als Tabelle aufstellen und daraus Wahrscheinlichkeiten von Ereignissen bestimmen, in denen beide vorkommen,    Randverteilungen aus einer gemeinsamen Wahrscheinlichkeitsfunktion oder Dichte bestimmen und begründen, warum die Ränder die gemeinsame Verteilung im Allgemeinen nicht festlegen,    die Wahrscheinlichkeit eines Gebiets wie als Doppelintegral über eine gemeinsame Dichte aufstellen und als zwei einfache Integrale nacheinander ausrechnen,    mit der gemeinsamen Verteilungsfunktion rechnen: Rechtecke über Ein- und Ausschließen, Ränder als Grenzwert,    die Unabhängigkeit zweier Zufallsvariablen am Produkt der Ränder prüfen und umgekehrt aus unabhängigen Rändern die gemeinsame Dichte bilden,    Erwartungswerte von Funktionen zweier Zufallsvariablen berechnen und die Regeln für , und samt ihren Voraussetzungen anwenden.    "
},
{
  "id": "def-gemeinsame-wahrscheinlichkeitsfunktion",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#def-gemeinsame-wahrscheinlichkeitsfunktion",
  "type": "Definition",
  "number": "4.1.1",
  "title": "Gemeinsame Wahrscheinlichkeitsfunktion.",
  "body": " Gemeinsame Wahrscheinlichkeitsfunktion  gemeinsame Wahrscheinlichkeitsfunktion  Wahrscheinlichkeitsfunktion gemeinsame  gemeinsame Verteilung  Verteilung gemeinsame   Seien und diskrete Zufallsvariablen auf demselben Wahrscheinlichkeitsraum. Die gemeinsame Wahrscheinlichkeitsfunktion von und ist Die Wahrscheinlichkeiten für Mengen bilden die gemeinsame Verteilung von und .   "
},
{
  "id": "thm-randverteilung-diskret",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#thm-randverteilung-diskret",
  "type": "Satz",
  "number": "4.1.2",
  "title": "Randverteilungen.",
  "body": " Randverteilungen  Randverteilung   Seien und diskret mit gemeinsamer Wahrscheinlichkeitsfunktion und Werten bzw. . Dann sind  und heißen in diesem Zusammenhang Randwahrscheinlichkeitsfunktionen Randwahrscheinlichkeitsfunktion , ihre Verteilungen die Randverteilungen .    Die Ereignisse bilden eine Zerlegung von . Wie im Beweis von ist die disjunkte Vereinigung der Mengen , also . Für vertauscht man die Rollen.   "
},
{
  "id": "ex-minimum-maximum-wuerfel",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-minimum-maximum-wuerfel",
  "type": "Beispiel",
  "number": "4.1.3",
  "title": "Minimum und Maximum zweier Würfel.",
  "body": " Minimum und Maximum zweier Würfel   Zwei faire Würfel werden geworfen. Sei die kleinere, die größere der beiden Augenzahlen.  Stellen Sie die gemeinsame Wahrscheinlichkeitsfunktion von und auf.   Bestimmen Sie die Randverteilungen. Vergleichen Sie mit .    Mit welcher Wahrscheinlichkeit liegen die beiden Augenzahlen mindestens 3 auseinander, ist also ?       (a) Von den 36 gleich wahrscheinlichen Paaren führt als einziges auf . Für führen und auf , . ist unmöglich. Also ist für , für und 0 für . Die Tabelle zeigt , am Rand die Summen:       \\  1 2 3 4 5 6  Summe    1  1 2 2 2 2 2  11    2  0 1 2 2 2 2  9    3  0 0 1 2 2 2  7    4  0 0 0 1 2 2  5    5  0 0 0 0 1 2  3    6  0 0 0 0 0 1  1    Summe  1 3 5 7 9 11  36    (b) Die Zeilensummen ergeben , die Spaltensummen . Das ist die Wahrscheinlichkeitsfunktion aus , diesmal ohne den Umweg über die Verteilungsfunktion.  (c) gilt in den Feldern mit : drei, zwei und ein Feld, jedes mit . Also ist .  Die Randverteilungen allein hätten (c) nicht beantwortet: Dafür muss man wissen, welche Werte von und zusammen auftreten. Die Nullen unterhalb der Diagonale sagen zum Beispiel, dass ein großes Minimum nie zusammen mit einem kleinen Maximum auftritt.  Minimum und Maximum zweier Würfel ist das Beispiel der Vorlesung zur gemeinsamen Verteilung; die Folien zeigen dazu eine Abbildung aus Arens u. a. .   "
},
{
  "id": "sub-gemeinsame-wahrscheinlichkeitsfunktion-10",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-gemeinsame-wahrscheinlichkeitsfunktion-10",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Kreuztabelle "
},
{
  "id": "ex-konfusionsmatrix-drei-klassen",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-konfusionsmatrix-drei-klassen",
  "type": "Beispiel",
  "number": "4.1.4",
  "title": "Eine Konfusionsmatrix mit drei Klassen.",
  "body": " Eine Konfusionsmatrix mit drei Klassen   Ein Klassifikator ordnet Supporttickets einer der Abteilungen Rechnung (R), Technik (T) oder Sonstiges (S) zu. Auf 1000 Tickets mit bekannter Abteilung ergab sich die folgende Kreuztabelle; die Zeilen sind die wahre Abteilung , die Spalten die vorhergesagte eines zufällig gewählten Tickets.      \\  R T S    R  240 20 40    T  30 330 40    S  50 30 220       Bestimmen Sie die Randverteilungen von und . Was beschreiben sie?    Mit welcher Wahrscheinlichkeit wird ein Ticket richtig zugeordnet?    Wie viel Prozent der Technik-Tickets landen in der Abteilung Rechnung, und wie viel Prozent der Tickets, die dort landen, gehören eigentlich zur Technik?          Zeilensummen durch 1000: für R, T, S. Spaltensummen: . Die erste Randverteilung beschreibt, wie sich die Tickets tatsächlich verteilen, die zweite, wie der Klassifikator sie verteilt.    Richtig sind die Felder auf der Diagonale: .    Mit der bedingten Wahrscheinlichkeit aus :  % der Technik-Tickets werden falsch an die Rechnung geschickt, und  % der Tickets in der Rechnungsabteilung gehören zur Technik.     Die beiden Randverteilungen sind fast gleich, und doch landet mehr als jedes fünfte Ticket falsch. Wer nur prüft, ob der Klassifikator die Tickets im richtigen Verhältnis verteilt, prüft die Ränder, nicht die Treffer. Die Fehler stehen außerhalb der Diagonale, und welche dort am häufigsten sind, sagt, wo sich ein besseres Modell lohnt: Hier gehen 50 Tickets aus Sonstiges fälschlich an die Rechnung.   "
},
{
  "id": "ex-simpson-rechenzentren",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-simpson-rechenzentren",
  "type": "Beispiel",
  "number": "4.1.5",
  "title": "Zwei Rechenzentren und das Simpson-Paradoxon.",
  "body": " Zwei Rechenzentren und das Simpson-Paradoxon  Simpson-Paradoxon   Ein Dienst läuft in zwei Rechenzentren A und B. Eine Anfrage gilt als schnell, wenn sie in weniger als 100 ms beantwortet wird. Ein Tag Protokoll ergibt, aufgeschlüsselt nach Lese- und Schreibanfragen:       A: Anfragen A: schnell  B: Anfragen B: schnell    lesen  200 190 800 720    schreiben  800 600 200 140       Welcher Anteil der Anfragen ist in A schnell, welcher in B?    Vergleichen Sie die Anteile getrennt für Lese- und Schreibanfragen.    Welches Rechenzentrum ist schneller? Wie vergleicht man fair?       Sei das Rechenzentrum, der Typ und der Indikator für schnell einer zufällig gewählten Anfrage. Aus der Tabelle liest man die gemeinsame Verteilung von in Anzahlen ab: Die Zahl der langsamen Anfragen ist jeweils die Zahl der Anfragen minus die der schnellen.   Summiert man über , bleibt die gemeinsame Verteilung von und : In A sind von 1000 Anfragen schnell, also 79 %, in B , also 86 %.    Lesen: A 95 %, B 90 %. Schreiben: A 75 %, B 70 %. Bei jedem Typ ist A schneller.    A ist schneller. B wirkt nur besser, weil es vor allem Leseanfragen bekommt, die überall schnell sind, während A vier Fünftel Schreibanfragen beantwortet. Fair vergleicht man bei derselben Mischung, etwa halb und halb, wie es der Last beider Rechenzentren zusammen entspricht: A erreicht dann  %, B  %.     Dass sich ein Vergleich umkehrt, wenn man über eine dritte Größe summiert, heißt Simpson-Paradoxon . Der Rand über vermischt zwei Dinge, die Qualität der Rechenzentren und die Zusammensetzung ihrer Last. Wer Kennzahlen aus einem Dashboard vergleicht, sollte deshalb fragen, über welche Merkmale dort schon summiert wurde.   "
},
{
  "id": "def-gemeinsame-dichte",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#def-gemeinsame-dichte",
  "type": "Definition",
  "number": "4.1.6",
  "title": "Gemeinsame Dichte.",
  "body": " Gemeinsame Dichte  gemeinsame Dichte  Dichte gemeinsame   Seien und Zufallsvariablen auf demselben Wahrscheinlichkeitsraum. Eine Funktion heißt gemeinsame Dichte von und , wenn für jedes Gebiet  gilt. Mit Gebiet sind hier Rechtecke, Dreiecke, Kreisscheiben und allgemein alle Mengen gemeint, über die sich integrieren lässt.   "
},
{
  "id": "sub-gemeinsame-dichte-4",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-gemeinsame-dichte-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Gleichverteilung auf einem Gebiet "
},
{
  "id": "sub-gemeinsame-dichte-5-2",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-gemeinsame-dichte-5-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Satz von Fubini "
},
{
  "id": "fig-integrationsbereich",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#fig-integrationsbereich",
  "type": "Abbildung",
  "number": "4.1.7",
  "title": "",
  "body": " Das Dreieck zerlegt in senkrechte Streifen (bei festem läuft von bis 1) oder in waagerechte (bei festem läuft von 0 bis ).   Ein Dreieck im Einheitsquadrat mit einem senkrechten und einem waagerechten Streifen   Ein Einheitsquadrat mit Achsen und . Grau gefüllt ist das Dreieck oberhalb der Diagonale mit den Ecken , und . Ein dunkler senkrechter Streifen bei reicht von der Diagonale bis zur oberen Kante, ein dunkler waagerechter Streifen bei reicht von der -Achse bis zur Diagonale.     "
},
{
  "id": "thm-randdichte",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#thm-randdichte",
  "type": "Satz",
  "number": "4.1.8",
  "title": "Randdichten.",
  "body": " Randdichten  Randdichte   Haben und die gemeinsame Dichte , so sind und stetig mit den Dichten Sie heißen in diesem Zusammenhang Randdichten .    Das Ereignis ist für den Streifen . Integriert man zuerst über , ist Nach ist die Klammer eine Dichte von . Für nimmt man den waagerechten Streifen.   "
},
{
  "id": "ex-erste-letzte-anfrage",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-erste-letzte-anfrage",
  "type": "Beispiel",
  "number": "4.1.9",
  "title": "Erste und letzte Anfrage.",
  "body": " Erste und letzte Anfrage   Ein Dienst sammelt Anfragen und verarbeitet sie gebündelt. In einer Sekunde gehen drei Anfragen ein, jede zu einem auf gleichverteilten Zeitpunkt und unabhängig voneinander. Sei der Zeitpunkt der ersten, der der letzten Anfrage. Wie zeigen wird, haben sie die gemeinsame Dichte und 0 sonst.  Prüfen Sie, dass eine Dichte ist.  Bestimmen Sie die Randdichten.   Mit welcher Wahrscheinlichkeit kommt die erste Anfrage in der ersten, die letzte in der zweiten Hälfte der Sekunde?       Das Gebiet, auf dem positiv ist, ist das Dreieck aus .    , und mit senkrechten Streifen ist     Das innere Integral aus (a) ist schon die Randdichte von : Auf ist . Für hält man fest; dann läuft von 0 bis : Außerhalb von sind beide 0.    Das Ereignis ist das Quadrat , das ganz im Dreieck liegt:      Zwei Proben ohne Integral: ist die Dichte des Maximums dreier unabhängiger gleichverteilter Zeitpunkte, denn nach ist . Und das Gegenereignis von (c) heißt, dass alle drei Anfragen in dieselbe Hälfte fallen, mit Wahrscheinlichkeit . In drei von vier Sekunden überspannt ein Bündel also die Mitte der Sekunde.   "
},
{
  "id": "fig-dichte-erste-letzte",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#fig-dichte-erste-letzte",
  "type": "Abbildung",
  "number": "4.1.10",
  "title": "",
  "body": " Die gemeinsame Dichte aus als Fläche über dem Einheitsquadrat. Unterhalb der Diagonale ist sie 0, darüber steigt sie zur Ecke hin an: Am wahrscheinlichsten liegen erste und letzte Anfrage weit auseinander.   Eine schräge Ebene über einem Dreieck, daneben eine flache Fläche auf Höhe 0   Eine dreidimensionale Darstellung über dem Einheitsquadrat in der - -Ebene. Über dem Dreieck mit ist die Dichte eine schräge Ebene, die auf der Diagonale bei 0 beginnt und zur Ecke , auf die Höhe 6 ansteigt. Über dem übrigen Dreieck liegt die Fläche flach auf Höhe 0.     "
},
{
  "id": "ex-wafer-defekte",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-wafer-defekte",
  "type": "Beispiel",
  "number": "4.1.11",
  "title": "Defekte auf einem Wafer.",
  "body": " Defekte auf einem Wafer   Ein Inspektionssystem erfasst die Lage von Defekten auf einem kreisrunden Wafer mit Radius 10 cm, gemessen vom Mittelpunkt aus. Die Defekte seien gleichmäßig über die Fläche verteilt.  Geben Sie die gemeinsame Dichte von und an.   Bestimmen Sie die Randdichte von . Ist auf gleichverteilt?    Zeigen Sie mit dem Ereignis , dass und nicht unabhängig sind.          Der Wafer ist die Kreisscheibe mit der Fläche . Also ist auf der Scheibe und 0 außerhalb.    Bei festem mit läuft von bis , also Das ist die Länge der Sehne bei , geteilt durch die Fläche. Gleichverteilt ist nicht: In der Mitte ist , bei nur , während eine Gleichverteilung überall hätte ( ).    Für und ist : Das Gebiet liegt ganz außerhalb des Wafers, also ist . Dagegen sind und positiv, weil die Randdichten auf bzw. positiv sind. Wären und unabhängig, müsste nach  sein.     Wer die -Koordinaten aller Defekte in einem Histogramm aufträgt, sieht einen Buckel in der Mitte, auch wenn die Defekte völlig gleichmäßig verteilt sind. Das ist reine Geometrie: In der Mitte sind die Sehnen des Wafers länger. Ein Hinweis auf ein Problem in der Mitte des Wafers wäre erst eine Abweichung von der Form . Teil (c) zeigt außerdem, dass und zusammenhängen, obwohl kein Mechanismus sie verbindet; der runde Rand genügt: Ein Defekt weit oben kann nicht zugleich weit rechts liegen.   "
},
{
  "id": "fig-wafer-randdichte",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#fig-wafer-randdichte",
  "type": "Abbildung",
  "number": "4.1.12",
  "title": "",
  "body": " Links der Wafer mit der Sehne bei , rechts die Randdichte von (durchgezogen) im Vergleich zur Gleichverteilung auf (gestrichelt).   Ein Kreis mit senkrechter Sehne, daneben eine Halbellipse über einer gestrichelten waagerechten Linie   Links ein Kreis mit Radius 10 um den Ursprung, darin eine dicke senkrechte Sehne bei von bis . Rechts ein Diagramm über von bis 10: Die Randdichte ist eine Halbellipse mit Höchstwert etwa 0,064 bei 0, die an den Rändern auf 0 fällt. Eine gestrichelte waagerechte Linie auf Höhe 0,05 zeigt die Gleichverteilung; sie liegt in der Mitte unter, an den Rändern über der Halbellipse.     "
},
{
  "id": "def-gemeinsame-verteilungsfunktion",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#def-gemeinsame-verteilungsfunktion",
  "type": "Definition",
  "number": "4.1.13",
  "title": "Gemeinsame Verteilungsfunktion.",
  "body": " Gemeinsame Verteilungsfunktion  Verteilungsfunktion gemeinsame  gemeinsame Verteilungsfunktion   Die gemeinsame Verteilungsfunktion zweier Zufallsvariablen und ist    "
},
{
  "id": "sub-gemeinsame-verteilungsfunktion-5",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-gemeinsame-verteilungsfunktion-5",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "partielle Ableitungen "
},
{
  "id": "thm-gemeinsame-verteilungsfunktion",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#thm-gemeinsame-verteilungsfunktion",
  "type": "Satz",
  "number": "4.1.14",
  "title": "Rechnen mit der gemeinsamen Verteilungsfunktion.",
  "body": " Rechnen mit der gemeinsamen Verteilungsfunktion   Sei .   Für und ist     Die Ränder sind Grenzwerte: und .    Haben und eine gemeinsame Dichte, so ist und an jeder Stelle, an der stetig ist und sich die beiden Ableitungen bilden lassen, gilt .       (1) Das ist die Rechnung aus dem Beweis von , nur ohne das Produkt am Ende: Vom Quadranten nimmt man die Quadranten bei und weg und gibt ihren doppelt abgezogenen Schnitt bei zurück.  (2) ist die disjunkte Vereinigung von und den Ereignissen für Wie im Beweis von ergibt das dritte Axiom eine Teleskopsumme: Weil in wächst, ist das auch der Grenzwert für .  (3) Die erste Formel ist die Definition der gemeinsamen Dichte mit dem Quadranten . Leitet man sie nach ab, liefert der Hauptsatz der Differential- und Integralrechnung das innere Integral an der Stelle , also ; leitet man das nach ab, liefert er , wie in für eine Variable. Beide Schritte brauchen, dass der jeweilige Integrand an der Stelle stetig ist. Springt er dort, lässt sich die Ableitung nicht bilden. Bei den Dichten dieses Buchs gibt es solche Sprünge nur am Rand des Gebiets, auf dem die Dichte positiv ist, und oberhalb von Randstücken, die senkrecht verlaufen.   "
},
{
  "id": "ex-erste-letzte-verteilungsfunktion",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-erste-letzte-verteilungsfunktion",
  "type": "Beispiel",
  "number": "4.1.15",
  "title": "Erste und letzte Anfrage: woher die Dichte kommt.",
  "body": " Erste und letzte Anfrage: woher die Dichte kommt   In der Situation von :   Bestimmen Sie für . Zerlegen Sie dazu danach, ob ist oder nicht. Was gilt für ?   Leiten Sie daraus die gemeinsame Dichte her.   Bestimmen Sie die Randverteilungsfunktionen und .    Mit welcher Wahrscheinlichkeit kommt die erste Anfrage im zweiten, die letzte im dritten Viertel der Sekunde, ist also und ? Rechnen Sie mit .           heißt, dass alle drei Anfragen bis kommen; wegen der Unabhängigkeit hat das die Wahrscheinlichkeit . heißt, dass alle drei in fallen, mit Wahrscheinlichkeit . Also ist Für folgt schon aus , also ist dort .    Für ist und . Für hängt nicht von ab, die Ableitung ist 0. Das ist die Dichte aus .    Für ist , denn für ändert sich nicht mehr, und . Ableiten ergibt die Randdichten aus . Weiter ist wie in , Teil (c), diesmal ohne Integral.    Gesucht ist die Wahrscheinlichkeit des Rechtecks . An seinen vier Ecken ist , dort gilt also die Formel aus (a), zum Beispiel . Mit ist nach , Teil (1), In knapp jeder zehnten Sekunde fallen also alle drei Anfragen in die mittlere halbe Sekunde und überspannen dabei die Mitte der Sekunde. Das Doppelintegral der Dichte über ergibt dasselbe; mit genügen vier Funktionswerte.     Wie in war die Verteilungsfunktion leichter zu bekommen als die Dichte, weil sich ihre Ereignisse direkt in Worte über die drei Anfragen übersetzen lassen. Die Dichte folgt dann durch Ableiten.   "
},
{
  "id": "thm-produktkriterium",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#thm-produktkriterium",
  "type": "Satz",
  "number": "4.1.16",
  "title": "Produktkriterium für Dichten.",
  "body": " Produktkriterium für Dichten  Produktkriterium   Seien und stetig mit den Dichten und .   Sind und unabhängig, so ist eine gemeinsame Dichte von und .    Ist umgekehrt eine gemeinsame Dichte von und , so sind sie unabhängig.   Kurz: Zwei stetige Zufallsvariablen sind genau dann unabhängig, wenn das Produkt ihrer Randdichten eine gemeinsame Dichte ist.    (2) Integriert man die Produktdichte über den Quadranten , zerfällt das Doppelintegral: Das ist .  (1) Für ein Rechteck ist nach  Die Produktdichte liefert also für jedes Rechteck die richtige Wahrscheinlichkeit. Jedes Gebiet lässt sich beliebig genau durch Vereinigungen kleiner, disjunkter Rechtecke annähern, wie bei den Treppenfunktionen nach . Den Grenzübergang führen wir nicht aus.   "
},
{
  "id": "cor-faktorisierung",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#cor-faktorisierung",
  "type": "Korollar",
  "number": "4.1.17",
  "title": "Faktorisierung.",
  "body": " Faktorisierung   Lässt sich eine gemeinsame Dichte für alle  als mit Funktionen schreiben, so sind und unabhängig, und die Randdichten sind und .    Nach ist und , und das Gesamtvolumen 1 heißt . Also ist , und Teil (2) des Satzes liefert die Unabhängigkeit.   "
},
{
  "id": "ex-faktorisierung",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-faktorisierung",
  "type": "Beispiel",
  "number": "4.1.18",
  "title": "Produkt oder nicht.",
  "body": " Produkt oder nicht   Entscheiden Sie, ob und unabhängig sind, und bestimmen Sie die Randdichten.    für , , sonst 0.     für , , , sonst 0.          Mit auf und auf , jeweils 0 sonst, ist auf ganz , denn das Quadrat ist ein Rechteck. Also sind und unabhängig mit und auf .    Die Formel ist ein Produkt, das Gebiet aber ein Dreieck. Die Randdichte ist und ebenso . An der Stelle außerhalb des Dreiecks ist , aber . In einer Umgebung dieser Stelle gilt dasselbe, also ist das Produkt keine gemeinsame Dichte, und und sind abhängig.     In (b) ist die Abhängigkeit anschaulich klar: Ist fast 1, muss fast 0 sein. Wer nur auf die Formel schaut und das Gebiet vergisst, kommt zum falschen Schluss.   "
},
{
  "id": "ex-regen-auftrag",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-regen-auftrag",
  "type": "Beispiel",
  "number": "4.1.19",
  "title": "Vor dem Regen zurück?",
  "body": " Vor dem Regen zurück?   Ein Lieferroboter übernimmt einen Auftrag, dessen Dauer (in Stunden) auf gleichverteilt ist. Bei Regen muss er die Fahrt abbrechen. Die Zeit bis zum nächsten Regenschauer sei exponentialverteilt mit Erwartungswert 2 Stunden und unabhängig von .  Geben Sie die gemeinsame Dichte von und an.   Mit welcher Wahrscheinlichkeit schafft der Roboter den Auftrag, bevor es regnet?    Für die Rückfahrt ins Depot braucht er danach eine Stunde. Mit welcher Wahrscheinlichkeit kommt er vor dem Regen zurück?          Nach , Teil (1), ist für und , sonst 0.    Gesucht ist , das Volumen über dem Gebiet oberhalb der Diagonale. Bei festem läuft von bis . Den Faktor zieht man vor das innere Integral; übrig bleibt . Also ist     Gesucht ist , das Gebiet oberhalb der um 1 nach oben verschobenen Diagonale. Bei festem bleibt nach dem Herausziehen von jetzt , also      Mehr als jeder dritte Auftrag wird vom Regen unterbrochen, und nur gut jede dritte Fahrt endet trocken im Depot. Wer solche Touren plant, braucht die gemeinsame Verteilung von Fahrzeit und Wetter, nicht nur die beiden Mittelwerte: Im Mittel dauert ein Auftrag eine Stunde, und im Mittel regnet es erst nach zwei.   "
},
{
  "id": "sub-unabhaengigkeit-gemeinsam-16",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-unabhaengigkeit-gemeinsam-16",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Stichprobe "
},
{
  "id": "ex-stichprobe-antwortzeiten",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-stichprobe-antwortzeiten",
  "type": "Beispiel",
  "number": "4.1.20",
  "title": "Wie gut passt ein Modell zu drei Messwerten?",
  "body": " Wie gut passt ein Modell zu drei Messwerten?   Drei gemessene Antwortzeiten eines Dienstes betragen 0,5; 1,2 und 0,3 Sekunden. Als Modell nehmen wir an, dass sie unabhängig und alle -verteilt sind.  Stellen Sie die gemeinsame Dichte der drei Antwortzeiten auf.   Werten Sie sie an den gemessenen Werten für , und aus.   Welche Eigenschaft der Daten geht in das Ergebnis ein?         Für ist sonst 0.    Die Summe der Messwerte ist 2,0, also ist die gemeinsame Dichte an den Daten : für etwa 0,135, für etwa 0,168 und für etwa 0,147.    Nur die Summe der Messwerte. Drei andere Antwortzeiten mit derselben Summe, etwa 0,7; 0,7 und 0,6, ergäben genau dieselben Werte.     Hohe gemeinsame Dichte an den beobachteten Daten heißt: Das Modell hätte diese Daten eher hervorgebracht. Unter den drei Parametern erklärt die Messungen am besten, also eine mittlere Antwortzeit von  s, und das ist genau der Mittelwert der Daten. Die gemeinsame Dichte als Funktion des Parameters heißt Likelihood , und den besten Parameter systematisch zu finden ist der Gegenstand von .   "
},
{
  "id": "thm-erwartungswert-gemeinsam",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#thm-erwartungswert-gemeinsam",
  "type": "Satz",
  "number": "4.1.21",
  "title": "Erwartungswert einer Funktion zweier Zufallsvariablen (Transformationssatz).",
  "body": " Erwartungswert einer Funktion zweier Zufallsvariablen (Transformationssatz)  Erwartungswert einer Funktion zweier Zufallsvariablen  Transformationssatz für zwei Zufallsvariablen   Haben und die gemeinsame Dichte und ist stückweise stetig, so ist sofern das Integral mit an Stelle von endlich ist.   "
},
{
  "id": "thm-summen-produkte-stetig",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#thm-summen-produkte-stetig",
  "type": "Satz",
  "number": "4.1.22",
  "title": "Summen und Produkte, stetiger Fall.",
  "body": " Summen und Produkte, stetiger Fall   Seien und Zufallsvariablen mit gemeinsamer Dichte, deren Erwartungswerte existieren.  .   Sind und unabhängig, so ist für stückweise stetige und , für die beide Seiten existieren, insbesondere .    Sind und unabhängig und existieren ihre Varianzen, so ist .       (1) Mit und den Randdichten aus :   (2) Nach ist eine gemeinsame Dichte. Welche gemeinsame Dichte man in einsetzt, ist gleichgültig, weil jede dieselben Wahrscheinlichkeiten und damit dieselben Erwartungswerte liefert. Mit dem Produkt zerfällt das Doppelintegral:   (3) Wie im Beweis von , Teil (2): Mit und ist nach (1) . Man multipliziert aus; weil der Erwartungswert nach ein Integral ist, darf man ihn gliedweise bilden: und nach (2) ist der letzte Erwartungswert .   "
},
{
  "id": "sub-erwartungswerte-gemeinsam-8",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-erwartungswerte-gemeinsam-8",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "gemeinsamer Erwartungswert Korrelation "
},
{
  "id": "ex-wartezeit-buendel",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-wartezeit-buendel",
  "type": "Beispiel",
  "number": "4.1.23",
  "title": "Wie lange wartet die erste Anfrage?",
  "body": " Wie lange wartet die erste Anfrage?   In der Situation von wird das Bündel verarbeitet, sobald die letzte Anfrage da ist. Die erste Anfrage wartet also .   Bestimmen Sie einmal über und , einmal als Doppelintegral.   Vergleichen Sie mit .   Bestimmen Sie und vergleichen Sie mit .          Mit den Randdichten und ist und , also nach , Teil (1), mit statt : . Als Doppelintegral, mit :      dagegen . Die Produktregel gilt hier nicht, wie zu erwarten: und sind abhängig.     , also . Aus den Randdichten ist und , also und . Die Varianz der Differenz ist kleiner.     Im Mittel wartet die erste Anfrage eine halbe Sekunde. Den Erwartungswert durfte man über die Ränder ausrechnen, die Varianz nicht: Kommt die erste Anfrage spät, kommt auch die letzte spät, die beiden schwanken also teilweise gemeinsam, und in der Differenz hebt sich das auf. Mit der Formel für unabhängige Zufallsvariablen hätte man die Varianz der Wartezeit um die Hälfte überschätzt.   "
},
{
  "id": "sub-erwartungswerte-gemeinsam-10",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-erwartungswerte-gemeinsam-10",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Signal plus Rauschen "
},
{
  "id": "ex-signal-rauschen",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#ex-signal-rauschen",
  "type": "Beispiel",
  "number": "4.1.24",
  "title": "Mitteln über mehrere Sensoren.",
  "body": " Mitteln über mehrere Sensoren   Die Temperatur in einer Halle schwankt im Lauf des Tages mit Erwartungswert 20  C und Standardabweichung 2  C. Ein Sensor zeigt an, wobei der Messfehler den Erwartungswert 0 und die Standardabweichung 1  C hat. Temperatur und Messfehler seien stetige Zufallsvariablen, und und seien unabhängig.   Bestimmen Sie Erwartungswert und Varianz der Anzeige. Welcher Anteil ihrer Varianz stammt von der Temperatur selbst?    Vier Sensoren mit Messfehlern dieser Art messen gleichzeitig, wobei unabhängig sind, und man mittelt ihre Anzeigen. Welche Varianz hat der Mittelwert, und welche sein Messfehler?    Was ändert sich, wenn man über sehr viele Sensoren mittelt?             C und nach , Teil (3), , also eine Standardabweichung von etwa 2,24  C. Der Anteil der Temperatur an der Varianz ist  %.    Der Mittelwert ist mit . Nach ist , und weil als Funktion von unabhängig von ist, hat der Mittelwert die Varianz . Sein Messfehler hat die Varianz , also die Standardabweichung   C.    Bei Sensoren ist die Varianz des Mittelwerts , die des Messfehlers . Der Messfehler verschwindet, die Varianz des Mittelwerts sinkt aber nie unter 4.     Mitteln beseitigt das Rauschen, nicht die Schwankung des Signals. Mehr Sensoren messen die momentane Temperatur immer genauer, aber die Anzeige schwankt weiter, weil die Temperatur selbst schwankt. Wer aus der Streuung der Anzeigen auf die Güte der Sensoren schließen will, muss beides trennen. Das Verhältnis der Varianzen von Signal und Rauschen, hier , heißt Signal-Rausch-Verhältnis Signal-Rausch-Verhältnis ; durch Mitteln über Sensoren steigt es auf .   "
},
{
  "id": "sub-zusammenfassung-4-1-2",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#sub-zusammenfassung-4-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Gemeinsame Wahrscheinlichkeitsfunktion. Gemeinsame Dichte. Randverteilungen. Gemeinsame Verteilungsfunktion. Unabhängigkeit. Welcher Wert kommt zuerst? Erwartungswerte. "
},
{
  "id": "exercise-buch-code-review",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#exercise-buch-code-review",
  "type": "Übung",
  "number": "4.1.7.1",
  "title": "Code-Review und Release.",
  "body": " Code-Review und Release   Sei die Zahl der schweren Fehler, die ein Code-Review in einer Änderung findet, und , wenn das Release danach verschoben wird, sonst . Die gemeinsame Wahrscheinlichkeitsfunktion ist      \\ 0 1   0 0,40 0,05  1 0,20 0,10  2 0,05 0,20     Bestimmen Sie die Randverteilungen und .   Mit welcher Wahrscheinlichkeit wird ein Release verschoben, wenn das Review mindestens einen schweren Fehler gefunden hat?   Sind und unabhängig?         Zeilensummen: , , ; Spaltensummen: , . .     .    Nein: , aber .      "
},
{
  "id": "exercise-buch-dichte-dreieck",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#exercise-buch-dichte-dreieck",
  "type": "Übung",
  "number": "4.1.7.2",
  "title": "Eine Dichte auf einem Dreieck.",
  "body": " Eine Dichte auf einem Dreieck    und haben die gemeinsame Dichte für und 0 sonst.  Bestimmen Sie . Skizzieren Sie das Gebiet.  Bestimmen Sie die Randdichten.  Bestimmen Sie .   Bestimmen Sie , und . Gilt ?          Das Gebiet ist das Dreieck unterhalb der Diagonale. , also .     und , jeweils für Werte in .     .     , und . Dagegen ist : und sind abhängig, und die Produktregel gilt nicht.      "
},
{
  "id": "exercise-buch-zwei-zufallszahlen",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#exercise-buch-zwei-zufallszahlen",
  "type": "Übung",
  "number": "4.1.7.3",
  "title": "Zwei Zufallszahlen.",
  "body": " Zwei Zufallszahlen    und seien unabhängig und beide auf gleichverteilt, etwa zwei Aufrufe von random.random() .  Geben Sie die gemeinsame Dichte an.  Bestimmen Sie .   Bestimmen Sie . Ein Taschenrechner ist erlaubt.          Nach : 1 auf dem Einheitsquadrat, 0 sonst. Wahrscheinlichkeiten sind Flächen.    Die Fläche unter der Parabel: .    Für ist für jedes ; für muss sein. Also       "
},
{
  "id": "exercise-buch-verteilungsfunktion",
  "level": "2",
  "url": "sec-gemeinsame-verteilungen-randverteilungen.html#exercise-buch-verteilungsfunktion",
  "type": "Übung",
  "number": "4.1.7.4",
  "title": "Eine gemeinsame Verteilungsfunktion.",
  "body": " Eine gemeinsame Verteilungsfunktion    und haben die gemeinsame Verteilungsfunktion für und sonst.   Bestimmen Sie die Randverteilungsfunktionen. Welche Verteilungen sind das?   Sind und unabhängig? Bestimmen Sie die gemeinsame Dichte.   Bestimmen Sie mit Hilfe von .           und für : , .    Ja, denn , das ist . Die gemeinsame Dichte ist für , das Produkt der Randdichten.     .      "
},
{
  "id": "sec-kovarianz-korrelation-zufallsvektoren",
  "level": "1",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html",
  "type": "Abschnitt",
  "number": "4.2",
  "title": "Kovarianz, Korrelation, bedingte Erwartung und Zufallsvektoren",
  "body": " Kovarianz, Korrelation, bedingte Erwartung und Zufallsvektoren    Nach diesem Abschnitt können Sie     die Kovarianz zweier Zufallsvariablen berechnen, mit ihren Rechenregeln umformen und die Varianz einer Summe abhängiger Zufallsvariablen bestimmen,    den Korrelationskoeffizienten berechnen und deuten, begründen, warum er zwischen und 1 liegt, und an Beispielen zeigen, dass unkorrelierte Zufallsvariablen abhängig sein können,    bedingte Wahrscheinlichkeitsfunktionen, bedingte Dichten und bedingte Erwartungen bestimmen und den Erwartungswert über die bedingte Erwartung berechnen, ,    die beste lineare Vorhersage von aus samt Restfehler aufstellen und mit der bedingten Erwartung als bester Vorhersage überhaupt vergleichen,    mit Erwartungsvektor und Kovarianzmatrix rechnen, insbesondere anwenden,    bei einer zweidimensionalen Normalverteilung die Randverteilungen und die bedingte Verteilung von gegeben angeben.      Ein Rechenzentrum soll vorhersagen, wie viel Strom es in der nächsten Stunde braucht. Bekannt ist die geplante Auslastung. Wie gut lässt sich die eine Größe aus der anderen vorhersagen, und wie sieht die beste Vorhersage aus? Die Antwort steckt in der gemeinsamen Verteilung, aber man möchte sie in wenigen Zahlen zusammenfassen. Genau das leisten Kovarianz und Korrelationskoeffizient, und die bedingte Erwartung ist die Vorhersage selbst. In Data Science heißt sie Regressionsfunktion.   führt die Kovarianz ein und liefert die allgemeine Formel für die Varianz einer Summe, die nur für unabhängige Summanden hatte. normiert die Kovarianz zum Korrelationskoeffizienten und klärt, was er misst und was nicht: Unkorreliert heißt nicht unabhängig, und Korrelation heißt nicht Ursache. und sind der Kern der Woche: bedingte Verteilungen, die bedingte Erwartung als Zufallsvariable und als beste Vorhersage, und die Regressionsgerade. Hier sollte die meiste Zeit hingehen. fasst viele Zufallsvariablen zu einem Vektor zusammen; ihre Kovarianzmatrix steckt hinter Portfolios und der Hauptkomponentenanalyse. zeigt zum Schluss die Normalverteilung in zwei Dimensionen, bei der alles Bisherige besonders einfach wird.    Kovarianz und die Varianz einer Summe  In war die Varianz der Wartezeit nur zwei Drittel so groß wie . Kommt die erste Anfrage spät, kommt meist auch die letzte spät, und in der Differenz hebt sich das auf. Beim Ausmultiplizieren von in war dafür ein einziger Term zuständig, der bei Unabhängigkeit wegfällt. Er misst, ob zwei Zufallsvariablen gemeinsam über und unter ihren Erwartungswert schwanken.   Kovarianz  Kovarianz  unkorreliert   Seien und Zufallsvariablen auf demselben Wahrscheinlichkeitsraum mit Erwartungswerten , und endlichen Varianzen. Die Kovarianz von und ist Ist , so heißen und  unkorreliert .    Der Erwartungswert existiert, weil ist und die Varianzen endlich sind. Für diskrete und ist er eine Summe über die Tabelle der gemeinsamen Wahrscheinlichkeitsfunktion, für Zufallsvariablen mit gemeinsamer Dichte ein Doppelintegral nach . Das Vorzeichen lässt sich ablesen: Das Produkt ist positiv, wenn beide Werte über oder beide unter ihrem Erwartungswert liegen, und negativ, wenn einer darüber und der andere darunter liegt. Eine positive Kovarianz heißt also, dass große Werte von eher mit großen Werten von zusammen auftreten; eine negative, dass sie eher mit kleinen zusammen auftreten.   Rechenregeln für die Kovarianz  Kovarianz Rechenregeln   Seien , und Zufallsvariablen mit endlichen Varianzen und .  .  und .    und . Wegen (2) gilt dasselbe im zweiten Argument.   Sind und unabhängig, so ist .      (1) Ausmultiplizieren und die Linearität des Erwartungswerts:   (2) folgt direkt aus der Definition. (3) Es ist , also , und der Faktor geht vor den Erwartungswert. Ebenso ist ; man multipliziert mit und bildet den Erwartungswert gliedweise. (4) folgt aus (1) und , also aus bzw. .    Regel (1) ist die Kovarianz-Form des Verschiebungssatzes und meist der kürzeste Rechenweg. Aus (3) folgt : Konstanten, die man addiert, ändern die Kovarianz nicht, Faktoren gehen als Produkt ein. Die Kovarianz hängt also von den Einheiten ab. Misst man in Metern statt in Kilometern, wird sie tausendmal so groß.  Mit den Regeln lässt sich die Varianz jeder Summe ausrechnen, auch wenn die Summanden abhängen. Das ist der Ersatz für die Additivität aus .   Varianz einer Summe  Varianz einer Summe   Für Zufallsvariablen und mit endlichen Varianzen ist Allgemein gilt für mit endlichen Varianzen     Nach Regel (2) ist für , und nach Regel (3) in beiden Argumenten Die Summanden mit sind die Varianzen. Jedes Paar kommt zweimal vor, als und als , mit derselben Kovarianz. Für setzt man , und benutzt .    Sind die Summanden paarweise unkorreliert, bleibt nur die Summe der Varianzen; dafür genügt die Unkorreliertheit, Unabhängigkeit ist mehr, als man braucht. In ist und deshalb wie dort als Doppelintegral berechnet. Die positive Kovarianz ist genau der Anteil, der sich in der Differenz aufhebt.   Wie stark hängen Minimum und Maximum zusammen?   In der Situation von sind und Minimum und Maximum der Augenzahlen , zweier fairer Würfel.   Bestimmen Sie und aus den Randverteilungen.    Bestimmen Sie und . Hinweis : Welches Produkt der Augenzahlen ist ?    Es ist . Bestimmen Sie mit , und prüfen Sie das Ergebnis ohne Kovarianz.          Mit ist . Weil ist, folgt ohne weitere Summe .    Minimum mal Maximum ist das Produkt der beiden Augenzahlen, . Die Würfel sind unabhängig, also , und nach Regel (1)      . Ohne Kovarianz: ist die Summe zweier unabhängiger Würfe, also .     Die Kovarianz ist positiv: Ein großes Minimum zwingt das Maximum nach oben. Hätte man die Varianzen einfach addiert, käme man auf etwa statt ; ein Drittel der Streuung der Summe stammt aus dem Zusammenhang. Wie stark dieser ist, lässt sich an allein noch nicht ablesen, denn die Kovarianz hängt von den Einheiten ab. Das holt nach.     Summen abhängiger Indikatoren  In blieben zwei Fragen offen, weil die Kovarianz fehlte: die Varianz der hypergeometrischen Verteilung und der Zusammenhang der Anzahlen einer Multinomialverteilung. Beide Male ist eine Anzahl eine Summe von Indikatoren, die voneinander abhängen.    Varianz der hypergeometrischen Verteilung   Für und ist     Wie in sei das Ereignis, dass die -te Ziehung ein Stück mit der Eigenschaft bringt, und . Jedes geordnete Paar verschiedener Stücke landet mit derselben Wahrscheinlichkeit an den Positionen , also ist . Nach Regel (1), mit : Jeder Indikator hat die Varianz , und es gibt Paare . Nach ist     Die Indikatoren sind negativ korreliert: Hat die erste Ziehung ein defektes Stück gebracht, ist für die übrigen eines weniger da. Diese negativen Kovarianzen sind die Endlichkeitskorrektur. In mit 50 Sensoren, davon drei defekt, ist , und die 20 Kovarianzen mit drücken die Varianz von auf .   Kovarianz der Multinomial-Anzahlen   Ist , so ist für      Fasst man die Klassen und zu einer zusammen, zählt die Erfolge mit Wahrscheinlichkeit , ist also -verteilt. Mit , aufgelöst nach der Kovarianz:     Auch hier ist das Vorzeichen negativ, denn die Anzahlen teilen sich die Versuche. Für die fünf Supporttickets aus ist : Sind unter den fünf viele Technik-Tickets, betreffen eher wenige die Rechnung. Wer aus Klassenhäufigkeiten Schlüsse zieht, etwa beim Vergleich der Anteile zweier Klassen, muss diese Abhängigkeit mitrechnen.    Der Korrelationskoeffizient  Ob eine Kovarianz von viel oder wenig ist, hängt von den Einheiten ab. Teilt man durch beide Standardabweichungen, fallen die Einheiten heraus, und es bleibt eine Zahl, die man über alle Datensätze hinweg vergleichen kann.   Korrelationskoeffizient  Korrelationskoeffizient  Korrelation   Seien und Zufallsvariablen mit positiven, endlichen Varianzen. Der Korrelationskoeffizient von und ist      Eigenschaften des Korrelationskoeffizienten     .    genau dann, wenn mit Wahrscheinlichkeit 1 mit Konstanten und gilt; genau dann, wenn das mit gilt.    Für Konstanten mit ist , falls und dasselbe Vorzeichen haben, und sonst.       Wir standardisieren: und haben die Varianz 1, und nach den Rechenregeln ist . Mit : Mit dem Pluszeichen folgt , mit dem Minuszeichen . Das ist (1).  (2) Ist , so ist . Eine Zufallsvariable mit Varianz 0 ist mit Wahrscheinlichkeit 1 gleich ihrem Erwartungswert, hier 0, denn ihre quadrierte Abweichung ist nicht negativ und hat den Erwartungswert 0 (eine nicht negative Größe mit Erwartungswert 0 ist mit Wahrscheinlichkeit 1 gleich 0, sonst wäre ihr Erwartungswert positiv). Also ist , das heißt , eine Gerade mit positiver Steigung. Für benutzt man . Ist umgekehrt , so ist und , also .  (3) Nach den Rechenregeln wird die Kovarianz mit multipliziert, das Produkt der Standardabweichungen mit .    Der Korrelationskoeffizient misst also, wie gut die Punkte auf einer Geraden liegen. Bei liegen sie exakt darauf, und das Vorzeichen ist das der Steigung. Wie steil die Gerade ist, sagt er nicht: und haben beide . Nach (3) ändert ein Wechsel der Einheiten, etwa von Grad Celsius zu Fahrenheit, nichts am Korrelationskoeffizienten. zeigt, wie Punktwolken mit verschiedenen Korrelationskoeffizienten aussehen.   Je 150 Punkte . Oben normalverteilte Paare mit , und , unten links mit . Die beiden anderen Wolken haben ebenfalls , aber und hängen deutlich zusammen: liegt nahe einer Parabel über , oder der Punkt ist gleichverteilt auf einer Kreisscheibe wie in .   Sechs Punktwolken mit verschiedenen Korrelationskoeffizienten   Sechs quadratische Felder in zwei Reihen, jedes mit einer Wolke aus 150 Punkten. Oben links liegen die Punkte eng um eine steigende Gerade ( ), daneben locker um eine steigende Gerade ( ), oben rechts bilden sie einen runden Fleck ohne Richtung ( ). Unten links liegen sie um eine fallende Gerade ( ). Unten in der Mitte bilden sie einen nach oben offenen Bogen, unten rechts füllen sie gleichmäßig eine Kreisscheibe; beide haben .       Minimum und Maximum, normiert   Bestimmen Sie in der Situation von den Korrelationskoeffizienten von und . Ändert er sich, wenn ein Spiel für das Minimum Punkte vergibt?    Beide Varianzen sind , also Nach , Teil (3), hat mit denselben Korrelationskoeffizienten, obwohl die Kovarianz zehnmal so groß ist.  Ein Wert von knapp beschreibt einen deutlichen, aber keineswegs festen Zusammenhang: Zum Minimum 1 passt jedes Maximum von 1 bis 6. Die Zahl ist dieselbe, ob man in Augen, Punkten oder Euro rechnet; deshalb vergleicht man in Datensätzen Korrelationen und nicht Kovarianzen.     Unkorreliert oder unabhängig?  Nach , Teil (4), sind unabhängige Zufallsvariablen unkorreliert. Die Umkehrung ist falsch, und die Verwechslung der beiden Begriffe ist einer der häufigsten Fehler in der Datenanalyse. Die Kovarianz misst nur den Teil des Zusammenhangs, der sich durch eine Gerade beschreiben lässt. Das bekannteste Beispiel ist ein um 0 symmetrisch verteiltes mit endlichem und : ist durch vollständig festgelegt, und doch ist , weil sich positive und negative Werte von aufheben.    Defekte auf dem Wafer, noch einmal   In ist die Lage eines Defekts gleichverteilt auf der Kreisscheibe mit Radius 10. Zeigen Sie, dass und unkorreliert sind. Sind sie unabhängig?    Die Dichte ist konstant auf einer Scheibe, die symmetrisch zu beiden Achsen liegt. Zu jedem Punkt der Scheibe gehört der Punkt mit derselben Dichte, und dort hat das umgekehrte Vorzeichen. Im Doppelintegral für heben sich die beiden Hälften links und rechts der -Achse also auf: . Ebenso ist , und .  Unabhängig sind sie nicht: , Teil (c), hat gezeigt. Der runde Rand koppelt die Koordinaten, aber nicht linear: Ein großes macht ein großes unmöglich, egal in welcher Richtung. Die Kovarianz sieht davon nichts: Sie misst nur, ob große Werte von eher mit großen oder eher mit kleinen Werten von zusammen auftreten. Wegen der Symmetrie der Scheibe kommen zu jedem Wert von große und kleine Werte von gleich häufig vor, und das hebt sich genau auf.     Korrelation ohne Kausalität  Ein Korrelationskoeffizient sagt nicht, welche Größe welche beeinflusst, und auch nicht, ob überhaupt eine die andere beeinflusst. Oft hängen beide von einer dritten Größe ab, einer gemeinsamen Ursache gemeinsame Ursache Korrelation und Kausalität (englisch confounder ).    Fehlermeldungen und Supporttickets   Ein Onlinedienst zählt täglich die Fehlermeldungen und die Supporttickets . Beide hängen von der Zahl der aktiven Nutzer ab. Als Modell sei und , wobei die Abweichung der Nutzerzahl vom Mittel ist und , zufällige Schwankungen sind, die mit den Nutzern nichts zu tun haben. , und seien unabhängig mit , und .  Bestimmen Sie und .   Ein Team sieht die Korrelation und schlägt vor, weniger Fehlermeldungen anzuzeigen, damit weniger Tickets kommen. Was bewirkt das in diesem Modell?    Wie hängen und an Tagen mit derselben Nutzerzahl, also festem Wert , zusammen?          Mit den Rechenregeln und der Unabhängigkeit fallen alle Terme mit oder weg: . Weiter ist und , also .    Nichts. Im Modell kommt in der Formel für gar nicht vor. Wer Fehlermeldungen unterdrückt, verändert , aber weder noch . Nur von diesen hängt ab, und die Tickets bleiben, wie sie sind.    Bei festem ist und . Diese hängen nur noch über die unabhängigen Schwankungen und vom Zufall ab, sind also unabhängig und erst recht unkorreliert.     Die ganze Korrelation von stammt aus der gemeinsamen Ursache. Aus Daten allein lässt sich das nicht vom Fall unterscheiden, in dem Fehlermeldungen tatsächlich Tickets auslösen. Man trennt die beiden, indem man die vermutete Ursache festhält, wie in (c), oder indem man in einem Experiment gezielt nur verändert, etwa in einem A\/B-Test.    Die Zelle erzeugt viele Tage nach dem Modell des Beispiels und berechnet den Korrelationskoeffizienten der Datenpunkte. Mit breite = 10 wertet sie praktisch alle Tage aus, mit kleineren Werten nur die Tage, an denen die Nutzerzahl fast gleich ist.   import random, math # Tage nach dem Modell X = 2U + R, Y = 3U + S; ausgewertet nur |U| < breite. # Probieren Sie breite = 10, 1, 0.1. breite = 10 nutzer = [random.gauss(0, 2) for _ in range(20000)] nah = [u for u in nutzer if abs(u) < breite] paare = [(2*u + random.gauss(0, 3), 3*u + random.gauss(0, 28**0.5)) for u in nah] n = len(paare) mx, my = sum([x for x, y in paare]) \/ n, sum([y for x, y in paare]) \/ n cov = sum([(x - mx) * (y - my) for x, y in paare]) \/ n sx = math.sqrt(sum([(x - mx) ** 2 for x, y in paare]) \/ n) sy = math.sqrt(sum([(y - my) ** 2 for x, y in paare]) \/ n) print(\"Tage mit |U| < %.1f: %d\" % (breite, n)) print(\"Korrelation von X und Y: %.3f\" % (cov \/ (sx * sy)))   Korrelation ist trotzdem nützlich, auch ohne Kausalität: Für eine Vorhersage genügt sie. Wer an einem Tag viele Fehlermeldungen sieht, darf mit vielen Tickets rechnen, gleich aus welchem Grund. Wie man diese Vorhersage baut, zeigt . Zuvor noch ein Fall, in dem Korrelation über Erfolg oder Misserfolg eines Verfahrens entscheidet.   Mitteln über korrelierte Modelle   Ein Ensemble mittelt die Vorhersagen von Modellen. Ihre Fehler haben den Erwartungswert 0 und die Varianz , und je zwei von ihnen haben den Korrelationskoeffizienten , weil die Modelle auf ähnlichen Daten trainiert sind.   Zeigen Sie, dass der gemittelte Fehler die Varianz hat.    Werten Sie für aus. Was geschieht für sehr große ?   Was folgt daraus für den Bau eines Ensembles?         Jede Kovarianz ist . Nach mit Varianzen und Paaren ist     Für : , also eine Standardabweichung von etwa statt 2 beim einzelnen Modell. Für geht die Varianz gegen ; die Standardabweichung fällt nie unter 1, wie viele Modelle man auch mittelt.    Mehr Modelle helfen nur gegen den unkorrelierten Teil des Fehlers. Den gemeinsamen Teil senkt man nur, indem man die Modelle unähnlicher macht.     Für ist das , für bringt das Mitteln gar nichts. Das Gesetz der großen Zahlen, das Sie in kennenlernen ( ), wird deshalb unabhängige oder wenigstens unkorrelierte Größen voraussetzen; greift dieses Beispiel dort wieder auf. Ein Random Forest trainiert seine Bäume aus demselben Grund absichtlich auf zufällig gezogenen Teilen der Daten und mit zufällig ausgewählten Merkmalen: Jeder einzelne Baum wird dadurch etwas schlechter, aber die Korrelation zwischen den Bäumen sinkt, und das zahlt sich im Mittel aus.    Solche korrelierten Fehler kann man mit dem Gedanken der gemeinsamen Ursache erzeugen: Jeder Fehler ist ein gemeinsamer Anteil mit Varianz 1, den alle Modelle teilen, plus ein eigener Anteil mit Varianz 3. Dann ist jede Varianz 4 und jede Kovarianz , also wie im Beispiel. Die Zelle mittelt solche Fehler und vergleicht die Streuung mit der Formel.   import random, math # Fehler = gemeinsamer Anteil (Varianz 1) + eigener (Varianz 3), rho = 0.25. # Probieren Sie n = 1, 10, 100. n = 10 def gemittelter_fehler(): g = random.gauss(0, 1) return g + sum([random.gauss(0, math.sqrt(3)) for _ in range(n)]) \/ n fehler = [gemittelter_fehler() for _ in range(2000)] m = sum(fehler) \/ len(fehler) s = math.sqrt(sum([(f - m) ** 2 for f in fehler]) \/ len(fehler)) formel = 2 * math.sqrt(0.25 + 0.75 \/ n) print(\"Standardabweichung des gemittelten Fehlers: %.3f\" % s) print(\"Formel 2 * Wurzel(0.25 + 0.75 \/ n): %.3f\" % formel)     Bedingte Verteilungen und bedingte Erwartung  Kennt man den Wert von , ändert sich, was man über erwartet. In der Tabelle einer gemeinsamen Wahrscheinlichkeitsfunktion heißt das: Man schaut nur noch auf die Zeile und teilt durch ihre Summe, damit wieder eine Verteilung herauskommt. Das ist die bedingte Wahrscheinlichkeit aus , angewandt auf die Ereignisse und .   Bedingte Wahrscheinlichkeitsfunktion und bedingte Dichte  bedingte Wahrscheinlichkeitsfunktion  Wahrscheinlichkeitsfunktion bedingte  bedingte Verteilung  Verteilung bedingte  bedingte Dichte  Dichte bedingte      Seien und diskret und . Die bedingte Wahrscheinlichkeitsfunktion von gegeben ist     Haben und die gemeinsame Dichte und ist , so ist die bedingte Dichte von gegeben  und man setzt .       Für festes ist eine Wahrscheinlichkeitsfunktion und eine Dichte: Nach bzw. ist die Summe bzw. das Integral über gerade der Nenner. Im stetigen Fall ist , und die Definition aus greift nicht. Anschaulich bedingt man auf einen schmalen Streifen : Seine Wahrscheinlichkeit ist etwa , die Wahrscheinlichkeit, dass zusätzlich gilt, etwa , und der Quotient hängt nicht mehr von ab. Geometrisch schneidet man das Gebirge der gemeinsamen Dichte bei durch und skaliert den Schnitt auf die Fläche 1. Die Rollen von und sind vertauschbar: entsteht genauso, mit im Nenner, und ebenso im diskreten Fall. Die Folien der Vorlesung bedingen in dieser Richtung, also gegeben .  Umgestellt lauten die Definitionen die Multiplikationsregel aus für Zufallsvariablen. So baut man gemeinsame Verteilungen in zwei Stufen: zuerst die Verteilung von , dann die von für jeden Wert von . Viele Simulationen und generative Modelle des maschinellen Lernens sind so aufgebaut. Hängt die bedingte Verteilung gar nicht von ab, ist sie gleich der Randverteilung von , und und sind unabhängig, nach dem Produktkriterium aus .   Bedingte Erwartung  bedingte Erwartung  Erwartungswert bedingter   Die bedingte Erwartung von gegeben ist der Erwartungswert der bedingten Verteilung, im diskreten Fall und bei gemeinsamer Dichte, sofern die Summe bzw. das Integral mit endlich ist. Ebenso ist definiert.     Das Maximum, wenn das Minimum bekannt ist   In der Situation von sei das Minimum und das Maximum zweier fairer Würfel.   Bestimmen Sie die bedingte Wahrscheinlichkeitsfunktion von gegeben .   Bestimmen Sie für .   Mitteln Sie die Werte aus (b) mit den Gewichten . Was kommt heraus?          Die Zeile der Tabelle enthält bei und bei jedem ; ihre Summe ist . Also und 0 für . Für etwa nimmt die Werte 4, 5, 6 mit den Wahrscheinlichkeiten an.    Mit ist also der Reihe nach , , , , und 6.    Der Faktor kürzt sich:      Ohne weitere Information erwartet man als Maximum ; weiß man, dass das Minimum 1 war, nur noch , bei Minimum 5 schon . Teil (c) ist kein Zufall, sondern .     Wann kommt die letzte Anfrage?   In haben der Zeitpunkt der ersten und der Zeitpunkt der letzten von drei Anfragen die gemeinsame Dichte auf , und es ist .   Bestimmen Sie die bedingte Dichte von gegeben für .   Bestimmen Sie .   Die erste Anfrage kommt bei . Wann ist das Bündel im Mittel vollständig?           für , sonst 0. Bei festem steigt sie linear von 0 auf ; das Integral über ist die Dreiecksfläche .    Mit :      : im Mittel nach  Sekunden.     Das Ergebnis lässt sich deuten: Steht die erste Anfrage bei fest, liegen die beiden anderen irgendwo in , und die spätere von ihnen kommt im Mittel nach zwei Dritteln dieses Intervalls. Für den Dienst heißt das: Eine frühe erste Anfrage verspricht noch keine frühe Verarbeitung, denn ist nie kleiner als .    Die bedingte Erwartung ist der Mittelwert von unter den Fällen mit . Mit Daten kann man ihn genau so schätzen: Man nimmt die Datenpunkte, deren -Wert in einem schmalen Streifen um liegt, und mittelt ihre -Werte. Die Zelle tut das für viele simulierte Bündel aus drei Anfragen.   import random # X erste, Y letzte von drei Anfragen; Mittel von Y, wo |X - x0| < 0.01. # Probieren Sie x0 = 0.1, 0.4, 0.7. x0 = 0.4 buendel = [[random.random() for _ in range(3)] for _ in range(50000)] paare = [(min(t), max(t)) for t in buendel] streifen = [y for x, y in paare if abs(x - x0) < 0.01] print(\"Bündel im Streifen: %d\" % len(streifen)) print(\"Mittel von Y dort: %.3f\" % (sum(streifen) \/ len(streifen))) print(\"E(Y | X = x0): %.3f\" % ((2 + x0) \/ 3))   Bisher war eine Zahl für jedes feste , also eine Funktion . Setzt man für den zufälligen Wert von ein, entsteht eine Zufallsvariable.   Bedingte Erwartung als Zufallsvariable  bedingte Erwartung als Zufallsvariable   Ist , so heißt die Zufallsvariable die bedingte Erwartung von gegeben .    In ist , in ist . ist die Vorhersage von , die man trifft, sobald man kennt. Teil (c) von hat gezeigt, dass diese Vorhersagen im Mittel den Erwartungswert von treffen. Das gilt immer.   Satz vom iterierten Erwartungswert  iterierter Erwartungswert  Erwartungswert iterierter  Satz vom iterierten Erwartungswert   Seien und diskret oder mit gemeinsamer Dichte, und existiere.  .   Für jede Funktion , für die existiert, ist .    Sind und unabhängig, so ist .       (2) im diskreten Fall: Mit und dem Transformationssatz für die Funktion von ist die letzte Gleichung nach , Teil (2). Mit Dichten ersetzt man die Summen durch Integrale und benutzt ; der Faktor kürzt sich ebenso. (1) ist (2) mit . (3) Bei Unabhängigkeit ist die bedingte Verteilung gleich der Randverteilung von , also für jedes .    Ausgeschrieben heißt (1) im diskreten Fall : Der Erwartungswert ist das gewichtete Mittel der bedingten Erwartungswerte. Ist der Indikator eines Ereignisses, steht dort die totale Wahrscheinlichkeit aus . Für die erste und die letzte Anfrage folgt , ohne Doppelintegral. Teil (2) rechnet Erwartungswerte von Produkten aus, wenn nur die bedingte Erwartung bekannt ist, und damit Kovarianzen. Das ist bei zweistufigen Modellen der kürzeste Weg.   Wie lange wird ein Video angesehen?   Auf einer Plattform hat ein zufällig gewähltes Video die Länge (in Minuten), gleichverteilt auf . Ein Nutzer bricht an einer zufälligen Stelle ab: Gegeben ist die gesehene Dauer gleichverteilt auf .  Geben Sie die gemeinsame Dichte von und an.   Bestimmen Sie und . Vergleichen Sie mit dem Weg über die Randdichte für .   Bestimmen Sie .         Nach der Multiplikationsregel ist für und 0 sonst.    Die bedingte Verteilung ist die Gleichverteilung auf , also und . Nach ist  Minuten. Über die Randdichte bräuchte man , also eine partielle Integration, mit demselben Ergebnis.    Nach Teil (2) des Satzes mit ist also .     Im Mittel wird ein Video zweieinhalb Minuten angesehen, längere Videos länger, daher die positive Kovarianz. Die Kennzahl mittlere Sehdauer mischt also zwei Dinge, die Länge der Videos und das Verhalten der Nutzer. Wer wissen will, ob Nutzer abspringen, schaut auf die bedingte Verteilung bei fester Länge, hier auf den Anteil .      Vorhersage: Regressionsgerade und bedingte Erwartung  Man möchte vorhersagen und kennt nur . Eine Vorhersage ist dann eine Funktion , und ihre Güte misst man meist mit dem mittleren quadratischen Fehler mittlerer quadratischer Fehler einer Vorhersage  , kurz MSE. Er bestraft große Fehler stärker als kleine und hat, wie sich zeigen wird, einfache Lösungen. Wir gehen in drei Stufen vor: ohne , mit einer Geraden in und mit einer beliebigen Funktion von .  Ohne ist die Vorhersage eine Zahl . Mit ist , und der mittlere Term hat den Erwartungswert 0. Also ist am kleinsten für , und dann ist der Fehler die Varianz von . Der Erwartungswert ist die beste konstante Vorhersage.   Beste lineare Vorhersage  Regressionsgerade  beste lineare Vorhersage  Vorhersage beste lineare   Seien und Zufallsvariablen mit positiven, endlichen Varianzen und Korrelationskoeffizient . Unter allen Vorhersagen der Form hat den kleinsten mittleren quadratischen Fehler, und dieser ist     Für festes ist ; die Zahl ist also eine konstante Vorhersage der Zufallsvariablen . Nach der Vorüberlegung ist am besten, mit dem Fehler nach . Das ist eine nach oben geöffnete Parabel in mit dem Scheitel bei , und dort ist der Wert .    Die Gerade heißt Regressionsgerade von auf . Sie geht durch den Punkt . Misst man beide Größen in Standardabweichungen vom Erwartungswert, lautet sie : Liegt zwei Standardabweichungen über dem Mittel, sagt die Gerade für nur Standardabweichungen über dem Mittel voraus. Francis Galton beobachtete an Körpergrößen, dass die Kinder sehr großer Eltern im Mittel weniger groß sind als ihre Eltern, und nannte das Regression ( Regression towards mediocrity in hereditary stature , Journal of the Anthropological Institute of Great Britain and Ireland 15 (1886), 246 263; ). Der Name ist geblieben.  Der Restfehler zeigt, was der Korrelationskoeffizient für Vorhersagen bedeutet. Ohne ist der Fehler ; die Gerade beseitigt davon den Anteil . Diese Zahl heißt Bestimmtheitsmaß Bestimmtheitsmaß und wird in der Statistik als angegeben. Bei erklärt die Gerade nur ein Viertel der Varianz. Und noch etwas sagt der Satz: Wer umgekehrt aus vorhersagt, bekommt die Steigung und damit eine andere Gerade. Sie ist nicht die Umkehrung der ersten, außer bei .   Strombedarf aus der Auslastung   Für ein Rechenzentrum sei die Auslastung (in Prozent) und die Leistungsaufnahme (in kW) in einer Stunde. Aus dem Betrieb kennt man , , , und .  Bestimmen Sie die beste lineare Vorhersage von aus .   Welche Leistungsaufnahme sagt sie für eine Auslastung von 80 % vorher? Wie groß ist ihr mittlerer quadratischer Fehler, ausgedrückt als Standardabweichung?   Welcher Anteil der Varianz von wird durch die Auslastung erklärt?          kW je Prozentpunkt und , also .      kW. Der mittlere quadratische Fehler ist , also  kW als Standardabweichung.   , also 64 %.    80 % Auslastung liegen Standardabweichungen über dem Mittel, die Vorhersage nur Standardabweichungen. Die Gerade ist die beste lineare Vorhersage; über alle Stunden gemittelt liegt sie um 24 kW daneben, gemessen als Wurzel aus dem mittleren quadratischen Fehler. Ein gutes Drittel der Varianz bleibt also unerklärt, und wer die Stromversorgung plant, braucht über die 348 kW hinaus eine Reserve. Dass der Verbrauch bei 80 % Auslastung im Mittel wirklich 348 kW beträgt, ist nur sicher, wenn linear ist. Wie groß der Fehler gerade dort ist, hängt außerdem davon ab, wie stark der Verbrauch bei dieser Auslastung streut. Beides sagen fünf Kennzahlen allein nicht; mehr dazu in .     Die beste Vorhersage überhaupt  Lässt man jede Funktion zu, nicht nur Geraden, wird die Vorhersage höchstens besser. Die beste ist die bedingte Erwartung. Um ihren Fehler anzugeben, brauchen wir noch die Streuung der bedingten Verteilung: Die bedingte Varianz bedingte Varianz Varianz bedingte von gegeben ist die Varianz der bedingten Verteilung, mit , und ist die Zufallsvariable, die man erhält, wenn man für einsetzt.    Die bedingte Erwartung ist die beste Vorhersage  beste Vorhersage  Vorhersage beste   Seien und diskret oder mit gemeinsamer Dichte, endlich und . Für jede Funktion mit endlichem ist also ist die Vorhersage mit dem kleinsten mittleren quadratischen Fehler, und dieser ist .    Man schreibt und quadriert. Für den gemischten Term setzt man ; nach , Teil (2), ist , also . Das ergibt die Zerlegung. Im diskreten Fall ist schließlich und mit Dichten ebenso mit Integralen.     Varianzzerlegung  Varianzzerlegung   Unter denselben Voraussetzungen ist     Man setzt im Satz die Konstante ein. Links steht dann , rechts der Fehler von und . Weil ist, ist das die Varianz von .    Die Varianz von zerfällt also in den Teil, den die Kenntnis von erklärt, , und den Rest, der auch bei bekanntem bleibt. Ein Regressionsbaum im maschinellen Lernen teilt die Daten nach einem Merkmal in Gruppen und sagt in jeder Gruppe deren Mittelwert vorher. Er wählt die Teilung, nach der die mittlere Varianz innerhalb der Gruppen am kleinsten ist, nach dem Korollar also die, die am meisten erklärt.  Die Regressionsgerade ist eine der Funktionen , also ist ihr Fehler nie kleiner als der der bedingten Erwartung. Gleich sind sie genau dann, wenn selbst eine Gerade in ist: Dann ist die bedingte Erwartung die beste Funktion überhaupt, also erst recht die beste lineare. Sind umgekehrt beide Fehler gleich, so ist nach der Zerlegung in der mittlere quadratische Abstand zwischen und der Geraden null, also stimmen beide mit Wahrscheinlichkeit 1 überein. Die Gerade ist deshalb gut, wenn der Zusammenhang annähernd linear ist, und kann vollständig versagen, wenn er es nicht ist. Die folgenden beiden Beispiele zeigen beide Fälle.   Wenn die bedingte Erwartung eine Gerade ist   Für die erste und die letzte von drei Anfragen ist nach  . Aus und kennt man , , und .   Bestimmen Sie die Regressionsgerade von auf , und vergleichen Sie mit .   Bestimmen Sie und den Restfehler der Geraden.   Die bedingte Varianz ist . Prüfen Sie den Restfehler mit .           und . Die Gerade ist genau die bedingte Erwartung.     , weil beide Varianzen gleich sind. Restfehler: .    Mit ist      Weil die bedingte Erwartung hier linear ist, kann keine andere Funktion die letzte Anfrage besser vorhersagen als die Gerade. Sie erklärt aber nur der Varianz: Der Zeitpunkt der ersten Anfrage verrät wenig über den der letzten.     Heizen und Kühlen: Korrelation null, Zusammenhang stark   Ein Bürogebäude wird bei Kälte geheizt und bei Hitze gekühlt. Als Modell sei die Außentemperatur (in C) gleichverteilt auf und die Leistungsaufnahme (in kW) wobei von unabhängig ist, mit und .  Bestimmen Sie und .   Zeigen Sie . Was ist die beste lineare Vorhersage? Bestimmen Sie ihren Fehler; dabei ist .    Welchen Fehler hat die bedingte Erwartung, und welchen Anteil der Varianz von erklärt sie?       Sei , gleichverteilt auf , also und .   Gegeben ist , und weil unabhängig von ist, ist . Also und .    Mit den Rechenregeln ist und , weil symmetrisch um 0 verteilt ist. Mit ist : Die beste Gerade ist die Konstante 60, und ihr Fehler ist .    Gegeben bleibt nur zufällig, also und nach ein Fehler von 20. Erklärt werden  % der Varianz.     Wer nur den Korrelationskoeffizienten ansieht, hält die Temperatur für bedeutungslos; tatsächlich erklärt sie vier Fünftel der Schwankung. Eine Regressionsgerade findet nur lineare Zusammenhänge. Verfahren, die flexibler schätzen, etwa Regressionsbäume oder neuronale Netze, oder eine Gerade in einem passenden Merkmal wie , finden auch diesen.      Zufallsvektoren und Kovarianzmatrix  Ein Datensatz hat meist viele Spalten, und ein einzelner Datenpunkt ist ein Vektor von Messwerten. Für zwei Zufallsvariablen reichen zwei Varianzen und eine Kovarianz, für sind es Varianzen und Kovarianzen. Man ordnet sie in einer Matrix an und rechnet mit Matrix-Vektor-Produkten. Aus der linearen Algebra brauchen wir nur das Produkt von Matrizen und Vektoren und die Transponierte: Für einen Spaltenvektor ist der zugehörige Zeilenvektor, und für eine Matrix mit Einträgen hat die Einträge .   Zufallsvektor, Erwartungsvektor, Kovarianzmatrix  Zufallsvektor  Erwartungsvektor  Kovarianzmatrix   Seien Zufallsvariablen auf demselben Wahrscheinlichkeitsraum mit endlichen Varianzen. Der Spaltenvektor heißt Zufallsvektor . Sein Erwartungsvektor ist , seine Kovarianzmatrix ist die -Matrix mit den Einträgen     Auf der Diagonalen stehen die Varianzen , und weil ist, ist symmetrisch, . Für den Erwartungsvektor braucht man nur die Randverteilungen, für die Kovarianzmatrix die gemeinsamen Verteilungen von je zwei Komponenten. Teilt man jeden Eintrag durch , erhält man die Korrelationsmatrix Korrelationsmatrix mit Einsen auf der Diagonalen. In der Datenanalyse ist sie oft das erste Bild eines neuen Datensatzes: eine farbige Tabelle der Korrelationen aller Merkmale, an der man ablesen kann, welche Merkmale fast dasselbe messen.   Lineare Abbildungen von Zufallsvektoren   Sei ein -dimensionaler Zufallsvektor mit Erwartungsvektor und Kovarianzmatrix , eine -Matrix und . Dann ist Insbesondere ist für      Die -te Komponente von ist . Die erste Formel ist die Linearität des Erwartungswerts. Nach den Rechenregeln für die Kovarianz fällt weg, und das ist der Eintrag von . Der Sonderfall ist mit .    Die letzte Formel ist mit Gewichten. Weil eine Varianz nie negativ ist, folgt sofort eine Eigenschaft jeder Kovarianzmatrix.   Kovarianzmatrizen sind positiv semidefinit  positiv semidefinit  Kovarianzmatrix positiv semidefinit   Für jede Kovarianzmatrix und jedes ist .    Nicht jede symmetrische Matrix mit positiver Diagonale und Korrelationen zwischen und 1 ist deshalb eine Kovarianzmatrix. Drei Größen mit Varianz 1 können zum Beispiel nicht paarweise die Korrelation haben: Mit wäre . Wer eine Kovarianzmatrix von Hand zusammensetzt, etwa für eine Simulation, sollte das prüfen.  Bei der Multinomialverteilung aus ist und . Jede Zeile summiert sich zu , also ist für . Das muss so sein: Die Summe aller Anzahlen ist immer und hat die Varianz 0.   Ein Portfolio aus drei Anlagen   Ein Fonds legt die Anteile seines Geldes in Aktien, Anleihen und Immobilien an. Ihre Jahresrenditen (in Prozent) haben die Erwartungswerte , die Standardabweichungen und die Korrelationskoeffizienten , und . Die Rendite des Fonds ist .  Stellen Sie die Kovarianzmatrix auf.   Bestimmen Sie Erwartungswert und Standardabweichung der Fondsrendite.    Welche Standardabweichung ergäbe sich, wenn man die Kovarianzen vergäße? Vergleichen Sie mit einer reinen Aktienanlage.    Bestimmen Sie mit die Kovarianzmatrix des Vektors aus Fondsrendite und Aktienrendite. Wie stark sind die beiden korreliert?           , also      . Mit ist also eine Standardabweichung von 12 Prozentpunkten.    Nur mit der Diagonale: , also etwa . Die reine Aktienanlage hat den Erwartungswert 8 und die Standardabweichung 20.    Der Vektor ist mit seine Kovarianzmatrix nach dem Satz also . Die erste Zeile von ist aus (b), die zweite ist die erste Zeile von . Danach multipliziert man von rechts mit , dessen Spalten und sind: Unten links steht zum Beispiel . Auf der Diagonalen stehen die Varianzen von Fonds und Aktien, daneben ihre Kovarianz 234. Der Korrelationskoeffizient ist : Der Fonds hängt fast vollständig an den Aktien, obwohl nur die Hälfte des Geldes in ihnen steckt.     Gegenüber reinen Aktien gibt der Fonds gut ein Viertel der erwarteten Rendite auf und senkt dafür die Standardabweichung um zwei Fünftel. Die positiven Korrelationen kosten ihn dabei etwas: Wer sie übersieht, unterschätzt das Risiko um rund ein Achtel. Diese Rechnung ist der Kern der Portfoliotheorie von Harry Markowitz ( Portfolio Selection , Journal of Finance 7 (1952), 77 91; ).    Die Kovarianzmatrix sagt auch, in welcher Richtung ein Datensatz am stärksten streut. Das ist die Idee der Hauptkomponentenanalyse (englisch principal component analysis , PCA), mit der man viele korrelierte Merkmale auf wenige zusammenfasst.   Vertiefung: die Richtung der größten Streuung  Hauptkomponentenanalyse   Zwei Merkmale und eines Datensatzes haben beide die Varianz 4 und den Korrelationskoeffizienten . Für einen Einheitsvektor ist die Projektion der Daten auf die Richtung .   Bestimmen Sie als Funktion von .   In welcher Richtung ist sie am größten, in welcher am kleinsten?   Welcher Anteil der Gesamtvarianz entfällt auf die Richtung der größten Streuung?          Mit ist     Am größten für , also  Grad, die Richtung , mit Varianz . Am kleinsten für  Grad, die Richtung , mit Varianz .    %.    Die Projektion auf , im Wesentlichen der Mittelwert der beiden Merkmale, heißt erste Hauptkomponente . Sie trägt neun Zehntel der Streuung; wer die beiden Merkmale durch sie ersetzt, verliert wenig. Allgemein sind die Richtungen der Hauptkomponenten die Eigenvektoren der Kovarianzmatrix und ihre Varianzen die Eigenwerte. Das gehört in die lineare Algebra und wird hier nicht weiter gebraucht.      Die zweidimensionale Normalverteilung  Die Normalverteilung aus hat ein Gegenstück für Zufallsvektoren. Sie ist durch den Erwartungsvektor und die Kovarianzmatrix vollständig bestimmt, und für sie werden die Begriffe dieses Abschnitts besonders einfach. Wir behandeln sie in zwei Dimensionen und geben die allgemeine Formel am Ende an.   Zweidimensionale Normalverteilung  Normalverteilung zweidimensionale  zweidimensionale Normalverteilung   Seien , und . Der Zufallsvektor heißt zweidimensional normalverteilt , wenn er die gemeinsame Dichte mit und hat. Mit und der Matrix schreibt man .     Ränder und bedingte Verteilung   Sei wie in der Definition.    und .    Gegeben ist normalverteilt mit      . Also ist die Kovarianzmatrix und der Korrelationskoeffizient von und .   und sind genau dann unabhängig, wenn ist.      Der Kern ist eine quadratische Ergänzung: . Damit zerfällt die Dichte in zwei Faktoren, Wegen ist der zweite Faktor als Funktion von die Dichte der Normalverteilung mit Erwartungswert und Varianz . Sein Integral über ist 1, also ist der erste Faktor die Randdichte von , die Dichte von . Teilt man durch sie, bleibt der zweite Faktor als bedingte Dichte. Das ist (1) für und (2); für vertauscht man die Rollen. (3) Nach , Teil (2), mit ist (4) Für ist die Dichte das Produkt der beiden Randdichten, und das Produktkriterium aus liefert die Unabhängigkeit. Umgekehrt sind unabhängige Zufallsvariablen unkorreliert.    Bei der zweidimensionalen Normalverteilung ist die bedingte Erwartung also eine Gerade, und zwar genau die Regressionsgerade aus . Nach ist die Gerade hier die beste Vorhersage überhaupt, und der Restfehler hängt nicht einmal von ab. Das ist der Grund, warum lineare Regression und Normalverteilung so oft zusammen auftreten. Ebenso besonders ist (4): Für gemeinsam normalverteilte Größen folgt aus unkorreliert schon unabhängig. Dass beide Randverteilungen normal sind, genügt dafür nicht. Ist etwa und mit einem davon unabhängigen Vorzeichen , das mit Wahrscheinlichkeit je gleich 1 oder ist, so ist auch und , aber .  Die Höhenlinien der Dichte sind die Kurven, auf denen der Exponent konstant ist, also die Ellipsen ( ). Für sind sie nach rechts oben geneigt, für nach rechts unten, für und sind es Kreise.   Höhenlinien der Dichte für , und . Durchgezogen die Regressionsgerade , gepunktet die Hauptachse der Ellipsen. Die Regressionsgerade halbiert jede senkrechte Sehne der Ellipsen, denn bei festem ist die bedingte Dichte symmetrisch um . Deshalb trifft sie die Ellipsen dort, wo diese senkrechte Tangenten haben.   Vier ineinander liegende, schräg gestellte Ellipsen mit zwei Geraden durch den Ursprung   Ein Koordinatensystem von bis 3 in beiden Richtungen. Vier ineinander liegende Ellipsen um den Ursprung, nach rechts oben geneigt. Eine gepunktete Gerade läuft durch die langen Achsen der Ellipsen. Eine flachere, durchgezogene Gerade schneidet jede Ellipse in ihrem am weitesten rechts und ihrem am weitesten links liegenden Punkt. Eine Legende unten rechts benennt die beiden Geraden.       Wird es morgen heiß?   Die Tageshöchsttemperaturen von heute und von morgen (in C) seien an einem Ort im Juli gemeinsam normalverteilt mit , und . Heute waren es 30  C.  Wie ist gegeben verteilt?   Mit welcher Wahrscheinlichkeit wird es morgen heißer als 32  C? Vergleichen Sie mit der Wahrscheinlichkeit ohne Kenntnis der heutigen Temperatur.    Ab welcher heutigen Temperatur ist ein Tag über 32  C morgen wahrscheinlicher als nicht?          Nach normal mit Erwartungswert und Varianz , also Standardabweichung 3.     . Ohne Kenntnis von heute ist .    Wahrscheinlicher als nicht heißt mehr als , also muss der bedingte Erwartungswert, zugleich der Median der bedingten Normalverteilung, über 32 liegen: , also   C.     Ein heißer Tag macht einen heißen Folgetag etwa doppelt so wahrscheinlich. Und wegen sagt das Modell für morgen immer eine Temperatur näher am Julimittel voraus als heute: Erst ab knapp 34  C heute rechnet es eher mit über 32 morgen. So arbeitet die einfachste statistische Wettervorhersage; echte Modelle bedingen auf viele Größen zugleich.     Vertiefung: Dimensionen  Allgemein heißt ein Zufallsvektor mit Werten im normalverteilt, , wenn er für einen Vektor und eine symmetrische, positiv semidefinite und invertierbare Matrix die Dichte hat. Symmetrisch und positiv semidefinit ist nach jede Kovarianzmatrix; neu ist nur, dass invertierbar sein muss. Für ist das die Dichte der Definition: Es ist , und ausmultipliziert ergibt die quadratische Form im Exponenten genau . Ohne Beweis halten wir fest: ist der Erwartungsvektor und die Kovarianzmatrix, jede Komponente ist normalverteilt, und für eine Matrix mit linear unabhängigen Zeilen ist wieder normalverteilt, mit den Parametern aus . Dass insbesondere Summen unabhängiger normalverteilter Größen normalverteilt sind, zeigt . Ist eine Diagonalmatrix, zerfällt die Dichte in ein Produkt, und die Komponenten sind unabhängig. Mit dieser Verteilung arbeiten unter anderem der Kalman-Filter, der Messungen mehrerer Sensoren zu einer Schätzung verschmilzt, und viele Verfahren zur Klassifikation und Anomalieerkennung.     Zusammenfassung      Kovarianz.  . Positiv, wenn große Werte von eher mit großen Werten von auftreten. Sie ist symmetrisch, , , sie ist in jedem Argument additiv, und unabhängige Zufallsvariablen haben die Kovarianz 0.     Varianz einer Summe.  und . Daraus folgen die Varianz der hypergeometrischen Verteilung und die Kovarianz der Multinomial-Anzahlen. Der Mittelwert von Größen mit Varianz und paarweiser Korrelation hat die Varianz .     Korrelationskoeffizient.  , unabhängig von den Einheiten, mit und genau bei einem exakt linearen Zusammenhang. Unabhängig heißt unkorreliert, aber nicht umgekehrt: Die Korrelation misst nur den linearen Teil eines Zusammenhangs. Und sie sagt nichts über Ursache und Wirkung; oft steckt eine gemeinsame Ursache dahinter.     Bedingte Verteilung und bedingte Erwartung.  bzw. , umgestellt die Multiplikationsregel für zweistufige Modelle. ist der Erwartungswert der bedingten Verteilung, und ist die Zufallsvariable, die entsteht, wenn man für einsetzt.     Iterierter Erwartungswert.  und ; bei Unabhängigkeit ist . In zweistufigen Modellen ist das der kürzeste Weg zu Erwartungswerten und Kovarianzen.     Vorhersage. Die beste lineare Vorhersage von aus ist die Regressionsgerade mit dem mittleren quadratischen Fehler ; sie erklärt den Anteil der Varianz. Die beste Vorhersage überhaupt ist , mit dem Fehler , und . Beide stimmen genau dann überein, wenn linear ist.     Zufallsvektoren. Erwartungsvektor und Kovarianzmatrix mit , symmetrisch. Es gilt , und .     Zweidimensionale Normalverteilung.  ist durch Erwartungsvektor und Kovarianzmatrix bestimmt. Die Ränder sind normal, und gegeben ist normal mit Erwartungswert und Varianz . Gemeinsam normalverteilte Größen sind genau dann unabhängig, wenn sie unkorreliert sind.       Übungsaufgaben   Gutschein und Warenkorb   Sei , wenn ein Kunde einen Gutschein hat, sonst , und die Zahl der Artikel, die er kauft. Die gemeinsame Wahrscheinlichkeitsfunktion ist      \\ 0 1 2   0 0,30 0,15 0,05  1 0,10 0,20 0,20      Bestimmen Sie und . Ein Taschenrechner ist erlaubt.    Bestimmen Sie und , und prüfen Sie damit .   Bestimmen Sie .          , und , also . Mit und ist .     und . Gewichtet: .     .        Noch einmal die Dichte auf dem Dreieck   In haben und die gemeinsame Dichte auf , und es ist , , .   Bestimmen Sie und . Hinweis : und .    Bestimmen Sie die bedingte Dichte von gegeben und . Prüfen Sie mit .    Bestimmen Sie die Regressionsgerade von auf . Warum stimmt sie mit überein?    Bestimmen Sie umgekehrt ; nach ist . Ist das eine Gerade in ? Vergleichen Sie bei und mit der Regressionsgeraden von auf .           , , , also .     , also für : Gegeben ist gleichverteilt auf , und . Damit .     und , also . Die bedingte Erwartung ist schon eine Gerade, und als beste Vorhersage überhaupt ist sie auch die beste lineare.     für , also keine Gerade. Die Regressionsgerade von auf hat die Steigung und geht durch , also . Bei ist gegen , bei ist es 1 gegen . In diese Richtung ist die Gerade nur eine Näherung der besten Vorhersage.        Rechnen mit Kovarianzen   Für und sei , und .  Bestimmen Sie und .  Bestimmen Sie .   Bestimmen Sie und den Korrelationskoeffizienten von und .           und .    Ausmultiplizieren mit den Rechenregeln: .     . Die Faktoren 2 und haben verschiedene Vorzeichen, die Konstante 1 spielt keine Rolle. Nach , Teil (3), ist der Korrelationskoeffizient also . Zur Probe: und .        Ein Ersatzwert für einen ausgefallenen Pegel   Zwei Messstellen an einem Fluss melden die Wasserstände (oberhalb) und (unterhalb), in Zentimetern über einer Bezugsmarke. Sie seien gemeinsam normalverteilt mit , , , und . Ein Taschenrechner ist erlaubt.   Bestimmen Sie und die Kovarianzmatrix von .    Die obere Messstelle fällt aus, die untere meldet 45 cm. Wie ist der fehlende Wert gegeben diese Meldung verteilt?    Welchen Wasserstand hatte die obere Messstelle mit Wahrscheinlichkeit 90 % mindestens? Benutzen Sie die Tabelle der Quantile aus .           und .    Mit vertauschten Rollen in ist gegeben normalverteilt mit Erwartungswert und Varianz , also Standardabweichung .    Gesucht ist das 10-%-Quantil der bedingten Verteilung:  cm.     Ein solcher Ersatzwert samt Unsicherheit ist eine einfache Form der Imputation fehlender Daten: Statt die Lücke mit dem Mittel 40 zu füllen, nutzt man, was die andere Messstelle verrät.     "
},
{
  "id": "sec-kovarianz-korrelation-zufallsvektoren-2",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sec-kovarianz-korrelation-zufallsvektoren-2",
  "type": "Lernziele",
  "number": "4.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     die Kovarianz zweier Zufallsvariablen berechnen, mit ihren Rechenregeln umformen und die Varianz einer Summe abhängiger Zufallsvariablen bestimmen,    den Korrelationskoeffizienten berechnen und deuten, begründen, warum er zwischen und 1 liegt, und an Beispielen zeigen, dass unkorrelierte Zufallsvariablen abhängig sein können,    bedingte Wahrscheinlichkeitsfunktionen, bedingte Dichten und bedingte Erwartungen bestimmen und den Erwartungswert über die bedingte Erwartung berechnen, ,    die beste lineare Vorhersage von aus samt Restfehler aufstellen und mit der bedingten Erwartung als bester Vorhersage überhaupt vergleichen,    mit Erwartungsvektor und Kovarianzmatrix rechnen, insbesondere anwenden,    bei einer zweidimensionalen Normalverteilung die Randverteilungen und die bedingte Verteilung von gegeben angeben.    "
},
{
  "id": "def-kovarianz",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-kovarianz",
  "type": "Definition",
  "number": "4.2.1",
  "title": "Kovarianz.",
  "body": " Kovarianz  Kovarianz  unkorreliert   Seien und Zufallsvariablen auf demselben Wahrscheinlichkeitsraum mit Erwartungswerten , und endlichen Varianzen. Die Kovarianz von und ist Ist , so heißen und  unkorreliert .   "
},
{
  "id": "thm-kovarianz-rechenregeln",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-kovarianz-rechenregeln",
  "type": "Satz",
  "number": "4.2.2",
  "title": "Rechenregeln für die Kovarianz.",
  "body": " Rechenregeln für die Kovarianz  Kovarianz Rechenregeln   Seien , und Zufallsvariablen mit endlichen Varianzen und .  .  und .    und . Wegen (2) gilt dasselbe im zweiten Argument.   Sind und unabhängig, so ist .      (1) Ausmultiplizieren und die Linearität des Erwartungswerts:   (2) folgt direkt aus der Definition. (3) Es ist , also , und der Faktor geht vor den Erwartungswert. Ebenso ist ; man multipliziert mit und bildet den Erwartungswert gliedweise. (4) folgt aus (1) und , also aus bzw. .   "
},
{
  "id": "thm-varianz-summe",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-varianz-summe",
  "type": "Satz",
  "number": "4.2.3",
  "title": "Varianz einer Summe.",
  "body": " Varianz einer Summe  Varianz einer Summe   Für Zufallsvariablen und mit endlichen Varianzen ist Allgemein gilt für mit endlichen Varianzen     Nach Regel (2) ist für , und nach Regel (3) in beiden Argumenten Die Summanden mit sind die Varianzen. Jedes Paar kommt zweimal vor, als und als , mit derselben Kovarianz. Für setzt man , und benutzt .   "
},
{
  "id": "ex-kovarianz-wuerfel",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-kovarianz-wuerfel",
  "type": "Beispiel",
  "number": "4.2.4",
  "title": "Wie stark hängen Minimum und Maximum zusammen?",
  "body": " Wie stark hängen Minimum und Maximum zusammen?   In der Situation von sind und Minimum und Maximum der Augenzahlen , zweier fairer Würfel.   Bestimmen Sie und aus den Randverteilungen.    Bestimmen Sie und . Hinweis : Welches Produkt der Augenzahlen ist ?    Es ist . Bestimmen Sie mit , und prüfen Sie das Ergebnis ohne Kovarianz.          Mit ist . Weil ist, folgt ohne weitere Summe .    Minimum mal Maximum ist das Produkt der beiden Augenzahlen, . Die Würfel sind unabhängig, also , und nach Regel (1)      . Ohne Kovarianz: ist die Summe zweier unabhängiger Würfe, also .     Die Kovarianz ist positiv: Ein großes Minimum zwingt das Maximum nach oben. Hätte man die Varianzen einfach addiert, käme man auf etwa statt ; ein Drittel der Streuung der Summe stammt aus dem Zusammenhang. Wie stark dieser ist, lässt sich an allein noch nicht ablesen, denn die Kovarianz hängt von den Einheiten ab. Das holt nach.   "
},
{
  "id": "prop-varianz-hypergeometrisch",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#prop-varianz-hypergeometrisch",
  "type": "Proposition",
  "number": "4.2.5",
  "title": "Varianz der hypergeometrischen Verteilung.",
  "body": " Varianz der hypergeometrischen Verteilung   Für und ist     Wie in sei das Ereignis, dass die -te Ziehung ein Stück mit der Eigenschaft bringt, und . Jedes geordnete Paar verschiedener Stücke landet mit derselben Wahrscheinlichkeit an den Positionen , also ist . Nach Regel (1), mit : Jeder Indikator hat die Varianz , und es gibt Paare . Nach ist    "
},
{
  "id": "prop-kovarianz-multinomial",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#prop-kovarianz-multinomial",
  "type": "Proposition",
  "number": "4.2.6",
  "title": "Kovarianz der Multinomial-Anzahlen.",
  "body": " Kovarianz der Multinomial-Anzahlen   Ist , so ist für      Fasst man die Klassen und zu einer zusammen, zählt die Erfolge mit Wahrscheinlichkeit , ist also -verteilt. Mit , aufgelöst nach der Kovarianz:    "
},
{
  "id": "def-korrelationskoeffizient",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-korrelationskoeffizient",
  "type": "Definition",
  "number": "4.2.7",
  "title": "Korrelationskoeffizient.",
  "body": " Korrelationskoeffizient  Korrelationskoeffizient  Korrelation   Seien und Zufallsvariablen mit positiven, endlichen Varianzen. Der Korrelationskoeffizient von und ist    "
},
{
  "id": "thm-korrelation-schranke",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-korrelation-schranke",
  "type": "Satz",
  "number": "4.2.8",
  "title": "Eigenschaften des Korrelationskoeffizienten.",
  "body": " Eigenschaften des Korrelationskoeffizienten     .    genau dann, wenn mit Wahrscheinlichkeit 1 mit Konstanten und gilt; genau dann, wenn das mit gilt.    Für Konstanten mit ist , falls und dasselbe Vorzeichen haben, und sonst.       Wir standardisieren: und haben die Varianz 1, und nach den Rechenregeln ist . Mit : Mit dem Pluszeichen folgt , mit dem Minuszeichen . Das ist (1).  (2) Ist , so ist . Eine Zufallsvariable mit Varianz 0 ist mit Wahrscheinlichkeit 1 gleich ihrem Erwartungswert, hier 0, denn ihre quadrierte Abweichung ist nicht negativ und hat den Erwartungswert 0 (eine nicht negative Größe mit Erwartungswert 0 ist mit Wahrscheinlichkeit 1 gleich 0, sonst wäre ihr Erwartungswert positiv). Also ist , das heißt , eine Gerade mit positiver Steigung. Für benutzt man . Ist umgekehrt , so ist und , also .  (3) Nach den Rechenregeln wird die Kovarianz mit multipliziert, das Produkt der Standardabweichungen mit .   "
},
{
  "id": "fig-punktwolken",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#fig-punktwolken",
  "type": "Abbildung",
  "number": "4.2.9",
  "title": "",
  "body": " Je 150 Punkte . Oben normalverteilte Paare mit , und , unten links mit . Die beiden anderen Wolken haben ebenfalls , aber und hängen deutlich zusammen: liegt nahe einer Parabel über , oder der Punkt ist gleichverteilt auf einer Kreisscheibe wie in .   Sechs Punktwolken mit verschiedenen Korrelationskoeffizienten   Sechs quadratische Felder in zwei Reihen, jedes mit einer Wolke aus 150 Punkten. Oben links liegen die Punkte eng um eine steigende Gerade ( ), daneben locker um eine steigende Gerade ( ), oben rechts bilden sie einen runden Fleck ohne Richtung ( ). Unten links liegen sie um eine fallende Gerade ( ). Unten in der Mitte bilden sie einen nach oben offenen Bogen, unten rechts füllen sie gleichmäßig eine Kreisscheibe; beide haben .     "
},
{
  "id": "ex-wuerfel-korrelation",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-wuerfel-korrelation",
  "type": "Beispiel",
  "number": "4.2.10",
  "title": "Minimum und Maximum, normiert.",
  "body": " Minimum und Maximum, normiert   Bestimmen Sie in der Situation von den Korrelationskoeffizienten von und . Ändert er sich, wenn ein Spiel für das Minimum Punkte vergibt?    Beide Varianzen sind , also Nach , Teil (3), hat mit denselben Korrelationskoeffizienten, obwohl die Kovarianz zehnmal so groß ist.  Ein Wert von knapp beschreibt einen deutlichen, aber keineswegs festen Zusammenhang: Zum Minimum 1 passt jedes Maximum von 1 bis 6. Die Zahl ist dieselbe, ob man in Augen, Punkten oder Euro rechnet; deshalb vergleicht man in Datensätzen Korrelationen und nicht Kovarianzen.   "
},
{
  "id": "ex-wafer-unkorreliert",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-wafer-unkorreliert",
  "type": "Beispiel",
  "number": "4.2.11",
  "title": "Defekte auf dem Wafer, noch einmal.",
  "body": " Defekte auf dem Wafer, noch einmal   In ist die Lage eines Defekts gleichverteilt auf der Kreisscheibe mit Radius 10. Zeigen Sie, dass und unkorreliert sind. Sind sie unabhängig?    Die Dichte ist konstant auf einer Scheibe, die symmetrisch zu beiden Achsen liegt. Zu jedem Punkt der Scheibe gehört der Punkt mit derselben Dichte, und dort hat das umgekehrte Vorzeichen. Im Doppelintegral für heben sich die beiden Hälften links und rechts der -Achse also auf: . Ebenso ist , und .  Unabhängig sind sie nicht: , Teil (c), hat gezeigt. Der runde Rand koppelt die Koordinaten, aber nicht linear: Ein großes macht ein großes unmöglich, egal in welcher Richtung. Die Kovarianz sieht davon nichts: Sie misst nur, ob große Werte von eher mit großen oder eher mit kleinen Werten von zusammen auftreten. Wegen der Symmetrie der Scheibe kommen zu jedem Wert von große und kleine Werte von gleich häufig vor, und das hebt sich genau auf.   "
},
{
  "id": "sub-korrelation-10-2",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-korrelation-10-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "gemeinsamen Ursache "
},
{
  "id": "ex-gemeinsame-ursache",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-gemeinsame-ursache",
  "type": "Beispiel",
  "number": "4.2.12",
  "title": "Fehlermeldungen und Supporttickets.",
  "body": " Fehlermeldungen und Supporttickets   Ein Onlinedienst zählt täglich die Fehlermeldungen und die Supporttickets . Beide hängen von der Zahl der aktiven Nutzer ab. Als Modell sei und , wobei die Abweichung der Nutzerzahl vom Mittel ist und , zufällige Schwankungen sind, die mit den Nutzern nichts zu tun haben. , und seien unabhängig mit , und .  Bestimmen Sie und .   Ein Team sieht die Korrelation und schlägt vor, weniger Fehlermeldungen anzuzeigen, damit weniger Tickets kommen. Was bewirkt das in diesem Modell?    Wie hängen und an Tagen mit derselben Nutzerzahl, also festem Wert , zusammen?          Mit den Rechenregeln und der Unabhängigkeit fallen alle Terme mit oder weg: . Weiter ist und , also .    Nichts. Im Modell kommt in der Formel für gar nicht vor. Wer Fehlermeldungen unterdrückt, verändert , aber weder noch . Nur von diesen hängt ab, und die Tickets bleiben, wie sie sind.    Bei festem ist und . Diese hängen nur noch über die unabhängigen Schwankungen und vom Zufall ab, sind also unabhängig und erst recht unkorreliert.     Die ganze Korrelation von stammt aus der gemeinsamen Ursache. Aus Daten allein lässt sich das nicht vom Fall unterscheiden, in dem Fehlermeldungen tatsächlich Tickets auslösen. Man trennt die beiden, indem man die vermutete Ursache festhält, wie in (c), oder indem man in einem Experiment gezielt nur verändert, etwa in einem A\/B-Test.   "
},
{
  "id": "ex-mittel-korreliert",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-mittel-korreliert",
  "type": "Beispiel",
  "number": "4.2.13",
  "title": "Mitteln über korrelierte Modelle.",
  "body": " Mitteln über korrelierte Modelle   Ein Ensemble mittelt die Vorhersagen von Modellen. Ihre Fehler haben den Erwartungswert 0 und die Varianz , und je zwei von ihnen haben den Korrelationskoeffizienten , weil die Modelle auf ähnlichen Daten trainiert sind.   Zeigen Sie, dass der gemittelte Fehler die Varianz hat.    Werten Sie für aus. Was geschieht für sehr große ?   Was folgt daraus für den Bau eines Ensembles?         Jede Kovarianz ist . Nach mit Varianzen und Paaren ist     Für : , also eine Standardabweichung von etwa statt 2 beim einzelnen Modell. Für geht die Varianz gegen ; die Standardabweichung fällt nie unter 1, wie viele Modelle man auch mittelt.    Mehr Modelle helfen nur gegen den unkorrelierten Teil des Fehlers. Den gemeinsamen Teil senkt man nur, indem man die Modelle unähnlicher macht.     Für ist das , für bringt das Mitteln gar nichts. Das Gesetz der großen Zahlen, das Sie in kennenlernen ( ), wird deshalb unabhängige oder wenigstens unkorrelierte Größen voraussetzen; greift dieses Beispiel dort wieder auf. Ein Random Forest trainiert seine Bäume aus demselben Grund absichtlich auf zufällig gezogenen Teilen der Daten und mit zufällig ausgewählten Merkmalen: Jeder einzelne Baum wird dadurch etwas schlechter, aber die Korrelation zwischen den Bäumen sinkt, und das zahlt sich im Mittel aus.   "
},
{
  "id": "def-bedingte-verteilung",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-bedingte-verteilung",
  "type": "Definition",
  "number": "4.2.14",
  "title": "Bedingte Wahrscheinlichkeitsfunktion und bedingte Dichte.",
  "body": " Bedingte Wahrscheinlichkeitsfunktion und bedingte Dichte  bedingte Wahrscheinlichkeitsfunktion  Wahrscheinlichkeitsfunktion bedingte  bedingte Verteilung  Verteilung bedingte  bedingte Dichte  Dichte bedingte      Seien und diskret und . Die bedingte Wahrscheinlichkeitsfunktion von gegeben ist     Haben und die gemeinsame Dichte und ist , so ist die bedingte Dichte von gegeben  und man setzt .      "
},
{
  "id": "def-bedingte-erwartung",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-bedingte-erwartung",
  "type": "Definition",
  "number": "4.2.15",
  "title": "Bedingte Erwartung.",
  "body": " Bedingte Erwartung  bedingte Erwartung  Erwartungswert bedingter   Die bedingte Erwartung von gegeben ist der Erwartungswert der bedingten Verteilung, im diskreten Fall und bei gemeinsamer Dichte, sofern die Summe bzw. das Integral mit endlich ist. Ebenso ist definiert.   "
},
{
  "id": "ex-bedingt-wuerfel",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-bedingt-wuerfel",
  "type": "Beispiel",
  "number": "4.2.16",
  "title": "Das Maximum, wenn das Minimum bekannt ist.",
  "body": " Das Maximum, wenn das Minimum bekannt ist   In der Situation von sei das Minimum und das Maximum zweier fairer Würfel.   Bestimmen Sie die bedingte Wahrscheinlichkeitsfunktion von gegeben .   Bestimmen Sie für .   Mitteln Sie die Werte aus (b) mit den Gewichten . Was kommt heraus?          Die Zeile der Tabelle enthält bei und bei jedem ; ihre Summe ist . Also und 0 für . Für etwa nimmt die Werte 4, 5, 6 mit den Wahrscheinlichkeiten an.    Mit ist also der Reihe nach , , , , und 6.    Der Faktor kürzt sich:      Ohne weitere Information erwartet man als Maximum ; weiß man, dass das Minimum 1 war, nur noch , bei Minimum 5 schon . Teil (c) ist kein Zufall, sondern .   "
},
{
  "id": "ex-bedingt-erste-letzte",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-bedingt-erste-letzte",
  "type": "Beispiel",
  "number": "4.2.17",
  "title": "Wann kommt die letzte Anfrage?",
  "body": " Wann kommt die letzte Anfrage?   In haben der Zeitpunkt der ersten und der Zeitpunkt der letzten von drei Anfragen die gemeinsame Dichte auf , und es ist .   Bestimmen Sie die bedingte Dichte von gegeben für .   Bestimmen Sie .   Die erste Anfrage kommt bei . Wann ist das Bündel im Mittel vollständig?           für , sonst 0. Bei festem steigt sie linear von 0 auf ; das Integral über ist die Dreiecksfläche .    Mit :      : im Mittel nach  Sekunden.     Das Ergebnis lässt sich deuten: Steht die erste Anfrage bei fest, liegen die beiden anderen irgendwo in , und die spätere von ihnen kommt im Mittel nach zwei Dritteln dieses Intervalls. Für den Dienst heißt das: Eine frühe erste Anfrage verspricht noch keine frühe Verarbeitung, denn ist nie kleiner als .   "
},
{
  "id": "def-bedingte-erwartung-zufallsvariable",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-bedingte-erwartung-zufallsvariable",
  "type": "Definition",
  "number": "4.2.18",
  "title": "Bedingte Erwartung als Zufallsvariable.",
  "body": " Bedingte Erwartung als Zufallsvariable  bedingte Erwartung als Zufallsvariable   Ist , so heißt die Zufallsvariable die bedingte Erwartung von gegeben .   "
},
{
  "id": "thm-iterierter-erwartungswert",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-iterierter-erwartungswert",
  "type": "Satz",
  "number": "4.2.19",
  "title": "Satz vom iterierten Erwartungswert.",
  "body": " Satz vom iterierten Erwartungswert  iterierter Erwartungswert  Erwartungswert iterierter  Satz vom iterierten Erwartungswert   Seien und diskret oder mit gemeinsamer Dichte, und existiere.  .   Für jede Funktion , für die existiert, ist .    Sind und unabhängig, so ist .       (2) im diskreten Fall: Mit und dem Transformationssatz für die Funktion von ist die letzte Gleichung nach , Teil (2). Mit Dichten ersetzt man die Summen durch Integrale und benutzt ; der Faktor kürzt sich ebenso. (1) ist (2) mit . (3) Bei Unabhängigkeit ist die bedingte Verteilung gleich der Randverteilung von , also für jedes .   "
},
{
  "id": "ex-sehdauer",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-sehdauer",
  "type": "Beispiel",
  "number": "4.2.20",
  "title": "Wie lange wird ein Video angesehen?",
  "body": " Wie lange wird ein Video angesehen?   Auf einer Plattform hat ein zufällig gewähltes Video die Länge (in Minuten), gleichverteilt auf . Ein Nutzer bricht an einer zufälligen Stelle ab: Gegeben ist die gesehene Dauer gleichverteilt auf .  Geben Sie die gemeinsame Dichte von und an.   Bestimmen Sie und . Vergleichen Sie mit dem Weg über die Randdichte für .   Bestimmen Sie .         Nach der Multiplikationsregel ist für und 0 sonst.    Die bedingte Verteilung ist die Gleichverteilung auf , also und . Nach ist  Minuten. Über die Randdichte bräuchte man , also eine partielle Integration, mit demselben Ergebnis.    Nach Teil (2) des Satzes mit ist also .     Im Mittel wird ein Video zweieinhalb Minuten angesehen, längere Videos länger, daher die positive Kovarianz. Die Kennzahl mittlere Sehdauer mischt also zwei Dinge, die Länge der Videos und das Verhalten der Nutzer. Wer wissen will, ob Nutzer abspringen, schaut auf die bedingte Verteilung bei fester Länge, hier auf den Anteil .   "
},
{
  "id": "sub-vorhersage-2",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-vorhersage-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "mittleren quadratischen Fehler "
},
{
  "id": "thm-regressionsgerade",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-regressionsgerade",
  "type": "Satz",
  "number": "4.2.21",
  "title": "Beste lineare Vorhersage.",
  "body": " Beste lineare Vorhersage  Regressionsgerade  beste lineare Vorhersage  Vorhersage beste lineare   Seien und Zufallsvariablen mit positiven, endlichen Varianzen und Korrelationskoeffizient . Unter allen Vorhersagen der Form hat den kleinsten mittleren quadratischen Fehler, und dieser ist     Für festes ist ; die Zahl ist also eine konstante Vorhersage der Zufallsvariablen . Nach der Vorüberlegung ist am besten, mit dem Fehler nach . Das ist eine nach oben geöffnete Parabel in mit dem Scheitel bei , und dort ist der Wert .   "
},
{
  "id": "sub-vorhersage-5",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-vorhersage-5",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Regressionsgerade "
},
{
  "id": "sub-vorhersage-6",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-vorhersage-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Bestimmtheitsmaß "
},
{
  "id": "ex-regression-rechenzentrum",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-regression-rechenzentrum",
  "type": "Beispiel",
  "number": "4.2.22",
  "title": "Strombedarf aus der Auslastung.",
  "body": " Strombedarf aus der Auslastung   Für ein Rechenzentrum sei die Auslastung (in Prozent) und die Leistungsaufnahme (in kW) in einer Stunde. Aus dem Betrieb kennt man , , , und .  Bestimmen Sie die beste lineare Vorhersage von aus .   Welche Leistungsaufnahme sagt sie für eine Auslastung von 80 % vorher? Wie groß ist ihr mittlerer quadratischer Fehler, ausgedrückt als Standardabweichung?   Welcher Anteil der Varianz von wird durch die Auslastung erklärt?          kW je Prozentpunkt und , also .      kW. Der mittlere quadratische Fehler ist , also  kW als Standardabweichung.   , also 64 %.    80 % Auslastung liegen Standardabweichungen über dem Mittel, die Vorhersage nur Standardabweichungen. Die Gerade ist die beste lineare Vorhersage; über alle Stunden gemittelt liegt sie um 24 kW daneben, gemessen als Wurzel aus dem mittleren quadratischen Fehler. Ein gutes Drittel der Varianz bleibt also unerklärt, und wer die Stromversorgung plant, braucht über die 348 kW hinaus eine Reserve. Dass der Verbrauch bei 80 % Auslastung im Mittel wirklich 348 kW beträgt, ist nur sicher, wenn linear ist. Wie groß der Fehler gerade dort ist, hängt außerdem davon ab, wie stark der Verbrauch bei dieser Auslastung streut. Beides sagen fünf Kennzahlen allein nicht; mehr dazu in .   "
},
{
  "id": "sub-vorhersage-8-2",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-vorhersage-8-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "bedingte Varianz "
},
{
  "id": "thm-beste-vorhersage",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-beste-vorhersage",
  "type": "Satz",
  "number": "4.2.23",
  "title": "Die bedingte Erwartung ist die beste Vorhersage.",
  "body": " Die bedingte Erwartung ist die beste Vorhersage  beste Vorhersage  Vorhersage beste   Seien und diskret oder mit gemeinsamer Dichte, endlich und . Für jede Funktion mit endlichem ist also ist die Vorhersage mit dem kleinsten mittleren quadratischen Fehler, und dieser ist .    Man schreibt und quadriert. Für den gemischten Term setzt man ; nach , Teil (2), ist , also . Das ergibt die Zerlegung. Im diskreten Fall ist schließlich und mit Dichten ebenso mit Integralen.   "
},
{
  "id": "cor-varianzzerlegung",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#cor-varianzzerlegung",
  "type": "Korollar",
  "number": "4.2.24",
  "title": "Varianzzerlegung.",
  "body": " Varianzzerlegung  Varianzzerlegung   Unter denselben Voraussetzungen ist     Man setzt im Satz die Konstante ein. Links steht dann , rechts der Fehler von und . Weil ist, ist das die Varianz von .   "
},
{
  "id": "ex-erste-letzte-vorhersage",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-erste-letzte-vorhersage",
  "type": "Beispiel",
  "number": "4.2.25",
  "title": "Wenn die bedingte Erwartung eine Gerade ist.",
  "body": " Wenn die bedingte Erwartung eine Gerade ist   Für die erste und die letzte von drei Anfragen ist nach  . Aus und kennt man , , und .   Bestimmen Sie die Regressionsgerade von auf , und vergleichen Sie mit .   Bestimmen Sie und den Restfehler der Geraden.   Die bedingte Varianz ist . Prüfen Sie den Restfehler mit .           und . Die Gerade ist genau die bedingte Erwartung.     , weil beide Varianzen gleich sind. Restfehler: .    Mit ist      Weil die bedingte Erwartung hier linear ist, kann keine andere Funktion die letzte Anfrage besser vorhersagen als die Gerade. Sie erklärt aber nur der Varianz: Der Zeitpunkt der ersten Anfrage verrät wenig über den der letzten.   "
},
{
  "id": "ex-energie-temperatur",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-energie-temperatur",
  "type": "Beispiel",
  "number": "4.2.26",
  "title": "Heizen und Kühlen: Korrelation null, Zusammenhang stark.",
  "body": " Heizen und Kühlen: Korrelation null, Zusammenhang stark   Ein Bürogebäude wird bei Kälte geheizt und bei Hitze gekühlt. Als Modell sei die Außentemperatur (in C) gleichverteilt auf und die Leistungsaufnahme (in kW) wobei von unabhängig ist, mit und .  Bestimmen Sie und .   Zeigen Sie . Was ist die beste lineare Vorhersage? Bestimmen Sie ihren Fehler; dabei ist .    Welchen Fehler hat die bedingte Erwartung, und welchen Anteil der Varianz von erklärt sie?       Sei , gleichverteilt auf , also und .   Gegeben ist , und weil unabhängig von ist, ist . Also und .    Mit den Rechenregeln ist und , weil symmetrisch um 0 verteilt ist. Mit ist : Die beste Gerade ist die Konstante 60, und ihr Fehler ist .    Gegeben bleibt nur zufällig, also und nach ein Fehler von 20. Erklärt werden  % der Varianz.     Wer nur den Korrelationskoeffizienten ansieht, hält die Temperatur für bedeutungslos; tatsächlich erklärt sie vier Fünftel der Schwankung. Eine Regressionsgerade findet nur lineare Zusammenhänge. Verfahren, die flexibler schätzen, etwa Regressionsbäume oder neuronale Netze, oder eine Gerade in einem passenden Merkmal wie , finden auch diesen.   "
},
{
  "id": "def-zufallsvektor",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-zufallsvektor",
  "type": "Definition",
  "number": "4.2.27",
  "title": "Zufallsvektor, Erwartungsvektor, Kovarianzmatrix.",
  "body": " Zufallsvektor, Erwartungsvektor, Kovarianzmatrix  Zufallsvektor  Erwartungsvektor  Kovarianzmatrix   Seien Zufallsvariablen auf demselben Wahrscheinlichkeitsraum mit endlichen Varianzen. Der Spaltenvektor heißt Zufallsvektor . Sein Erwartungsvektor ist , seine Kovarianzmatrix ist die -Matrix mit den Einträgen    "
},
{
  "id": "sub-zufallsvektoren-4",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-zufallsvektoren-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Korrelationsmatrix "
},
{
  "id": "thm-affine-transformation-vektor",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-affine-transformation-vektor",
  "type": "Satz",
  "number": "4.2.28",
  "title": "Lineare Abbildungen von Zufallsvektoren.",
  "body": " Lineare Abbildungen von Zufallsvektoren   Sei ein -dimensionaler Zufallsvektor mit Erwartungsvektor und Kovarianzmatrix , eine -Matrix und . Dann ist Insbesondere ist für      Die -te Komponente von ist . Die erste Formel ist die Linearität des Erwartungswerts. Nach den Rechenregeln für die Kovarianz fällt weg, und das ist der Eintrag von . Der Sonderfall ist mit .   "
},
{
  "id": "cor-kovarianzmatrix-semidefinit",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#cor-kovarianzmatrix-semidefinit",
  "type": "Korollar",
  "number": "4.2.29",
  "title": "Kovarianzmatrizen sind positiv semidefinit.",
  "body": " Kovarianzmatrizen sind positiv semidefinit  positiv semidefinit  Kovarianzmatrix positiv semidefinit   Für jede Kovarianzmatrix und jedes ist .   "
},
{
  "id": "ex-portfolio",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-portfolio",
  "type": "Beispiel",
  "number": "4.2.30",
  "title": "Ein Portfolio aus drei Anlagen.",
  "body": " Ein Portfolio aus drei Anlagen   Ein Fonds legt die Anteile seines Geldes in Aktien, Anleihen und Immobilien an. Ihre Jahresrenditen (in Prozent) haben die Erwartungswerte , die Standardabweichungen und die Korrelationskoeffizienten , und . Die Rendite des Fonds ist .  Stellen Sie die Kovarianzmatrix auf.   Bestimmen Sie Erwartungswert und Standardabweichung der Fondsrendite.    Welche Standardabweichung ergäbe sich, wenn man die Kovarianzen vergäße? Vergleichen Sie mit einer reinen Aktienanlage.    Bestimmen Sie mit die Kovarianzmatrix des Vektors aus Fondsrendite und Aktienrendite. Wie stark sind die beiden korreliert?           , also      . Mit ist also eine Standardabweichung von 12 Prozentpunkten.    Nur mit der Diagonale: , also etwa . Die reine Aktienanlage hat den Erwartungswert 8 und die Standardabweichung 20.    Der Vektor ist mit seine Kovarianzmatrix nach dem Satz also . Die erste Zeile von ist aus (b), die zweite ist die erste Zeile von . Danach multipliziert man von rechts mit , dessen Spalten und sind: Unten links steht zum Beispiel . Auf der Diagonalen stehen die Varianzen von Fonds und Aktien, daneben ihre Kovarianz 234. Der Korrelationskoeffizient ist : Der Fonds hängt fast vollständig an den Aktien, obwohl nur die Hälfte des Geldes in ihnen steckt.     Gegenüber reinen Aktien gibt der Fonds gut ein Viertel der erwarteten Rendite auf und senkt dafür die Standardabweichung um zwei Fünftel. Die positiven Korrelationen kosten ihn dabei etwas: Wer sie übersieht, unterschätzt das Risiko um rund ein Achtel. Diese Rechnung ist der Kern der Portfoliotheorie von Harry Markowitz ( Portfolio Selection , Journal of Finance 7 (1952), 77 91; ).   "
},
{
  "id": "sub-zufallsvektoren-11",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-zufallsvektoren-11",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Hauptkomponentenanalyse "
},
{
  "id": "ex-hauptkomponenten",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-hauptkomponenten",
  "type": "Beispiel",
  "number": "4.2.31",
  "title": "Vertiefung: die Richtung der größten Streuung.",
  "body": " Vertiefung: die Richtung der größten Streuung  Hauptkomponentenanalyse   Zwei Merkmale und eines Datensatzes haben beide die Varianz 4 und den Korrelationskoeffizienten . Für einen Einheitsvektor ist die Projektion der Daten auf die Richtung .   Bestimmen Sie als Funktion von .   In welcher Richtung ist sie am größten, in welcher am kleinsten?   Welcher Anteil der Gesamtvarianz entfällt auf die Richtung der größten Streuung?          Mit ist     Am größten für , also  Grad, die Richtung , mit Varianz . Am kleinsten für  Grad, die Richtung , mit Varianz .    %.    Die Projektion auf , im Wesentlichen der Mittelwert der beiden Merkmale, heißt erste Hauptkomponente . Sie trägt neun Zehntel der Streuung; wer die beiden Merkmale durch sie ersetzt, verliert wenig. Allgemein sind die Richtungen der Hauptkomponenten die Eigenvektoren der Kovarianzmatrix und ihre Varianzen die Eigenwerte. Das gehört in die lineare Algebra und wird hier nicht weiter gebraucht.   "
},
{
  "id": "def-normalverteilung-zweidimensional",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#def-normalverteilung-zweidimensional",
  "type": "Definition",
  "number": "4.2.32",
  "title": "Zweidimensionale Normalverteilung.",
  "body": " Zweidimensionale Normalverteilung  Normalverteilung zweidimensionale  zweidimensionale Normalverteilung   Seien , und . Der Zufallsvektor heißt zweidimensional normalverteilt , wenn er die gemeinsame Dichte mit und hat. Mit und der Matrix schreibt man .   "
},
{
  "id": "thm-normal-rand-bedingt",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#thm-normal-rand-bedingt",
  "type": "Satz",
  "number": "4.2.33",
  "title": "Ränder und bedingte Verteilung.",
  "body": " Ränder und bedingte Verteilung   Sei wie in der Definition.    und .    Gegeben ist normalverteilt mit      . Also ist die Kovarianzmatrix und der Korrelationskoeffizient von und .   und sind genau dann unabhängig, wenn ist.      Der Kern ist eine quadratische Ergänzung: . Damit zerfällt die Dichte in zwei Faktoren, Wegen ist der zweite Faktor als Funktion von die Dichte der Normalverteilung mit Erwartungswert und Varianz . Sein Integral über ist 1, also ist der erste Faktor die Randdichte von , die Dichte von . Teilt man durch sie, bleibt der zweite Faktor als bedingte Dichte. Das ist (1) für und (2); für vertauscht man die Rollen. (3) Nach , Teil (2), mit ist (4) Für ist die Dichte das Produkt der beiden Randdichten, und das Produktkriterium aus liefert die Unabhängigkeit. Umgekehrt sind unabhängige Zufallsvariablen unkorreliert.   "
},
{
  "id": "fig-hoehenlinien",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#fig-hoehenlinien",
  "type": "Abbildung",
  "number": "4.2.34",
  "title": "",
  "body": " Höhenlinien der Dichte für , und . Durchgezogen die Regressionsgerade , gepunktet die Hauptachse der Ellipsen. Die Regressionsgerade halbiert jede senkrechte Sehne der Ellipsen, denn bei festem ist die bedingte Dichte symmetrisch um . Deshalb trifft sie die Ellipsen dort, wo diese senkrechte Tangenten haben.   Vier ineinander liegende, schräg gestellte Ellipsen mit zwei Geraden durch den Ursprung   Ein Koordinatensystem von bis 3 in beiden Richtungen. Vier ineinander liegende Ellipsen um den Ursprung, nach rechts oben geneigt. Eine gepunktete Gerade läuft durch die langen Achsen der Ellipsen. Eine flachere, durchgezogene Gerade schneidet jede Ellipse in ihrem am weitesten rechts und ihrem am weitesten links liegenden Punkt. Eine Legende unten rechts benennt die beiden Geraden.     "
},
{
  "id": "ex-temperatur-vorhersage",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#ex-temperatur-vorhersage",
  "type": "Beispiel",
  "number": "4.2.35",
  "title": "Wird es morgen heiß?",
  "body": " Wird es morgen heiß?   Die Tageshöchsttemperaturen von heute und von morgen (in C) seien an einem Ort im Juli gemeinsam normalverteilt mit , und . Heute waren es 30  C.  Wie ist gegeben verteilt?   Mit welcher Wahrscheinlichkeit wird es morgen heißer als 32  C? Vergleichen Sie mit der Wahrscheinlichkeit ohne Kenntnis der heutigen Temperatur.    Ab welcher heutigen Temperatur ist ein Tag über 32  C morgen wahrscheinlicher als nicht?          Nach normal mit Erwartungswert und Varianz , also Standardabweichung 3.     . Ohne Kenntnis von heute ist .    Wahrscheinlicher als nicht heißt mehr als , also muss der bedingte Erwartungswert, zugleich der Median der bedingten Normalverteilung, über 32 liegen: , also   C.     Ein heißer Tag macht einen heißen Folgetag etwa doppelt so wahrscheinlich. Und wegen sagt das Modell für morgen immer eine Temperatur näher am Julimittel voraus als heute: Erst ab knapp 34  C heute rechnet es eher mit über 32 morgen. So arbeitet die einfachste statistische Wettervorhersage; echte Modelle bedingen auf viele Größen zugleich.   "
},
{
  "id": "sub-zusammenfassung-4-2-2",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#sub-zusammenfassung-4-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Kovarianz. Varianz einer Summe. Korrelationskoeffizient. Bedingte Verteilung und bedingte Erwartung. Iterierter Erwartungswert. Vorhersage. Zufallsvektoren. Zweidimensionale Normalverteilung. "
},
{
  "id": "exercise-buch-gutschein",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#exercise-buch-gutschein",
  "type": "Übung",
  "number": "4.2.8.1",
  "title": "Gutschein und Warenkorb.",
  "body": " Gutschein und Warenkorb   Sei , wenn ein Kunde einen Gutschein hat, sonst , und die Zahl der Artikel, die er kauft. Die gemeinsame Wahrscheinlichkeitsfunktion ist      \\ 0 1 2   0 0,30 0,15 0,05  1 0,10 0,20 0,20      Bestimmen Sie und . Ein Taschenrechner ist erlaubt.    Bestimmen Sie und , und prüfen Sie damit .   Bestimmen Sie .          , und , also . Mit und ist .     und . Gewichtet: .     .      "
},
{
  "id": "exercise-buch-dreieck-bedingt",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#exercise-buch-dreieck-bedingt",
  "type": "Übung",
  "number": "4.2.8.2",
  "title": "Noch einmal die Dichte auf dem Dreieck.",
  "body": " Noch einmal die Dichte auf dem Dreieck   In haben und die gemeinsame Dichte auf , und es ist , , .   Bestimmen Sie und . Hinweis : und .    Bestimmen Sie die bedingte Dichte von gegeben und . Prüfen Sie mit .    Bestimmen Sie die Regressionsgerade von auf . Warum stimmt sie mit überein?    Bestimmen Sie umgekehrt ; nach ist . Ist das eine Gerade in ? Vergleichen Sie bei und mit der Regressionsgeraden von auf .           , , , also .     , also für : Gegeben ist gleichverteilt auf , und . Damit .     und , also . Die bedingte Erwartung ist schon eine Gerade, und als beste Vorhersage überhaupt ist sie auch die beste lineare.     für , also keine Gerade. Die Regressionsgerade von auf hat die Steigung und geht durch , also . Bei ist gegen , bei ist es 1 gegen . In diese Richtung ist die Gerade nur eine Näherung der besten Vorhersage.      "
},
{
  "id": "exercise-buch-rechenregeln",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#exercise-buch-rechenregeln",
  "type": "Übung",
  "number": "4.2.8.3",
  "title": "Rechnen mit Kovarianzen.",
  "body": " Rechnen mit Kovarianzen   Für und sei , und .  Bestimmen Sie und .  Bestimmen Sie .   Bestimmen Sie und den Korrelationskoeffizienten von und .           und .    Ausmultiplizieren mit den Rechenregeln: .     . Die Faktoren 2 und haben verschiedene Vorzeichen, die Konstante 1 spielt keine Rolle. Nach , Teil (3), ist der Korrelationskoeffizient also . Zur Probe: und .      "
},
{
  "id": "exercise-buch-pegel-ersatzwert",
  "level": "2",
  "url": "sec-kovarianz-korrelation-zufallsvektoren.html#exercise-buch-pegel-ersatzwert",
  "type": "Übung",
  "number": "4.2.8.4",
  "title": "Ein Ersatzwert für einen ausgefallenen Pegel.",
  "body": " Ein Ersatzwert für einen ausgefallenen Pegel   Zwei Messstellen an einem Fluss melden die Wasserstände (oberhalb) und (unterhalb), in Zentimetern über einer Bezugsmarke. Sie seien gemeinsam normalverteilt mit , , , und . Ein Taschenrechner ist erlaubt.   Bestimmen Sie und die Kovarianzmatrix von .    Die obere Messstelle fällt aus, die untere meldet 45 cm. Wie ist der fehlende Wert gegeben diese Meldung verteilt?    Welchen Wasserstand hatte die obere Messstelle mit Wahrscheinlichkeit 90 % mindestens? Benutzen Sie die Tabelle der Quantile aus .           und .    Mit vertauschten Rollen in ist gegeben normalverteilt mit Erwartungswert und Varianz , also Standardabweichung .    Gesucht ist das 10-%-Quantil der bedingten Verteilung:  cm.     Ein solcher Ersatzwert samt Unsicherheit ist eine einfache Form der Imputation fehlender Daten: Statt die Lücke mit dem Mittel 40 zu füllen, nutzt man, was die andere Messstelle verrät.   "
},
{
  "id": "sec-summen-von-zufallsvariablen",
  "level": "1",
  "url": "sec-summen-von-zufallsvariablen.html",
  "type": "Abschnitt",
  "number": "5.1",
  "title": "Summen von Zufallsvariablen: Faltung und momenterzeugende Funktionen",
  "body": " Summen von Zufallsvariablen: Faltung und momenterzeugende Funktionen    Nach diesem Abschnitt können Sie     die Wahrscheinlichkeitsfunktion der Summe zweier unabhängiger diskreter Zufallsvariablen mit der diskreten Faltung berechnen und daraus etwa einen Vorrat oder eine Kapazität bestimmen,    die Dichte der Summe zweier unabhängiger stetiger Zufallsvariablen als Faltungsintegral aufstellen und auswerten, auch wenn die Dichten nur auf Intervallen positiv sind,    die momenterzeugende Funktion einer Verteilung bestimmen und aus ihr Momente durch Ableiten gewinnen,    mit der Produktregel und dem Eindeutigkeitssatz die Verteilung einer Summe unabhängiger Zufallsvariablen bestimmen und begründen, welche Verteilungsfamilien unter Summen erhalten bleiben,    die Chi-Quadrat-Verteilung als Verteilung einer Summe quadrierter standardnormalverteilter Größen herleiten und mit ihr rechnen.      Eine Anfrage an einen Webdienst durchläuft drei Microservices nacheinander, und jeder braucht im Mittel 20 ms. Wie lange dauert die ganze Anfrage? Erwartungswert und Varianz der Gesamtzeit liefern die Rechenregeln aus und . Eine Zusage wie 99 % aller Anfragen sind nach 200 ms beantwortet lässt sich damit aber nicht prüfen. Dafür braucht man die Verteilung der Summe. Dieselbe Frage stellt sich, wenn ein Zählrohr die Impulse einer Probe und des Hintergrunds zusammen zählt, wenn sich Messfehler über mehrere Arbeitsschritte aufaddieren oder wenn ein Überwachungssystem die quadrierten Abweichungen mehrerer Sensoren zu einer einzigen Kennzahl zusammenzählt.   und berechnen die Verteilung einer Summe direkt, mit der Faltung. Es ist dieselbe Rechenoperation, die in der Signalverarbeitung ein Signal glättet und in Faltungsnetzen Bilder filtert. führt die momenterzeugende Funktion ein: Sie macht aus der Faltung ein Produkt und aus dem Berechnen von Momenten ein Ableiten. wendet das an und zeigt, welche Verteilungsfamilien unter Summen erhalten bleiben; hier löst sich auch die Frage nach den Microservices. Diese beiden Unterabschnitte sind der Kern der Woche. gewinnt daraus die Chi-Quadrat-Verteilung, die Verteilung einer Summe von Quadraten. Alles in diesem Abschnitt ist exakt. Was für Summen sehr vieler Zufallsvariablen näherungsweise gilt, gleich wie die einzelnen verteilt sind, ist das Thema von .    Die Summe diskreter Zufallsvariablen  In lagen die Paare mit der Augensumme in der Tabelle aller 36 Paare auf einer Diagonale. Weil jedes Paar dieselbe Wahrscheinlichkeit hat, genügte Abzählen. Sind die Werte nicht gleich wahrscheinlich, trägt jedes Paar auf der Diagonale sein eigenes Gewicht , bei unabhängigen und also . Man summiert die Gewichte entlang der Diagonale.   Diskrete Faltung  Faltung diskrete   Seien und Wahrscheinlichkeitsfunktionen von Zufallsvariablen mit ganzzahligen Werten. Ihre Faltung ist die Funktion      Verteilung einer Summe, diskreter Fall   Seien und unabhängige Zufallsvariablen mit ganzzahligen Werten und den Wahrscheinlichkeitsfunktionen und . Dann hat die Wahrscheinlichkeitsfunktion , also Nehmen und nur Werte in an, so läuft die Summe von bis .    Das Ereignis zerfällt in die disjunkten Ereignisse , . Mit dem dritten Axiom aus und der Unabhängigkeit ist Hat nur Werte ab 0, so ist für ; hat nur Werte ab 0, so ist für .    Von Hand rechnet man am bequemsten mit einer Tabelle: die Werte von als Zeilen, die von als Spalten, in jedem Feld das Produkt der beiden Wahrscheinlichkeiten. Dann ist die Summe einer Diagonale. Die Reihenfolge spielt keine Rolle: Mit sieht man . Für drei unabhängige Summanden faltet man zweimal, erst , dann mit ; dabei benutzt man, dass und wieder unabhängig sind (ohne Beweis). Und hat andere als ganzzahlige Werte, summiert man in eben über die Werte von .   Ein Zentrallager statt zweier Filiallager   Ein Händler hat zwei Filialen. Die Zahl der Kunden, die an einem Tag in Filiale 1 ein bestimmtes Ersatzteil verlangen, hat die Wahrscheinlichkeiten , und für 0, 1 und 2. In Filiale 2 sind es Kunden mit den Wahrscheinlichkeiten , , und für 0, 1, 2 und 3. Die beiden Nachfragen sind unabhängig.   Bestimmen Sie die Verteilung der Gesamtnachfrage und ihren Erwartungswert.    Bisher hat jede Filiale morgens zwei Teile vorrätig. Mit welcher Wahrscheinlichkeit muss an einem Tag mindestens eine Filiale einen Kunden vertrösten? Wie oft passiert das, wenn stattdessen ein Zentrallager mit denselben vier Teilen beide Filialen noch am selben Tag beliefert?    Wie viele Teile braucht das Zentrallager mindestens, damit es nicht öfter einen Kunden vertrösten muss als die beiden Filiallager mit je zwei Teilen?          Nach summiert man die Produkte entlang der Diagonalen, etwa Insgesamt:       0 1 2 3 4 5     0,20 0,27 0,27 0,17 0,07 0,02    Die Werte summieren sich zu 1, und , wie es die Linearität mit und verlangt.    Filiale 1 kann immer liefern, Filiale 2 nicht bei , also an  % der Tage. Das Zentrallager mit vier Teilen muss nur bei vertrösten, also an  % der Tage.    Mit drei Teilen fehlt etwas bei , mit Wahrscheinlichkeit ; mit zwei Teilen wären es . Drei Teile genügen.     Ein Zentrallager kommt mit einem Teil weniger aus und liefert trotzdem zuverlässiger. Der Grund ist der Ausgleich: Ein Tag mit hoher Nachfrage in der einen Filiale fällt nur selten mit einem in der anderen zusammen, und die Faltung rechnet genau das aus. Dasselbe Argument spricht für gemeinsam genutzte Rechnerpools statt fest zugeteilter Server. Erkauft wird der Ausgleich mit dem Transport, hier der Belieferung am selben Tag.    Für Poisson-verteilte Anzahlen lässt sich die Faltung allgemein ausrechnen, und das Ergebnis ist wieder eine Poisson-Verteilung.   Summe unabhängiger Poisson-verteilter Zufallsvariablen   Sind und unabhängig, so ist . Allgemein ist die Summe von unabhängigen Zufallsvariablen wieder Poisson-verteilt, mit dem Parameter .    Nach ist für  Im ersten Schritt haben wir mit erweitert, im zweiten den binomischen Lehrsatz benutzt. Für Summanden faltet man schrittweise: ist -verteilt und unabhängig von , und so weiter.    Dasselbe gilt für Prozesse. Laufen zwei unabhängige Poisson-Prozesse mit den Raten und , so ist die Zahl ihrer Ereignisse zusammen in einem Zeitraum der Länge nach dem Satz -verteilt, und für Zeiträume, die sich nicht überlappen, bleiben diese Anzahlen unabhängig. Die zusammengelegten Ereignisse bilden also wieder einen Poisson-Prozess, mit der Rate .   Probe und Hintergrund im Zählrohr   Ein Zählrohr misst die Strahlung einer schwach radioaktiven Probe. Die Probe löst im Mittel 2,5 Impulse je Sekunde aus, die Hintergrundstrahlung 3,5, jeweils als Poisson-Prozess und unabhängig voneinander.   Welche Verteilung hat die Zahl der Impulse, die das Zählrohr in einer Sekunde registriert? Bestimmen Sie Erwartungswert und Varianz.    Berechnen Sie zweimal: über die Herkunft der beiden Impulse mit der Faltung und mit dem Ergebnis aus (a).    Wie lange dauert es im Mittel bis zum nächsten Impuls, gleich woher er stammt? Mit welcher Wahrscheinlichkeit länger als eine halbe Sekunde?          Nach ist , also .    Seien und die Zahlen der Impulse von der Probe und vom Hintergrund. Zwei Impulse kommen als , oder zustande, und jede Kombination hat den Faktor : Mit ist ebenso . Die Klammer ist , ausmultipliziert nach der binomischen Formel; genau so läuft der Beweis von .    Die Impulse beider Quellen zusammen bilden einen Poisson-Prozess mit der Rate 6 je Sekunde. Die Wartezeit bis zum nächsten Impuls ist nach  -verteilt, mit dem Erwartungswert  s, und .     Für die Zählrate zählt nur die Summe der Raten. Einem einzelnen Impuls sieht man nicht an, ob er von der Probe oder vom Hintergrund stammt. Deshalb misst man den Hintergrund einmal ohne Probe und zieht seine Rate von der gemessenen Gesamtrate ab. Eine zweite Probe mit der Rate erhöht die Rate einfach auf , und alle Rechnungen bleiben gleich.     Faltung in der Signalverarbeitung und in Faltungsnetzen  Die Formel der Faltung braucht nicht, dass und Wahrscheinlichkeiten sind. Für zwei Zahlenfolgen und heißt ebenso Faltung. Ist an den Stellen 0, 1 und 2 gleich und sonst 0, so ist der gleitende Durchschnitt über drei Werte: Die Faltung glättet ein Signal. In einem Faltungsnetz, englisch convolutional neural network , läuft ein kleiner Filterkern über ein Bild, und jeder Ausgabewert ist die mit dem Kern gewichtete Summe der Pixel im Fenster. Das ist dieselbe Operation in zwei Dimensionen; die Bibliotheken lassen meist die Spiegelung weg, was an der Idee nichts ändert.  Die Verteilung einer Summe ist in diesem Bild die eine Verteilung, geglättet mit der anderen. Faltet man immer wieder mit derselben Verteilung, wird das Ergebnis breiter und glatter, wie für Würfel zeigt. Dass dabei fast immer eine Glockenform entsteht, gleich womit man anfängt, ist der zentrale Grenzwertsatz ( ).    Wahrscheinlichkeitsfunktion der Augensumme von fairen Würfeln für . Jede Verteilung entsteht aus der vorigen durch Faltung mit der Gleichverteilung auf .   Vier Wahrscheinlichkeitsfunktionen, von einer flachen Linie über ein Dreieck zu immer breiteren Glocken   Über den Augensummen von 1 bis 24 stehen vier Punktfolgen, jeweils mit Linien verbunden. Für einen Würfel liegen sechs Punkte auf der Höhe 0,167. Für zwei Würfel bilden die Punkte ein Dreieck von 2 bis 12 mit der Spitze 0,167 bei 7. Für drei Würfel reicht die Kurve von 3 bis 18, ist oben abgerundet und erreicht 0,125 bei 10 und 11. Für vier Würfel reicht sie von 4 bis 24 und erreicht 0,113 bei 14. Mit jedem Würfel wird die Kurve breiter, flacher und glockenförmiger.      Die folgende Zelle faltet die Würfelverteilung -mal mit sich selbst und druckt die Wahrscheinlichkeiten samt einem einfachen Balken. Die Funktion falte ist in einem einzigen Ausdruck.   def falte(p, q): # (p * q)[s] = Summe über k von p[k] * q[s - k] laenge = len(p) + len(q) - 1 return [sum([p[k] * q[s - k] for k in range(len(p)) if 0 <= s - k < len(q)]) for s in range(laenge)] # Augensumme von n fairen Würfeln. Probieren Sie n = 2, 3, 10. n = 3 wuerfel = [0] + [1 \/ 6] * 6 # Index = Augenzahl summe = [1] # null Würfel haben die Summe 0 for _ in range(n): summe = falte(summe, wuerfel) for s in range(n, 6 * n + 1): print(\"%3d %.4f %s\" % (s, summe[s], \"#\" * int(300 * summe[s])))     Die Summe stetiger Zufallsvariablen  Im stetigen Fall wird aus der Summe über eine Diagonale ein Integral über die Gerade : Man nimmt für jedes den Wert und gewichtet mit dem Produkt der Dichten.   Verteilung einer Summe, stetiger Fall  Faltung stetige   Seien und unabhängige stetige Zufallsvariablen mit den Dichten und . Dann ist stetig mit der Dichte Die Funktion heißt Faltung von und .    Nach hat das Paar die gemeinsame Dichte , und ist das Integral darüber, erstreckt über das Gebiet : Im inneren Integral substituieren wir ; aus der oberen Grenze wird . Dann vertauschen wir die Reihenfolge der Integration: Die Verteilungsfunktion von ist also das Integral der inneren Funktion bis , und nach ist diese Funktion eine Dichte von .    Die eigentliche Arbeit steckt in den Integrationsgrenzen. Der Integrand ist nur dort positiv, wo zugleich und ist. Haben beide Zufallsvariablen nur positive Werte, läuft das Integral deshalb von 0 bis . Sind die Dichten nur auf Intervallen positiv, schiebt man in Gedanken das Fenster, in dem positiv ist, mit über die -Achse. Je nachdem, wie es den Bereich von überlappt, entstehen verschiedene Fälle ( ). Für eine Differenz benutzt man, dass die Dichte hat; dann ist .   Faltung zweier Gleichverteilungen auf . Links für die Dichte (durchgezogen) und das verschobene Fenster (gestrichelt). Der Wert ist die grau gefüllte Überlappung, hier . Rechts die entstehende Dichte .   Links zwei überlappende Rechtecke, rechts ein Dreieck   Zwei Koordinatensysteme nebeneinander. Im linken steht ein Rechteck der Höhe 1 über dem Intervall von minus 0,5 bis 0,5, durchgezogen gezeichnet, und ein gestricheltes Rechteck der Höhe 1 über dem Intervall von minus 0,1 bis 0,9. Der Bereich, in dem sich beide überlappen, von minus 0,1 bis 0,5, ist grau gefüllt. Im rechten Koordinatensystem steht ein Dreieck mit den Ecken bei minus 1 und 1 auf der Achse und der Spitze der Höhe 1 bei 0. An der Stelle 0,4 ist der Punkt der Höhe 0,6 auf dem Dreieck markiert.       Rundungsfehler addieren sich   Zwei Rechnungsbeträge werden auf volle Euro gerundet und dann addiert. Die Rundungsfehler und (gerundeter minus wahrer Betrag, in Euro) seien unabhängig und auf gleichverteilt.   Bestimmen Sie die Dichte des Fehlers der Summe.    Mit welcher Wahrscheinlichkeit weicht die Summe der gerundeten Beträge um mehr als 80 Cent von der wahren Summe ab?    Bestimmen Sie . Was ändert sich, wenn man die Beträge erst addiert und dann rundet?          Beide Dichten sind 1 auf . Der Integrand ist also 1, wenn in und in liegt, sonst 0, und ist die Länge des Durchschnitts. Für reicht er von bis , für von bis ; für ist er leer. Zusammen: Das ist die Dreiecksverteilung Dreiecksverteilung aus .     sind die beiden Spitzen des Dreiecks außerhalb von , zwei Dreiecke mit Grundseite und Höhe : .    Nach addieren sich die Varianzen, und nach hat jeder Rundungsfehler die Varianz . Also ist ; zur Probe ergibt denselben Wert. Rundet man erst die Summe, ist der Fehler wieder gleichverteilt auf , mit der Varianz , und mehr als 50 Cent Abweichung kommt nie vor, mehr als 80 Cent also erst recht nicht.     Jeder Rundungsschritt bringt seinen eigenen Fehler mit, und die Varianzen addieren sich. In der Buchhaltung rundet man deshalb möglichst spät. Dasselbe Problem hat, wer neuronale Netze mit niedriger Rechengenauigkeit betreibt: Ein Skalarprodukt summiert Hunderte gerundeter Produkte, und ihre Fehler streuen zusammen wie die Wurzel aus ihrer Anzahl. Wie die Summe vieler solcher Fehler verteilt ist, beantwortet .    Wie im Diskreten glättet die Faltung: Das Dreieck hat keine Sprünge mehr, obwohl beide Rechteckdichten springen. Allgemein ist die Dichte von mit einem davon unabhängigen, auf gleichverteilten an jeder Stelle der Mittelwert der Dichte von über ein Fenster der Breite . Eine verrauschte Messgröße hat also eine verschmierte Dichte. Umgekehrt nutzt man das gezielt: Ein Kerndichteschätzer macht aus Daten eine glatte Kurve, indem er über jeden Datenpunkt eine kleine Dichte, den Kern, legt und diese Kerne mittelt. Das ist die Faltung der Daten mit dem Kern.  Bei Wartezeiten sind beide Dichten nur für positive Argumente positiv. Für zwei unabhängige -verteilte Zeiten und läuft das Faltungsintegral deshalb von 0 bis , und für ist Der Integrand hängt nicht von ab, weil sich die Exponenten zu addieren. Das Ergebnis ist die Dichte von aus : Die Summe zweier unabhängiger exponentialverteilter Zeiten mit derselben Rate ist erlangverteilt. Für Summanden müsste man solche Integrale nacheinander ausrechnen. Wie man das vermeidet, zeigt der nächste Unterabschnitt.    Momenterzeugende Funktionen  Für zehn Summanden müsste man neunmal falten. Bequemer wäre eine Darstellung der Verteilung, in der aus der Summe unabhängiger Zufallsvariablen ein Produkt wird, so wie der Logarithmus aus einem Produkt eine Summe macht. Den Schlüssel liefert die Exponentialfunktion: , und der Erwartungswert eines Produkts unabhängiger Faktoren ist das Produkt der Erwartungswerte.   Momenterzeugende Funktion  momenterzeugende Funktion   Sei eine Zufallsvariable. Die Funktion heißt momenterzeugende Funktion von . Sie ist für alle definiert, für die der Erwartungswert existiert.    Nach dem Transformationssatz ist für diskrete ( ) und für stetige ( ). Weil ist, gilt immer ; das ist eine bequeme Probe. Wer aus der Regelungstechnik die Laplace-Transformation kennt, erkennt sie wieder: Für eine Dichte, die nur für positiv ist, ist ihre Laplace-Transformierte.   Drei momenterzeugende Funktionen   Bestimmen Sie die momenterzeugende Funktion samt ihrem Definitionsbereich für  ,  ,  .          für alle .    Mit der Exponentialreihe für : für alle .     für . Für fällt der Integrand nicht ab, das Integral divergiert, und existiert nicht.     In allen drei Fällen ist . Dass bei der Exponentialverteilung nur links von existiert, ist typisch für Verteilungen, deren Dichte rechts nur exponentiell abfällt: wächst für selbst exponentiell, und das Integral konvergiert nur, solange die Dichte schneller fällt. Bei der Poisson-Verteilung fallen die Wahrscheinlichkeiten schneller als jede Exponentialfunktion; dort existiert für alle , obwohl die Werte nach oben unbeschränkt sind.    Für die Normalverteilung hilft eine Regel für lineare Transformationen.   Lineare Transformation   Für ist , überall dort, wo existiert.     , denn ist eine Konstante.     Momenterzeugende Funktion der Normalverteilung   Für ist für alle .    Sei zuerst mit der Dichte . Quadratische Ergänzung im Exponenten, , ergibt denn ist die Dichte von und hat das Integral 1. Nach hat die Verteilung , und nach ist .     Warum momenterzeugend  Die Zahlen heißen Momente von : ist das erste, das zweite, und aus beiden ergibt sich die Varianz. Leitet man  -mal nach ab, entsteht , an der Stelle also . Darf man Ableiten und Erwartungswert vertauschen, so erzeugen die Ableitungen von bei 0 die Momente.    Momente durch Ableiten  Momente   Existiert auf einem offenen Intervall, das 0 enthält, so existieren alle Momente von , und für ist Insbesondere ist und .    Wir zeigen nur die Rechnung; dass man Ableiten und Erwartungswert unter der Voraussetzung vertauschen darf, übernehmen wir ohne Beweis. Für stetiges ist und bei steht rechts . Für diskretes ersetzt man das Integral durch eine Summe.    Gleichwertig ist die Taylorreihe : Kennt man eine Reihe für , kann man die Momente als Koeffizienten ablesen, ohne abzuleiten.   Momente ablesen      Bestimmen Sie für Erwartungswert und Varianz durch Ableiten, und alle Momente aus einer Reihe für .    Bestimmen Sie für die Momente und .     Vertiefung: Die Wölbung Wölbung einer Zufallsvariablen mit Erwartungswert und Standardabweichung ist . Bestimmen Sie sie für jede Normalverteilung und für die Exponentialverteilung.          Mit aus ist und , also , und , wie in . Als geometrische Reihe ist für  also .    Mit der Exponentialreihe ist Ungerade Potenzen kommen nicht vor, also ist . Der Koeffizient von ist , also .     Vertiefung: Für ist standardnormalverteilt, also , gleich welche Parameter. Für die Exponentialverteilung genügt , denn ändert sich beim Strecken nicht. Mit und ist also .      Vertiefung: Die Wölbung misst, wie viel Gewicht weit draußen liegt. Eine Abweichung von mehr als vier Standardabweichungen nach oben hat bei der Exponentialverteilung die Wahrscheinlichkeit , bei der Normalverteilung nur . Viele Programme, etwa pandas und scipy , geben aus, sodass die Normalverteilung den Wert 0 bekommt. Tagesrenditen von Aktien haben typischerweise eine deutlich größere Wölbung als 3; ein Normalverteilungsmodell unterschätzt dann, wie oft extreme Kursbewegungen vorkommen. Quelle: R. Cont, Empirical properties of asset returns: stylized facts and statistical issues, Quantitative Finance 1 (2001), 223 236 ( ).     Vertiefung: Nicht jede Verteilung hat eine momenterzeugende Funktion  Fällt die Dichte zu langsam ab, existiert für kein . Das betrifft die Antwortzeit aus , deren Dichte wie abfällt und die nicht einmal eine Varianz hat. Es betrifft aber auch die Lognormalverteilung aus , obwohl bei ihr alle Momente existieren: wächst für schneller, als die Dichte von fällt. Für solche Verteilungen mit schweren Rändern, wie sie bei Dateigrößen, Einkommen oder Schadenhöhen vorkommen, ist der Eindeutigkeitssatz ( ) nicht anwendbar und damit auch nicht das Rezept für Summen am Ende dieses Unterabschnitts. Die Produktregel ( ) gilt weiter, wo beide Faktoren existieren. Bei schweren Rändern hilft die charakteristische Funktion mit der imaginären Einheit , die immer existiert; sie gehört nicht zu dieser Vorlesung.   Dass nützlich ist, liegt an zwei Sätzen. Der erste sagt, dass keine Information verloren geht.   Eindeutigkeitssatz  Eindeutigkeitssatz   Seien und Zufallsvariablen, deren momenterzeugende Funktionen auf einem offenen Intervall mit existieren und dort übereinstimmen. Dann haben und dieselbe Verteilung, also .    Den Beweis lassen wir weg; er braucht Methoden der Funktionentheorie. Wichtig ist die Anwendung: Erkennt man eine momenterzeugende Funktion als die einer bekannten Verteilung, so hat man die Verteilung. Der zweite Satz macht aus der Faltung ein Produkt.   Produktregel für unabhängige Summanden  Produktregel für momenterzeugende Funktionen   Sind und unabhängig, so ist für alle , für die beide Faktoren existieren. Allgemein ist für unabhängige  .     Der mittlere Schritt ist , Teil (2), mit und . Für diskrete und zerfällt die Doppelsumme genauso wie im Beweis von . Mit Faktoren zerfällt das -fache Integral bzw. die -fache Summe ebenso.    Zusammen ergibt das ein Rezept für die Verteilung einer Summe unabhängiger Zufallsvariablen: die momenterzeugenden Funktionen der Summanden bestimmen, multiplizieren, das Produkt als momenterzeugende Funktion einer bekannten Verteilung erkennen und mit schließen. Ein Faltungsintegral braucht man dafür nicht. Der nächste Unterabschnitt wendet das Rezept auf die wichtigsten Familien an.    Summen in den Verteilungsfamilien  Für das Rezept aus braucht man die momenterzeugenden Funktionen der Familien. Zwei fehlen noch.   Binomial- und Gammaverteilung      Für ist für alle .    Für ist für .       (1) Nach dem binomischen Lehrsatz ist   (2) Mit der Dichte aus und der Substitution , die für erlaubt ist: denn das letzte Integral ist . Für erhält man wieder für .     Summen unabhängiger Zufallsvariablen in einer Familie  Summen unabhängiger Zufallsvariablen   Seien und unabhängig.   Ist und mit demselben , so ist .    Ist und , so ist .    Ist und , so ist für , und nicht beide 0, Insbesondere ist .    Ist und mit derselben Rate , so ist . Insbesondere ist die Summe von unabhängigen -verteilten Zufallsvariablen -verteilt.   Entsprechendes gilt für unabhängige Summanden.    In jedem Fall multiplizieren wir nach , erkennen das Produkt und schließen mit .    .     . Das ist der Satz aus , diesmal in einer Zeile statt mit dem binomischen Lehrsatz.    Mit , Teil (2), für und und mit ist      für . Wegen ist die Summe von Summanden .       Die Voraussetzungen sind keine Formalien. Haben zwei Binomialverteilungen verschiedene , ist die Summe nicht binomialverteilt, wie an Stamm- und Laufkunden gezeigt hat. Haben zwei Exponentialverteilungen verschiedene Raten , ist das Produkt von keiner der Formen oben: Die Summe ist weder exponential- noch gammaverteilt. Und zwei Gleichverteilungen gleicher Breite ergeben, wie in , ein Dreieck, bei verschiedener Breite ein Trapez. Unter Summen erhalten bleiben also nur bestimmte Familien, und meist nur bei einem gemeinsamen Parameter.  Damit sind zwei Ankündigungen aus früheren Abschnitten eingelöst. Das Spiel zwischen Bohrung und Welle in ist nach Teil (3) tatsächlich normalverteilt, wenn die beiden Durchmesser es sind und unabhängig voneinander schwanken. Die Wartezeit bis zum -ten Ereignis eines Poisson-Prozesses ist die Summe von unabhängigen Abständen, und nach Teil (4) ist umgekehrt jede solche Summe erlangverteilt, wie in angekündigt. Dazu kommt eine Folgerung für Mittelwerte: Das Mittel von unabhängigen -verteilten Messungen ist nach Teil (3), auf Summanden mit den Faktoren erweitert, exakt -verteilt. Für andere Verteilungen gilt das nur näherungsweise, wie andeutet; das ist der Inhalt von .   Drei Microservices hintereinander   Eine Anfrage durchläuft wie in der Einleitung drei Microservices nacheinander. Ihre Bearbeitungszeiten seien unabhängig und exponentialverteilt mit dem Erwartungswert 20 ms. Der Betreiber sagt zu, dass 99 % der Anfragen nach 200 ms beantwortet sind.   Welche Verteilung hat die Gesamtzeit ? Hält der Betreiber seine Zusage ein?    Dieselbe Arbeit wird stattdessen auf zwei Dienste mit je 30 ms im Mittel verteilt oder von einem einzigen Dienst mit 60 ms im Mittel erledigt, wieder mit unabhängigen, exponentialverteilten Zeiten. Hält die Zusage dann?          Jede Bearbeitungszeit ist -verteilt, also ist nach , Teil (4). Wie in ist die Wahrscheinlichkeit, dass ein Poisson-Prozess mit der Rate bis höchstens zwei Ereignisse hat. Mit ist Gut 99,7 % der Anfragen sind nach 200 ms beantwortet; die Zusage hält.    Bei zwei Diensten ist und , also : Die Zusage hält gerade noch. Bei einem Dienst ist : Nur 96,4 % der Anfragen wären rechtzeitig fertig.     Alle drei Varianten brauchen im Mittel 60 ms und unterscheiden sich doch genau dort, wo die Zusage greift. Mit Erwartungswert und Varianz allein ließe sich die Zusage gar nicht prüfen; dazu braucht man die Verteilung der Summe, und liefert sie für jede Zahl unabhängiger, gleich schneller Stufen. Ob das Zerlegen in Stufen sich im Betrieb lohnt, ist eine andere Frage: Jeder weitere Dienst kostet Zeit im Netz, und die Bearbeitungszeiten sind dort nicht immer unabhängig.    Die folgende Zelle summiert simulierte -Zeiten und vergleicht den Anteil der Summen über der doppelten mittleren Gesamtzeit mit der Formel der Erlang-Verteilung. Mit wachsendem wird dieser Anteil kleiner: Die Summe konzentriert sich relativ immer enger um ihren Erwartungswert.   import random, math # Summe von k Exp(1)-Zeiten gegen die Erlang-Formel für P(T > 2k). # Probieren Sie k = 1, 3, 10. k = 3 t = 2 * k summen = [sum([random.expovariate(1) for _ in range(k)]) for _ in range(100000)] anteil = len([x for x in summen if x > t]) \/ len(summen) erlang = math.exp(-t) * sum([t ** j \/ math.factorial(j) for j in range(k)]) print(\"simuliert: %.4f\" % anteil) print(\"Erlang-Formel: %.4f\" % erlang)    Fehlerfortpflanzung bei einer Streckenmessung   Ein Vermessungsteam bestimmt eine Strecke in drei Abschnitten. Die Messfehler der Abschnitte (in Millimetern) sind unabhängig und normalverteilt mit Erwartungswert 0 und den Standardabweichungen 2, 3 und 6. Der Fehler der Gesamtstrecke ist ihre Summe . Benutzen Sie und .  Welche Verteilung hat ?   Mit welcher Wahrscheinlichkeit ist die Gesamtstrecke um mehr als 14 mm falsch?    Das Team kann einen der drei Abschnitte mit einem besseren Gerät messen und dessen Standardabweichung halbieren. Welchen sollte es wählen, und was gewinnt es?          Nach , Teil (3), ist normalverteilt mit Erwartungswert 0 und Varianz , also .     .    Halbiert man die Standardabweichung eines Abschnitts, sinkt die Varianz der Summe um , also am stärksten beim größten . Beim dritten Abschnitt sinkt sie auf , die Standardabweichung auf ; beim ersten bliebe . Also den dritten Abschnitt; dann ist und , etwa ein Sechzehntel des bisherigen Werts.     Weil sich Varianzen addieren und nicht Standardabweichungen, bestimmt der größte Einzelfehler fast allein den Gesamtfehler: Der Abschnitt mit der Standardabweichung 6 trägt 36 der 49 Einheiten Varianz bei. Wer ein Messverfahren oder eine Datenpipeline verbessern will, sucht deshalb zuerst die größte Fehlerquelle. Dass die Summe normalverteilt ist, braucht man erst für die Wahrscheinlichkeiten in (b) und (c).     fasst die momenterzeugenden Funktionen und das Verhalten unter Summen zusammen. Neu ist darin nur die Zeile der Gleichverteilung: Für und ist , und .   Momenterzeugende Funktionen und Summen unabhängiger Zufallsvariablen       Verteilung   Summe unabhängiger      Summanden:      mit :      mit :     ,  keine Gleichverteilung     ,  Summanden:     ,  mit :      mit :       Die Chi-Quadrat-Verteilung  Wie gut passt ein Modell zu den Daten? Eine verbreitete Antwort fasst alle Abweichungen zu einer einzigen Zahl zusammen: Man standardisiert jede Abweichung, quadriert und summiert. So entstehen die Prüfgrößen der Anomalieerkennung, die Summe der quadrierten standardisierten Residuen einer Regression und die Prüfgrößen vieler statistischer Tests. Sind die standardisierten Abweichungen unabhängig und standardnormalverteilt, hat diese Summe eine eigene Verteilung. Sie ergibt sich mit den Werkzeugen dieses Abschnitts in wenigen Zeilen.   Das Quadrat einer standardnormalverteilten Größe   Für ist für , und .    Für substituieren wir : und das letzte Integral ist 1. Nach hat die momenterzeugende Funktion . Mit folgt die Behauptung.     Chi-Quadrat-Verteilung  Chi-Quadrat-Verteilung  Freiheitsgrade   Seien unabhängig und -verteilt. Die Verteilung von heißt Chi-Quadrat-Verteilung mit  Freiheitsgraden , kurz .     Eigenschaften der Chi-Quadrat-Verteilung       , mit der Dichte für .    Für ist und .     , also für . Allgemein ist .       (1) Nach ist jedes , und die sind unabhängig. Nach , Teil (4), addieren sich die Formparameter zu ; die Dichte ist die der Gammaverteilung aus . (2) Es ist , und nach ist , also . Erwartungswerte und, wegen der Unabhängigkeit, Varianzen addieren sich. (3) und .    Für gerades lassen sich die Wahrscheinlichkeiten also mit der Formel der Erlang-Verteilung von Hand ausrechnen. Für genügen die Werte von aus , denn für und ist . Für größeres ungerades nimmt man ein Programm, etwa scipy.stats.chi2 . zeigt, wie sich die Dichte mit der Zahl der Freiheitsgrade nach rechts verschiebt und breiter wird: Der Erwartungswert wächst wie , die Standardabweichung nur wie .   Dichten von für . Für wächst die Dichte bei 0 über alle Grenzen, für ist es die Dichte von . Der Gipfel liegt für bei .   Vier Dichtekurven auf der positiven Achse, mit wachsendem n immer weiter rechts und flacher   Über dem Bereich von 0 bis 14 stehen vier Kurven. Die für n gleich 1 kommt von oben, steigt also bei 0 über alle Grenzen, und fällt dann schnell ab. Die für n gleich 2 beginnt bei 0 mit der Höhe 0,5 und fällt exponentiell. Die für n gleich 4 beginnt bei 0, erreicht bei 2 ihr Maximum 0,18 und fällt dann. Die für n gleich 8 erreicht ihr Maximum 0,11 bei 6 und ist am breitesten. Eine Legende rechts in der Mitte ordnet die Linienarten zu.       Eine Prüfgröße für vier Sensoren   Eine Maschine wird mit vier Sensoren überwacht. Im Normalbetrieb ist jeder Messwert normalverteilt mit bekanntem Erwartungswert und bekannter Standardabweichung, und die vier Messwerte sind unabhängig. Das System bildet aus den standardisierten Abweichungen die Prüfgröße und meldet eine Anomalie, wenn ist.   Welche Verteilung hat im Normalbetrieb? Bestimmen Sie Erwartungswert und Varianz.    Wie oft meldet das System im Normalbetrieb fälschlich eine Anomalie?    Alle vier Sensoren zeigen gleichzeitig eine Abweichung von Standardabweichungen. Meldet das System eine Anomalie? Wie ungewöhnlich wäre eine solche Abweichung bei einem einzelnen Sensor? Benutzen Sie .           nach , mit und .    Mit der Erlang-Formel für : , also bei knapp 2 % der Messungen.     : Das System meldet eine Anomalie. Bei einem einzelnen Sensor ist ; etwa jeder vierzehnte Messwert weicht so weit ab.     Jeder Sensor für sich ist unauffällig, aber vier gleichzeitige Abweichungen dieser Größe kommen im Normalbetrieb selten vor. Genau das erkennt die Prüfgröße, und eine Regel, die jeden Sensor einzeln prüft, würde es übersehen. ist das Quadrat des Abstands vom Normalzustand, gemessen in Standardabweichungen. Hängen die Sensoren voneinander ab, misst man den Abstand mit der Kovarianzmatrix aus , als ; für normalverteilte Zufallsvektoren ist auch dieser Mahalanobis-Abstand Mahalanobis-Abstand im Quadrat -verteilt (ohne Beweis).    Die Zelle simuliert für Freiheitsgrade und vergleicht Mittelwert und Varianz der Simulation mit und .   import random # Q = Summe von n quadrierten N(0, 1)-Größen. Probieren Sie n = 1, 4, 20. n = 4 werte = [sum([random.gauss(0, 1) ** 2 for _ in range(n)]) for _ in range(10000)] m = sum(werte) \/ len(werte) v = sum([(q - m) ** 2 for q in werte]) \/ len(werte) print(\"Mittel von Q: %.2f (Theorie: %d)\" % (m, n)) print(\"Varianz von Q: %.2f (Theorie: %d)\" % (v, 2 * n))   Die Chi-Quadrat-Verteilung kehrt in wieder: Die Stichprobenvarianz normalverteilter Messwerte ist, geeignet skaliert, -verteilt. Dass dort ein Freiheitsgrad fehlt, liegt daran, dass man den Erwartungswert durch das Stichprobenmittel ersetzt.    Zusammenfassung      Diskrete Faltung. Für unabhängige ganzzahlige und ist , die Summe einer Diagonale in der Tabelle der Produkte. Insbesondere ist die Summe unabhängiger - und -verteilter Größen -verteilt, und zusammengelegte Poisson-Prozesse sind ein Poisson-Prozess mit der Summe der Raten.     Stetige Faltung. Für unabhängige stetige und ist . Die Grenzen ergeben sich daraus, wo beide Faktoren positiv sind, bei Intervallen mit Fallunterscheidung. Zwei Gleichverteilungen gleicher Breite ergeben ein Dreieck, zwei -Zeiten . Die Faltung glättet, wie ein gleitender Durchschnitt in der Signalverarbeitung.     Momenterzeugende Funktion.  , mit und . Es ist für , für , für und für .     Momente durch Ableiten.  , also und ; oder man liest die Momente als Koeffizienten der Reihe ab.     Eindeutigkeit und Produktregel. Stimmen zwei momenterzeugende Funktionen in einer Umgebung von 0 überein, so auch die Verteilungen. Für unabhängige und ist . Rezept für eine Summe: multiplizieren, das Produkt erkennen, mit der Eindeutigkeit schließen.     Familien unter Summen. Für unabhängige Summanden gilt: und ergeben ; und ergeben ; für normalverteilte und ist wieder normalverteilt, mit Erwartungswert und Varianz ; und ergeben , und unabhängige -Zeiten ergeben . Bei verschiedenem bzw. verschiedener Rate verlässt die Summe die Familie.     Chi-Quadrat-Verteilung. Für unabhängige ist , mit Erwartungswert und Varianz . Es ist und . Summen quadrierter standardisierter Abweichungen sind Prüfgrößen für Anomalien und für die Passung eines Modells.       Übungsaufgaben   Ein Tetraeder und ein halber Würfel   Ein fairer Tetraeder zeigt die Zahlen 1 bis 4, ein fairer Würfel trägt die Zahlen 1, 2 und 3 je zweimal. Beide werden unabhängig geworfen; ist die Zahl des Tetraeders, die des Würfels.  Bestimmen Sie die Verteilung von mit der Faltung.  Bestimmen Sie .   Bestimmen Sie aus der Verteilung, und prüfen Sie das Ergebnis mit der Linearität.          Jedes der zwölf Paare hat die Wahrscheinlichkeit , und ist mal die Zahl der Summanden , die nicht verschwinden: , , , , , für .     .     , und .        Die Differenz zweier Wartezeiten    und seien unabhängig und -verteilt.   Bestimmen Sie die Dichte von . Hinweis : hat die Dichte . Unterscheiden Sie und .   Bestimmen Sie .         Nach ist , und der Integrand ist positiv, wenn und ist. Für : . Für läuft das Integral ab 0 und ergibt . Zusammen ist .     .     Diese Verteilung heißt Laplace-Verteilung . Sie kehrt in als Vorwissen wieder, das kleine Parameter bevorzugt, und führt dort auf die Lasso-Regression.     Die momenterzeugende Funktion der geometrischen Verteilung   Sei mit und .   Zeigen Sie für .   Bestimmen Sie durch Ableiten.   Welche momenterzeugende Funktion hat die Summe von unabhängigen -verteilten Zufallsvariablen, und was ist ihr Erwartungswert?          Mit der geometrischen Reihe: .    Mit der Quotientenregel ist , also .    Nach ist es , die momenterzeugende Funktion der negativen Binomialverteilung aus . Der Erwartungswert ist .        Eine Linearkombination normalverteilter Größen    und seien unabhängig.   Welche Verteilung hat ? Begründen Sie mit momenterzeugenden Funktionen.    Bestimmen Sie . Benutzen Sie .           . Das ist die momenterzeugende Funktion von , und nach ist .     , denn .        Sechs Freiheitsgrade   Sei .  Bestimmen Sie und die Standardabweichung von .  Bestimmen Sie .          und , also .     , und mit ist .     Dieselbe Zahl kam in als Wahrscheinlichkeit für höchstens zwei Anrufe vor. Das ist kein Zufall: Die Wartezeit bis zum dritten Ereignis ist genau dann länger als , wenn bis höchstens zwei Ereignisse eintreten.     "
},
{
  "id": "sec-summen-von-zufallsvariablen-2",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#sec-summen-von-zufallsvariablen-2",
  "type": "Lernziele",
  "number": "5.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     die Wahrscheinlichkeitsfunktion der Summe zweier unabhängiger diskreter Zufallsvariablen mit der diskreten Faltung berechnen und daraus etwa einen Vorrat oder eine Kapazität bestimmen,    die Dichte der Summe zweier unabhängiger stetiger Zufallsvariablen als Faltungsintegral aufstellen und auswerten, auch wenn die Dichten nur auf Intervallen positiv sind,    die momenterzeugende Funktion einer Verteilung bestimmen und aus ihr Momente durch Ableiten gewinnen,    mit der Produktregel und dem Eindeutigkeitssatz die Verteilung einer Summe unabhängiger Zufallsvariablen bestimmen und begründen, welche Verteilungsfamilien unter Summen erhalten bleiben,    die Chi-Quadrat-Verteilung als Verteilung einer Summe quadrierter standardnormalverteilter Größen herleiten und mit ihr rechnen.    "
},
{
  "id": "def-faltung-diskret",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#def-faltung-diskret",
  "type": "Definition",
  "number": "5.1.1",
  "title": "Diskrete Faltung.",
  "body": " Diskrete Faltung  Faltung diskrete   Seien und Wahrscheinlichkeitsfunktionen von Zufallsvariablen mit ganzzahligen Werten. Ihre Faltung ist die Funktion    "
},
{
  "id": "thm-faltung-diskret",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-faltung-diskret",
  "type": "Satz",
  "number": "5.1.2",
  "title": "Verteilung einer Summe, diskreter Fall.",
  "body": " Verteilung einer Summe, diskreter Fall   Seien und unabhängige Zufallsvariablen mit ganzzahligen Werten und den Wahrscheinlichkeitsfunktionen und . Dann hat die Wahrscheinlichkeitsfunktion , also Nehmen und nur Werte in an, so läuft die Summe von bis .    Das Ereignis zerfällt in die disjunkten Ereignisse , . Mit dem dritten Axiom aus und der Unabhängigkeit ist Hat nur Werte ab 0, so ist für ; hat nur Werte ab 0, so ist für .   "
},
{
  "id": "ex-zentrallager",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-zentrallager",
  "type": "Beispiel",
  "number": "5.1.3",
  "title": "Ein Zentrallager statt zweier Filiallager.",
  "body": " Ein Zentrallager statt zweier Filiallager   Ein Händler hat zwei Filialen. Die Zahl der Kunden, die an einem Tag in Filiale 1 ein bestimmtes Ersatzteil verlangen, hat die Wahrscheinlichkeiten , und für 0, 1 und 2. In Filiale 2 sind es Kunden mit den Wahrscheinlichkeiten , , und für 0, 1, 2 und 3. Die beiden Nachfragen sind unabhängig.   Bestimmen Sie die Verteilung der Gesamtnachfrage und ihren Erwartungswert.    Bisher hat jede Filiale morgens zwei Teile vorrätig. Mit welcher Wahrscheinlichkeit muss an einem Tag mindestens eine Filiale einen Kunden vertrösten? Wie oft passiert das, wenn stattdessen ein Zentrallager mit denselben vier Teilen beide Filialen noch am selben Tag beliefert?    Wie viele Teile braucht das Zentrallager mindestens, damit es nicht öfter einen Kunden vertrösten muss als die beiden Filiallager mit je zwei Teilen?          Nach summiert man die Produkte entlang der Diagonalen, etwa Insgesamt:       0 1 2 3 4 5     0,20 0,27 0,27 0,17 0,07 0,02    Die Werte summieren sich zu 1, und , wie es die Linearität mit und verlangt.    Filiale 1 kann immer liefern, Filiale 2 nicht bei , also an  % der Tage. Das Zentrallager mit vier Teilen muss nur bei vertrösten, also an  % der Tage.    Mit drei Teilen fehlt etwas bei , mit Wahrscheinlichkeit ; mit zwei Teilen wären es . Drei Teile genügen.     Ein Zentrallager kommt mit einem Teil weniger aus und liefert trotzdem zuverlässiger. Der Grund ist der Ausgleich: Ein Tag mit hoher Nachfrage in der einen Filiale fällt nur selten mit einem in der anderen zusammen, und die Faltung rechnet genau das aus. Dasselbe Argument spricht für gemeinsam genutzte Rechnerpools statt fest zugeteilter Server. Erkauft wird der Ausgleich mit dem Transport, hier der Belieferung am selben Tag.   "
},
{
  "id": "thm-poisson-summe",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-poisson-summe",
  "type": "Satz",
  "number": "5.1.4",
  "title": "Summe unabhängiger Poisson-verteilter Zufallsvariablen.",
  "body": " Summe unabhängiger Poisson-verteilter Zufallsvariablen   Sind und unabhängig, so ist . Allgemein ist die Summe von unabhängigen Zufallsvariablen wieder Poisson-verteilt, mit dem Parameter .    Nach ist für  Im ersten Schritt haben wir mit erweitert, im zweiten den binomischen Lehrsatz benutzt. Für Summanden faltet man schrittweise: ist -verteilt und unabhängig von , und so weiter.   "
},
{
  "id": "ex-zaehlrohr",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-zaehlrohr",
  "type": "Beispiel",
  "number": "5.1.5",
  "title": "Probe und Hintergrund im Zählrohr.",
  "body": " Probe und Hintergrund im Zählrohr   Ein Zählrohr misst die Strahlung einer schwach radioaktiven Probe. Die Probe löst im Mittel 2,5 Impulse je Sekunde aus, die Hintergrundstrahlung 3,5, jeweils als Poisson-Prozess und unabhängig voneinander.   Welche Verteilung hat die Zahl der Impulse, die das Zählrohr in einer Sekunde registriert? Bestimmen Sie Erwartungswert und Varianz.    Berechnen Sie zweimal: über die Herkunft der beiden Impulse mit der Faltung und mit dem Ergebnis aus (a).    Wie lange dauert es im Mittel bis zum nächsten Impuls, gleich woher er stammt? Mit welcher Wahrscheinlichkeit länger als eine halbe Sekunde?          Nach ist , also .    Seien und die Zahlen der Impulse von der Probe und vom Hintergrund. Zwei Impulse kommen als , oder zustande, und jede Kombination hat den Faktor : Mit ist ebenso . Die Klammer ist , ausmultipliziert nach der binomischen Formel; genau so läuft der Beweis von .    Die Impulse beider Quellen zusammen bilden einen Poisson-Prozess mit der Rate 6 je Sekunde. Die Wartezeit bis zum nächsten Impuls ist nach  -verteilt, mit dem Erwartungswert  s, und .     Für die Zählrate zählt nur die Summe der Raten. Einem einzelnen Impuls sieht man nicht an, ob er von der Probe oder vom Hintergrund stammt. Deshalb misst man den Hintergrund einmal ohne Probe und zieht seine Rate von der gemessenen Gesamtrate ab. Eine zweite Probe mit der Rate erhöht die Rate einfach auf , und alle Rechnungen bleiben gleich.   "
},
{
  "id": "rem-faltung-signalverarbeitung",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#rem-faltung-signalverarbeitung",
  "type": "Bemerkung",
  "number": "5.1.6",
  "title": "Faltung in der Signalverarbeitung und in Faltungsnetzen.",
  "body": " Faltung in der Signalverarbeitung und in Faltungsnetzen  Die Formel der Faltung braucht nicht, dass und Wahrscheinlichkeiten sind. Für zwei Zahlenfolgen und heißt ebenso Faltung. Ist an den Stellen 0, 1 und 2 gleich und sonst 0, so ist der gleitende Durchschnitt über drei Werte: Die Faltung glättet ein Signal. In einem Faltungsnetz, englisch convolutional neural network , läuft ein kleiner Filterkern über ein Bild, und jeder Ausgabewert ist die mit dem Kern gewichtete Summe der Pixel im Fenster. Das ist dieselbe Operation in zwei Dimensionen; die Bibliotheken lassen meist die Spiegelung weg, was an der Idee nichts ändert.  Die Verteilung einer Summe ist in diesem Bild die eine Verteilung, geglättet mit der anderen. Faltet man immer wieder mit derselben Verteilung, wird das Ergebnis breiter und glatter, wie für Würfel zeigt. Dass dabei fast immer eine Glockenform entsteht, gleich womit man anfängt, ist der zentrale Grenzwertsatz ( ).  "
},
{
  "id": "fig-augensummen",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#fig-augensummen",
  "type": "Abbildung",
  "number": "5.1.7",
  "title": "",
  "body": " Wahrscheinlichkeitsfunktion der Augensumme von fairen Würfeln für . Jede Verteilung entsteht aus der vorigen durch Faltung mit der Gleichverteilung auf .   Vier Wahrscheinlichkeitsfunktionen, von einer flachen Linie über ein Dreieck zu immer breiteren Glocken   Über den Augensummen von 1 bis 24 stehen vier Punktfolgen, jeweils mit Linien verbunden. Für einen Würfel liegen sechs Punkte auf der Höhe 0,167. Für zwei Würfel bilden die Punkte ein Dreieck von 2 bis 12 mit der Spitze 0,167 bei 7. Für drei Würfel reicht die Kurve von 3 bis 18, ist oben abgerundet und erreicht 0,125 bei 10 und 11. Für vier Würfel reicht sie von 4 bis 24 und erreicht 0,113 bei 14. Mit jedem Würfel wird die Kurve breiter, flacher und glockenförmiger.     "
},
{
  "id": "thm-faltung-stetig",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-faltung-stetig",
  "type": "Satz",
  "number": "5.1.8",
  "title": "Verteilung einer Summe, stetiger Fall.",
  "body": " Verteilung einer Summe, stetiger Fall  Faltung stetige   Seien und unabhängige stetige Zufallsvariablen mit den Dichten und . Dann ist stetig mit der Dichte Die Funktion heißt Faltung von und .    Nach hat das Paar die gemeinsame Dichte , und ist das Integral darüber, erstreckt über das Gebiet : Im inneren Integral substituieren wir ; aus der oberen Grenze wird . Dann vertauschen wir die Reihenfolge der Integration: Die Verteilungsfunktion von ist also das Integral der inneren Funktion bis , und nach ist diese Funktion eine Dichte von .   "
},
{
  "id": "fig-faltung-fenster",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#fig-faltung-fenster",
  "type": "Abbildung",
  "number": "5.1.9",
  "title": "",
  "body": " Faltung zweier Gleichverteilungen auf . Links für die Dichte (durchgezogen) und das verschobene Fenster (gestrichelt). Der Wert ist die grau gefüllte Überlappung, hier . Rechts die entstehende Dichte .   Links zwei überlappende Rechtecke, rechts ein Dreieck   Zwei Koordinatensysteme nebeneinander. Im linken steht ein Rechteck der Höhe 1 über dem Intervall von minus 0,5 bis 0,5, durchgezogen gezeichnet, und ein gestricheltes Rechteck der Höhe 1 über dem Intervall von minus 0,1 bis 0,9. Der Bereich, in dem sich beide überlappen, von minus 0,1 bis 0,5, ist grau gefüllt. Im rechten Koordinatensystem steht ein Dreieck mit den Ecken bei minus 1 und 1 auf der Achse und der Spitze der Höhe 1 bei 0. An der Stelle 0,4 ist der Punkt der Höhe 0,6 auf dem Dreieck markiert.     "
},
{
  "id": "ex-rundungsfehler-summe",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-rundungsfehler-summe",
  "type": "Beispiel",
  "number": "5.1.10",
  "title": "Rundungsfehler addieren sich.",
  "body": " Rundungsfehler addieren sich   Zwei Rechnungsbeträge werden auf volle Euro gerundet und dann addiert. Die Rundungsfehler und (gerundeter minus wahrer Betrag, in Euro) seien unabhängig und auf gleichverteilt.   Bestimmen Sie die Dichte des Fehlers der Summe.    Mit welcher Wahrscheinlichkeit weicht die Summe der gerundeten Beträge um mehr als 80 Cent von der wahren Summe ab?    Bestimmen Sie . Was ändert sich, wenn man die Beträge erst addiert und dann rundet?          Beide Dichten sind 1 auf . Der Integrand ist also 1, wenn in und in liegt, sonst 0, und ist die Länge des Durchschnitts. Für reicht er von bis , für von bis ; für ist er leer. Zusammen: Das ist die Dreiecksverteilung Dreiecksverteilung aus .     sind die beiden Spitzen des Dreiecks außerhalb von , zwei Dreiecke mit Grundseite und Höhe : .    Nach addieren sich die Varianzen, und nach hat jeder Rundungsfehler die Varianz . Also ist ; zur Probe ergibt denselben Wert. Rundet man erst die Summe, ist der Fehler wieder gleichverteilt auf , mit der Varianz , und mehr als 50 Cent Abweichung kommt nie vor, mehr als 80 Cent also erst recht nicht.     Jeder Rundungsschritt bringt seinen eigenen Fehler mit, und die Varianzen addieren sich. In der Buchhaltung rundet man deshalb möglichst spät. Dasselbe Problem hat, wer neuronale Netze mit niedriger Rechengenauigkeit betreibt: Ein Skalarprodukt summiert Hunderte gerundeter Produkte, und ihre Fehler streuen zusammen wie die Wurzel aus ihrer Anzahl. Wie die Summe vieler solcher Fehler verteilt ist, beantwortet .   "
},
{
  "id": "def-momenterzeugende-funktion",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#def-momenterzeugende-funktion",
  "type": "Definition",
  "number": "5.1.11",
  "title": "Momenterzeugende Funktion.",
  "body": " Momenterzeugende Funktion  momenterzeugende Funktion   Sei eine Zufallsvariable. Die Funktion heißt momenterzeugende Funktion von . Sie ist für alle definiert, für die der Erwartungswert existiert.   "
},
{
  "id": "ex-mgf-grundverteilungen",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-mgf-grundverteilungen",
  "type": "Beispiel",
  "number": "5.1.12",
  "title": "Drei momenterzeugende Funktionen.",
  "body": " Drei momenterzeugende Funktionen   Bestimmen Sie die momenterzeugende Funktion samt ihrem Definitionsbereich für  ,  ,  .          für alle .    Mit der Exponentialreihe für : für alle .     für . Für fällt der Integrand nicht ab, das Integral divergiert, und existiert nicht.     In allen drei Fällen ist . Dass bei der Exponentialverteilung nur links von existiert, ist typisch für Verteilungen, deren Dichte rechts nur exponentiell abfällt: wächst für selbst exponentiell, und das Integral konvergiert nur, solange die Dichte schneller fällt. Bei der Poisson-Verteilung fallen die Wahrscheinlichkeiten schneller als jede Exponentialfunktion; dort existiert für alle , obwohl die Werte nach oben unbeschränkt sind.   "
},
{
  "id": "thm-mgf-linear",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-mgf-linear",
  "type": "Satz",
  "number": "5.1.13",
  "title": "Lineare Transformation.",
  "body": " Lineare Transformation   Für ist , überall dort, wo existiert.     , denn ist eine Konstante.   "
},
{
  "id": "prop-mgf-normal",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#prop-mgf-normal",
  "type": "Proposition",
  "number": "5.1.14",
  "title": "Momenterzeugende Funktion der Normalverteilung.",
  "body": " Momenterzeugende Funktion der Normalverteilung   Für ist für alle .    Sei zuerst mit der Dichte . Quadratische Ergänzung im Exponenten, , ergibt denn ist die Dichte von und hat das Integral 1. Nach hat die Verteilung , und nach ist .   "
},
{
  "id": "sub-momenterzeugende-funktion-9-2",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#sub-momenterzeugende-funktion-9-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Momente "
},
{
  "id": "thm-momente-ableiten",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-momente-ableiten",
  "type": "Satz",
  "number": "5.1.15",
  "title": "Momente durch Ableiten.",
  "body": " Momente durch Ableiten  Momente   Existiert auf einem offenen Intervall, das 0 enthält, so existieren alle Momente von , und für ist Insbesondere ist und .    Wir zeigen nur die Rechnung; dass man Ableiten und Erwartungswert unter der Voraussetzung vertauschen darf, übernehmen wir ohne Beweis. Für stetiges ist und bei steht rechts . Für diskretes ersetzt man das Integral durch eine Summe.   "
},
{
  "id": "ex-momente-woelbung",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-momente-woelbung",
  "type": "Beispiel",
  "number": "5.1.16",
  "title": "Momente ablesen.",
  "body": " Momente ablesen      Bestimmen Sie für Erwartungswert und Varianz durch Ableiten, und alle Momente aus einer Reihe für .    Bestimmen Sie für die Momente und .     Vertiefung: Die Wölbung Wölbung einer Zufallsvariablen mit Erwartungswert und Standardabweichung ist . Bestimmen Sie sie für jede Normalverteilung und für die Exponentialverteilung.          Mit aus ist und , also , und , wie in . Als geometrische Reihe ist für  also .    Mit der Exponentialreihe ist Ungerade Potenzen kommen nicht vor, also ist . Der Koeffizient von ist , also .     Vertiefung: Für ist standardnormalverteilt, also , gleich welche Parameter. Für die Exponentialverteilung genügt , denn ändert sich beim Strecken nicht. Mit und ist also .      Vertiefung: Die Wölbung misst, wie viel Gewicht weit draußen liegt. Eine Abweichung von mehr als vier Standardabweichungen nach oben hat bei der Exponentialverteilung die Wahrscheinlichkeit , bei der Normalverteilung nur . Viele Programme, etwa pandas und scipy , geben aus, sodass die Normalverteilung den Wert 0 bekommt. Tagesrenditen von Aktien haben typischerweise eine deutlich größere Wölbung als 3; ein Normalverteilungsmodell unterschätzt dann, wie oft extreme Kursbewegungen vorkommen. Quelle: R. Cont, Empirical properties of asset returns: stylized facts and statistical issues, Quantitative Finance 1 (2001), 223 236 ( ).   "
},
{
  "id": "rem-mgf-existenz",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#rem-mgf-existenz",
  "type": "Bemerkung",
  "number": "5.1.17",
  "title": "Vertiefung: Nicht jede Verteilung hat eine momenterzeugende Funktion.",
  "body": " Vertiefung: Nicht jede Verteilung hat eine momenterzeugende Funktion  Fällt die Dichte zu langsam ab, existiert für kein . Das betrifft die Antwortzeit aus , deren Dichte wie abfällt und die nicht einmal eine Varianz hat. Es betrifft aber auch die Lognormalverteilung aus , obwohl bei ihr alle Momente existieren: wächst für schneller, als die Dichte von fällt. Für solche Verteilungen mit schweren Rändern, wie sie bei Dateigrößen, Einkommen oder Schadenhöhen vorkommen, ist der Eindeutigkeitssatz ( ) nicht anwendbar und damit auch nicht das Rezept für Summen am Ende dieses Unterabschnitts. Die Produktregel ( ) gilt weiter, wo beide Faktoren existieren. Bei schweren Rändern hilft die charakteristische Funktion mit der imaginären Einheit , die immer existiert; sie gehört nicht zu dieser Vorlesung.  "
},
{
  "id": "thm-mgf-eindeutigkeit",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-mgf-eindeutigkeit",
  "type": "Satz",
  "number": "5.1.18",
  "title": "Eindeutigkeitssatz.",
  "body": " Eindeutigkeitssatz  Eindeutigkeitssatz   Seien und Zufallsvariablen, deren momenterzeugende Funktionen auf einem offenen Intervall mit existieren und dort übereinstimmen. Dann haben und dieselbe Verteilung, also .   "
},
{
  "id": "thm-mgf-produkt",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-mgf-produkt",
  "type": "Satz",
  "number": "5.1.19",
  "title": "Produktregel für unabhängige Summanden.",
  "body": " Produktregel für unabhängige Summanden  Produktregel für momenterzeugende Funktionen   Sind und unabhängig, so ist für alle , für die beide Faktoren existieren. Allgemein ist für unabhängige  .     Der mittlere Schritt ist , Teil (2), mit und . Für diskrete und zerfällt die Doppelsumme genauso wie im Beweis von . Mit Faktoren zerfällt das -fache Integral bzw. die -fache Summe ebenso.   "
},
{
  "id": "prop-mgf-binomial-gamma",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#prop-mgf-binomial-gamma",
  "type": "Proposition",
  "number": "5.1.20",
  "title": "Binomial- und Gammaverteilung.",
  "body": " Binomial- und Gammaverteilung      Für ist für alle .    Für ist für .       (1) Nach dem binomischen Lehrsatz ist   (2) Mit der Dichte aus und der Substitution , die für erlaubt ist: denn das letzte Integral ist . Für erhält man wieder für .   "
},
{
  "id": "thm-summen-familien",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-summen-familien",
  "type": "Satz",
  "number": "5.1.21",
  "title": "Summen unabhängiger Zufallsvariablen in einer Familie.",
  "body": " Summen unabhängiger Zufallsvariablen in einer Familie  Summen unabhängiger Zufallsvariablen   Seien und unabhängig.   Ist und mit demselben , so ist .    Ist und , so ist .    Ist und , so ist für , und nicht beide 0, Insbesondere ist .    Ist und mit derselben Rate , so ist . Insbesondere ist die Summe von unabhängigen -verteilten Zufallsvariablen -verteilt.   Entsprechendes gilt für unabhängige Summanden.    In jedem Fall multiplizieren wir nach , erkennen das Produkt und schließen mit .    .     . Das ist der Satz aus , diesmal in einer Zeile statt mit dem binomischen Lehrsatz.    Mit , Teil (2), für und und mit ist      für . Wegen ist die Summe von Summanden .      "
},
{
  "id": "ex-microservices",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-microservices",
  "type": "Beispiel",
  "number": "5.1.22",
  "title": "Drei Microservices hintereinander.",
  "body": " Drei Microservices hintereinander   Eine Anfrage durchläuft wie in der Einleitung drei Microservices nacheinander. Ihre Bearbeitungszeiten seien unabhängig und exponentialverteilt mit dem Erwartungswert 20 ms. Der Betreiber sagt zu, dass 99 % der Anfragen nach 200 ms beantwortet sind.   Welche Verteilung hat die Gesamtzeit ? Hält der Betreiber seine Zusage ein?    Dieselbe Arbeit wird stattdessen auf zwei Dienste mit je 30 ms im Mittel verteilt oder von einem einzigen Dienst mit 60 ms im Mittel erledigt, wieder mit unabhängigen, exponentialverteilten Zeiten. Hält die Zusage dann?          Jede Bearbeitungszeit ist -verteilt, also ist nach , Teil (4). Wie in ist die Wahrscheinlichkeit, dass ein Poisson-Prozess mit der Rate bis höchstens zwei Ereignisse hat. Mit ist Gut 99,7 % der Anfragen sind nach 200 ms beantwortet; die Zusage hält.    Bei zwei Diensten ist und , also : Die Zusage hält gerade noch. Bei einem Dienst ist : Nur 96,4 % der Anfragen wären rechtzeitig fertig.     Alle drei Varianten brauchen im Mittel 60 ms und unterscheiden sich doch genau dort, wo die Zusage greift. Mit Erwartungswert und Varianz allein ließe sich die Zusage gar nicht prüfen; dazu braucht man die Verteilung der Summe, und liefert sie für jede Zahl unabhängiger, gleich schneller Stufen. Ob das Zerlegen in Stufen sich im Betrieb lohnt, ist eine andere Frage: Jeder weitere Dienst kostet Zeit im Netz, und die Bearbeitungszeiten sind dort nicht immer unabhängig.   "
},
{
  "id": "ex-fehlerfortpflanzung",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-fehlerfortpflanzung",
  "type": "Beispiel",
  "number": "5.1.23",
  "title": "Fehlerfortpflanzung bei einer Streckenmessung.",
  "body": " Fehlerfortpflanzung bei einer Streckenmessung   Ein Vermessungsteam bestimmt eine Strecke in drei Abschnitten. Die Messfehler der Abschnitte (in Millimetern) sind unabhängig und normalverteilt mit Erwartungswert 0 und den Standardabweichungen 2, 3 und 6. Der Fehler der Gesamtstrecke ist ihre Summe . Benutzen Sie und .  Welche Verteilung hat ?   Mit welcher Wahrscheinlichkeit ist die Gesamtstrecke um mehr als 14 mm falsch?    Das Team kann einen der drei Abschnitte mit einem besseren Gerät messen und dessen Standardabweichung halbieren. Welchen sollte es wählen, und was gewinnt es?          Nach , Teil (3), ist normalverteilt mit Erwartungswert 0 und Varianz , also .     .    Halbiert man die Standardabweichung eines Abschnitts, sinkt die Varianz der Summe um , also am stärksten beim größten . Beim dritten Abschnitt sinkt sie auf , die Standardabweichung auf ; beim ersten bliebe . Also den dritten Abschnitt; dann ist und , etwa ein Sechzehntel des bisherigen Werts.     Weil sich Varianzen addieren und nicht Standardabweichungen, bestimmt der größte Einzelfehler fast allein den Gesamtfehler: Der Abschnitt mit der Standardabweichung 6 trägt 36 der 49 Einheiten Varianz bei. Wer ein Messverfahren oder eine Datenpipeline verbessern will, sucht deshalb zuerst die größte Fehlerquelle. Dass die Summe normalverteilt ist, braucht man erst für die Wahrscheinlichkeiten in (b) und (c).   "
},
{
  "id": "tab-summen-familien",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#tab-summen-familien",
  "type": "Tabelle",
  "number": "5.1.24",
  "title": "Momenterzeugende Funktionen und Summen unabhängiger Zufallsvariablen",
  "body": " Momenterzeugende Funktionen und Summen unabhängiger Zufallsvariablen       Verteilung   Summe unabhängiger      Summanden:      mit :      mit :     ,  keine Gleichverteilung     ,  Summanden:     ,  mit :      mit :    "
},
{
  "id": "prop-quadrat-standardnormal",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#prop-quadrat-standardnormal",
  "type": "Proposition",
  "number": "5.1.25",
  "title": "Das Quadrat einer standardnormalverteilten Größe.",
  "body": " Das Quadrat einer standardnormalverteilten Größe   Für ist für , und .    Für substituieren wir : und das letzte Integral ist 1. Nach hat die momenterzeugende Funktion . Mit folgt die Behauptung.   "
},
{
  "id": "def-chi-quadrat",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#def-chi-quadrat",
  "type": "Definition",
  "number": "5.1.26",
  "title": "Chi-Quadrat-Verteilung.",
  "body": " Chi-Quadrat-Verteilung  Chi-Quadrat-Verteilung  Freiheitsgrade   Seien unabhängig und -verteilt. Die Verteilung von heißt Chi-Quadrat-Verteilung mit  Freiheitsgraden , kurz .   "
},
{
  "id": "thm-chi-quadrat",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#thm-chi-quadrat",
  "type": "Satz",
  "number": "5.1.27",
  "title": "Eigenschaften der Chi-Quadrat-Verteilung.",
  "body": " Eigenschaften der Chi-Quadrat-Verteilung       , mit der Dichte für .    Für ist und .     , also für . Allgemein ist .       (1) Nach ist jedes , und die sind unabhängig. Nach , Teil (4), addieren sich die Formparameter zu ; die Dichte ist die der Gammaverteilung aus . (2) Es ist , und nach ist , also . Erwartungswerte und, wegen der Unabhängigkeit, Varianzen addieren sich. (3) und .   "
},
{
  "id": "fig-chi-quadrat-dichten",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#fig-chi-quadrat-dichten",
  "type": "Abbildung",
  "number": "5.1.28",
  "title": "",
  "body": " Dichten von für . Für wächst die Dichte bei 0 über alle Grenzen, für ist es die Dichte von . Der Gipfel liegt für bei .   Vier Dichtekurven auf der positiven Achse, mit wachsendem n immer weiter rechts und flacher   Über dem Bereich von 0 bis 14 stehen vier Kurven. Die für n gleich 1 kommt von oben, steigt also bei 0 über alle Grenzen, und fällt dann schnell ab. Die für n gleich 2 beginnt bei 0 mit der Höhe 0,5 und fällt exponentiell. Die für n gleich 4 beginnt bei 0, erreicht bei 2 ihr Maximum 0,18 und fällt dann. Die für n gleich 8 erreicht ihr Maximum 0,11 bei 6 und ist am breitesten. Eine Legende rechts in der Mitte ordnet die Linienarten zu.     "
},
{
  "id": "ex-anomalie-sensoren",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#ex-anomalie-sensoren",
  "type": "Beispiel",
  "number": "5.1.29",
  "title": "Eine Prüfgröße für vier Sensoren.",
  "body": " Eine Prüfgröße für vier Sensoren   Eine Maschine wird mit vier Sensoren überwacht. Im Normalbetrieb ist jeder Messwert normalverteilt mit bekanntem Erwartungswert und bekannter Standardabweichung, und die vier Messwerte sind unabhängig. Das System bildet aus den standardisierten Abweichungen die Prüfgröße und meldet eine Anomalie, wenn ist.   Welche Verteilung hat im Normalbetrieb? Bestimmen Sie Erwartungswert und Varianz.    Wie oft meldet das System im Normalbetrieb fälschlich eine Anomalie?    Alle vier Sensoren zeigen gleichzeitig eine Abweichung von Standardabweichungen. Meldet das System eine Anomalie? Wie ungewöhnlich wäre eine solche Abweichung bei einem einzelnen Sensor? Benutzen Sie .           nach , mit und .    Mit der Erlang-Formel für : , also bei knapp 2 % der Messungen.     : Das System meldet eine Anomalie. Bei einem einzelnen Sensor ist ; etwa jeder vierzehnte Messwert weicht so weit ab.     Jeder Sensor für sich ist unauffällig, aber vier gleichzeitige Abweichungen dieser Größe kommen im Normalbetrieb selten vor. Genau das erkennt die Prüfgröße, und eine Regel, die jeden Sensor einzeln prüft, würde es übersehen. ist das Quadrat des Abstands vom Normalzustand, gemessen in Standardabweichungen. Hängen die Sensoren voneinander ab, misst man den Abstand mit der Kovarianzmatrix aus , als ; für normalverteilte Zufallsvektoren ist auch dieser Mahalanobis-Abstand Mahalanobis-Abstand im Quadrat -verteilt (ohne Beweis).   "
},
{
  "id": "sub-zusammenfassung-5-1-2",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#sub-zusammenfassung-5-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Diskrete Faltung. Stetige Faltung. Momenterzeugende Funktion. Momente durch Ableiten. Eindeutigkeit und Produktregel. Familien unter Summen. Chi-Quadrat-Verteilung. "
},
{
  "id": "exercise-buch-tetraeder-wuerfel",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#exercise-buch-tetraeder-wuerfel",
  "type": "Übung",
  "number": "5.1.7.1",
  "title": "Ein Tetraeder und ein halber Würfel.",
  "body": " Ein Tetraeder und ein halber Würfel   Ein fairer Tetraeder zeigt die Zahlen 1 bis 4, ein fairer Würfel trägt die Zahlen 1, 2 und 3 je zweimal. Beide werden unabhängig geworfen; ist die Zahl des Tetraeders, die des Würfels.  Bestimmen Sie die Verteilung von mit der Faltung.  Bestimmen Sie .   Bestimmen Sie aus der Verteilung, und prüfen Sie das Ergebnis mit der Linearität.          Jedes der zwölf Paare hat die Wahrscheinlichkeit , und ist mal die Zahl der Summanden , die nicht verschwinden: , , , , , für .     .     , und .      "
},
{
  "id": "exercise-buch-differenz-exponential",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#exercise-buch-differenz-exponential",
  "type": "Übung",
  "number": "5.1.7.2",
  "title": "Die Differenz zweier Wartezeiten.",
  "body": " Die Differenz zweier Wartezeiten    und seien unabhängig und -verteilt.   Bestimmen Sie die Dichte von . Hinweis : hat die Dichte . Unterscheiden Sie und .   Bestimmen Sie .         Nach ist , und der Integrand ist positiv, wenn und ist. Für : . Für läuft das Integral ab 0 und ergibt . Zusammen ist .     .     Diese Verteilung heißt Laplace-Verteilung . Sie kehrt in als Vorwissen wieder, das kleine Parameter bevorzugt, und führt dort auf die Lasso-Regression.   "
},
{
  "id": "exercise-buch-mgf-geometrisch",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#exercise-buch-mgf-geometrisch",
  "type": "Übung",
  "number": "5.1.7.3",
  "title": "Die momenterzeugende Funktion der geometrischen Verteilung.",
  "body": " Die momenterzeugende Funktion der geometrischen Verteilung   Sei mit und .   Zeigen Sie für .   Bestimmen Sie durch Ableiten.   Welche momenterzeugende Funktion hat die Summe von unabhängigen -verteilten Zufallsvariablen, und was ist ihr Erwartungswert?          Mit der geometrischen Reihe: .    Mit der Quotientenregel ist , also .    Nach ist es , die momenterzeugende Funktion der negativen Binomialverteilung aus . Der Erwartungswert ist .      "
},
{
  "id": "exercise-buch-normal-linear",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#exercise-buch-normal-linear",
  "type": "Übung",
  "number": "5.1.7.4",
  "title": "Eine Linearkombination normalverteilter Größen.",
  "body": " Eine Linearkombination normalverteilter Größen    und seien unabhängig.   Welche Verteilung hat ? Begründen Sie mit momenterzeugenden Funktionen.    Bestimmen Sie . Benutzen Sie .           . Das ist die momenterzeugende Funktion von , und nach ist .     , denn .      "
},
{
  "id": "exercise-buch-chi-quadrat-sechs",
  "level": "2",
  "url": "sec-summen-von-zufallsvariablen.html#exercise-buch-chi-quadrat-sechs",
  "type": "Übung",
  "number": "5.1.7.5",
  "title": "Sechs Freiheitsgrade.",
  "body": " Sechs Freiheitsgrade   Sei .  Bestimmen Sie und die Standardabweichung von .  Bestimmen Sie .          und , also .     , und mit ist .     Dieselbe Zahl kam in als Wahrscheinlichkeit für höchstens zwei Anrufe vor. Das ist kein Zufall: Die Wartezeit bis zum dritten Ereignis ist genau dann länger als , wenn bis höchstens zwei Ereignisse eintreten.   "
},
{
  "id": "sec-grenzwertsaetze",
  "level": "1",
  "url": "sec-grenzwertsaetze.html",
  "type": "Abschnitt",
  "number": "5.2",
  "title": "Grenzwertsätze: Gesetz der großen Zahlen und zentraler Grenzwertsatz",
  "body": " Grenzwertsätze: Gesetz der großen Zahlen und zentraler Grenzwertsatz    Nach diesem Abschnitt können Sie     mit den Ungleichungen von Markov und Tschebyscheff die Wahrscheinlichkeit großer Werte und großer Abweichungen nach oben abschätzen, wenn von einer Verteilung nur Erwartungswert und Varianz bekannt sind,    das schwache Gesetz der großen Zahlen angeben, aus der Ungleichung von Tschebyscheff herleiten und an einem Modell prüfen, ob seine Voraussetzungen erfüllt sind,    stochastische Konvergenz und Konvergenz in Verteilung unterscheiden und den zentralen Grenzwertsatz samt seinen Voraussetzungen formulieren,    Wahrscheinlichkeiten für Summen und Mittelwerte vieler unabhängiger Größen mit der Normalverteilung nähern, auch für Binomial- und Poisson-Verteilungen, und begründen, wann die Näherung trägt,    beurteilen, wie genau eine Monte-Carlo-Simulation, ein Mittelwert mit Fehlerbalken oder ein A\/B-Test ist, und daraus einen nötigen Umfang bestimmen.      Eine Simulation soll die Wahrscheinlichkeit schätzen, dass ein Stromnetz bei einem Sturm ausfällt. Jeder Lauf würfelt Windgeschwindigkeiten und Leitungsschäden aus und meldet am Ende Ausfall oder kein Ausfall ; der Anteil der Ausfälle über alle Läufe ist die Schätzung. Warum nähert dieser Anteil die gesuchte Wahrscheinlichkeit überhaupt an? Und wie viele Läufe braucht man, bis er auf einen Prozentpunkt genau ist? Beide Fragen handeln von einer Summe sehr vieler Zufallsvariablen, und beide lassen sich beantworten, ohne die Verteilung der einzelnen Summanden zu kennen. Erwartungswert und Varianz genügen.   beginnt mit zwei Ungleichungen, die aus Erwartungswert und Varianz eine Schranke für große Abweichungen machen, gleich wie die Größe verteilt ist. Aus ihnen folgt in in wenigen Zeilen das Gesetz der großen Zahlen: Das Mittel vieler unabhängiger Beobachtungen liegt mit großer Wahrscheinlichkeit nah an ihrem Erwartungswert. sagt genauer, wie die Abweichungen verteilt sind: näherungsweise normal, mit einer Streuung, die wie eins durch die Wurzel aus der Zahl der Beobachtungen fällt. Das ist der Kern der Woche. macht daraus ein Werkzeug für Summen, Mittelwerte, Binomial- und Poisson-Verteilung und wendet es auf Simulationen, Fehlerbalken, A\/B-Tests und Versicherungen an. Gerechnet wird dabei mit bekannten Parametern oder mit Schranken für sie; wie man unbekannte Parameter aus Daten schätzt, ist das Thema von .    Die Ungleichungen von Markov und Tschebyscheff  Kennt man von einer Zufallsvariablen nur den Erwartungswert und die Varianz, so kennt man ihre Verteilung nicht. Trotzdem lässt sich über ihre Ränder etwas sagen. Eine nichtnegative Größe mit kleinem Erwartungswert kann nicht oft sehr groß sein, sonst wäre ihr Erwartungswert größer. Und eine Größe mit kleiner Varianz kann nicht oft weit von ihrem Erwartungswert entfernt liegen. Die beiden Sätze dieses Unterabschnitts machen das genau.   Ungleichung von Markov  Ungleichung von Markov  Markov-Ungleichung   Sei eine Zufallsvariable mit und endlichem Erwartungswert. Dann gilt für jedes      Sei stetig mit der Dichte . Wegen ist für , und Im ersten Schritt lassen wir das Integral von 0 bis weg, das nicht negativ ist; im zweiten benutzen wir, dass im verbleibenden Bereich ist. Teilen durch ergibt die Behauptung. Für diskretes steht dieselbe Rechnung mit Summen über die Werte von .    Die Voraussetzung ist nötig. Eine Größe, die die Werte und je mit Wahrscheinlichkeit annimmt, hat den Erwartungswert 0, und trotzdem ist . Negative Werte können große positive Werte im Erwartungswert ausgleichen; die Voraussetzung schließt diesen Ausgleich aus.   Ungleichung von Tschebyscheff  Ungleichung von Tschebyscheff  Tschebyscheff-Ungleichung   Sei eine Zufallsvariable mit Erwartungswert und endlicher Varianz. Dann gilt für jedes      Die Zufallsvariable ist nichtnegativ und hat den Erwartungswert . Weil beide Seiten nichtnegativ sind, ist genau dann, wenn ist. Mit für folgt     Mit , wobei die Standardabweichung ist, lautet die Ungleichung Innerhalb von zwei Standardabweichungen um den Erwartungswert liegen also mindestens drei Viertel der Wahrscheinlichkeit, innerhalb von drei mindestens acht Neuntel, und das für jede Verteilung mit endlicher Varianz. Bei der Normalverteilung sind es nach 95,45 % und 99,73 %. Die Schranken von Tschebyscheff sind grob, dafür gelten sie immer.  Die Ungleichung schätzt beide Ränder zusammen ab. Fragt man nur nach einem, etwa nach , so gilt dieselbe Schranke erst recht, denn das Ereignis ist im Ereignis enthalten. Ebenso darf man die Ungleichung von Markov auf eine nichtnegative Funktion von anwenden; die Ungleichung von Tschebyscheff ist genau das, für .   Wie gut sind die Schranken?   Die Zahl der Anfragen, die ein Webserver in einer Sekunde erhält, sei -verteilt.   Schätzen Sie mit der Ungleichung von Markov und mit der von Tschebyscheff nach oben ab.    Berechnen Sie mit dem Taschenrechner und vergleichen Sie.    Zeigen Sie, dass sich die Schranke von Tschebyscheff für ohne weitere Kenntnis der Verteilung nicht verbessern lässt: Geben Sie eine Zufallsvariable mit Erwartungswert 4 und Varianz 4 an, für die Gleichheit gilt.          Nach ist . Markov: . Tschebyscheff: Das Ereignis ist in enthalten, also ist .     . Die Schranke von Markov ist rund fünfzigmal zu groß, die von Tschebyscheff rund vierzehnmal.    Sei mit Wahrscheinlichkeit und oder mit Wahrscheinlichkeit je . Aus Symmetriegründen ist , und . Genau mit Wahrscheinlichkeit ist .     Die Schranken gelten für jede Verteilung mit diesen Kennzahlen, auch für eine so ungewöhnliche wie in (c), die ihre ganze Abweichung auf zwei Punkte legt. Für eine bestimmte, gutartige Verteilung wie die Poisson-Verteilung sind sie deshalb grob. Ihr Wert liegt woanders: Man muss die Verteilung nicht kennen.     Ein Alarm ohne Verteilungsannahme   Ein Monitoring überwacht die Last eines Rechnerclusters. Aus dem Normalbetrieb kennt man Erwartungswert und Standardabweichung der Last, aber nicht ihre Verteilung. Ein Alarm geht los, wenn die Last um mindestens von abweicht.   Welches garantiert, dass im Normalbetrieb höchstens 1 % der Messungen einen Fehlalarm auslösen?    Welches genügte, wenn die Last normalverteilt wäre?    Ein Kollege wählt und beruft sich auf die -Regel. Was kann er ohne Verteilungsannahme garantieren?          Nach ist die Fehlalarmrate höchstens , und heißt .    Für normalverteilte Last ist die Fehlalarmrate , und heißt , nach also .    Nur , also höchstens rund 11 % Fehlalarme. Die 0,27 % der -Regel gelten nur unter der Normalverteilung.     Eine Garantie ohne Verteilungsannahme ist teuer: Die Schwelle liegt fast viermal so weit draußen wie unter der Normalverteilung, und echte Lastspitzen werden entsprechend später erkannt. Dafür hält sie auch bei schiefen Verteilungen mit schweren Rändern, bei denen große Abweichungen nach viel öfter vorkommen als unter der Glocke.    Für ein Mittel unabhängiger Beobachtungen wird die Ungleichung von Tschebyscheff mit wachsender Zahl der Beobachtungen immer schärfer, weil die Varianz des Mittels fällt. Das Mittel von Beobachtungen heißt in der Statistik und auf den Folien der Vorlesung Stichprobenmittel Stichprobenmittel Mittelwert .   Tschebyscheff für ein Mittel   Seien unabhängig mit gemeinsamem Erwartungswert und gemeinsamer Varianz , und sei . Dann gilt für jedes      Nach , das mit auch für stetige Zufallsvariablen gilt, ist und . Das setzen wir in ein.      Das Gesetz der großen Zahlen  Die rechte Seite in geht für gegen 0, wie klein auch ist. Für großes liegt das Mittel also mit großer Wahrscheinlichkeit beliebig nah an . Um das kurz sagen zu können, braucht man einen Konvergenzbegriff für Zufallsvariablen.   Stochastische Konvergenz  stochastische Konvergenz  Konvergenz stochastische   Eine Folge von Zufallsvariablen  konvergiert stochastisch oder in Wahrscheinlichkeit gegen eine Zufallsvariable , wenn für jedes  ist. Wir schreiben . Oft ist eine Konstante , also die Zufallsvariable, die immer den Wert hat.    Stochastische Konvergenz heißt nicht, dass irgendwann gleich ist. Sie heißt: Für jedes feste, große ist eine Abweichung um mehr als unwahrscheinlich, und zwar beliebig unwahrscheinlich, wenn nur groß genug ist.   Schwaches Gesetz der großen Zahlen  Gesetz der großen Zahlen schwaches   Seien unabhängig und identisch verteilt mit Erwartungswert und endlicher Varianz . Dann konvergiert das Mittel stochastisch gegen :     Sei . Ist , so ist erst recht . Mit folgt und die rechte Seite strebt für gegen 0.    Die endliche Varianz braucht nur dieser Beweis, nicht der Satz selbst, wie ausführt; auf den Folien der Vorlesung verlangt er lediglich einen endlichen Erwartungswert.   zeigt das Gesetz an Würfeln. Am Anfang springt das Mittel weit, denn ein einzelner Wurf verschiebt es stark. Mit jedem Wurf zählt der neue Wert weniger, und die drei Folgen ziehen sich auf 3,5 zusammen. Wie schnell, verrät der Trichter: Er hat die Breite , also zwei Standardabweichungen des Mittels. Um die Abweichung zu halbieren, braucht man viermal so viele Würfe. Der Trichter gilt für jedes einzeln: Nach liegt das Mittel mit Wahrscheinlichkeit mindestens darin, nach sogar mit rund 95 %. Dass eine einzelne Folge ihn eine Weile verlässt, schließt das nicht aus.   Drei Folgen von je 2000 Würfen eines fairen Würfels und das Mittel der ersten Würfe, auf logarithmischer Achse. Die dünnen Linien sind mit .   Drei schwankende Kurven, die sich mit wachsendem n auf die Höhe 3,5 zusammenziehen   Waagrecht steht die Zahl der Würfe von 1 bis 2000 auf logarithmischer Skala, senkrecht das Mittel der ersten Würfe zwischen 1 und 6. Drei Kurven beginnen bei verschiedenen Augenzahlen und schwanken in den ersten zehn Würfen stark. Danach werden die Ausschläge kleiner; ab einigen hundert Würfen liegen alle drei Kurven nahe der waagrechten Linie bei 3,5. Zwei dünne Linien bilden einen Trichter um 3,5, der sich wie eins durch die Wurzel aus verengt; die Kurven bleiben fast immer darin.      Der wichtigste Spezialfall betrifft Häufigkeiten. Er rechtfertigt, eine Wahrscheinlichkeit durch eine relative Häufigkeit zu schätzen.   Relative Häufigkeit und Wahrscheinlichkeit  relative Häufigkeit  Häufigkeit relative   Ein Zufallsexperiment wird unabhängig wiederholt, und sei der Anteil der ersten Wiederholungen, in denen das Ereignis eintritt. Dann ist , und für jedes gilt     Sei der Indikator von in der -ten Wiederholung. Die sind unabhängig und -verteilt mit , also nach mit Erwartungswert und Varianz , und ist ihr Mittel. Die erste Ungleichung ist , die zweite folgt aus . Daraus folgt die stochastische Konvergenz wie im Beweis von .    Damit ist eingelöst, was angekündigt hat: Dass die relative Häufigkeit gegen die Wahrscheinlichkeit strebt, ist kein zusätzliches Axiom, sondern folgt aus den Axiomen von Kolmogorov. Die Wahrscheinlichkeit als Zahl in einem Modell und die Wahrscheinlichkeit als Häufigkeit auf lange Sicht passen zusammen.   Konvergenz hängt von der Skalierung ab   Ein Dienst hat Clients, von denen jeder unabhängig als Poisson-Prozess mit der Rate 1 je Minute anfragt. Zusammen bilden ihre Anfragen nach einen Poisson-Prozess mit der Rate , und die Wartezeit bis zur ersten Anfrage ist -verteilt.  Zeigen Sie .   Konvergiert auch stochastisch gegen 0? Bestimmen Sie dazu die Verteilung von .   Was gilt für ?         Für ist , und das strebt gegen 0.    Für ist : Die Größe ist für jedes  -verteilt. Insbesondere ist für jedes ; das strebt nicht gegen 0, also konvergiert nicht stochastisch gegen 0.     strebt gegen 0, also ist .     Je mehr Clients, desto schneller kommt die erste Anfrage, und schrumpft gegen 0. Wie schnell, zeigt die Skalierung: Vergrößert man um einen Faktor, der langsamer wächst als , bleibt der Grenzwert 0; vergrößert man um genau , bleibt eine feste Verteilung übrig, die nicht mehr schrumpft; vergrößert man um mehr, wächst die Größe über alle Grenzen. Dieselbe Frage nach der richtigen Skalierung führt beim Mittel in auf den Faktor .     Wie viele Simulationsläufe?  Monte-Carlo-Simulation   Eine Simulation schätzt die Wahrscheinlichkeit , dass ein Stromnetz bei einem Sturm ausfällt, durch den Anteil der Ausfälle in unabhängigen Läufen.   Wie viele Läufe garantieren nach der Ungleichung von Tschebyscheff, dass mit Wahrscheinlichkeit mindestens 95 % um weniger als 0,01 von abweicht, gleich wie groß ist?    Aus einer ersten Rechnung weiß man, dass höchstens 0,02 ist. Wie viele Läufe genügen dann?    Bei ist eine Abweichung um 0,01 aber halb so groß wie selbst. Wie viele Läufe braucht man für eine Abweichung von weniger als 0,002, also einem Zehntel von ?          Nach genügt , also .    Mit statt genügt , also .     heißt .     Seltene Ereignisse sind teuer zu simulieren. Wer ihre Wahrscheinlichkeit nach Tschebyscheff auf ein Zehntel genau kennen will, braucht so viele Läufe, dass das Ereignis rund 2000-mal eintritt: Bei und 98 000 Läufen sind es knapp 2000 Ausfälle. Die Schranken von Tschebyscheff sind dabei vorsichtig; zeigt, dass schon einige hundert Ausfälle genügen.     Monte-Carlo-Integration  Monte-Carlo-Integration  Dasselbe Prinzip berechnet Integrale. Ist auf gleichverteilt und eine Funktion auf , so ist nach  . Nach dem Gesetz der großen Zahlen nähert deshalb der Mittelwert von für unabhängige, gleichverteilte das Integral an. Ebenso nähert der Anteil zufälliger Punkte im Einheitsquadrat, die unter dem Graphen einer Funktion mit Werten in liegen, die Fläche unter dem Graphen an; das ist . In beiden Fällen fällt die Standardabweichung der Schätzung wie , gleich in wie vielen Dimensionen man integriert. Für Integrale über hundert oder tausend Variablen, wie sie in der Finanzmathematik, der Physik und beim Rechnen mit Bayes-Modellen vorkommen, sind solche Verfahren deshalb oft die einzigen, die in vertretbarer Zeit fertig werden.   Die folgende Zelle schätzt : Der Viertelkreis mit Radius 1 hat die Fläche , also ist der vierfache Anteil der Zufallspunkte im Viertelkreis eine Schätzung von . Die letzte Zeile gibt die Standardabweichung dieser Schätzung nach und aus, mit .   import random, math # Monte-Carlo-Schätzung von pi mit n Zufallspunkten im Einheitsquadrat. # Probieren Sie n = 100, 10000, 100000. n = 1000 treffer = len([1 for _ in range(n) if random.random() ** 2 + random.random() ** 2 <= 1]) schaetzung = 4 * treffer \/ n p = math.pi \/ 4 print(\"Schätzung: %.4f\" % schaetzung) print(\"Abweichung von pi: %.4f\" % (schaetzung - math.pi)) print(\"Standardabweichung: %.4f\" % (4 * math.sqrt(p * (1 - p) \/ n)))    Was das Gesetz braucht  Der Beweis von benutzt nur zweierlei: Alle haben denselben Erwartungswert , und strebt gegen 0. Für das Zweite genügt nach , dass die dieselbe Varianz haben und paarweise unkorreliert sind, denn dann fallen alle Kovarianzen weg. Identisch verteilt müssen die also nicht sein, unabhängig auch nicht. Ganz ohne Bedingung an die Abhängigkeit trägt der Beweis aber nicht: In haben je zwei Fehler den Korrelationskoeffizienten , und strebt gegen , nicht gegen 0; die Schranke von Tschebyscheff strebt dann nicht mehr gegen 0. Anschaulich: Der Teil des Fehlers, den alle Modelle gemeinsam haben, mittelt sich nicht heraus, wie viele man auch zusammennimmt.  In der anderen Richtung gilt das Gesetz für unabhängige, identisch verteilte auch ohne endliche Varianz, sobald der Erwartungswert existiert; der Beweis braucht dann andere Mittel und fehlt hier. Bei schweren Rändern, etwa bei der Antwortzeit aus , die keine Varianz hat, konvergiert das Mittel aber langsamer, einzelne extreme Werte ziehen es immer wieder weit nach oben, und die Fehlerbalken aus gelten nicht.    Das starke Gesetz der großen Zahlen  Gesetz der großen Zahlen starkes  Konvergenz fast sichere  fast sichere Konvergenz  Unter den Voraussetzungen von gilt sogar Mit Wahrscheinlichkeit 1 konvergiert die Folge der Mittelwerte, die man tatsächlich beobachtet, gegen . Man sagt,  konvergiert fast sicher gegen , und schreibt . Der Unterschied zum schwachen Gesetz steckt in der Reihenfolge: Dort steht der Grenzwert außerhalb der Wahrscheinlichkeit, hier innerhalb. Das schwache Gesetz ließe zu, dass eine einzelne Folge von Mittelwerten immer wieder einmal weit von abweicht, nur zu immer selteneren Zeitpunkten; das starke schließt das aus. Fast sichere Konvergenz zieht stochastische Konvergenz nach sich, aber nicht umgekehrt. Für die Rechnungen in diesem Buch macht der Unterschied nichts aus, und das starke Gesetz bleibt hier ohne Beweis.     Der zentrale Grenzwertsatz  Das Gesetz der großen Zahlen sagt, dass gegen 0 strebt. Wie die kleinen Abweichungen für großes verteilt sind, sagt es nicht. Um sie zu sehen, vergrößert man sie mit dem passenden Faktor. Das Mittel hat die Standardabweichung , also hat für jedes den Erwartungswert 0 und die Varianz 1. Wie in ist das die Skalierung, bei der weder 0 noch etwas Unbeschränktes herauskommt. In und in der Zelle zur Faltung von Würfeln in wurde die Verteilung der Augensumme mit jedem Würfel glockenförmiger. Der zentrale Grenzwertsatz sagt, dass das keine Eigenheit von Würfeln ist. Um ihn auszusprechen, braucht man einen zweiten Konvergenzbegriff.   Konvergenz in Verteilung  Konvergenz in Verteilung   Eine Folge von Zufallsvariablen mit den Verteilungsfunktionen  konvergiert in Verteilung gegen eine Zufallsvariable mit der Verteilungsfunktion , wenn für jedes gilt, an dem stetig ist. Wir schreiben .    Hier nähern sich nur die Verteilungen an, nicht die Werte. In ist für jedes  -verteilt; die Folge konvergiert also in Verteilung gegen eine -verteilte Größe, und das sagt nichts darüber, ob sich ihre Werte einander nähern. Ganz deutlich wird der Unterschied an mit . Weil die Standardnormalverteilung symmetrisch ist, ist jedes standardnormalverteilt, und die Folge konvergiert in Verteilung. Ihre Werte springen aber hin und her: Zwei aufeinanderfolgende liegen um auseinander.  Umgekehrt zieht stochastische Konvergenz die Konvergenz in Verteilung nach sich (ohne Beweis). Die Stellen, an denen springt, nimmt die Definition aus, weil dort nichts konvergieren muss: Die Konstanten sollen gegen konvergieren, aber für jedes , während ist.   Zentraler Grenzwertsatz  zentraler Grenzwertsatz  Grenzwertsatz zentraler   Seien unabhängig und identisch verteilt mit Erwartungswert und endlicher Varianz , und sei . Dann konvergiert in Verteilung gegen eine standardnormalverteilte Zufallsvariable, also gilt für jedes      Bemerkenswert ist, was in den Voraussetzungen fehlt. Über die Verteilung der braucht man nur zu wissen, dass ihre Varianz endlich ist. Ob sie diskret oder stetig sind, symmetrisch oder schief, ändert am Grenzwert nichts; es ändert nur, wie schnell er erreicht wird. zeigt das für Summen von Exponentialzeiten, also für die Gesamtzeit einer Pipeline aus gleich schnellen Stufen wie in .   Verteilung der standardisierten Summe von unabhängigen -verteilten Zeiten für , als Histogramm mit der Klassenbreite , darüber die Dichte der Standardnormalverteilung. Die Balken sind exakt berechnet, nicht simuliert: ist -verteilt.   Vier Histogramme, die von einer schiefen Form zur Glockenkurve übergehen   Vier Felder in zwei Reihen, jedes mit einem Histogramm über dem Bereich von minus 3 bis 4 und der Glockenkurve der Standardnormalverteilung. Für beginnt das Histogramm erst bei minus 1, springt dort auf seinen höchsten Wert nahe 0,9 und fällt nach rechts langsam ab; mit der Glocke hat es wenig gemein. Für ist es noch deutlich nach rechts schief, der Gipfel liegt links von 0. Für folgt es der Glocke schon gut, mit einem etwas längeren rechten Rand. Für ist es von der Glocke kaum noch zu unterscheiden.      Bei einer Stufe hat die standardisierte Zeit die schiefe Gestalt der Exponentialverteilung, bei vier ist sie noch deutlich schief, bei 64 von der Glocke kaum zu unterscheiden. Am längsten halten sich die Unterschiede in den Rändern. Selbst für 64 Stufen ist die Wahrscheinlichkeit, mehr als zwei Standardabweichungen über dem Erwartungswert zu liegen, nach der Erlang-Verteilung 0,029, nach der Normalverteilung nur 0,023. Für die Mitte der Verteilung reichen also weniger Summanden als für kleine Randwahrscheinlichkeiten.   Vertiefung: Warum der Satz gilt  Diese Skizze ist kein Prüfungsstoff. Sie zeigt, warum gerade die Normalverteilung herauskommt, und benutzt dafür die momenterzeugenden Funktionen aus . Dafür nehmen wir zusätzlich an, dass in einer Umgebung von 0 existiert; der Satz selbst braucht das nicht. Ersetzt man durch , ändert sich nicht, also dürfen wir und annehmen. Dann ist , und nach und ist Nach ist , und . Die Taylorformel ergibt für kleines  mit einem Rest, für den gegen 0 strebt. Mit ist also und der Zähler strebt gegen . Aus der Analysis kennt man für , also strebt gegen , die momenterzeugende Funktion von nach . Ein Satz, der verschärft und den wir nicht beweisen, schließt daraus auf die Konvergenz in Verteilung.  An der Rechnung sieht man, warum die Normalverteilung universell ist: Von der Verteilung der Summanden überleben im Grenzwert nur die ersten beiden Momente, und die sind durch das Standardisieren festgelegt. Alles, was die Summanden sonst unterscheidet, steckt im Rest und verschwindet.    Viele Rundungsfehler   Wie in werden Rechnungsbeträge auf volle Euro gerundet und dann addiert, diesmal Beträge. Die Rundungsfehler seien unabhängig und auf gleichverteilt, und sei der Fehler der Summe.   Sei . Wie ist näherungsweise verteilt? Mit welcher Wahrscheinlichkeit weicht die Summe der gerundeten Beträge um mehr als 5 Euro von der wahren Summe ab? Vergleichen Sie mit der Schranke von Tschebyscheff.   Dieselbe Frage für .   Was geschieht für wachsendes mit dem mittleren Fehler je Betrag, , und was mit selbst?          Nach hat jeder Rundungsfehler den Erwartungswert 0 und die Varianz . Also ist und , die Standardabweichung ist , und nach ist näherungsweise -verteilt. Damit ist Tschebyscheff liefert nur .    Jetzt ist und die Standardabweichung 10, also . Die Schranke von Tschebyscheff ist und sagt gar nichts mehr.     strebt gegen 0, und nach ist . Die Standardabweichung von ist aber und wächst über alle Grenzen. Nach dem zentralen Grenzwertsatz ist , und das strebt gegen .     Die Rundungsfehler heben sich teilweise auf. Deshalb wächst der Gesamtfehler nur wie und nicht wie , und je Betrag wird er klein. Aber er wächst: Bei 1200 Beträgen ist die Summe öfter um mehr als 5 Euro falsch als nicht. Das ist der Unterschied der beiden Grenzwertsätze in einem Bild: Das Gesetz der großen Zahlen spricht über das Mittel, der zentrale Grenzwertsatz über die Summe in der Größenordnung .     Warum so vieles normalverteilt ist  Damit ist begründet, was vorweggenommen hat: Eine Größe, die sich aus vielen kleinen, unabhängigen Beiträgen zusammensetzt, ist näherungsweise normalverteilt, gleich wie die Beiträge verteilt sind. Streng genommen verlangt identisch verteilte Summanden. Allgemeinere Fassungen, etwa der Satz von Lindeberg, den wir nicht beweisen, lassen verschieden verteilte unabhängige Summanden zu, solange keiner von ihnen die Summe dominiert. Messfehler aus vielen Störquellen, das Füllgewicht einer Packung, die Summe vieler Rundungsfehler gehören dazu. Wirken die Beiträge nicht addierend, sondern multiplikativ, wie Zinsen, Wachstum oder Verdünnung, so addieren sich ihre Logarithmen. Der Logarithmus des Produkts ist dann näherungsweise normalverteilt und das Produkt selbst näherungsweise lognormalverteilt, wie angekündigt hat. Wo dagegen ein einziger Beitrag dominiert, wo die Beiträge stark voneinander abhängen oder wo ihre Varianz unendlich ist, gibt es keinen Grund für eine Glocke.   Die folgende Zelle simuliert die standardisierte Summe aus und druckt ein Histogramm aus Zeichen. In der dritten Spalte steht, welcher Anteil nach der Glockenkurve in die Klasse fiele.   import random, math # n Exp(1)-Zeiten addieren und standardisieren, 10000-mal. # Spalten: Klasse ab, Anteil, Anteil nach der Glockenkurve, Balken. # Probieren Sie n = 1, 4, 30. n = 4 z = [(sum([random.expovariate(1) for _ in range(n)]) - n) \/ math.sqrt(n) for _ in range(10000)] for k in range(-6, 8): a = k \/ 2 anteil = len([x for x in z if a <= x < a + 0.5]) \/ len(z) glocke = 0.5 * math.exp(-(a + 0.25) ** 2 \/ 2) \/ math.sqrt(2 * math.pi) balken = \"#\" * int(150 * anteil) print(\"%5.1f %.3f %.3f %s\" % (a, anteil, glocke, balken))     Die Normalnäherung in der Praxis  Für großes liest man als Näherung: Summe und Mittel von unabhängigen, identisch verteilten Größen mit Erwartungswert und Varianz sind näherungsweise normalverteilt, Gemeint ist: Man berechnet Wahrscheinlichkeiten für oder , als wären sie normalverteilt mit diesen Kennzahlen, also mit , etwa Die Kennzahlen selbst sind dabei exakt, denn und gelten für jedes . Genähert wird nur die Gestalt der Verteilung. Die Größe , die Standardabweichung des Mittels, heißt in der Datenanalyse auch Standardfehler Standardfehler .  Zwei Familien aus sind selbst Summen. Eine -verteilte Größe hat dieselbe Verteilung wie die Zahl der Erfolge in unabhängigen Bernoulli-Versuchen, also wie eine Summe von unabhängigen -verteilten Größen. Und nach hat eine -verteilte Größe dieselbe Verteilung wie die Summe von unabhängigen -verteilten.   Normalnäherung der Binomial- und der Poisson-Verteilung  Normalnäherung      (Satz von de Moivre und Laplace) Satz von de Moivre und Laplace de Moivre und Laplace, Satz von Ist mit festem , so konvergiert für in Verteilung gegen eine standardnormalverteilte Zufallsvariable.    Ist , so konvergiert für in Verteilung gegen eine standardnormalverteilte Zufallsvariable.       (1) ist verteilt wie eine Summe von unabhängigen -verteilten Größen mit und ; das ist . (2) Für ganzzahliges ist verteilt wie eine Summe von unabhängigen -verteilten Größen mit , und wieder greift der Satz. Dass die Aussage auch zwischen den ganzen Zahlen gilt, übernehmen wir ohne Beweis.     Wann die Näherung trägt  Der Satz spricht über ; wie groß in einer Anwendung sein muss, sagt er nicht. Bewährt hat sich diese Faustregel Faustregel für die Normalnäherung : Die Normalnäherung einer Binomialverteilung ist brauchbar, wenn ist, die Standardabweichung also mindestens 3; die einer Poisson-Verteilung, wenn ist. Dann liegt der Bereich von drei Standardabweichungen um den Erwartungswert ganz im Bereich der möglichen Werte, und die Verteilung ist nicht mehr nennenswert schief. Ist sehr klein und nicht groß, nähert man eine Binomialverteilung stattdessen nach durch eine Poisson-Verteilung. Für Summen anderer Größen nennt man oft . Das ist bei symmetrischen Summanden reichlich, bei Würfeln ist schon die Summe von dreien glockenförmig ( ); bei schiefen Summanden kann es zu wenig sein, vor allem für kleine Randwahrscheinlichkeiten, wie der Vergleich der Ränder im Absatz nach zeigt.    Kontinuitätskorrektur  Kontinuitätskorrektur  Eine ganzzahlige Größe wird hier durch eine stetige genähert. Für ganzzahliges ist aber , während die Normalnäherung für beide Seiten verschiedene Werte liefert. Am genauesten ist meist die Mitte: Man nähert durch und durch . Das heißt Kontinuitätskorrektur . Sie lohnt sich, wenn die Standardabweichung klein ist, sodass ein halber Schritt ins Gewicht fällt; bei großer Standardabweichung ändert sie wenig. Wo nicht ausdrücklich anders gesagt, rechnen die Beispiele dieses Abschnitts ohne sie. Wer sie benutzt, sagt es dazu.    Mit und ohne Korrektur   Ein Händler schreibt 48 Firmenkunden wegen eines Angebots an; jeder sagt unabhängig von den anderen mit Wahrscheinlichkeit zu. Sei die Zahl der Zusagen.   Ist die Faustregel für die Normalnäherung erfüllt? Nähern Sie ohne und mit Kontinuitätskorrektur.    Der exakte Wert ist . Welche Näherung ist besser?           mit und ; die Faustregel ist gerade erfüllt. Ohne Korrektur ist , mit Korrektur .    Die Näherung mit Korrektur trifft den exakten Wert bis auf 0,002, die ohne Korrektur liegt um 0,035 daneben.     Bei einer Standardabweichung von 3 ist ein halber Schritt ein Sechstel der Standardabweichung, und das merkt man. Bei 400 Kunden wäre die Standardabweichung 8,7, und die Korrektur verschöbe das Ergebnis kaum noch.    Die folgende Zelle vergleicht die exakten Wahrscheinlichkeiten einer -Verteilung mit der Höhe der Glockenkurve gleichen Erwartungswerts und gleicher Varianz an der Stelle . Das ist die Kontinuitätskorrektur für einen einzelnen Wert: ist die Wahrscheinlichkeit für das Intervall von bis , und die Fläche unter der Glocke darüber ist ungefähr ihre Höhe bei .   import math # X ~ Bin(n; 0,1): P(X = k) gegen die Glockenkurve gleicher Kennzahlen. # Probieren Sie n = 10, 100, 1000. n = 10 mu, s = 0.1 * n, math.sqrt(0.09 * n) w = [0.9 ** n] for k in range(n): w.append(w[-1] * (n - k) \/ (k + 1) \/ 9) glocke = [math.exp(-((k - mu) \/ s) ** 2 \/ 2) \/ (s * math.sqrt(2 * math.pi)) for k in range(n + 1)] fehler = max([abs(w[k] - glocke[k]) for k in range(n + 1)]) print(\"n p (1 - p) = %.1f\" % (s * s)) print(\"größter Fehler: %.1f %% der größten Wahrscheinlichkeit\" % (100 * fehler \/ max(w)))   Bei liegt die Glocke an einer Stelle um mehr als ein Viertel der größten Wahrscheinlichkeit daneben. Bei ist , die Faustregel also gerade erfüllt, und der größte Fehler ist auf gut 6 % geschrumpft.   Wie viele Simulationsläufe, genauer   In der Situation von soll der Anteil der Ausfälle mit Wahrscheinlichkeit 95 % um weniger als von abweichen.   Wie viele Läufe braucht man nach dem zentralen Grenzwertsatz für , gleich wie groß ist?    Wie viele für , wenn höchstens 0,02 ist?    Woher kommt der Unterschied zu den Zahlen aus ?           ist näherungsweise normalverteilt mit Erwartungswert und Standardabweichung , also ist Das ist mindestens 0,95, wenn das Argument von mindestens ist, also für . Mit und genügen Läufe.     .    Tschebyscheff muss für jede Verteilung gelten. Für 95 % hält die Ungleichung erst Standardabweichungen für sicher, die Normalverteilung schon 1,96. Weil mit dem Quadrat dieser Zahl wächst, braucht Tschebyscheff -mal so viele Läufe.     In der Praxis gibt man zu einer Monte-Carlo-Schätzung deshalb den geschätzten Standardfehler an und liest ihn wie eine Standardabweichung einer Normalverteilung. Dass man dabei das unbekannte durch die Schätzung ersetzt, ist für großes unbedenklich; genauer untersucht das die Statistik.     Was ein Fehlerbalken sagt  Fehlerbalken   Ein Benchmark misst die Laufzeit eines Programms 25-mal. Die Messungen seien unabhängig mit Erwartungswert und Standardabweichung 10 ms. Ein Diagramm zeigt ihren Mittelwert mit einem Fehlerbalken von zwei Standardfehlern nach oben und unten.   Wie lang ist der Fehlerbalken, und mit welcher Wahrscheinlichkeit liegt höchstens so weit von entfernt?    Tatsächlich laufen alle Messungen auf derselben Maschine, und je zwei haben den Korrelationskoeffizienten 0,2. Wie groß ist die Standardabweichung von dann? Um welchen Faktor ist der Fehlerbalken zu kurz?    Wie viele unabhängige Messungen braucht man, damit mit Wahrscheinlichkeit 95 % um höchstens 1 ms von abweicht?          Der Standardfehler ist  ms, der Fehlerbalken reicht also 4 ms nach oben und unten. Nach dem zentralen Grenzwertsatz ist .    Nach ist , die Standardabweichung also  ms statt 2 ms. Der Fehlerbalken ist um den Faktor 2,4 zu kurz.     heißt , also mindestens 385 Messungen.     Ein Fehlerbalken von zwei Standardfehlern beschreibt, wie weit das Mittel bei unabhängigen Messungen typischerweise vom Erwartungswert abweicht, und für eine Halbierung braucht man viermal so viele Messungen. Sind die Messungen korreliert, etwa weil Cache, Temperatur oder Hintergrundlast der Maschine alle betreffen, ist der Balken zu kurz, und mehr Messungen auf derselben Maschine helfen nach nur begrenzt. Benchmarks verteilt man deshalb auf mehrere Maschinen und Zeitpunkte.     Unterschiede im A\/B-Test, die nur Zufall sind  A\/B-Test   Ein Onlinehändler zeigt 2000 Besuchern Variante A seiner Startseite und 2000 anderen Variante B. Angenommen, beide Varianten sind gleich gut: Jeder Besucher kauft mit Wahrscheinlichkeit 0,05, unabhängig von den anderen. Seien und die beobachteten Kaufquoten und .   Bestimmen Sie Erwartungswert und Standardabweichung von .    Mit welcher Wahrscheinlichkeit unterscheiden sich die beobachteten Kaufquoten trotzdem um mindestens einen Prozentpunkt?    Welchen Unterschied überschreitet bei gleich guten Varianten nur mit Wahrscheinlichkeit 5 %?           ist -verteilt, also ist und , ebenso für . Weil beide Gruppen unabhängig sind, ist und , die Standardabweichung also etwa 0,0069.    Mit ist die Faustregel in jeder Gruppe weit erfüllt, es sind also genug Summanden. ist selbst eine Summe von 4000 unabhängigen Größen, einer je Besucher; fasst man je einen Besucher von A und einen von B zusammen, sind es 2000 unabhängige, identisch verteilte. Nach rechnen wir für deshalb mit der Normalverteilung: .     heißt , also rund 1,35 Prozentpunkte.     Eine Kaufquote von 5,0 % gegen 6,0 % sieht nach einem klaren Sieger aus. Bei 2000 Besuchern je Variante kommt ein Unterschied dieser Größe, in die eine oder die andere Richtung, aber in etwa jedem siebten Test zustande, obwohl beide Varianten gleich gut sind. Exakt mit der Binomialverteilung gerechnet sind es 0,157 statt 0,147: Die Kaufzahlen sind ganzzahlig, und bei einer Standardabweichung der Zähldifferenz von knapp 14 macht ein halber Schritt noch etwas aus, wie in . Erst ab etwa 1,35 Prozentpunkten wird ein Unterschied so selten, dass man ihn ernst nehmen mag. Wie man daraus eine Entscheidungsregel macht und deren Fehler kontrolliert, ist Gegenstand der Statistik.     Risikoausgleich im Kollektiv   Eine Versicherung hat gleichartige Verträge. In einem Jahr meldet jeder Vertrag unabhängig von den anderen mit Wahrscheinlichkeit 0,02 einen Schaden von 5000 Euro, sonst nichts. Die Prämie je Vertrag ist 110 Euro.   Bestimmen Sie Erwartungswert und Standardabweichung des Schadens eines Vertrags und der Schadensumme aller Verträge.    Mit welcher Wahrscheinlichkeit übersteigt die Prämieneinnahmen bei 4900 Verträgen, mit welcher bei 19 600?    Welche Prämie müsste die Versicherung bei 4900 Verträgen verlangen, damit die Schäden die Einnahmen nur mit Wahrscheinlichkeit 0,0228 übersteigen?          Der Schaden eines Vertrags ist mit , hat also den Erwartungswert 100 Euro und die Standardabweichung  Euro. Die Schadensumme hat den Erwartungswert und die Standardabweichung .    Die Einnahmen sind , und Für ist das , für ist es .    Bei der Prämie ist , und mit heißt , dass ist. Die Prämie müsste 120 Euro betragen. Exakt mit der Binomialverteilung gerechnet, übersteigen die Schäden die Einnahmen dann mit Wahrscheinlichkeit 0,026: Die Schadensumme ist rechtsschief und hat im rechten Rand mehr Gewicht als die Glocke, und gerade dort zählt es für eine Versicherung.     Die Prämie liegt über dem erwarteten Schaden, und der gesamte Zuschlag wächst mit der Zahl der Verträge wie , die Streuung der Schadensumme nur wie . Deshalb sinkt die Wahrscheinlichkeit eines Verlustjahrs bei gleichem Zuschlag, je größer das Kollektiv ist, und umgekehrt kommt ein großes Kollektiv mit einem kleineren Zuschlag je Vertrag aus. Das ist der Risikoausgleich, auf dem jede Versicherung beruht. Er setzt Unabhängigkeit voraus: Ein Hochwasser, das viele Verträge zugleich trifft, gleicht sich nicht aus, und dafür gibt es Rückversicherungen.      Zusammenfassung      Markov und Tschebyscheff. Für ist . Für jede Zufallsvariable mit Erwartungswert und endlicher Varianz ist , mit also höchstens . Die Schranken gelten für jede Verteilung, auch für einen einzelnen Rand, und sind deshalb grob.     Gesetz der großen Zahlen. Für unabhängige, identisch verteilte mit endlicher Varianz ist , also : Das Mittel konvergiert stochastisch gegen den Erwartungswert, die relative Häufigkeit gegen die Wahrscheinlichkeit. Das starke Gesetz sagt sogar .     Voraussetzungen. Der Beweis braucht gleiche Erwartungswerte und ; dafür genügen paarweise unkorrelierte Größen gleicher Varianz. Bei gleich korrelierten Größen strebt gegen : Gemeinsame Fehler mitteln sich nicht heraus.     Zentraler Grenzwertsatz. Für unabhängige, identisch verteilte mit endlicher Varianz ist mit , also . Konvergenz in Verteilung heißt, dass die Verteilungsfunktionen an den Stetigkeitsstellen konvergieren, nicht die Werte.     Normalnäherung. Für großes ist und ; der Standardfehler halbiert sich mit viermal so vielen Beobachtungen. nähert man durch , wenn ist, durch , wenn ist. Bei kleiner Standardabweichung verbessert die Kontinuitätskorrektur meist die Näherung.     Anwendungen. Eine Monte-Carlo-Schätzung, ein Mittelwert mit Fehlerbalken, die Differenz zweier Quoten im A\/B-Test und die Schadensumme einer Versicherung sind Summen vieler unabhängiger Größen. Der Standardfehler fällt wie , und die Normalnäherung sagt, wie groß für eine verlangte Genauigkeit sein muss.       Übungsaufgaben   Schranken für eine gleichverteilte Wartezeit   Die Wartezeit (in Minuten) auf eine S-Bahn sei auf gleichverteilt.   Schätzen Sie mit der Ungleichung von Markov ab.    Schätzen Sie mit der Ungleichung von Tschebyscheff ab.   Berechnen Sie beide Wahrscheinlichkeiten exakt.          , also .     , also .     und . Beide Schranken sind gültig, aber weit vom wahren Wert entfernt.        Wie oft würfeln?   Ein fairer Würfel wird -mal geworfen, und sei der Anteil der Sechsen. Wie groß muss nach der Ungleichung von Tschebyscheff mindestens sein, damit mit Wahrscheinlichkeit mindestens 0,9 um weniger als 0,02 von abweicht?    Nach mit genügt , also . Mit 3473 Würfen ist die Bedingung erfüllt.     Eine Schicht voller Tickets   Ein Supportteam bearbeitet in einer Schicht 64 Tickets. Die Bearbeitungszeiten seien unabhängig und identisch verteilt mit Erwartungswert 12 Minuten und Standardabweichung 9 Minuten.   Mit welcher Wahrscheinlichkeit braucht das Team insgesamt mehr als 14 Stunden? Benutzen Sie .    Welche Gesamtzeit wird nur mit Wahrscheinlichkeit 2,5 % überschritten?          Die Gesamtzeit hat den Erwartungswert  Minuten und die Standardabweichung  Minuten. Nach dem zentralen Grenzwertsatz ist .      Minuten, gut 15 Stunden.        Anfragen je Minute   Ein Server erhält im Mittel 400 Anfragen je Minute; die Zahl der Anfragen in einer Minute sei Poisson-verteilt.   Ist die Faustregel für die Normalnäherung erfüllt? Nähern Sie ohne Kontinuitätskorrektur.    Nähern Sie dieselbe Wahrscheinlichkeit mit Korrektur; dazu ist . Der exakte Wert ist . Welche Näherung ist hier besser?           , die Standardabweichung ist 20. Also .     heißt , mit Korrektur also . Hier liegt ausnahmsweise die Näherung ohne Korrektur näher am exakten Wert. Bei einer Standardabweichung von 20 ändert die Korrektur ohnehin wenig, und die Poisson-Verteilung ist leicht nach rechts schief: Ihr rechter Rand ist etwas schwerer als der der Glocke, und das gleicht den halben Schritt hier gerade aus. Die Korrektur verbessert die Näherung meist, aber nicht immer.        "
},
{
  "id": "sec-grenzwertsaetze-2",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#sec-grenzwertsaetze-2",
  "type": "Lernziele",
  "number": "5.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     mit den Ungleichungen von Markov und Tschebyscheff die Wahrscheinlichkeit großer Werte und großer Abweichungen nach oben abschätzen, wenn von einer Verteilung nur Erwartungswert und Varianz bekannt sind,    das schwache Gesetz der großen Zahlen angeben, aus der Ungleichung von Tschebyscheff herleiten und an einem Modell prüfen, ob seine Voraussetzungen erfüllt sind,    stochastische Konvergenz und Konvergenz in Verteilung unterscheiden und den zentralen Grenzwertsatz samt seinen Voraussetzungen formulieren,    Wahrscheinlichkeiten für Summen und Mittelwerte vieler unabhängiger Größen mit der Normalverteilung nähern, auch für Binomial- und Poisson-Verteilungen, und begründen, wann die Näherung trägt,    beurteilen, wie genau eine Monte-Carlo-Simulation, ein Mittelwert mit Fehlerbalken oder ein A\/B-Test ist, und daraus einen nötigen Umfang bestimmen.    "
},
{
  "id": "thm-markov-ungleichung",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#thm-markov-ungleichung",
  "type": "Satz",
  "number": "5.2.1",
  "title": "Ungleichung von Markov.",
  "body": " Ungleichung von Markov  Ungleichung von Markov  Markov-Ungleichung   Sei eine Zufallsvariable mit und endlichem Erwartungswert. Dann gilt für jedes      Sei stetig mit der Dichte . Wegen ist für , und Im ersten Schritt lassen wir das Integral von 0 bis weg, das nicht negativ ist; im zweiten benutzen wir, dass im verbleibenden Bereich ist. Teilen durch ergibt die Behauptung. Für diskretes steht dieselbe Rechnung mit Summen über die Werte von .   "
},
{
  "id": "thm-tschebyscheff-ungleichung",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#thm-tschebyscheff-ungleichung",
  "type": "Satz",
  "number": "5.2.2",
  "title": "Ungleichung von Tschebyscheff.",
  "body": " Ungleichung von Tschebyscheff  Ungleichung von Tschebyscheff  Tschebyscheff-Ungleichung   Sei eine Zufallsvariable mit Erwartungswert und endlicher Varianz. Dann gilt für jedes      Die Zufallsvariable ist nichtnegativ und hat den Erwartungswert . Weil beide Seiten nichtnegativ sind, ist genau dann, wenn ist. Mit für folgt    "
},
{
  "id": "ex-schranken-vergleich",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-schranken-vergleich",
  "type": "Beispiel",
  "number": "5.2.3",
  "title": "Wie gut sind die Schranken?",
  "body": " Wie gut sind die Schranken?   Die Zahl der Anfragen, die ein Webserver in einer Sekunde erhält, sei -verteilt.   Schätzen Sie mit der Ungleichung von Markov und mit der von Tschebyscheff nach oben ab.    Berechnen Sie mit dem Taschenrechner und vergleichen Sie.    Zeigen Sie, dass sich die Schranke von Tschebyscheff für ohne weitere Kenntnis der Verteilung nicht verbessern lässt: Geben Sie eine Zufallsvariable mit Erwartungswert 4 und Varianz 4 an, für die Gleichheit gilt.          Nach ist . Markov: . Tschebyscheff: Das Ereignis ist in enthalten, also ist .     . Die Schranke von Markov ist rund fünfzigmal zu groß, die von Tschebyscheff rund vierzehnmal.    Sei mit Wahrscheinlichkeit und oder mit Wahrscheinlichkeit je . Aus Symmetriegründen ist , und . Genau mit Wahrscheinlichkeit ist .     Die Schranken gelten für jede Verteilung mit diesen Kennzahlen, auch für eine so ungewöhnliche wie in (c), die ihre ganze Abweichung auf zwei Punkte legt. Für eine bestimmte, gutartige Verteilung wie die Poisson-Verteilung sind sie deshalb grob. Ihr Wert liegt woanders: Man muss die Verteilung nicht kennen.   "
},
{
  "id": "ex-alarm-verteilungsfrei",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-alarm-verteilungsfrei",
  "type": "Beispiel",
  "number": "5.2.4",
  "title": "Ein Alarm ohne Verteilungsannahme.",
  "body": " Ein Alarm ohne Verteilungsannahme   Ein Monitoring überwacht die Last eines Rechnerclusters. Aus dem Normalbetrieb kennt man Erwartungswert und Standardabweichung der Last, aber nicht ihre Verteilung. Ein Alarm geht los, wenn die Last um mindestens von abweicht.   Welches garantiert, dass im Normalbetrieb höchstens 1 % der Messungen einen Fehlalarm auslösen?    Welches genügte, wenn die Last normalverteilt wäre?    Ein Kollege wählt und beruft sich auf die -Regel. Was kann er ohne Verteilungsannahme garantieren?          Nach ist die Fehlalarmrate höchstens , und heißt .    Für normalverteilte Last ist die Fehlalarmrate , und heißt , nach also .    Nur , also höchstens rund 11 % Fehlalarme. Die 0,27 % der -Regel gelten nur unter der Normalverteilung.     Eine Garantie ohne Verteilungsannahme ist teuer: Die Schwelle liegt fast viermal so weit draußen wie unter der Normalverteilung, und echte Lastspitzen werden entsprechend später erkannt. Dafür hält sie auch bei schiefen Verteilungen mit schweren Rändern, bei denen große Abweichungen nach viel öfter vorkommen als unter der Glocke.   "
},
{
  "id": "sub-ungleichungen-10",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#sub-ungleichungen-10",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Stichprobenmittel "
},
{
  "id": "cor-tschebyscheff-mittel",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#cor-tschebyscheff-mittel",
  "type": "Korollar",
  "number": "5.2.5",
  "title": "Tschebyscheff für ein Mittel.",
  "body": " Tschebyscheff für ein Mittel   Seien unabhängig mit gemeinsamem Erwartungswert und gemeinsamer Varianz , und sei . Dann gilt für jedes      Nach , das mit auch für stetige Zufallsvariablen gilt, ist und . Das setzen wir in ein.   "
},
{
  "id": "def-stochastische-konvergenz",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#def-stochastische-konvergenz",
  "type": "Definition",
  "number": "5.2.6",
  "title": "Stochastische Konvergenz.",
  "body": " Stochastische Konvergenz  stochastische Konvergenz  Konvergenz stochastische   Eine Folge von Zufallsvariablen  konvergiert stochastisch oder in Wahrscheinlichkeit gegen eine Zufallsvariable , wenn für jedes  ist. Wir schreiben . Oft ist eine Konstante , also die Zufallsvariable, die immer den Wert hat.   "
},
{
  "id": "thm-schwaches-gesetz",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#thm-schwaches-gesetz",
  "type": "Satz",
  "number": "5.2.7",
  "title": "Schwaches Gesetz der großen Zahlen.",
  "body": " Schwaches Gesetz der großen Zahlen  Gesetz der großen Zahlen schwaches   Seien unabhängig und identisch verteilt mit Erwartungswert und endlicher Varianz . Dann konvergiert das Mittel stochastisch gegen :     Sei . Ist , so ist erst recht . Mit folgt und die rechte Seite strebt für gegen 0.   "
},
{
  "id": "fig-laufendes-mittel",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#fig-laufendes-mittel",
  "type": "Abbildung",
  "number": "5.2.8",
  "title": "",
  "body": " Drei Folgen von je 2000 Würfen eines fairen Würfels und das Mittel der ersten Würfe, auf logarithmischer Achse. Die dünnen Linien sind mit .   Drei schwankende Kurven, die sich mit wachsendem n auf die Höhe 3,5 zusammenziehen   Waagrecht steht die Zahl der Würfe von 1 bis 2000 auf logarithmischer Skala, senkrecht das Mittel der ersten Würfe zwischen 1 und 6. Drei Kurven beginnen bei verschiedenen Augenzahlen und schwanken in den ersten zehn Würfen stark. Danach werden die Ausschläge kleiner; ab einigen hundert Würfen liegen alle drei Kurven nahe der waagrechten Linie bei 3,5. Zwei dünne Linien bilden einen Trichter um 3,5, der sich wie eins durch die Wurzel aus verengt; die Kurven bleiben fast immer darin.     "
},
{
  "id": "cor-relative-haeufigkeit",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#cor-relative-haeufigkeit",
  "type": "Korollar",
  "number": "5.2.9",
  "title": "Relative Häufigkeit und Wahrscheinlichkeit.",
  "body": " Relative Häufigkeit und Wahrscheinlichkeit  relative Häufigkeit  Häufigkeit relative   Ein Zufallsexperiment wird unabhängig wiederholt, und sei der Anteil der ersten Wiederholungen, in denen das Ereignis eintritt. Dann ist , und für jedes gilt     Sei der Indikator von in der -ten Wiederholung. Die sind unabhängig und -verteilt mit , also nach mit Erwartungswert und Varianz , und ist ihr Mittel. Die erste Ungleichung ist , die zweite folgt aus . Daraus folgt die stochastische Konvergenz wie im Beweis von .   "
},
{
  "id": "ex-wartezeit-skalierung",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-wartezeit-skalierung",
  "type": "Beispiel",
  "number": "5.2.10",
  "title": "Konvergenz hängt von der Skalierung ab.",
  "body": " Konvergenz hängt von der Skalierung ab   Ein Dienst hat Clients, von denen jeder unabhängig als Poisson-Prozess mit der Rate 1 je Minute anfragt. Zusammen bilden ihre Anfragen nach einen Poisson-Prozess mit der Rate , und die Wartezeit bis zur ersten Anfrage ist -verteilt.  Zeigen Sie .   Konvergiert auch stochastisch gegen 0? Bestimmen Sie dazu die Verteilung von .   Was gilt für ?         Für ist , und das strebt gegen 0.    Für ist : Die Größe ist für jedes  -verteilt. Insbesondere ist für jedes ; das strebt nicht gegen 0, also konvergiert nicht stochastisch gegen 0.     strebt gegen 0, also ist .     Je mehr Clients, desto schneller kommt die erste Anfrage, und schrumpft gegen 0. Wie schnell, zeigt die Skalierung: Vergrößert man um einen Faktor, der langsamer wächst als , bleibt der Grenzwert 0; vergrößert man um genau , bleibt eine feste Verteilung übrig, die nicht mehr schrumpft; vergrößert man um mehr, wächst die Größe über alle Grenzen. Dieselbe Frage nach der richtigen Skalierung führt beim Mittel in auf den Faktor .   "
},
{
  "id": "ex-monte-carlo-laeufe",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-monte-carlo-laeufe",
  "type": "Beispiel",
  "number": "5.2.11",
  "title": "Wie viele Simulationsläufe?",
  "body": " Wie viele Simulationsläufe?  Monte-Carlo-Simulation   Eine Simulation schätzt die Wahrscheinlichkeit , dass ein Stromnetz bei einem Sturm ausfällt, durch den Anteil der Ausfälle in unabhängigen Läufen.   Wie viele Läufe garantieren nach der Ungleichung von Tschebyscheff, dass mit Wahrscheinlichkeit mindestens 95 % um weniger als 0,01 von abweicht, gleich wie groß ist?    Aus einer ersten Rechnung weiß man, dass höchstens 0,02 ist. Wie viele Läufe genügen dann?    Bei ist eine Abweichung um 0,01 aber halb so groß wie selbst. Wie viele Läufe braucht man für eine Abweichung von weniger als 0,002, also einem Zehntel von ?          Nach genügt , also .    Mit statt genügt , also .     heißt .     Seltene Ereignisse sind teuer zu simulieren. Wer ihre Wahrscheinlichkeit nach Tschebyscheff auf ein Zehntel genau kennen will, braucht so viele Läufe, dass das Ereignis rund 2000-mal eintritt: Bei und 98 000 Läufen sind es knapp 2000 Ausfälle. Die Schranken von Tschebyscheff sind dabei vorsichtig; zeigt, dass schon einige hundert Ausfälle genügen.   "
},
{
  "id": "rem-ggz-voraussetzungen",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#rem-ggz-voraussetzungen",
  "type": "Bemerkung",
  "number": "5.2.12",
  "title": "Was das Gesetz braucht.",
  "body": " Was das Gesetz braucht  Der Beweis von benutzt nur zweierlei: Alle haben denselben Erwartungswert , und strebt gegen 0. Für das Zweite genügt nach , dass die dieselbe Varianz haben und paarweise unkorreliert sind, denn dann fallen alle Kovarianzen weg. Identisch verteilt müssen die also nicht sein, unabhängig auch nicht. Ganz ohne Bedingung an die Abhängigkeit trägt der Beweis aber nicht: In haben je zwei Fehler den Korrelationskoeffizienten , und strebt gegen , nicht gegen 0; die Schranke von Tschebyscheff strebt dann nicht mehr gegen 0. Anschaulich: Der Teil des Fehlers, den alle Modelle gemeinsam haben, mittelt sich nicht heraus, wie viele man auch zusammennimmt.  In der anderen Richtung gilt das Gesetz für unabhängige, identisch verteilte auch ohne endliche Varianz, sobald der Erwartungswert existiert; der Beweis braucht dann andere Mittel und fehlt hier. Bei schweren Rändern, etwa bei der Antwortzeit aus , die keine Varianz hat, konvergiert das Mittel aber langsamer, einzelne extreme Werte ziehen es immer wieder weit nach oben, und die Fehlerbalken aus gelten nicht.  "
},
{
  "id": "rem-starkes-gesetz",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#rem-starkes-gesetz",
  "type": "Bemerkung",
  "number": "5.2.13",
  "title": "Das starke Gesetz der großen Zahlen.",
  "body": " Das starke Gesetz der großen Zahlen  Gesetz der großen Zahlen starkes  Konvergenz fast sichere  fast sichere Konvergenz  Unter den Voraussetzungen von gilt sogar Mit Wahrscheinlichkeit 1 konvergiert die Folge der Mittelwerte, die man tatsächlich beobachtet, gegen . Man sagt,  konvergiert fast sicher gegen , und schreibt . Der Unterschied zum schwachen Gesetz steckt in der Reihenfolge: Dort steht der Grenzwert außerhalb der Wahrscheinlichkeit, hier innerhalb. Das schwache Gesetz ließe zu, dass eine einzelne Folge von Mittelwerten immer wieder einmal weit von abweicht, nur zu immer selteneren Zeitpunkten; das starke schließt das aus. Fast sichere Konvergenz zieht stochastische Konvergenz nach sich, aber nicht umgekehrt. Für die Rechnungen in diesem Buch macht der Unterschied nichts aus, und das starke Gesetz bleibt hier ohne Beweis.  "
},
{
  "id": "def-konvergenz-in-verteilung",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#def-konvergenz-in-verteilung",
  "type": "Definition",
  "number": "5.2.14",
  "title": "Konvergenz in Verteilung.",
  "body": " Konvergenz in Verteilung  Konvergenz in Verteilung   Eine Folge von Zufallsvariablen mit den Verteilungsfunktionen  konvergiert in Verteilung gegen eine Zufallsvariable mit der Verteilungsfunktion , wenn für jedes gilt, an dem stetig ist. Wir schreiben .   "
},
{
  "id": "thm-zentraler-grenzwertsatz",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#thm-zentraler-grenzwertsatz",
  "type": "Satz",
  "number": "5.2.15",
  "title": "Zentraler Grenzwertsatz.",
  "body": " Zentraler Grenzwertsatz  zentraler Grenzwertsatz  Grenzwertsatz zentraler   Seien unabhängig und identisch verteilt mit Erwartungswert und endlicher Varianz , und sei . Dann konvergiert in Verteilung gegen eine standardnormalverteilte Zufallsvariable, also gilt für jedes     "
},
{
  "id": "fig-zgs-histogramme",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#fig-zgs-histogramme",
  "type": "Abbildung",
  "number": "5.2.16",
  "title": "",
  "body": " Verteilung der standardisierten Summe von unabhängigen -verteilten Zeiten für , als Histogramm mit der Klassenbreite , darüber die Dichte der Standardnormalverteilung. Die Balken sind exakt berechnet, nicht simuliert: ist -verteilt.   Vier Histogramme, die von einer schiefen Form zur Glockenkurve übergehen   Vier Felder in zwei Reihen, jedes mit einem Histogramm über dem Bereich von minus 3 bis 4 und der Glockenkurve der Standardnormalverteilung. Für beginnt das Histogramm erst bei minus 1, springt dort auf seinen höchsten Wert nahe 0,9 und fällt nach rechts langsam ab; mit der Glocke hat es wenig gemein. Für ist es noch deutlich nach rechts schief, der Gipfel liegt links von 0. Für folgt es der Glocke schon gut, mit einem etwas längeren rechten Rand. Für ist es von der Glocke kaum noch zu unterscheiden.     "
},
{
  "id": "rem-zgs-beweisskizze",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#rem-zgs-beweisskizze",
  "type": "Bemerkung",
  "number": "5.2.17",
  "title": "Vertiefung: Warum der Satz gilt.",
  "body": " Vertiefung: Warum der Satz gilt  Diese Skizze ist kein Prüfungsstoff. Sie zeigt, warum gerade die Normalverteilung herauskommt, und benutzt dafür die momenterzeugenden Funktionen aus . Dafür nehmen wir zusätzlich an, dass in einer Umgebung von 0 existiert; der Satz selbst braucht das nicht. Ersetzt man durch , ändert sich nicht, also dürfen wir und annehmen. Dann ist , und nach und ist Nach ist , und . Die Taylorformel ergibt für kleines  mit einem Rest, für den gegen 0 strebt. Mit ist also und der Zähler strebt gegen . Aus der Analysis kennt man für , also strebt gegen , die momenterzeugende Funktion von nach . Ein Satz, der verschärft und den wir nicht beweisen, schließt daraus auf die Konvergenz in Verteilung.  An der Rechnung sieht man, warum die Normalverteilung universell ist: Von der Verteilung der Summanden überleben im Grenzwert nur die ersten beiden Momente, und die sind durch das Standardisieren festgelegt. Alles, was die Summanden sonst unterscheidet, steckt im Rest und verschwindet.  "
},
{
  "id": "ex-rundungsfehler-viele",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-rundungsfehler-viele",
  "type": "Beispiel",
  "number": "5.2.18",
  "title": "Viele Rundungsfehler.",
  "body": " Viele Rundungsfehler   Wie in werden Rechnungsbeträge auf volle Euro gerundet und dann addiert, diesmal Beträge. Die Rundungsfehler seien unabhängig und auf gleichverteilt, und sei der Fehler der Summe.   Sei . Wie ist näherungsweise verteilt? Mit welcher Wahrscheinlichkeit weicht die Summe der gerundeten Beträge um mehr als 5 Euro von der wahren Summe ab? Vergleichen Sie mit der Schranke von Tschebyscheff.   Dieselbe Frage für .   Was geschieht für wachsendes mit dem mittleren Fehler je Betrag, , und was mit selbst?          Nach hat jeder Rundungsfehler den Erwartungswert 0 und die Varianz . Also ist und , die Standardabweichung ist , und nach ist näherungsweise -verteilt. Damit ist Tschebyscheff liefert nur .    Jetzt ist und die Standardabweichung 10, also . Die Schranke von Tschebyscheff ist und sagt gar nichts mehr.     strebt gegen 0, und nach ist . Die Standardabweichung von ist aber und wächst über alle Grenzen. Nach dem zentralen Grenzwertsatz ist , und das strebt gegen .     Die Rundungsfehler heben sich teilweise auf. Deshalb wächst der Gesamtfehler nur wie und nicht wie , und je Betrag wird er klein. Aber er wächst: Bei 1200 Beträgen ist die Summe öfter um mehr als 5 Euro falsch als nicht. Das ist der Unterschied der beiden Grenzwertsätze in einem Bild: Das Gesetz der großen Zahlen spricht über das Mittel, der zentrale Grenzwertsatz über die Summe in der Größenordnung .   "
},
{
  "id": "sub-normalnaeherung-2",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#sub-normalnaeherung-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Standardfehler "
},
{
  "id": "cor-normalnaeherung-binomial-poisson",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#cor-normalnaeherung-binomial-poisson",
  "type": "Korollar",
  "number": "5.2.19",
  "title": "Normalnäherung der Binomial- und der Poisson-Verteilung.",
  "body": " Normalnäherung der Binomial- und der Poisson-Verteilung  Normalnäherung      (Satz von de Moivre und Laplace) Satz von de Moivre und Laplace de Moivre und Laplace, Satz von Ist mit festem , so konvergiert für in Verteilung gegen eine standardnormalverteilte Zufallsvariable.    Ist , so konvergiert für in Verteilung gegen eine standardnormalverteilte Zufallsvariable.       (1) ist verteilt wie eine Summe von unabhängigen -verteilten Größen mit und ; das ist . (2) Für ganzzahliges ist verteilt wie eine Summe von unabhängigen -verteilten Größen mit , und wieder greift der Satz. Dass die Aussage auch zwischen den ganzen Zahlen gilt, übernehmen wir ohne Beweis.   "
},
{
  "id": "sub-normalnaeherung-5-2",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#sub-normalnaeherung-5-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Faustregel "
},
{
  "id": "rem-kontinuitaetskorrektur",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#rem-kontinuitaetskorrektur",
  "type": "Bemerkung",
  "number": "5.2.20",
  "title": "Kontinuitätskorrektur.",
  "body": " Kontinuitätskorrektur  Kontinuitätskorrektur  Eine ganzzahlige Größe wird hier durch eine stetige genähert. Für ganzzahliges ist aber , während die Normalnäherung für beide Seiten verschiedene Werte liefert. Am genauesten ist meist die Mitte: Man nähert durch und durch . Das heißt Kontinuitätskorrektur . Sie lohnt sich, wenn die Standardabweichung klein ist, sodass ein halber Schritt ins Gewicht fällt; bei großer Standardabweichung ändert sie wenig. Wo nicht ausdrücklich anders gesagt, rechnen die Beispiele dieses Abschnitts ohne sie. Wer sie benutzt, sagt es dazu.  "
},
{
  "id": "ex-kontinuitaetskorrektur",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-kontinuitaetskorrektur",
  "type": "Beispiel",
  "number": "5.2.21",
  "title": "Mit und ohne Korrektur.",
  "body": " Mit und ohne Korrektur   Ein Händler schreibt 48 Firmenkunden wegen eines Angebots an; jeder sagt unabhängig von den anderen mit Wahrscheinlichkeit zu. Sei die Zahl der Zusagen.   Ist die Faustregel für die Normalnäherung erfüllt? Nähern Sie ohne und mit Kontinuitätskorrektur.    Der exakte Wert ist . Welche Näherung ist besser?           mit und ; die Faustregel ist gerade erfüllt. Ohne Korrektur ist , mit Korrektur .    Die Näherung mit Korrektur trifft den exakten Wert bis auf 0,002, die ohne Korrektur liegt um 0,035 daneben.     Bei einer Standardabweichung von 3 ist ein halber Schritt ein Sechstel der Standardabweichung, und das merkt man. Bei 400 Kunden wäre die Standardabweichung 8,7, und die Korrektur verschöbe das Ergebnis kaum noch.   "
},
{
  "id": "ex-monte-carlo-normal",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-monte-carlo-normal",
  "type": "Beispiel",
  "number": "5.2.22",
  "title": "Wie viele Simulationsläufe, genauer.",
  "body": " Wie viele Simulationsläufe, genauer   In der Situation von soll der Anteil der Ausfälle mit Wahrscheinlichkeit 95 % um weniger als von abweichen.   Wie viele Läufe braucht man nach dem zentralen Grenzwertsatz für , gleich wie groß ist?    Wie viele für , wenn höchstens 0,02 ist?    Woher kommt der Unterschied zu den Zahlen aus ?           ist näherungsweise normalverteilt mit Erwartungswert und Standardabweichung , also ist Das ist mindestens 0,95, wenn das Argument von mindestens ist, also für . Mit und genügen Läufe.     .    Tschebyscheff muss für jede Verteilung gelten. Für 95 % hält die Ungleichung erst Standardabweichungen für sicher, die Normalverteilung schon 1,96. Weil mit dem Quadrat dieser Zahl wächst, braucht Tschebyscheff -mal so viele Läufe.     In der Praxis gibt man zu einer Monte-Carlo-Schätzung deshalb den geschätzten Standardfehler an und liest ihn wie eine Standardabweichung einer Normalverteilung. Dass man dabei das unbekannte durch die Schätzung ersetzt, ist für großes unbedenklich; genauer untersucht das die Statistik.   "
},
{
  "id": "ex-fehlerbalken",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-fehlerbalken",
  "type": "Beispiel",
  "number": "5.2.23",
  "title": "Was ein Fehlerbalken sagt.",
  "body": " Was ein Fehlerbalken sagt  Fehlerbalken   Ein Benchmark misst die Laufzeit eines Programms 25-mal. Die Messungen seien unabhängig mit Erwartungswert und Standardabweichung 10 ms. Ein Diagramm zeigt ihren Mittelwert mit einem Fehlerbalken von zwei Standardfehlern nach oben und unten.   Wie lang ist der Fehlerbalken, und mit welcher Wahrscheinlichkeit liegt höchstens so weit von entfernt?    Tatsächlich laufen alle Messungen auf derselben Maschine, und je zwei haben den Korrelationskoeffizienten 0,2. Wie groß ist die Standardabweichung von dann? Um welchen Faktor ist der Fehlerbalken zu kurz?    Wie viele unabhängige Messungen braucht man, damit mit Wahrscheinlichkeit 95 % um höchstens 1 ms von abweicht?          Der Standardfehler ist  ms, der Fehlerbalken reicht also 4 ms nach oben und unten. Nach dem zentralen Grenzwertsatz ist .    Nach ist , die Standardabweichung also  ms statt 2 ms. Der Fehlerbalken ist um den Faktor 2,4 zu kurz.     heißt , also mindestens 385 Messungen.     Ein Fehlerbalken von zwei Standardfehlern beschreibt, wie weit das Mittel bei unabhängigen Messungen typischerweise vom Erwartungswert abweicht, und für eine Halbierung braucht man viermal so viele Messungen. Sind die Messungen korreliert, etwa weil Cache, Temperatur oder Hintergrundlast der Maschine alle betreffen, ist der Balken zu kurz, und mehr Messungen auf derselben Maschine helfen nach nur begrenzt. Benchmarks verteilt man deshalb auf mehrere Maschinen und Zeitpunkte.   "
},
{
  "id": "ex-ab-test-zufall",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-ab-test-zufall",
  "type": "Beispiel",
  "number": "5.2.24",
  "title": "Unterschiede im A\/B-Test, die nur Zufall sind.",
  "body": " Unterschiede im A\/B-Test, die nur Zufall sind  A\/B-Test   Ein Onlinehändler zeigt 2000 Besuchern Variante A seiner Startseite und 2000 anderen Variante B. Angenommen, beide Varianten sind gleich gut: Jeder Besucher kauft mit Wahrscheinlichkeit 0,05, unabhängig von den anderen. Seien und die beobachteten Kaufquoten und .   Bestimmen Sie Erwartungswert und Standardabweichung von .    Mit welcher Wahrscheinlichkeit unterscheiden sich die beobachteten Kaufquoten trotzdem um mindestens einen Prozentpunkt?    Welchen Unterschied überschreitet bei gleich guten Varianten nur mit Wahrscheinlichkeit 5 %?           ist -verteilt, also ist und , ebenso für . Weil beide Gruppen unabhängig sind, ist und , die Standardabweichung also etwa 0,0069.    Mit ist die Faustregel in jeder Gruppe weit erfüllt, es sind also genug Summanden. ist selbst eine Summe von 4000 unabhängigen Größen, einer je Besucher; fasst man je einen Besucher von A und einen von B zusammen, sind es 2000 unabhängige, identisch verteilte. Nach rechnen wir für deshalb mit der Normalverteilung: .     heißt , also rund 1,35 Prozentpunkte.     Eine Kaufquote von 5,0 % gegen 6,0 % sieht nach einem klaren Sieger aus. Bei 2000 Besuchern je Variante kommt ein Unterschied dieser Größe, in die eine oder die andere Richtung, aber in etwa jedem siebten Test zustande, obwohl beide Varianten gleich gut sind. Exakt mit der Binomialverteilung gerechnet sind es 0,157 statt 0,147: Die Kaufzahlen sind ganzzahlig, und bei einer Standardabweichung der Zähldifferenz von knapp 14 macht ein halber Schritt noch etwas aus, wie in . Erst ab etwa 1,35 Prozentpunkten wird ein Unterschied so selten, dass man ihn ernst nehmen mag. Wie man daraus eine Entscheidungsregel macht und deren Fehler kontrolliert, ist Gegenstand der Statistik.   "
},
{
  "id": "ex-risikoausgleich",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#ex-risikoausgleich",
  "type": "Beispiel",
  "number": "5.2.25",
  "title": "Risikoausgleich im Kollektiv.",
  "body": " Risikoausgleich im Kollektiv   Eine Versicherung hat gleichartige Verträge. In einem Jahr meldet jeder Vertrag unabhängig von den anderen mit Wahrscheinlichkeit 0,02 einen Schaden von 5000 Euro, sonst nichts. Die Prämie je Vertrag ist 110 Euro.   Bestimmen Sie Erwartungswert und Standardabweichung des Schadens eines Vertrags und der Schadensumme aller Verträge.    Mit welcher Wahrscheinlichkeit übersteigt die Prämieneinnahmen bei 4900 Verträgen, mit welcher bei 19 600?    Welche Prämie müsste die Versicherung bei 4900 Verträgen verlangen, damit die Schäden die Einnahmen nur mit Wahrscheinlichkeit 0,0228 übersteigen?          Der Schaden eines Vertrags ist mit , hat also den Erwartungswert 100 Euro und die Standardabweichung  Euro. Die Schadensumme hat den Erwartungswert und die Standardabweichung .    Die Einnahmen sind , und Für ist das , für ist es .    Bei der Prämie ist , und mit heißt , dass ist. Die Prämie müsste 120 Euro betragen. Exakt mit der Binomialverteilung gerechnet, übersteigen die Schäden die Einnahmen dann mit Wahrscheinlichkeit 0,026: Die Schadensumme ist rechtsschief und hat im rechten Rand mehr Gewicht als die Glocke, und gerade dort zählt es für eine Versicherung.     Die Prämie liegt über dem erwarteten Schaden, und der gesamte Zuschlag wächst mit der Zahl der Verträge wie , die Streuung der Schadensumme nur wie . Deshalb sinkt die Wahrscheinlichkeit eines Verlustjahrs bei gleichem Zuschlag, je größer das Kollektiv ist, und umgekehrt kommt ein großes Kollektiv mit einem kleineren Zuschlag je Vertrag aus. Das ist der Risikoausgleich, auf dem jede Versicherung beruht. Er setzt Unabhängigkeit voraus: Ein Hochwasser, das viele Verträge zugleich trifft, gleicht sich nicht aus, und dafür gibt es Rückversicherungen.   "
},
{
  "id": "sub-zusammenfassung-5-2-2",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#sub-zusammenfassung-5-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Markov und Tschebyscheff. Gesetz der großen Zahlen. Voraussetzungen. Zentraler Grenzwertsatz. Normalnäherung. Anwendungen. "
},
{
  "id": "exercise-buch-schranken-gleichverteilung",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#exercise-buch-schranken-gleichverteilung",
  "type": "Übung",
  "number": "5.2.6.1",
  "title": "Schranken für eine gleichverteilte Wartezeit.",
  "body": " Schranken für eine gleichverteilte Wartezeit   Die Wartezeit (in Minuten) auf eine S-Bahn sei auf gleichverteilt.   Schätzen Sie mit der Ungleichung von Markov ab.    Schätzen Sie mit der Ungleichung von Tschebyscheff ab.   Berechnen Sie beide Wahrscheinlichkeiten exakt.          , also .     , also .     und . Beide Schranken sind gültig, aber weit vom wahren Wert entfernt.      "
},
{
  "id": "exercise-buch-sechsen-tschebyscheff",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#exercise-buch-sechsen-tschebyscheff",
  "type": "Übung",
  "number": "5.2.6.2",
  "title": "Wie oft würfeln?",
  "body": " Wie oft würfeln?   Ein fairer Würfel wird -mal geworfen, und sei der Anteil der Sechsen. Wie groß muss nach der Ungleichung von Tschebyscheff mindestens sein, damit mit Wahrscheinlichkeit mindestens 0,9 um weniger als 0,02 von abweicht?    Nach mit genügt , also . Mit 3473 Würfen ist die Bedingung erfüllt.   "
},
{
  "id": "exercise-buch-tickets-summe",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#exercise-buch-tickets-summe",
  "type": "Übung",
  "number": "5.2.6.3",
  "title": "Eine Schicht voller Tickets.",
  "body": " Eine Schicht voller Tickets   Ein Supportteam bearbeitet in einer Schicht 64 Tickets. Die Bearbeitungszeiten seien unabhängig und identisch verteilt mit Erwartungswert 12 Minuten und Standardabweichung 9 Minuten.   Mit welcher Wahrscheinlichkeit braucht das Team insgesamt mehr als 14 Stunden? Benutzen Sie .    Welche Gesamtzeit wird nur mit Wahrscheinlichkeit 2,5 % überschritten?          Die Gesamtzeit hat den Erwartungswert  Minuten und die Standardabweichung  Minuten. Nach dem zentralen Grenzwertsatz ist .      Minuten, gut 15 Stunden.      "
},
{
  "id": "exercise-buch-poisson-normal",
  "level": "2",
  "url": "sec-grenzwertsaetze.html#exercise-buch-poisson-normal",
  "type": "Übung",
  "number": "5.2.6.4",
  "title": "Anfragen je Minute.",
  "body": " Anfragen je Minute   Ein Server erhält im Mittel 400 Anfragen je Minute; die Zahl der Anfragen in einer Minute sei Poisson-verteilt.   Ist die Faustregel für die Normalnäherung erfüllt? Nähern Sie ohne Kontinuitätskorrektur.    Nähern Sie dieselbe Wahrscheinlichkeit mit Korrektur; dazu ist . Der exakte Wert ist . Welche Näherung ist hier besser?           , die Standardabweichung ist 20. Also .     heißt , mit Korrektur also . Hier liegt ausnahmsweise die Näherung ohne Korrektur näher am exakten Wert. Bei einer Standardabweichung von 20 ändert die Korrektur ohnehin wenig, und die Poisson-Verteilung ist leicht nach rechts schief: Ihr rechter Rand ist etwas schwerer als der der Glocke, und das gleicht den halben Schritt hier gerade aus. Die Korrektur verbessert die Näherung meist, aber nicht immer.      "
},
{
  "id": "sec-parameterschaetzung",
  "level": "1",
  "url": "sec-parameterschaetzung.html",
  "type": "Abschnitt",
  "number": "6.1",
  "title": "Parameterschätzung: Maximum-Likelihood, MAP und Güteeigenschaften",
  "body": " Parameterschätzung: Maximum-Likelihood, MAP und Güteeigenschaften    Nach diesem Abschnitt können Sie     zu einem Modell und einer Stichprobe die Likelihood und die Log-Likelihood aufstellen und den Maximum-Likelihood-Schätzer durch Ableiten bestimmen, auch wenn die Daten unvollständig sind oder das Maximum am Rand liegt,    die Maximum-Likelihood-Schätzer für Bernoulli-, Poisson-, Exponential- und Normalverteilung angeben und begründen und die Methode der kleinsten Quadrate und die Kreuzentropie als Maximum-Likelihood deuten,    Vorwissen als A-priori-Verteilung ausdrücken, mit einem Beta- oder Gamma-Prior die A-posteriori-Verteilung von Hand bestimmen und daraus den MAP-Schätzer und den A-posteriori-Erwartungswert berechnen,    Ridge- und Lasso-Regression als MAP-Schätzung mit Gauß- bzw. Laplace-Prior herleiten und erklären, wie stark der Prior schrumpft,    Verzerrung, Varianz und mittleren quadratischen Fehler eines Schätzers berechnen, Schätzer damit vergleichen, die Konsistenz eines Schätzers begründen und erklären, warum die Stichprobenvarianz durch teilt,    erkennen, wann eine Größe - oder -verteilt ist.      Eine neue Anzeige wurde zehnmal eingeblendet und kein einziges Mal angeklickt. Wie groß ist ihre Klickrate? Der Anteil der Klicks in den Daten ist 0, aber niemand glaubt, dass die Anzeige nie angeklickt wird. Wer ähnliche Anzeigen kennt, weiß, dass Klickraten meist zwischen einem und acht Prozent liegen, und möchte dieses Wissen mit den zehn Beobachtungen verrechnen. Bisher war in diesem Buch die Verteilung immer gegeben und eine Wahrscheinlichkeit gesucht. Jetzt sind Daten gegeben, und gesucht ist der Parameter der Verteilung, die sie erzeugt hat.  Der Abschnitt hat drei Teile. wählt den Parameter, unter dem die beobachteten Daten am wahrscheinlichsten sind; dieses Prinzip steckt in fast jedem Lernverfahren, von der Regressionsgerade bis zum neuronalen Netz. nimmt das Vorwissen hinzu und rechnet mit dem Satz von Bayes aus, wie die Daten es verändern; zeigt, dass Ridge- und Lasso-Regression genau solche Schätzungen sind. fragt schließlich, woran man einen guten Schätzer erkennt, und zerlegt seinen Fehler in Verzerrung und Varianz. Zwei Steckbriefe zur - und zur -Verteilung schließen den Abschnitt ab. Die meiste Zeit gehört den ersten beiden Teilen. Wie man aus Schätzungen Konfidenzintervalle und Tests baut, ist Stoff der Statistik.    Maximum-Likelihood-Schätzung  Ausgangspunkt jeder Schätzung ist ein Modell: Die Daten werden als beobachtete Werte von Zufallsvariablen aufgefasst, deren Verteilung bis auf einen Parameter bekannt ist. Bei Klickdaten ist das eine Bernoulli-Verteilung mit unbekanntem , bei Zählungen je Minute eine Poisson-Verteilung mit unbekanntem , bei Messwerten eine Normalverteilung mit unbekanntem und . Der Parameter kann also auch aus mehreren Zahlen bestehen.   Stichprobe und Schätzer  Stichprobe  Schätzer  Schätzwert   Sind unabhängig und identisch verteilt, so heißen sie eine Stichprobe vom Umfang . Ein Schätzer für ist eine Zufallsvariable , die aus der Stichprobe berechnet wird. Setzt man die beobachteten Daten ein, erhält man die Zahl , den Schätzwert .    Das Stichprobenmittel ist ein Schätzer; der Mittelwert der Daten ist ein Schätzwert. Der Unterschied ist wichtig: Nur der Schätzer hat eine Verteilung, einen Erwartungswert und eine Varianz, denn mit einer neuen Stichprobe ergäbe sich ein anderer Schätzwert. Darum geht es in . Zuerst die Frage, welchen Schätzer man überhaupt nehmen soll.  In wurde die gemeinsame Dichte dreier Antwortzeiten für drei Werte von ausgewertet, und erklärte die Daten am besten. Das Prinzip dahinter lässt sich zur Methode machen: Man betrachtet die gemeinsame Dichte oder Wahrscheinlichkeitsfunktion der Daten als Funktion des Parameters und sucht ihr Maximum.   Likelihood und Log-Likelihood  Likelihood  Log-Likelihood   Seien die beobachteten Werte einer Stichprobe, deren Verteilung die Wahrscheinlichkeitsfunktion bzw. die Dichte hat. Die Funktion heißt Likelihood , ihr Logarithmus bzw. die Log-Likelihood .    Das Produkt ist die gemeinsame Wahrscheinlichkeitsfunktion bzw. Dichte der Stichprobe, denn die sind unabhängig. Neu ist nur der Blick: Die Daten sind fest, der Parameter ist die Variable. Die Likelihood ist deshalb keine Dichte in , und ihre Fläche muss nicht 1 sein. Im diskreten Fall ist die Wahrscheinlichkeit, genau die beobachteten Daten zu erhalten, wenn der Parameter ist.   Maximum-Likelihood-Schätzer  Maximum-Likelihood-Schätzer  ML-Schätzer   Ein Wert , an dem die Likelihood ihr Maximum annimmt, heißt Maximum-Likelihood-Schätzwert , kurz ML-Schätzwert. Als Funktion der Stichprobe aufgefasst, ist er der Maximum-Likelihood-Schätzer .    Weil der Logarithmus streng wächst, haben und ihr Maximum an derselben Stelle. Mit rechnet es sich leichter: Aus dem Produkt wird eine Summe, und die Ableitung einer Summe ist die Summe der Ableitungen. Das Rezept lautet daher: aufstellen, nach ableiten, die Ableitung null setzen und prüfen, dass dort wirklich das Maximum liegt, etwa weil die Ableitung von nach wechselt. Liegt das Maximum am Rand des zulässigen Bereichs, findet man es nicht über die Ableitung; dann hilft nur der Blick auf den Verlauf von .   ML-Schätzer der Grundverteilungen  Maximum-Likelihood-Schätzer der Grundverteilungen   Für eine Stichprobe mit Mittelwert gilt:    : , der Anteil der Einsen.     : , sofern ist.     : .     mit beiden Parametern unbekannt: sofern nicht alle gleich sind.       (1) Mit , der Zahl der Einsen, ist und . Für ist und das ist positiv für und negativ für . Für ist fallend, das Maximum liegt am Rand bei ; ebenso liegt es für bei .  (2) hat die Ableitung , die bei von nach wechselt.  (3) hat die Ableitung , die bei von nach wechselt.  (4) Mit ist Für jedes feste ist das am größten, wenn die Summe am kleinsten ist. Wegen (ausmultiplizieren; der gemischte Term ist ) ist das bei der Fall, gleich wie groß ist. Mit bleibt zu maximieren. Die Ableitung nach ist und wechselt bei von nach .    Für , und schätzt der ML-Schätzer den Erwartungswert also durch den Mittelwert, und für die Exponentialverteilung mit kommt heraus. Die Daten gehen jedes Mal nur über wenige Größen ein, über und bei der Normalverteilung zusätzlich über die Streuung um . Bei Bernoulli-, Poisson- und Exponentialverteilung ergeben deshalb Daten mit derselben Summe dieselbe Likelihood, bei der Poisson-Verteilung bis auf einen konstanten Faktor, und damit dieselbe Stelle des Maximums, wie in . Dort ist , also : Der beste der drei Kandidaten war sogar der beste überhaupt.   Fehlgeschlagene Anmeldungen je Stunde   Ein Anmeldedienst zählt acht Stunden lang die fehlgeschlagenen Anmeldungen je Stunde: 2, 0, 3, 1, 4, 2, 1, 3. Als Modell nehmen wir an, dass die Zahlen unabhängig und -verteilt sind.   Stellen Sie die Log-Likelihood auf, und bestimmen Sie den ML-Schätzwert von durch Ableiten.    Schätzen Sie damit den Anteil der Stunden ohne Fehlversuch, und vergleichen Sie mit dem Anteil in den Daten.          Die Summe der Zählungen ist 16. Mit ist denn . Die Ableitung ist null bei und wechselt dort von nach , also ist , der Mittelwert der Daten, wie es sagt.    Im Modell ist ; mit dem Schätzwert ergibt das . In den Daten war eine der acht Stunden ohne Fehlversuch, also .     Modell und Daten passen in diesem Punkt gut zusammen. Für die Überwachung heißt das: Rund jede siebte Stunde ist ohne Fehlversuch, eine Stunde mit sieben oder mehr Fehlversuchen wäre dagegen ungewöhnlich und ein Anlass, nach einem Angriff zu suchen. zeigt die Log-Likelihood.     Die Log-Likelihood aus . Ihr Maximum liegt beim Mittelwert der Daten, .   Eine nach unten gewölbte Kurve mit dem höchsten Punkt bei lambda gleich 2   Über dem Bereich von 0,5 bis 4,5 steht eine nach unten gewölbte Kurve. Sie steigt von etwa minus 23 bei 0,5 steil an, erreicht bei 2 ihren höchsten Wert von etwa minus 13,1 und fällt dann langsamer auf etwa minus 20 bei 4,5. Eine gestrichelte senkrechte Linie markiert die Stelle 2.      Die Zelle wertet die Log-Likelihood auf einem Gitter aus und vergleicht die Stelle des Maximums mit dem Mittelwert der Daten.   import math # Log-Likelihood eines Poisson-Modells für Zählungen. # Probieren Sie daten = [0, 0, 1, 0, 2, 0, 1, 0]. daten = [2, 0, 3, 1, 4, 2, 1, 3] n = len(daten) konst = sum([math.log(math.factorial(k)) for k in daten]) def ell(lam): return sum(daten) * math.log(lam) - n * lam - konst werte = [(ell(i \/ 100), i \/ 100) for i in range(5, 801)] bester = max(werte) print(\"Maximum auf dem Gitter: %.2f\" % bester[1]) print(\"Mittelwert der Daten: %.2f\" % (sum(daten) \/ n))    Ein Maximum am Rand   Ein Lastgenerator wartet vor jeder Anfrage eine Zeit, die auf gleichverteilt ist; ist eine Einstellung, die niemand dokumentiert hat. Gemessen wurden die Wartezeiten 2,1; 0,7; 3,4 und 1,8 Sekunden. Bestimmen Sie den ML-Schätzwert von .    Die Dichte ist auf und 0 sonst. Das Produkt der vier Dichtewerte ist , wenn alle vier Messwerte in liegen, also wenn ist, und 0 sonst: Für fällt ; das Maximum liegt also am linken Rand, , der größte Messwert.  Die Ableitung ist an keiner Stelle null; das Rezept mit dem Nullsetzen hätte nichts gefunden. Allgemein ist bei dieser Verteilung der größte Wert der Stichprobe der ML-Schätzer. Er liegt nie über und fast immer darunter, unterschätzt also systematisch. zeigt, wie man das korrigiert.     Funktionen des Parameters schätzen  Maximum-Likelihood-Schätzer einer Funktion des Parameters  Interessiert nicht selbst, sondern eine Größe , etwa die mittlere Lebensdauer , die Wahrscheinlichkeit für keinen Ausfall oder der Median , so schätzt man sie durch . Ist umkehrbar, ist das genau der ML-Schätzwert von : Die Likelihood als Funktion von ist , und die ist am größten, wenn ist. So wurde in der Anteil der Stunden ohne Fehlversuch geschätzt. Im Beispiel der Antwortzeiten ist der geschätzte Median  Sekunden.    Unvollständige Beobachtungen  zensierte Beobachtung  Nicht jede Beobachtung ist ein genauer Wert. Eine Waage zeigt über ihrem Messbereich nur zu schwer an, eine Studie endet, bevor alle Geräte ausgefallen sind, ein Sensor meldet nur, ob ein Ereignis eingetreten ist. Die Likelihood bleibt das Produkt der Wahrscheinlichkeiten bzw. Dichtewerte dessen, was man tatsächlich beobachtet hat. Für einen genauen Wert ist das wie bisher ; weiß man von einer Beobachtung nur, dass sie größer als ist, trägt sie den Faktor bei, weiß man nur, dass sie höchstens ist, den Faktor . Solche Beobachtungen heißen zensiert . Sie wegzulassen oder sie als genau zu zählen, verfälscht die Schätzung: Wer bei einer Lebensdauerstudie nur die ausgefallenen Geräte auswertet, lässt gerade die haltbarsten weg.    Lineare Regression als Maximum-Likelihood  In war die beste lineare Vorhersage aus der gemeinsamen Verteilung von und berechnet. In der Praxis kennt man diese Verteilung nicht, sondern hat Datenpaare . Das übliche Modell dafür ist mit festen, bekannten , die nicht alle gleich sind. Die Gerade beschreibt den Zusammenhang, das Rauschen  alles, was sie nicht erklärt.    Kleinste Quadrate als ML-Schätzung  Methode der kleinsten Quadrate  lineare Regression  Regression lineare   Im Modell oben sind die ML-Schätzwerte von und diejenigen Werte, die die Summe der quadrierten Abweichungen minimieren, nämlich und , die mittlere quadrierte Abweichung von der Geraden, sofern nicht alle Punkte auf einer Geraden liegen.     ist -verteilt, und die sind unabhängig. Wie im Beweis von , Teil (4), ist und für jedes feste ist das am größten, wo am kleinsten ist. Für festes ist die Summe der quadrierten Abstände der Zahlen von ; wie in Teil (4) ist sie am kleinsten, wenn deren Mittelwert ist. Eingesetzt bleibt mit , und . Diese nach oben geöffnete Parabel in hat ihren Scheitel bei . Die Aussage über folgt wie in Teil (4) mit .    Das sind die Formeln aus , mit Mittelwerten über die Daten statt Erwartungswerten: ist die empirische Kovarianz geteilt durch die empirische Varianz der . Die Methode der kleinsten Quadrate, die man oft nur als bequeme Wahl kennenlernt, ist also genau die Maximum-Likelihood-Schätzung, wenn das Rauschen normalverteilt ist. Bei Rauschen mit schwereren Rändern liefert die Likelihood andere Verfahren, die auf Ausreißer weniger empfindlich reagieren. Mehrere Merkmale ändern nichts am Prinzip; man minimiert dieselbe Quadratsumme über einen Koeffizientenvektor.   Vertiefung: Ist das Rauschen der Beobachtungen korreliert, ist die Likelihood die Dichte der -dimensionalen Normalverteilung aus , und an die Stelle der Quadratsumme tritt die quadratische Form in ihrem Exponenten.   Laufzeit eines Batch-Jobs   Ein nächtlicher Batch-Job verarbeitete an vier Tagen 1, 2, 3 und 4 Gigabyte Daten und lief dabei 3, 4, 7 und 6 Minuten. Bestimmen Sie im Modell die ML-Schätzwerte von , und . Welche Laufzeit sagt das Modell für 6 Gigabyte vorher?    Es ist und . Die Abweichungen sind bzw. , also und . Damit ist  Minuten je Gigabyte und  Minuten. Die Gerade sagt 3,2; 4,4; 5,6 und 6,8 Minuten vorher, die Abweichungen sind mit der Quadratsumme 2,8, also . Für 6 Gigabyte sagt das Modell  Minuten vorher.  Die geschätzte Standardabweichung des Rauschens ist  Minuten, die Vorhersage für einen einzelnen Lauf also nur auf knapp eine Minute genau. Vier Punkte sind wenig, und 6 Gigabyte liegen außerhalb der beobachteten Daten; ob der Zusammenhang dort noch linear ist, sagen die Daten nicht.     Kreuzentropie  Kreuzentropie  Ein Klassifikator ordnet jeder Eingabe Wahrscheinlichkeiten für die Klassen zu, also eine kategoriale Verteilung wie in . Die Wahrscheinlichkeiten hängen von den Parametern des Modells ab, etwa den Gewichten eines neuronalen Netzes. Sind die richtigen Klassen und werden die Beobachtungen als unabhängig angesehen, ist die Likelihood , das Produkt der Wahrscheinlichkeiten, die das Modell der jeweils richtigen Klasse gibt. Die negative Log-Likelihood, geteilt durch , heißt Kreuzentropie . Ein Klassifikator, der die Kreuzentropie minimiert, ist also ein ML-Schätzer. Ein Beispiel ist die logistische Regression, ein Modell für zwei Klassen, das die Wahrscheinlichkeit aus einem linearen Ausdruck in den Merkmalen bildet.   Vertiefung: Gibt ein Modell der richtigen Klasse dreier Beispiele die Wahrscheinlichkeiten 0,8, 0,5 und 0,1, ist die Kreuzentropie ; das dritte Beispiel trägt mit den Löwenanteil. Sichere Fehlentscheidungen kosten viel, und eine Wahrscheinlichkeit 0 für die richtige Klasse kostet unendlich viel. Ohne Merkmale, wenn jede Beobachtung dieselbe kategoriale Verteilung hat, sind die ML-Schätzer die relativen Häufigkeiten der Klassen (ohne Beweis; für ist es Teil (1) von ).     Vorwissen: Prior, Posterior und MAP  Für die Anzeige aus der Einleitung, zehnmal eingeblendet und nie angeklickt, liefert die Klickrate . Die Maximum-Likelihood-Methode hört nur auf die Daten, und zehn Daten sind wenig. In der bayesschen Sicht aus beschreibt man stattdessen auch das Wissen über den Parameter mit einer Wahrscheinlichkeitsverteilung: Der unbekannte Parameter wird als Zufallsvariable modelliert, deren Verteilung ausdrückt, welche Werte man vor den Daten für plausibel hält. Wo keine Verwechslung droht, schreiben wir für die Zufallsvariable denselben Buchstaben wie für den Parameter, etwa oder . Hier laufen die beiden Sichten tatsächlich auseinander. Für die Maximum-Likelihood-Methode ist eine feste, unbekannte Zahl; für die bayessche Methode ist sie eine Größe, über die man mehr oder weniger weiß.  Den Rest erledigt der Satz von Bayes aus . Dort wurde die Wahrscheinlichkeit einer Ursache nach der Beobachtung berechnet als , geteilt durch die Summe dieser Produkte über alle möglichen Ursachen. Jetzt sind die möglichen Ursachen die Werte von , die Beobachtung sind die Daten, wird zur Likelihood und zu einer Dichte über . Aus der Summe wird ein Integral, wie bei der bedingten Dichte in .   A-priori- und A-posteriori-Verteilung  Prior  Posterior  A-priori-Verteilung  A-posteriori-Verteilung   Die Dichte der Verteilung von vor den Daten heißt A-priori-Dichte oder kurz Prior . Sind beobachtet und ist ihre Likelihood, so heißt die A-posteriori-Dichte oder kurz Posterior . Das Integral läuft über alle möglichen Parameterwerte.    Der Nenner hängt nicht von ab; er sorgt nur dafür, dass die Fläche unter dem Posterior 1 ist. Man schreibt deshalb oft kurz gelesen proportional zu : gleich bis auf einen Faktor, der nicht von abhängt. Posterior ist Likelihood mal Prior. Erkennt man im Produkt die Gestalt einer bekannten Dichte, ist der Faktor damit festgelegt, und das Integral muss man nie ausrechnen.   MAP-Schätzer und A-posteriori-Erwartungswert  MAP-Schätzer  A-posteriori-Erwartungswert  Maximum-a-posteriori-Schätzung   Die Stelle des Maximums der A-posteriori-Dichte, heißt Maximum-a-posteriori-Schätzwert , kurz MAP-Schätzwert. Der Erwartungswert der A-posteriori-Verteilung, , heißt A-posteriori-Erwartungswert .    Der MAP-Schätzwert ist der Modus der A-posteriori-Verteilung, der wahrscheinlichste Wert nach den Daten; das ist das Prinzip aus , jetzt mit Parametern statt Bildern. Gegenüber der Maximum-Likelihood-Methode kommt der Summand hinzu, der Parameterwerte bevorzugt, die man vorher für plausibel hielt. Ist der Prior auf dem ganzen Bereich der möglichen Parameterwerte konstant (eine Dichte ist das nur, wenn der Bereich beschränkt ist), fällt er beim Maximieren weg, und MAP und ML stimmen überein; ist er nur auf einem Teilbereich konstant und außerhalb 0, gilt das, sofern der ML-Schätzwert in diesem Teilbereich liegt. Der A-posteriori-Erwartungswert ist wie in die beste Vorhersage von aus den Daten im Sinne des mittleren quadratischen Fehlers, gemittelt über den Prior und die Daten. Das ist ein anderer Mittelwert als der mittlere quadratische Fehler in , der bei festem Parameter nur über die Daten mittelt.  Mit zwei Familien aus geht das alles von Hand: Die Betaverteilung beschreibt Vorwissen über eine Wahrscheinlichkeit, die Gammaverteilung Vorwissen über eine Rate. Für beide braucht man den Modus, also die Stelle, an der die Dichte am größten ist.   Modus der Beta- und der Gammaverteilung  Modus   Die Dichte von mit hat ihr Maximum bei , die Dichte von mit bei .    Der Logarithmus der Betadichte ist bis auf eine Konstante mit der Ableitung . Sie ist null bei , also bei , und wechselt dort von nach . Beim Logarithmus der Gammadichte, plus Konstante, ist die Ableitung ; für wechselt sie bei das Vorzeichen, und für ist die Dichte fallend mit dem Maximum bei 0.     Beta-Prior für eine Wahrscheinlichkeit  Beta-Prior  konjugierter Prior  Prior konjugierter   Der Prior für die Erfolgswahrscheinlichkeit sei . In unabhängigen -Versuchen werden Erfolge beobachtet. Dann ist der Posterior , und es ist die erste Formel für und .    Die Likelihood ist , der Prior ist bis auf eine Konstante . Also ist für  und das ist bis auf eine Konstante die Dichte von . Weil beide Funktionen die Fläche 1 haben, stimmen auch die Konstanten überein. Modus und Erwartungswert stehen in und .    Liegen die Daten nur als Anzahl vor, ändert sich nichts, denn der Binomialkoeffizient ist ein konstanter Faktor. Prior und Posterior gehören derselben Familie an; man nennt den Beta-Prior deshalb konjugiert zur Binomialverteilung. Die Formeln lassen sich als Zählen lesen, wobei die Daten einfach hinzukommen. Für den A-posteriori-Erwartungswert wirkt der Prior wie Erfolge und Misserfolge, die man schon vor den Daten gesehen hat, für den MAP-Schätzwert wie Erfolge und Misserfolge: Der MAP-Schätzwert ist der Anteil der Erfolge, als hätte man diese Beobachtungen zu den Daten hinzugefügt. zeigt an einem Beispiel, wie der Posterior zwischen Prior und Daten liegt. Der A-posteriori-Erwartungswert ist ein gewichtetes Mittel aus dem Prior-Erwartungswert und dem Anteil in den Daten, und das Gewicht der Daten wächst mit gegen 1. Mit dem Prior , der Gleichverteilung, ist der MAP-Schätzwert , der ML-Schätzwert.   Die Klickrate einer neuen Anzeige   Klickraten ähnlicher Anzeigen liegen meist zwischen einem und acht Prozent und selten über zehn. Das beschreibt der Prior : Er hat den Erwartungswert  %, legt rund 83 % seiner Wahrscheinlichkeit zwischen 0,01 und 0,08 und knapp 4 % oberhalb von 0,1.   Die neue Anzeige wurde zehnmal eingeblendet und nie angeklickt. Bestimmen Sie den Posterior, den MAP-Schätzwert und den A-posteriori-Erwartungswert, und vergleichen Sie mit dem ML-Schätzwert.    Nach 1000 Einblendungen hat die Anzeige 30 Klicks. Was ergibt sich jetzt?          Mit und ist der Posterior . Also ist  % und der A-posteriori-Erwartungswert  %, gegenüber .    Mit und ist der Posterior , also  % und der A-posteriori-Erwartungswert  %, gegenüber  %.     Nach zehn Einblendungen ohne Klick ist die Anzeige verdächtig, aber nicht abgeschrieben: Der MAP-Schätzwert fällt vom Modus des Priors,  %, auf 1,7 %, der A-posteriori-Erwartungswert vom Prior-Erwartungswert 4 % auf 3,3 %; beide bleiben weit über 0. Für den A-posteriori-Erwartungswert wiegt der Prior hier so viel wie 50 frühere Einblendungen, die zehn neuen verschieben die Schätzung nur ein Stück. Nach 1000 Einblendungen wiegen die Daten zwanzigmal so viel wie der Prior, und alle drei Schätzwerte liegen nah beieinander. Bei vielen Daten spielt das Vorwissen kaum noch eine Rolle; es hilft gerade dort, wo die Daten noch zu wenig sagen.     Prior (gestrichelt), Likelihood nach 9 Erfolgen in 10 Versuchen, auf Fläche 1 skaliert (gepunktet), und Posterior (durchgezogen). Der Posterior liegt zwischen Prior und Likelihood, mit dem Modus zwischen und dem ML-Schätzwert .   Drei Dichtekurven auf dem Intervall von 0 bis 1: eine symmetrische in der Mitte, eine weit rechts, eine dazwischen   Über dem Intervall von 0 bis 1 stehen drei Kurven. Die gestrichelte Kurve des Priors ist symmetrisch mit dem Gipfel 2,19 bei 0,5. Die gepunktete Kurve der Likelihood steigt bis 0,9 auf etwa 4,26 an und fällt dann steil auf 0 bei 1. Die durchgezogene Kurve des Posteriors hat ihren Gipfel 3,83 bei 0,75 und ist schmaler als der Prior.       Gamma-Prior für eine Rate  Gamma-Prior   Der Prior für die Rate sei . Es werden unabhängige -verteilte Anzahlen mit der Summe beobachtet. Dann ist der Posterior , und es ist die erste Formel für .    Die Likelihood ist , der Prior ist bis auf eine Konstante . Ihr Produkt ist bis auf eine Konstante die Dichte von . Modus und Erwartungswert stehen in und .    Auch hier lässt sich zählen: Für den A-posteriori-Erwartungswert wirkt der Prior wie frühere Zeitabschnitte, in denen zusammen Ereignisse eingetreten sind. Dieser Erwartungswert ist wieder ein gewichtetes Mittel, aus dem Prior-Erwartungswert mit dem Gewicht und dem Mittelwert der Daten mit dem Gewicht .   Fehlermeldungen eines neuen Dienstes   Ein neuer Microservice geht in Betrieb. Ähnliche Dienste erzeugen im Mittel drei Fehlermeldungen je Tag, und dieser Mittelwert schwankt von Dienst zu Dienst mit einer Standardabweichung von etwa 1. Als Prior für die Rate des neuen Dienstes dient deshalb , mit Erwartungswert und Standardabweichung . In den ersten vier Tagen meldet er 1, 0, 2 und 1 Fehler. Bestimmen Sie den Posterior, den MAP-Schätzwert und den A-posteriori-Erwartungswert, und vergleichen Sie mit dem ML-Schätzwert.    Mit und ist der Posterior . Also ist und der A-posteriori-Erwartungswert Fehlermeldungen je Tag, gegenüber dem ML-Schätzwert .  Der Dienst läuft bisher deutlich ruhiger als seine Vorgänger, aber vier Tage sind wenig: Der Prior wiegt so viel wie drei Tage, die Daten wie vier. Wer Personal für die Fehlerbehebung plant, rechnet deshalb vorerst mit knapp zwei Meldungen je Tag statt mit einer, und mit jedem weiteren Tag rückt die Schätzung näher an das, was der neue Dienst tatsächlich tut.    Die Zelle simuliert Einblendungen einer Anzeige mit der wahren Klickrate 3 % und vergleicht die drei Schätzwerte unter dem Prior aus .   import random # Prior Bet(2, 48), wahre Klickrate 3 %, n Einblendungen. # Probieren Sie n = 10, 100, 1000, 10000. n = 100 alpha, beta, p = 2, 48, 0.03 k = sum([1 for _ in range(n) if random.random() < p]) ml = k \/ n map_wert = (alpha + k - 1) \/ (alpha + beta + n - 2) erwartung = (alpha + k) \/ (alpha + beta + n) print(\"Klicks: %d von %d\" % (k, n)) print(\"ML: %.4f\" % ml) print(\"MAP: %.4f\" % map_wert) print(\"A-posteriori-Erwartung: %.4f\" % erwartung)    Woher der Prior kommt  Den Prior wählt man so, dass er das Vorwissen trifft, meist über Erwartungswert und Streuung oder über den wahrscheinlichsten Wert, wie in den beiden Beispielen. Die konjugierten Familien sind bequem, weil der Posterior dann wieder eine bekannte Verteilung ist und die Rechnung aus Zählen besteht; mit anderen Priors muss man den Posterior numerisch bestimmen, etwa mit Monte-Carlo-Verfahren wie in . Ein schwacher Prior, etwa , lässt die Daten fast allein sprechen; ein starker Prior braucht viele Daten, bis sie ihn überstimmen. Ein falscher Prior verzerrt die Schätzung, solange die Daten wenige sind, wird aber mit wachsendem ebenso überstimmt, sofern er dem wahren Wert nicht die Dichte 0 gibt. Darin steckt der Kompromiss, den genauer fasst: Der Prior verringert die Streuung der Schätzung um den Preis einer Verzerrung.     Regularisierung als MAP-Schätzung  Aus 100 Merkmalen werden mit allen Produkten bis zum Grad drei mehr als 170 000 (nachgezählt in , einer Vertiefung). Ein Regressionsmodell mit so vielen Koeffizienten passt sich auch dem Rauschen in den Daten an: Die Quadratsumme aus wird auf den Trainingsdaten sehr klein, die Vorhersagen für neue Daten aber schlecht. Die übliche Abhilfe heißt Regularisierung Regularisierung . Man minimiert nicht die Quadratsumme allein, sondern addiert einen Strafterm Strafterm , der große Koeffizienten verteuert. Woher dieser Term kommt und wie groß er sein soll, erscheint oft willkürlich. Als MAP-Schätzung ist er es nicht: Er ist der Logarithmus eines Priors, der kleine Koeffizienten für plausibler hält als große.  Um alles von Hand rechnen zu können, betrachten wir ein Modell mit einem einzigen Koeffizienten und ohne Achsenabschnitt, etwa für zentrierte Daten, also wenn man von allen und vorher ihren jeweiligen Mittelwert abgezogen hat: mit bekannten , nicht alle null, und bekanntem . Wir schreiben und . Wie in ist der ML-Schätzwert die Stelle des Minimums von , also der Kleinste-Quadrate-Schätzwert .   Ridge-Regression als MAP-Schätzung  Ridge-Regression   Im Modell oben sei der Prior . Dann ist der MAP-Schätzwert die Stelle des Minimums von nämlich     Bis auf Konstanten ist und . Die Summe ist am größten, wo ihr -faches am kleinsten ist. Das ist , eine nach oben geöffnete Parabel mit dem Scheitel bei .    Der Strafterm der Ridge-Regression ist also der negative Logarithmus eines Gauß-Priors, und seine Stärke ist das Verhältnis der Rauschvarianz zur Prior-Varianz. Der Schätzwert ist der Kleinste-Quadrate-Wert, um den Faktor zur Null hin geschrumpft. Je kleiner , je fester man also an kleine Koeffizienten glaubt, desto stärker schrumpft er. Je mehr Daten, desto größer , desto weniger zählt .  Ein anderer Prior ergibt einen anderen Strafterm. Die Laplace-Verteilung Laplace-Verteilung aus mit der Dichte hat bei 0 eine Spitze und schwerere Ränder als die Normalverteilung: Sie hält Koeffizienten nahe 0 für sehr plausibel, einzelne große aber nicht für ausgeschlossen. Mit plus Konstante führt dieselbe Rechnung wie im Beweis oben auf die Minimierung von Das ist die Lasso-Regression .   Lasso als MAP-Schätzung  Lasso-Regression   Mit dem Laplace-Prior ist der MAP-Schätzwert      Vertiefung: Bis auf die Konstante ist die zu minimierende Funktion . Für ist , für ist . Ist , so ist auf fallend, und auf wechselt bei von nach ; dort ist das Minimum. Der Fall geht spiegelbildlich. Ist , so ist auf und auf ; fällt bis 0 und steigt danach, das Minimum liegt bei 0.    Beide Verfahren schrumpfen, aber verschieden, wie zeigt. Ridge verkleinert jeden Schätzwert um denselben Faktor und macht ihn nie ganz zu null. Lasso zieht von jedem den festen Betrag ab und setzt ihn auf 0, sobald er dabei das Vorzeichen wechseln würde. Bei vielen Merkmalen wählt Lasso so nebenbei aus, welche überhaupt ins Modell kommen.   Schätzwert als Funktion von für : kleinste Quadrate (gepunktet), Ridge mit (gestrichelt) und Lasso mit (durchgezogen). Lasso ist für genau null.   Zwei Geraden durch den Ursprung und eine geknickte Linie, die im mittleren Bereich auf null liegt   Waagerecht ist z von minus 20 bis 20 aufgetragen, senkrecht der Schätzwert. Die gepunktete Gerade der kleinsten Quadrate läuft durch den Ursprung mit der Steigung 0,1, die gestrichelte Ridge-Gerade mit der halben Steigung 0,05. Die durchgezogene Lasso-Linie liegt zwischen minus 5 und 5 auf der Achse und verläuft außerhalb parallel zur Geraden der kleinsten Quadrate, um 0,5 zur Achse hin verschoben.       Zwei Merkmale, zwei Strafterme   Ein Modell mit zwei Merkmalen wird an Daten angepasst, für die und ist, außerdem und .   Zeigen Sie, dass die Quadratsumme in zwei Teile zerfällt, die nur von bzw. nur von abhängen.    Bestimmen Sie die Schätzwerte nach den kleinsten Quadraten, nach Ridge und nach Lasso, jeweils mit und dem Strafterm bzw. .          Ausmultipliziert ist und der letzte Summand ist 0. Auch beide Strafterme sind Summen eines Terms in und eines in , also kann man jeden Koeffizienten für sich minimieren, mit und bzw. .    Kleinste Quadrate: und . Ridge: und . Lasso mit : , und wegen ist der zweite Schätzwert 0.     Ridge halbiert hier beide Koeffizienten. Lasso nimmt vom großen nur ein Fünftel weg und wirft das schwache zweite Merkmal ganz aus dem Modell. Ob das richtig ist, hängt davon ab, ob das zweite Merkmal tatsächlich nichts beiträgt; der Laplace-Prior hält genau das für wahrscheinlich.     Vertiefung: Viele Merkmale  Mit Merkmalen, der Datenmatrix mit Zeilen und Spalten und dem Prior, unter dem die Koeffizienten unabhängig und -verteilt sind, ist der Ridge-Schätzer (ohne Beweis). Ohne ist das der Kleinste-Quadrate-Schätzer, und ist bei vielen, untereinander korrelierten Merkmalen fast nicht invertierbar; dann schwanken die Koeffizienten von Datensatz zu Datensatz enorm. Der Summand behebt das. Die Merkmale sollten dabei vergleichbar skaliert sein, wie in , sonst bestraft derselbe Prior verschiedene Merkmale verschieden stark. Für Lasso gibt es keine geschlossene Formel; man minimiert numerisch und erhält Modelle, in denen viele Koeffizienten genau null sind. In der Praxis wählt man meist nicht über einen Prior, sondern so, dass das Modell auf zurückgehaltenen Daten am besten vorhersagt. zeigt, warum ein mittleres besser sein kann als gar keines.     Güteeigenschaften: Verzerrung, Varianz und Konsistenz  Für denselben Parameter gibt es meist mehrere Schätzer: den ML-Schätzer, den MAP-Schätzer zu verschiedenen Priors, den A-posteriori-Erwartungswert und Schätzer, die einfach naheliegen. Welcher ist der beste? Ein einzelner Schätzwert lässt das nicht erkennen, denn den wahren Parameter kennt man nicht. Beurteilen lässt sich aber der Schätzer als Zufallsvariable: Wie verteilt sich der Schätzwert, wenn man das Experiment immer wieder mit neuen Stichproben durchführt? Im Folgenden ist der wahre Parameter, und Erwartungswerte und Wahrscheinlichkeiten werden unter berechnet.   Verzerrung und Erwartungstreue  Verzerrung  Erwartungstreue  Bias   Die Verzerrung (englisch bias ) eines Schätzers ist . Der Schätzer heißt erwartungstreu oder unverzerrt, wenn für jeden möglichen Wert von gilt.     Mittlerer quadratischer Fehler  mittlerer quadratischer Fehler  Fehler mittlerer quadratischer   Der mittlere quadratische Fehler eines Schätzers ist .     Zerlegung des mittleren quadratischen Fehlers  mittlerer quadratischer Fehler Zerlegung   Für jeden Schätzer mit endlicher Varianz ist     Mit ist , und der zweite Summand ist eine Konstante. Nach dem Verschiebungssatz in der Form , angewandt auf mit , ist .    Diese Zerlegung heißt auch Bias-Varianz-Zerlegung Bias-Varianz-Zerlegung . Ein Schätzer kann also auf zwei Arten danebenliegen: Er streut um seinen eigenen Erwartungswert, und dieser Erwartungswert liegt neben dem wahren Wert. Wie bei einer Zielscheibe: Die Treffer können weit verstreut liegen, oder sie liegen eng beieinander, aber neben der Mitte. Für erwartungstreue Schätzer ist der mittlere quadratische Fehler die Varianz. Das Stichprobenmittel einer Stichprobe mit Erwartungswert und Varianz ist erwartungstreu für und hat nach die Varianz ; seine Standardabweichung ist der Standardfehler aus . Damit sind die ML-Schätzer für Bernoulli-, Poisson- und Normalverteilung aus für den Erwartungswert erwartungstreu.   Warum die Stichprobenvarianz durch teilt  Der ML-Schätzer für die Varianz einer Normalverteilung ist dagegen nicht erwartungstreu, und das liegt nicht an der Normalverteilung.    Erwartungswert der Quadratsumme  Stichprobenvarianz   Seien mit unabhängig mit Erwartungswert und Varianz . Dann ist Insbesondere ist mit verzerrt, und die Stichprobenvarianz  ist erwartungstreu für .    Wie im Beweis von , Teil (4), ist . Links ist der Erwartungswert jedes Summanden , zusammen . Rechts ist . Also ist der Erwartungswert der Quadratsumme .    Der Grund steckt in der Gleichung des Beweises: Das Mittel ist die Zahl, von der die Daten die kleinste Quadratsumme haben, kleiner als die vom wahren . Wer die Abweichungen von statt von misst, unterschätzt die Streuung im Mittel um genau je Beobachtung. Man sagt auch, beim Schätzen von geht ein Freiheitsgrad verloren: Die Abweichungen summieren sich zu 0, nur von ihnen sind frei. Ist bekannt, ist erwartungstreu. Für großes ist der Unterschied zwischen und unerheblich, für kleine Stichproben nicht.   Streuung einer Widerstandsserie   Fünf Widerstände einer Serie mit dem Nennwert haben 99, 102, 103, 98 und . Schätzen Sie die Standardabweichung der Serie mit und mit . Wie ändert sich die Schätzung, wenn man weiß, dass die Serie im Mittel genau den Nennwert trifft?    Der Mittelwert ist 101, die Quadratsumme der Abweichungen davon . Also ist und , die geschätzten Standardabweichungen sind und . Ist bekannt, misst man die Abweichungen von und teilt durch : Die Quadratsumme ist , die Schätzung , also rund . Das sind genau die , um die die Quadratsumme um nach der Gleichung im Beweis kleiner ist.  Bei fünf Werten macht der Faktor gut ein Zehntel in der Standardabweichung aus. Wer daraus Toleranzen ableitet, etwa für den Anteil brauchbarer Widerstände, rechnet mit zu optimistisch.    Die Zelle zieht viele Stichproben vom Umfang aus und mittelt beide Schätzwerte für .   import random # 4000 Schätzwerte für sigma^2 = 1, je aus n Werten. # Probieren Sie n = 2, 5, 50. n = 2 def quadratsumme(): x = [random.gauss(0, 1) for _ in range(n)] m = sum(x) \/ n return sum([(v - m) ** 2 for v in x]) q = [quadratsumme() for _ in range(4000)] mittel = sum(q) \/ len(q) print(\"Mittel von Q\/n: %.3f\" % (mittel \/ n)) print(\"Theorie für Q\/n: %.3f\" % ((n - 1) \/ n)) print(\"Mittel von Q\/(n - 1): %.3f\" % (mittel \/ (n - 1)))   Erwartungstreue allein macht einen Schätzer noch nicht gut. Das zeigt weitergedacht.   Seriennummern   Im Zweiten Weltkrieg schätzten die Alliierten, wie viele Panzer eines Typs produziert worden waren, aus den Seriennummern erbeuteter Fahrzeuge. Vereinfacht seien die Nummern unabhängig und auf gleichverteilt; ist die gesuchte Stückzahl. Drei Schätzer liegen nahe: , weil ist, das Maximum der Nummern, der ML-Schätzer, und .   Erbeutet wurden vier Fahrzeuge mit den Nummern 61, 19, 56 und 24. Berechnen Sie die drei Schätzwerte.     hat die Verteilungsfunktion auf . Bestimmen Sie und und damit Verzerrung und mittleren quadratischen Fehler der drei Schätzer für .          Der Mittelwert ist 40, also ; und .     ist höchstens , wenn alle vier Nummern höchstens sind; daher die Verteilungsfunktion. Die Dichte ist , und Für : und . Daraus:    ist erwartungstreu, mit , denn die Gleichverteilung auf hat die Varianz .     hat und .     ist erwartungstreu, mit .         ist am besten, mit halb so großem mittlerem quadratischem Fehler wie . Bemerkenswert ist der Vergleich der beiden anderen: Der verzerrte Schätzer schlägt den erwartungstreuen , weil er viel weniger streut. Das Maximum enthält mehr Information über als das Mittel, das auch die kleinen Nummern einrechnet. Nach dem Krieg zeigten die Produktionsunterlagen, dass die Schätzungen aus Seriennummern viel näher an den tatsächlichen Stückzahlen lagen als die Schätzungen der Nachrichtendienste.  Quelle: R. Ruggles, H. Brodie, An Empirical Approach to Economic Intelligence in World War II , Journal of the American Statistical Association 42 (1947), 72 91 ( ).    Dass sich eine kleine Verzerrung lohnen kann, ist der Grund für die Regularisierung aus . Das nächste Beispiel rechnet es für Ridge aus.   Wie stark schrumpfen?   Im Modell aus ist der Ridge-Schätzer mit .   Bestimmen Sie Verzerrung, Varianz und mittleren quadratischen Fehler von als Funktion von .    Werten Sie den mittleren quadratischen Fehler für , und bei , 4 und 10 aus.   Für welches ist er am kleinsten?          und, weil die unabhängig sind, . Also ist und .     : . : . : .    Die Ableitung nach ist und wechselt bei von nach . Hier ist das .     Der Kleinste-Quadrate-Schätzer, , ist erwartungstreu, aber nicht der beste. Mit wachsendem fällt die Varianz und wächst die Verzerrung, und das Optimum liegt dazwischen. Es ist , also gerade das aus mit : Ein Prior, dessen Streuung zur wahren Größe des Koeffizienten passt, schrumpft genau richtig. Weil man nicht kennt, bestimmt man in der Praxis aus den Daten.     Vertiefung: Bias-Varianz-Zerlegung des Vorhersagefehlers  Bias-Varianz-Zerlegung des Vorhersagefehlers  Im maschinellen Lernen interessiert weniger der Fehler im Parameter als der Fehler einer Vorhersage. Sagt man im Modell oben eine neue Beobachtung , unabhängig von den Daten, durch vorher, so ist , und wegen der Unabhängigkeit und ist Der erste Summand ist das irreduzible Rauschen , das auch die beste Vorhersage mit bekanntem nicht beseitigt; das ist der Restfehler aus und . Die beiden anderen Summanden bilden den Kompromiss, der unter dem Namen Bias-Varianz-Zerlegung durch das maschinelle Lernen zieht: Einfache oder stark regularisierte Modelle haben kleine Varianz und große Verzerrung, flexible Modelle umgekehrt.   Die letzte Güteeigenschaft betrifft das Verhalten für wachsenden Stichprobenumfang. Wir schreiben dafür für den Schätzer aus Beobachtungen.   Konsistenz  Konsistenz   Eine Folge von Schätzern heißt konsistent für , wenn für jeden möglichen Wert von gilt, im Sinn von .     Konsistenz über den mittleren quadratischen Fehler      Strebt gegen 0, also Verzerrung und Varianz, so ist die Folge konsistent.    Ist die Folge konsistent für und gilt für alle , mit einer Konstanten , so ist konsistent für .       (1) Nach der Ungleichung von Markov, , angewandt auf , ist Nach strebt der mittlere quadratische Fehler genau dann gegen 0, wenn Verzerrung und Varianz es tun. (2) Für folgt aus , dass ist, also .    Das Stichprobenmittel ist nach konsistent für , die relative Häufigkeit nach für eine Wahrscheinlichkeit. Alle drei Schätzer aus sind konsistent; für sieht man das auch direkt an . Die MAP-Schätzer aus und sind ebenfalls konsistent, der Einfluss des Priors schwindet. Im Beta-Binomial-Modell ist die Differenz zum ML-Schätzer  und weil ist, ist ihr Betrag ohne jeden Zufall höchstens eine Konstante mal . Liegt nah bei und ist groß, liegt also auch der MAP-Schätzer nah bei . Im Gamma-Poisson-Modell gibt es keine solche feste Schranke, weil beliebig groß werden kann; die Differenz strebt trotzdem stochastisch gegen 0, weil nach dem Gesetz der großen Zahlen bei bleibt. Für normalverteilte Daten ist , siehe ; also ist auch konsistent.  Erwartungstreu heißt nicht konsistent. Der Schätzer , der nur die erste Beobachtung verwendet, ist erwartungstreu für , wird aber nie genauer, wie groß die Stichprobe auch ist. Bei abhängigen Daten kann Ähnliches geschehen: In ist die gemittelte Vorhersage eines Ensembles erwartungstreu, die Varianz ihres Fehlers strebt aber gegen statt gegen 0. Das Argument aus greift dann nicht, und erklärt, warum sich gemeinsame Fehler nicht herausmitteln. Umgekehrt muss ein konsistenter Schätzer nicht erwartungstreu sein: und sind es nicht, doch ihre Verzerrung verschwindet für großes .    Steckbrief: die -Verteilung  -Verteilung  Die beiden letzten Verteilungen des Buchs lernen Sie wie in als Steckbrief kennen: wann sie auftreten, wie sie aus bekannten Verteilungen hervorgehen, ihre Formeln und ein Beispiel. Beide beschreiben, wie Größen streuen, die aus einer Stichprobe berechnet werden; die Statistik baut darauf ihre Intervalle und Tests. Für beide braucht man eine Tatsache, die wir ohne Beweis übernehmen. Sind unabhängig und -verteilt, so ist und und sind unabhängig. Das ist die Aussage, die angekündigt hat: Die Summe ist verteilt wie eine Summe von statt quadrierten standardnormalverteilten Größen, weil beim Schätzen von ein Freiheitsgrad verloren geht. Mit folgt , wie in , und .   Wann  Man standardisiert ein Stichprobenmittel normalverteilter Daten, kennt aber nicht und setzt die geschätzte Standardabweichung ein: . Mit bekanntem wäre diese Größe standardnormalverteilt. Mit statt ist sie -verteilt, und bei kleinen Stichproben ist der Unterschied erheblich. Wir schreiben mit Freiheitsgraden.    Woher  Ist und davon unabhängig , so heißt die Verteilung von  -Verteilung mit Freiheitsgraden. Mit und kürzt sich heraus, und es bleibt . Der Nenner ist selbst zufällig und manchmal klein; deshalb hat schwerere Ränder als . Weil das Mittel von quadrierten standardnormalverteilten Größen ist, strebt es nach stochastisch gegen 1, und die -Verteilung nähert sich für großes der Standardnormalverteilung.    Formeln  Für ist Die Dichte ist symmetrisch um 0 und fällt nur wie eine Potenz von , nicht wie . Für existiert nicht einmal der Erwartungswert, für nicht die Varianz. vergleicht die Dichten.    Dichten von (gepunktet), (gestrichelt) und (durchgezogen). Je weniger Freiheitsgrade, desto niedriger die Mitte und desto schwerer die Ränder.   Drei glockenförmige, symmetrische Kurven, die flacheren mit höheren Rändern   Über dem Bereich von minus 4 bis 4 stehen drei um 0 symmetrische Glockenkurven. Die durchgezogene Kurve der Standardnormalverteilung ist in der Mitte am höchsten, mit etwa 0,40, und fällt nach außen am schnellsten ab. Die gestrichelte Kurve für vier Freiheitsgrade hat die Höhe 0,375, die gepunktete für einen Freiheitsgrad die Höhe 0,32; sie liegen in der Mitte tiefer und außen höher als die Normalverteilung, die gestrichelte jenseits von etwa 1,6, die gepunktete jenseits von etwa 1,9.       Fehlerbalken aus fünf Messungen   Fünf Messungen einer normalverteilten Größe ergeben Mittelwert und Stichprobenstandardabweichung . Ein Messprotokoll gibt als Fehlerbalken an, im Glauben, ein so gebildeter Balken verfehle den wahren Erwartungswert nur in rund 5 % der Fälle. Mit welcher Wahrscheinlichkeit weicht tatsächlich um mehr als von ab? Für ist .    Die Abweichung ist größer als , wenn ist mit , und ist -verteilt. Die Wahrscheinlichkeit ist also rund 11,6 %, gut zweieinhalbmal so viel wie die  % bei bekanntem .  Mit mehr Messungen wird der Unterschied kleiner: Für , also zehn Messungen, ist  %, für etwa 5,5 %. Wer die Faustregel zwei Standardfehler aus mit geschätzter Standardabweichung auf eine Handvoll Messungen anwendet, zeichnet zu schmale Fehlerbalken.      Steckbrief: die -Verteilung  -Verteilung   Wann  Zwei Streuungen werden verglichen: die zweier Maschinen, zweier Messverfahren oder die Restfehler zweier Modelle. Man bildet das Verhältnis der beiden Stichprobenvarianzen. Selbst wenn beide Größen gleich streuen, schwankt dieses Verhältnis um 1 herum, nach oben weiter als nach unten, und die -Verteilung sagt, wie stark. Wir schreiben mit zwei Freiheitsgraden, dem des Zählers und dem des Nenners.    Woher  Sind und unabhängig, so heißt die Verteilung von  -Verteilung mit und Freiheitsgraden. Für zwei unabhängige normalverteilte Stichproben vom Umfang und mit den Varianzen und sind nach  und unabhängig und Chi-Quadrat-verteilt, also ist bei gleichen Varianzen einfach . Ist , so ist mit , also .    Formeln  Für ist Für ist die Dichte und die Verteilungsfunktion ; sonst rechnet man mit einer Tabelle oder mit scipy.stats.f .    Wie verlässlich ist ein Streuungsvergleich?   An zwei Abfüllanlagen, die in Wirklichkeit gleich stark streuen, werden je drei Füllmengen gemessen. Mit welcher Wahrscheinlichkeit ist die Stichprobenvarianz der ersten Anlage mehr als viermal so groß wie die der zweiten? Nehmen Sie normalverteilte Füllmengen an, und rechnen Sie ohne die Formel der Dichte, mit .    Mit ist , also mit unabhängigen . Damit ist denn für festes ist . Das stimmt mit der Verteilungsfunktion überein.  Mit Wahrscheinlichkeit zeigt die erste Anlage also mehr als die vierfache Stichprobenvarianz der zweiten, mehr als die doppelte Standardabweichung, und ebenso oft umgekehrt, obwohl beide gleich streuen. Aus drei Messungen je Anlage lässt sich über die Streuung kaum etwas sagen. Nach ist die Standardabweichung von das -fache von , bei drei Messungen also so groß wie selbst; erst mit 51 Messungen sinkt sie auf ein Fünftel.      Zusammenfassung      Likelihood. Für eine Stichprobe ist bzw. , die gemeinsame Wahrscheinlichkeitsfunktion bzw. Dichte der Daten als Funktion des Parameters, und . Der ML-Schätzwert ergibt sich meist durch Nullsetzen von ; liegt das Maximum am Rand, nicht. Eine Funktion schätzt man durch . Von einer zensierten Beobachtung, die man nur als größer als bzw. höchstens kennt, kommt der Faktor bzw. in die Likelihood.     ML-Schätzer der Grundverteilungen.  : ; : ; : ; : und . Bei normalverteiltem Rauschen ist die Regressionsgerade nach den kleinsten Quadraten der ML-Schätzer, und die Kreuzentropie eines Klassifikators ist die negative Log-Likelihood, geteilt durch .     Prior, Posterior, MAP. Mit einem Prior ist der Posterior . Der MAP-Schätzwert ist sein Modus, , der A-posteriori-Erwartungswert sein Erwartungswert. Ist der Parameterbereich beschränkt und der Prior darauf konstant, etwa , ist MAP gleich ML.     Konjugierte Priors. Prior und Erfolge in Versuchen ergeben den Posterior mit Modus und Erwartungswert . Prior und Poisson-Anzahlen mit der Summe in Abschnitten ergeben mit Modus und Erwartungswert . Der Prior wirkt wie zusätzliche Beobachtungen, deren Gewicht mit wachsendem schwindet.     Regularisierung. Im Modell mit führt der Prior auf Ridge: Minimum von mit , also . Der Laplace-Prior führt auf Lasso mit dem Strafterm , der kleine Koeffizienten genau auf 0 setzt.     Verzerrung und Varianz.  , und . Weil ist, ist erwartungstreu und nicht. Ein verzerrter Schätzer kann den kleineren mittleren quadratischen Fehler haben; darauf beruht die Regularisierung.     Konsistenz.  ist konsistent, wenn . Das gilt, wenn , und überträgt sich auf , wenn . Erwartungstreu und konsistent sind verschiedene Eigenschaften.     und . Für normalverteilte Stichproben ist , unabhängig von ; daraus folgt , mit schwereren Rändern als , und für zwei Stichproben gleicher Varianz .       Übungsaufgaben   Eine neue Menüführung   Von 20 Testpersonen finden 7 eine neue Menüführung schlechter als die alte. Jede Person urteile unabhängig, mit derselben Wahrscheinlichkeit für schlechter .  Bestimmen Sie den ML-Schätzwert von .   Schätzen Sie die Chance , also das Verhältnis der Wahrscheinlichkeiten für schlechter und nicht schlechter .          Nach ist .    Nach mit , einer umkehrbaren Funktion auf : .        Paketlaufzeiten   Vier Laufzeiten eines Netzwerkpakets betragen 3, 8, 6 und 7 Millisekunden. Nehmen Sie an, dass sie unabhängig und -verteilt sind. Bestimmen Sie die ML-Schätzwerte von und und die Stichprobenvarianz . Welcher der beiden Schätzwerte für ist erwartungstreu? Ab welchem Stichprobenumfang unterscheiden sich die beiden geschätzten Standardabweichungen um weniger als 5 %?     . Die Abweichungen sind , die Quadratsumme ist 14. Also ist und . Erwartungstreu ist nach die Stichprobenvarianz.  Die Standardabweichungen unterscheiden sich bei jeder Stichprobe um den Faktor , hier . Weniger als 5 % heißt , also : ab .     Schrittweise aktualisieren   Der Prior für eine Erfolgswahrscheinlichkeit sei .   In vier Versuchen gibt es einen Erfolg. Bestimmen Sie den Posterior, den MAP-Schätzwert, den A-posteriori-Erwartungswert und den ML-Schätzwert.    Rechnen Sie dieselben Daten in zwei Schritten: erst die ersten beiden Versuche mit einem Erfolg, dann den Posterior als neuen Prior für die beiden letzten Versuche ohne Erfolg. Was stellen Sie fest?          Nach ist der Posterior , also , der A-posteriori-Erwartungswert und .    Nach dem ersten Schritt ist der Posterior , nach dem zweiten , derselbe wie in (a). Ob man die Daten auf einmal oder nacheinander verrechnet, ist gleich; der Posterior von heute ist der Prior von morgen.        Ridge und Lasso an einer Zahl   Im Modell aus ist und .   Bestimmen Sie den Kleinste-Quadrate-Schätzwert und die Schätzwerte von Ridge und Lasso mit .    Für welches liefern Ridge und Lasso denselben Schätzwert?          Kleinste Quadrate: . Ridge: . Lasso: nach .    Solange ist, verlangt , also und damit . Beide Schätzwerte sind dann . Für kleinere schrumpft Ridge stärker, für größere Lasso; ab ist der Lasso-Schätzwert 0.        Zwei Arten zu mitteln    und seien unabhängig mit Erwartungswert und Varianz . Zeigen Sie, dass und beide erwartungstreu für sind. Welcher hat den kleineren mittleren quadratischen Fehler?     und . Bei erwartungstreuen Schätzern ist der mittlere quadratische Fehler die Varianz: und . ist besser: Bei gleich genauen Messungen gewichtet man gleich.     "
},
{
  "id": "sec-parameterschaetzung-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sec-parameterschaetzung-2",
  "type": "Lernziele",
  "number": "6.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie     zu einem Modell und einer Stichprobe die Likelihood und die Log-Likelihood aufstellen und den Maximum-Likelihood-Schätzer durch Ableiten bestimmen, auch wenn die Daten unvollständig sind oder das Maximum am Rand liegt,    die Maximum-Likelihood-Schätzer für Bernoulli-, Poisson-, Exponential- und Normalverteilung angeben und begründen und die Methode der kleinsten Quadrate und die Kreuzentropie als Maximum-Likelihood deuten,    Vorwissen als A-priori-Verteilung ausdrücken, mit einem Beta- oder Gamma-Prior die A-posteriori-Verteilung von Hand bestimmen und daraus den MAP-Schätzer und den A-posteriori-Erwartungswert berechnen,    Ridge- und Lasso-Regression als MAP-Schätzung mit Gauß- bzw. Laplace-Prior herleiten und erklären, wie stark der Prior schrumpft,    Verzerrung, Varianz und mittleren quadratischen Fehler eines Schätzers berechnen, Schätzer damit vergleichen, die Konsistenz eines Schätzers begründen und erklären, warum die Stichprobenvarianz durch teilt,    erkennen, wann eine Größe - oder -verteilt ist.    "
},
{
  "id": "def-stichprobe-schaetzer",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-stichprobe-schaetzer",
  "type": "Definition",
  "number": "6.1.1",
  "title": "Stichprobe und Schätzer.",
  "body": " Stichprobe und Schätzer  Stichprobe  Schätzer  Schätzwert   Sind unabhängig und identisch verteilt, so heißen sie eine Stichprobe vom Umfang . Ein Schätzer für ist eine Zufallsvariable , die aus der Stichprobe berechnet wird. Setzt man die beobachteten Daten ein, erhält man die Zahl , den Schätzwert .   "
},
{
  "id": "def-likelihood",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-likelihood",
  "type": "Definition",
  "number": "6.1.2",
  "title": "Likelihood und Log-Likelihood.",
  "body": " Likelihood und Log-Likelihood  Likelihood  Log-Likelihood   Seien die beobachteten Werte einer Stichprobe, deren Verteilung die Wahrscheinlichkeitsfunktion bzw. die Dichte hat. Die Funktion heißt Likelihood , ihr Logarithmus bzw. die Log-Likelihood .   "
},
{
  "id": "def-ml-schaetzer",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-ml-schaetzer",
  "type": "Definition",
  "number": "6.1.3",
  "title": "Maximum-Likelihood-Schätzer.",
  "body": " Maximum-Likelihood-Schätzer  Maximum-Likelihood-Schätzer  ML-Schätzer   Ein Wert , an dem die Likelihood ihr Maximum annimmt, heißt Maximum-Likelihood-Schätzwert , kurz ML-Schätzwert. Als Funktion der Stichprobe aufgefasst, ist er der Maximum-Likelihood-Schätzer .   "
},
{
  "id": "thm-ml-schaetzer",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-ml-schaetzer",
  "type": "Satz",
  "number": "6.1.4",
  "title": "ML-Schätzer der Grundverteilungen.",
  "body": " ML-Schätzer der Grundverteilungen  Maximum-Likelihood-Schätzer der Grundverteilungen   Für eine Stichprobe mit Mittelwert gilt:    : , der Anteil der Einsen.     : , sofern ist.     : .     mit beiden Parametern unbekannt: sofern nicht alle gleich sind.       (1) Mit , der Zahl der Einsen, ist und . Für ist und das ist positiv für und negativ für . Für ist fallend, das Maximum liegt am Rand bei ; ebenso liegt es für bei .  (2) hat die Ableitung , die bei von nach wechselt.  (3) hat die Ableitung , die bei von nach wechselt.  (4) Mit ist Für jedes feste ist das am größten, wenn die Summe am kleinsten ist. Wegen (ausmultiplizieren; der gemischte Term ist ) ist das bei der Fall, gleich wie groß ist. Mit bleibt zu maximieren. Die Ableitung nach ist und wechselt bei von nach .   "
},
{
  "id": "ex-login-fehlversuche",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-login-fehlversuche",
  "type": "Beispiel",
  "number": "6.1.5",
  "title": "Fehlgeschlagene Anmeldungen je Stunde.",
  "body": " Fehlgeschlagene Anmeldungen je Stunde   Ein Anmeldedienst zählt acht Stunden lang die fehlgeschlagenen Anmeldungen je Stunde: 2, 0, 3, 1, 4, 2, 1, 3. Als Modell nehmen wir an, dass die Zahlen unabhängig und -verteilt sind.   Stellen Sie die Log-Likelihood auf, und bestimmen Sie den ML-Schätzwert von durch Ableiten.    Schätzen Sie damit den Anteil der Stunden ohne Fehlversuch, und vergleichen Sie mit dem Anteil in den Daten.          Die Summe der Zählungen ist 16. Mit ist denn . Die Ableitung ist null bei und wechselt dort von nach , also ist , der Mittelwert der Daten, wie es sagt.    Im Modell ist ; mit dem Schätzwert ergibt das . In den Daten war eine der acht Stunden ohne Fehlversuch, also .     Modell und Daten passen in diesem Punkt gut zusammen. Für die Überwachung heißt das: Rund jede siebte Stunde ist ohne Fehlversuch, eine Stunde mit sieben oder mehr Fehlversuchen wäre dagegen ungewöhnlich und ein Anlass, nach einem Angriff zu suchen. zeigt die Log-Likelihood.   "
},
{
  "id": "fig-log-likelihood",
  "level": "2",
  "url": "sec-parameterschaetzung.html#fig-log-likelihood",
  "type": "Abbildung",
  "number": "6.1.6",
  "title": "",
  "body": " Die Log-Likelihood aus . Ihr Maximum liegt beim Mittelwert der Daten, .   Eine nach unten gewölbte Kurve mit dem höchsten Punkt bei lambda gleich 2   Über dem Bereich von 0,5 bis 4,5 steht eine nach unten gewölbte Kurve. Sie steigt von etwa minus 23 bei 0,5 steil an, erreicht bei 2 ihren höchsten Wert von etwa minus 13,1 und fällt dann langsamer auf etwa minus 20 bei 4,5. Eine gestrichelte senkrechte Linie markiert die Stelle 2.     "
},
{
  "id": "ex-gleichverteilung-maximum",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-gleichverteilung-maximum",
  "type": "Beispiel",
  "number": "6.1.7",
  "title": "Ein Maximum am Rand.",
  "body": " Ein Maximum am Rand   Ein Lastgenerator wartet vor jeder Anfrage eine Zeit, die auf gleichverteilt ist; ist eine Einstellung, die niemand dokumentiert hat. Gemessen wurden die Wartezeiten 2,1; 0,7; 3,4 und 1,8 Sekunden. Bestimmen Sie den ML-Schätzwert von .    Die Dichte ist auf und 0 sonst. Das Produkt der vier Dichtewerte ist , wenn alle vier Messwerte in liegen, also wenn ist, und 0 sonst: Für fällt ; das Maximum liegt also am linken Rand, , der größte Messwert.  Die Ableitung ist an keiner Stelle null; das Rezept mit dem Nullsetzen hätte nichts gefunden. Allgemein ist bei dieser Verteilung der größte Wert der Stichprobe der ML-Schätzer. Er liegt nie über und fast immer darunter, unterschätzt also systematisch. zeigt, wie man das korrigiert.   "
},
{
  "id": "rem-invarianz",
  "level": "2",
  "url": "sec-parameterschaetzung.html#rem-invarianz",
  "type": "Bemerkung",
  "number": "6.1.8",
  "title": "Funktionen des Parameters schätzen.",
  "body": " Funktionen des Parameters schätzen  Maximum-Likelihood-Schätzer einer Funktion des Parameters  Interessiert nicht selbst, sondern eine Größe , etwa die mittlere Lebensdauer , die Wahrscheinlichkeit für keinen Ausfall oder der Median , so schätzt man sie durch . Ist umkehrbar, ist das genau der ML-Schätzwert von : Die Likelihood als Funktion von ist , und die ist am größten, wenn ist. So wurde in der Anteil der Stunden ohne Fehlversuch geschätzt. Im Beispiel der Antwortzeiten ist der geschätzte Median  Sekunden.  "
},
{
  "id": "rem-unvollstaendige-daten",
  "level": "2",
  "url": "sec-parameterschaetzung.html#rem-unvollstaendige-daten",
  "type": "Bemerkung",
  "number": "6.1.9",
  "title": "Unvollständige Beobachtungen.",
  "body": " Unvollständige Beobachtungen  zensierte Beobachtung  Nicht jede Beobachtung ist ein genauer Wert. Eine Waage zeigt über ihrem Messbereich nur zu schwer an, eine Studie endet, bevor alle Geräte ausgefallen sind, ein Sensor meldet nur, ob ein Ereignis eingetreten ist. Die Likelihood bleibt das Produkt der Wahrscheinlichkeiten bzw. Dichtewerte dessen, was man tatsächlich beobachtet hat. Für einen genauen Wert ist das wie bisher ; weiß man von einer Beobachtung nur, dass sie größer als ist, trägt sie den Faktor bei, weiß man nur, dass sie höchstens ist, den Faktor . Solche Beobachtungen heißen zensiert . Sie wegzulassen oder sie als genau zu zählen, verfälscht die Schätzung: Wer bei einer Lebensdauerstudie nur die ausgefallenen Geräte auswertet, lässt gerade die haltbarsten weg.  "
},
{
  "id": "par-regression-ml-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#par-regression-ml-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Rauschen "
},
{
  "id": "thm-kleinste-quadrate",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-kleinste-quadrate",
  "type": "Satz",
  "number": "6.1.10",
  "title": "Kleinste Quadrate als ML-Schätzung.",
  "body": " Kleinste Quadrate als ML-Schätzung  Methode der kleinsten Quadrate  lineare Regression  Regression lineare   Im Modell oben sind die ML-Schätzwerte von und diejenigen Werte, die die Summe der quadrierten Abweichungen minimieren, nämlich und , die mittlere quadrierte Abweichung von der Geraden, sofern nicht alle Punkte auf einer Geraden liegen.     ist -verteilt, und die sind unabhängig. Wie im Beweis von , Teil (4), ist und für jedes feste ist das am größten, wo am kleinsten ist. Für festes ist die Summe der quadrierten Abstände der Zahlen von ; wie in Teil (4) ist sie am kleinsten, wenn deren Mittelwert ist. Eingesetzt bleibt mit , und . Diese nach oben geöffnete Parabel in hat ihren Scheitel bei . Die Aussage über folgt wie in Teil (4) mit .   "
},
{
  "id": "ex-batchjob-regression",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-batchjob-regression",
  "type": "Beispiel",
  "number": "6.1.11",
  "title": "Laufzeit eines Batch-Jobs.",
  "body": " Laufzeit eines Batch-Jobs   Ein nächtlicher Batch-Job verarbeitete an vier Tagen 1, 2, 3 und 4 Gigabyte Daten und lief dabei 3, 4, 7 und 6 Minuten. Bestimmen Sie im Modell die ML-Schätzwerte von , und . Welche Laufzeit sagt das Modell für 6 Gigabyte vorher?    Es ist und . Die Abweichungen sind bzw. , also und . Damit ist  Minuten je Gigabyte und  Minuten. Die Gerade sagt 3,2; 4,4; 5,6 und 6,8 Minuten vorher, die Abweichungen sind mit der Quadratsumme 2,8, also . Für 6 Gigabyte sagt das Modell  Minuten vorher.  Die geschätzte Standardabweichung des Rauschens ist  Minuten, die Vorhersage für einen einzelnen Lauf also nur auf knapp eine Minute genau. Vier Punkte sind wenig, und 6 Gigabyte liegen außerhalb der beobachteten Daten; ob der Zusammenhang dort noch linear ist, sagen die Daten nicht.   "
},
{
  "id": "par-kreuzentropie-3",
  "level": "2",
  "url": "sec-parameterschaetzung.html#par-kreuzentropie-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Kreuzentropie "
},
{
  "id": "sub-bayes-schaetzung-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-bayes-schaetzung-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "bayesschen "
},
{
  "id": "def-prior-posterior",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-prior-posterior",
  "type": "Definition",
  "number": "6.1.12",
  "title": "A-priori- und A-posteriori-Verteilung.",
  "body": " A-priori- und A-posteriori-Verteilung  Prior  Posterior  A-priori-Verteilung  A-posteriori-Verteilung   Die Dichte der Verteilung von vor den Daten heißt A-priori-Dichte oder kurz Prior . Sind beobachtet und ist ihre Likelihood, so heißt die A-posteriori-Dichte oder kurz Posterior . Das Integral läuft über alle möglichen Parameterwerte.   "
},
{
  "id": "def-map-schaetzer",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-map-schaetzer",
  "type": "Definition",
  "number": "6.1.13",
  "title": "MAP-Schätzer und A-posteriori-Erwartungswert.",
  "body": " MAP-Schätzer und A-posteriori-Erwartungswert  MAP-Schätzer  A-posteriori-Erwartungswert  Maximum-a-posteriori-Schätzung   Die Stelle des Maximums der A-posteriori-Dichte, heißt Maximum-a-posteriori-Schätzwert , kurz MAP-Schätzwert. Der Erwartungswert der A-posteriori-Verteilung, , heißt A-posteriori-Erwartungswert .   "
},
{
  "id": "prop-modus-beta-gamma",
  "level": "2",
  "url": "sec-parameterschaetzung.html#prop-modus-beta-gamma",
  "type": "Proposition",
  "number": "6.1.14",
  "title": "Modus der Beta- und der Gammaverteilung.",
  "body": " Modus der Beta- und der Gammaverteilung  Modus   Die Dichte von mit hat ihr Maximum bei , die Dichte von mit bei .    Der Logarithmus der Betadichte ist bis auf eine Konstante mit der Ableitung . Sie ist null bei , also bei , und wechselt dort von nach . Beim Logarithmus der Gammadichte, plus Konstante, ist die Ableitung ; für wechselt sie bei das Vorzeichen, und für ist die Dichte fallend mit dem Maximum bei 0.   "
},
{
  "id": "thm-beta-binomial",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-beta-binomial",
  "type": "Satz",
  "number": "6.1.15",
  "title": "Beta-Prior für eine Wahrscheinlichkeit.",
  "body": " Beta-Prior für eine Wahrscheinlichkeit  Beta-Prior  konjugierter Prior  Prior konjugierter   Der Prior für die Erfolgswahrscheinlichkeit sei . In unabhängigen -Versuchen werden Erfolge beobachtet. Dann ist der Posterior , und es ist die erste Formel für und .    Die Likelihood ist , der Prior ist bis auf eine Konstante . Also ist für  und das ist bis auf eine Konstante die Dichte von . Weil beide Funktionen die Fläche 1 haben, stimmen auch die Konstanten überein. Modus und Erwartungswert stehen in und .   "
},
{
  "id": "sub-bayes-schaetzung-11",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-bayes-schaetzung-11",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "konjugiert "
},
{
  "id": "ex-klickrate-vorwissen",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-klickrate-vorwissen",
  "type": "Beispiel",
  "number": "6.1.16",
  "title": "Die Klickrate einer neuen Anzeige.",
  "body": " Die Klickrate einer neuen Anzeige   Klickraten ähnlicher Anzeigen liegen meist zwischen einem und acht Prozent und selten über zehn. Das beschreibt der Prior : Er hat den Erwartungswert  %, legt rund 83 % seiner Wahrscheinlichkeit zwischen 0,01 und 0,08 und knapp 4 % oberhalb von 0,1.   Die neue Anzeige wurde zehnmal eingeblendet und nie angeklickt. Bestimmen Sie den Posterior, den MAP-Schätzwert und den A-posteriori-Erwartungswert, und vergleichen Sie mit dem ML-Schätzwert.    Nach 1000 Einblendungen hat die Anzeige 30 Klicks. Was ergibt sich jetzt?          Mit und ist der Posterior . Also ist  % und der A-posteriori-Erwartungswert  %, gegenüber .    Mit und ist der Posterior , also  % und der A-posteriori-Erwartungswert  %, gegenüber  %.     Nach zehn Einblendungen ohne Klick ist die Anzeige verdächtig, aber nicht abgeschrieben: Der MAP-Schätzwert fällt vom Modus des Priors,  %, auf 1,7 %, der A-posteriori-Erwartungswert vom Prior-Erwartungswert 4 % auf 3,3 %; beide bleiben weit über 0. Für den A-posteriori-Erwartungswert wiegt der Prior hier so viel wie 50 frühere Einblendungen, die zehn neuen verschieben die Schätzung nur ein Stück. Nach 1000 Einblendungen wiegen die Daten zwanzigmal so viel wie der Prior, und alle drei Schätzwerte liegen nah beieinander. Bei vielen Daten spielt das Vorwissen kaum noch eine Rolle; es hilft gerade dort, wo die Daten noch zu wenig sagen.   "
},
{
  "id": "fig-prior-posterior",
  "level": "2",
  "url": "sec-parameterschaetzung.html#fig-prior-posterior",
  "type": "Abbildung",
  "number": "6.1.17",
  "title": "",
  "body": " Prior (gestrichelt), Likelihood nach 9 Erfolgen in 10 Versuchen, auf Fläche 1 skaliert (gepunktet), und Posterior (durchgezogen). Der Posterior liegt zwischen Prior und Likelihood, mit dem Modus zwischen und dem ML-Schätzwert .   Drei Dichtekurven auf dem Intervall von 0 bis 1: eine symmetrische in der Mitte, eine weit rechts, eine dazwischen   Über dem Intervall von 0 bis 1 stehen drei Kurven. Die gestrichelte Kurve des Priors ist symmetrisch mit dem Gipfel 2,19 bei 0,5. Die gepunktete Kurve der Likelihood steigt bis 0,9 auf etwa 4,26 an und fällt dann steil auf 0 bei 1. Die durchgezogene Kurve des Posteriors hat ihren Gipfel 3,83 bei 0,75 und ist schmaler als der Prior.     "
},
{
  "id": "thm-gamma-poisson",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-gamma-poisson",
  "type": "Satz",
  "number": "6.1.18",
  "title": "Gamma-Prior für eine Rate.",
  "body": " Gamma-Prior für eine Rate  Gamma-Prior   Der Prior für die Rate sei . Es werden unabhängige -verteilte Anzahlen mit der Summe beobachtet. Dann ist der Posterior , und es ist die erste Formel für .    Die Likelihood ist , der Prior ist bis auf eine Konstante . Ihr Produkt ist bis auf eine Konstante die Dichte von . Modus und Erwartungswert stehen in und .   "
},
{
  "id": "ex-fehler-microservice",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-fehler-microservice",
  "type": "Beispiel",
  "number": "6.1.19",
  "title": "Fehlermeldungen eines neuen Dienstes.",
  "body": " Fehlermeldungen eines neuen Dienstes   Ein neuer Microservice geht in Betrieb. Ähnliche Dienste erzeugen im Mittel drei Fehlermeldungen je Tag, und dieser Mittelwert schwankt von Dienst zu Dienst mit einer Standardabweichung von etwa 1. Als Prior für die Rate des neuen Dienstes dient deshalb , mit Erwartungswert und Standardabweichung . In den ersten vier Tagen meldet er 1, 0, 2 und 1 Fehler. Bestimmen Sie den Posterior, den MAP-Schätzwert und den A-posteriori-Erwartungswert, und vergleichen Sie mit dem ML-Schätzwert.    Mit und ist der Posterior . Also ist und der A-posteriori-Erwartungswert Fehlermeldungen je Tag, gegenüber dem ML-Schätzwert .  Der Dienst läuft bisher deutlich ruhiger als seine Vorgänger, aber vier Tage sind wenig: Der Prior wiegt so viel wie drei Tage, die Daten wie vier. Wer Personal für die Fehlerbehebung plant, rechnet deshalb vorerst mit knapp zwei Meldungen je Tag statt mit einer, und mit jedem weiteren Tag rückt die Schätzung näher an das, was der neue Dienst tatsächlich tut.   "
},
{
  "id": "rem-prior-wahl",
  "level": "2",
  "url": "sec-parameterschaetzung.html#rem-prior-wahl",
  "type": "Bemerkung",
  "number": "6.1.20",
  "title": "Woher der Prior kommt.",
  "body": " Woher der Prior kommt  Den Prior wählt man so, dass er das Vorwissen trifft, meist über Erwartungswert und Streuung oder über den wahrscheinlichsten Wert, wie in den beiden Beispielen. Die konjugierten Familien sind bequem, weil der Posterior dann wieder eine bekannte Verteilung ist und die Rechnung aus Zählen besteht; mit anderen Priors muss man den Posterior numerisch bestimmen, etwa mit Monte-Carlo-Verfahren wie in . Ein schwacher Prior, etwa , lässt die Daten fast allein sprechen; ein starker Prior braucht viele Daten, bis sie ihn überstimmen. Ein falscher Prior verzerrt die Schätzung, solange die Daten wenige sind, wird aber mit wachsendem ebenso überstimmt, sofern er dem wahren Wert nicht die Dichte 0 gibt. Darin steckt der Kompromiss, den genauer fasst: Der Prior verringert die Streuung der Schätzung um den Preis einer Verzerrung.  "
},
{
  "id": "sub-regularisierung-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-regularisierung-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Regularisierung "
},
{
  "id": "thm-ridge-map",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-ridge-map",
  "type": "Satz",
  "number": "6.1.21",
  "title": "Ridge-Regression als MAP-Schätzung.",
  "body": " Ridge-Regression als MAP-Schätzung  Ridge-Regression   Im Modell oben sei der Prior . Dann ist der MAP-Schätzwert die Stelle des Minimums von nämlich     Bis auf Konstanten ist und . Die Summe ist am größten, wo ihr -faches am kleinsten ist. Das ist , eine nach oben geöffnete Parabel mit dem Scheitel bei .   "
},
{
  "id": "sub-regularisierung-6",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-regularisierung-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Laplace-Verteilung Lasso-Regression "
},
{
  "id": "thm-lasso-map",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-lasso-map",
  "type": "Satz",
  "number": "6.1.22",
  "title": "Lasso als MAP-Schätzung.",
  "body": " Lasso als MAP-Schätzung  Lasso-Regression   Mit dem Laplace-Prior ist der MAP-Schätzwert      Vertiefung: Bis auf die Konstante ist die zu minimierende Funktion . Für ist , für ist . Ist , so ist auf fallend, und auf wechselt bei von nach ; dort ist das Minimum. Der Fall geht spiegelbildlich. Ist , so ist auf und auf ; fällt bis 0 und steigt danach, das Minimum liegt bei 0.   "
},
{
  "id": "fig-schrumpfen",
  "level": "2",
  "url": "sec-parameterschaetzung.html#fig-schrumpfen",
  "type": "Abbildung",
  "number": "6.1.23",
  "title": "",
  "body": " Schätzwert als Funktion von für : kleinste Quadrate (gepunktet), Ridge mit (gestrichelt) und Lasso mit (durchgezogen). Lasso ist für genau null.   Zwei Geraden durch den Ursprung und eine geknickte Linie, die im mittleren Bereich auf null liegt   Waagerecht ist z von minus 20 bis 20 aufgetragen, senkrecht der Schätzwert. Die gepunktete Gerade der kleinsten Quadrate läuft durch den Ursprung mit der Steigung 0,1, die gestrichelte Ridge-Gerade mit der halben Steigung 0,05. Die durchgezogene Lasso-Linie liegt zwischen minus 5 und 5 auf der Achse und verläuft außerhalb parallel zur Geraden der kleinsten Quadrate, um 0,5 zur Achse hin verschoben.     "
},
{
  "id": "ex-zwei-merkmale",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-zwei-merkmale",
  "type": "Beispiel",
  "number": "6.1.24",
  "title": "Zwei Merkmale, zwei Strafterme.",
  "body": " Zwei Merkmale, zwei Strafterme   Ein Modell mit zwei Merkmalen wird an Daten angepasst, für die und ist, außerdem und .   Zeigen Sie, dass die Quadratsumme in zwei Teile zerfällt, die nur von bzw. nur von abhängen.    Bestimmen Sie die Schätzwerte nach den kleinsten Quadraten, nach Ridge und nach Lasso, jeweils mit und dem Strafterm bzw. .          Ausmultipliziert ist und der letzte Summand ist 0. Auch beide Strafterme sind Summen eines Terms in und eines in , also kann man jeden Koeffizienten für sich minimieren, mit und bzw. .    Kleinste Quadrate: und . Ridge: und . Lasso mit : , und wegen ist der zweite Schätzwert 0.     Ridge halbiert hier beide Koeffizienten. Lasso nimmt vom großen nur ein Fünftel weg und wirft das schwache zweite Merkmal ganz aus dem Modell. Ob das richtig ist, hängt davon ab, ob das zweite Merkmal tatsächlich nichts beiträgt; der Laplace-Prior hält genau das für wahrscheinlich.   "
},
{
  "id": "rem-ridge-allgemein",
  "level": "2",
  "url": "sec-parameterschaetzung.html#rem-ridge-allgemein",
  "type": "Bemerkung",
  "number": "6.1.25",
  "title": "Vertiefung: Viele Merkmale.",
  "body": " Vertiefung: Viele Merkmale  Mit Merkmalen, der Datenmatrix mit Zeilen und Spalten und dem Prior, unter dem die Koeffizienten unabhängig und -verteilt sind, ist der Ridge-Schätzer (ohne Beweis). Ohne ist das der Kleinste-Quadrate-Schätzer, und ist bei vielen, untereinander korrelierten Merkmalen fast nicht invertierbar; dann schwanken die Koeffizienten von Datensatz zu Datensatz enorm. Der Summand behebt das. Die Merkmale sollten dabei vergleichbar skaliert sein, wie in , sonst bestraft derselbe Prior verschiedene Merkmale verschieden stark. Für Lasso gibt es keine geschlossene Formel; man minimiert numerisch und erhält Modelle, in denen viele Koeffizienten genau null sind. In der Praxis wählt man meist nicht über einen Prior, sondern so, dass das Modell auf zurückgehaltenen Daten am besten vorhersagt. zeigt, warum ein mittleres besser sein kann als gar keines.  "
},
{
  "id": "def-erwartungstreue",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-erwartungstreue",
  "type": "Definition",
  "number": "6.1.26",
  "title": "Verzerrung und Erwartungstreue.",
  "body": " Verzerrung und Erwartungstreue  Verzerrung  Erwartungstreue  Bias   Die Verzerrung (englisch bias ) eines Schätzers ist . Der Schätzer heißt erwartungstreu oder unverzerrt, wenn für jeden möglichen Wert von gilt.   "
},
{
  "id": "def-mse",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-mse",
  "type": "Definition",
  "number": "6.1.27",
  "title": "Mittlerer quadratischer Fehler.",
  "body": " Mittlerer quadratischer Fehler  mittlerer quadratischer Fehler  Fehler mittlerer quadratischer   Der mittlere quadratische Fehler eines Schätzers ist .   "
},
{
  "id": "thm-mse-zerlegung",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-mse-zerlegung",
  "type": "Satz",
  "number": "6.1.28",
  "title": "Zerlegung des mittleren quadratischen Fehlers.",
  "body": " Zerlegung des mittleren quadratischen Fehlers  mittlerer quadratischer Fehler Zerlegung   Für jeden Schätzer mit endlicher Varianz ist     Mit ist , und der zweite Summand ist eine Konstante. Nach dem Verschiebungssatz in der Form , angewandt auf mit , ist .   "
},
{
  "id": "sub-gueteeigenschaften-6",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-gueteeigenschaften-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Bias-Varianz-Zerlegung "
},
{
  "id": "thm-stichprobenvarianz",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-stichprobenvarianz",
  "type": "Satz",
  "number": "6.1.29",
  "title": "Erwartungswert der Quadratsumme.",
  "body": " Erwartungswert der Quadratsumme  Stichprobenvarianz   Seien mit unabhängig mit Erwartungswert und Varianz . Dann ist Insbesondere ist mit verzerrt, und die Stichprobenvarianz  ist erwartungstreu für .    Wie im Beweis von , Teil (4), ist . Links ist der Erwartungswert jedes Summanden , zusammen . Rechts ist . Also ist der Erwartungswert der Quadratsumme .   "
},
{
  "id": "sub-gueteeigenschaften-9",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-gueteeigenschaften-9",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Freiheitsgrad "
},
{
  "id": "ex-varianz-schaetzen",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-varianz-schaetzen",
  "type": "Beispiel",
  "number": "6.1.30",
  "title": "Streuung einer Widerstandsserie.",
  "body": " Streuung einer Widerstandsserie   Fünf Widerstände einer Serie mit dem Nennwert haben 99, 102, 103, 98 und . Schätzen Sie die Standardabweichung der Serie mit und mit . Wie ändert sich die Schätzung, wenn man weiß, dass die Serie im Mittel genau den Nennwert trifft?    Der Mittelwert ist 101, die Quadratsumme der Abweichungen davon . Also ist und , die geschätzten Standardabweichungen sind und . Ist bekannt, misst man die Abweichungen von und teilt durch : Die Quadratsumme ist , die Schätzung , also rund . Das sind genau die , um die die Quadratsumme um nach der Gleichung im Beweis kleiner ist.  Bei fünf Werten macht der Faktor gut ein Zehntel in der Standardabweichung aus. Wer daraus Toleranzen ableitet, etwa für den Anteil brauchbarer Widerstände, rechnet mit zu optimistisch.   "
},
{
  "id": "ex-seriennummern",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-seriennummern",
  "type": "Beispiel",
  "number": "6.1.31",
  "title": "Seriennummern.",
  "body": " Seriennummern   Im Zweiten Weltkrieg schätzten die Alliierten, wie viele Panzer eines Typs produziert worden waren, aus den Seriennummern erbeuteter Fahrzeuge. Vereinfacht seien die Nummern unabhängig und auf gleichverteilt; ist die gesuchte Stückzahl. Drei Schätzer liegen nahe: , weil ist, das Maximum der Nummern, der ML-Schätzer, und .   Erbeutet wurden vier Fahrzeuge mit den Nummern 61, 19, 56 und 24. Berechnen Sie die drei Schätzwerte.     hat die Verteilungsfunktion auf . Bestimmen Sie und und damit Verzerrung und mittleren quadratischen Fehler der drei Schätzer für .          Der Mittelwert ist 40, also ; und .     ist höchstens , wenn alle vier Nummern höchstens sind; daher die Verteilungsfunktion. Die Dichte ist , und Für : und . Daraus:    ist erwartungstreu, mit , denn die Gleichverteilung auf hat die Varianz .     hat und .     ist erwartungstreu, mit .         ist am besten, mit halb so großem mittlerem quadratischem Fehler wie . Bemerkenswert ist der Vergleich der beiden anderen: Der verzerrte Schätzer schlägt den erwartungstreuen , weil er viel weniger streut. Das Maximum enthält mehr Information über als das Mittel, das auch die kleinen Nummern einrechnet. Nach dem Krieg zeigten die Produktionsunterlagen, dass die Schätzungen aus Seriennummern viel näher an den tatsächlichen Stückzahlen lagen als die Schätzungen der Nachrichtendienste.  Quelle: R. Ruggles, H. Brodie, An Empirical Approach to Economic Intelligence in World War II , Journal of the American Statistical Association 42 (1947), 72 91 ( ).   "
},
{
  "id": "ex-ridge-bias-varianz",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-ridge-bias-varianz",
  "type": "Beispiel",
  "number": "6.1.32",
  "title": "Wie stark schrumpfen?",
  "body": " Wie stark schrumpfen?   Im Modell aus ist der Ridge-Schätzer mit .   Bestimmen Sie Verzerrung, Varianz und mittleren quadratischen Fehler von als Funktion von .    Werten Sie den mittleren quadratischen Fehler für , und bei , 4 und 10 aus.   Für welches ist er am kleinsten?          und, weil die unabhängig sind, . Also ist und .     : . : . : .    Die Ableitung nach ist und wechselt bei von nach . Hier ist das .     Der Kleinste-Quadrate-Schätzer, , ist erwartungstreu, aber nicht der beste. Mit wachsendem fällt die Varianz und wächst die Verzerrung, und das Optimum liegt dazwischen. Es ist , also gerade das aus mit : Ein Prior, dessen Streuung zur wahren Größe des Koeffizienten passt, schrumpft genau richtig. Weil man nicht kennt, bestimmt man in der Praxis aus den Daten.   "
},
{
  "id": "rem-bias-varianz-vorhersage",
  "level": "2",
  "url": "sec-parameterschaetzung.html#rem-bias-varianz-vorhersage",
  "type": "Bemerkung",
  "number": "6.1.33",
  "title": "Vertiefung: Bias-Varianz-Zerlegung des Vorhersagefehlers.",
  "body": " Vertiefung: Bias-Varianz-Zerlegung des Vorhersagefehlers  Bias-Varianz-Zerlegung des Vorhersagefehlers  Im maschinellen Lernen interessiert weniger der Fehler im Parameter als der Fehler einer Vorhersage. Sagt man im Modell oben eine neue Beobachtung , unabhängig von den Daten, durch vorher, so ist , und wegen der Unabhängigkeit und ist Der erste Summand ist das irreduzible Rauschen , das auch die beste Vorhersage mit bekanntem nicht beseitigt; das ist der Restfehler aus und . Die beiden anderen Summanden bilden den Kompromiss, der unter dem Namen Bias-Varianz-Zerlegung durch das maschinelle Lernen zieht: Einfache oder stark regularisierte Modelle haben kleine Varianz und große Verzerrung, flexible Modelle umgekehrt.  "
},
{
  "id": "def-konsistenz",
  "level": "2",
  "url": "sec-parameterschaetzung.html#def-konsistenz",
  "type": "Definition",
  "number": "6.1.34",
  "title": "Konsistenz.",
  "body": " Konsistenz  Konsistenz   Eine Folge von Schätzern heißt konsistent für , wenn für jeden möglichen Wert von gilt, im Sinn von .   "
},
{
  "id": "thm-konsistenz-mse",
  "level": "2",
  "url": "sec-parameterschaetzung.html#thm-konsistenz-mse",
  "type": "Satz",
  "number": "6.1.35",
  "title": "Konsistenz über den mittleren quadratischen Fehler.",
  "body": " Konsistenz über den mittleren quadratischen Fehler      Strebt gegen 0, also Verzerrung und Varianz, so ist die Folge konsistent.    Ist die Folge konsistent für und gilt für alle , mit einer Konstanten , so ist konsistent für .       (1) Nach der Ungleichung von Markov, , angewandt auf , ist Nach strebt der mittlere quadratische Fehler genau dann gegen 0, wenn Verzerrung und Varianz es tun. (2) Für folgt aus , dass ist, also .   "
},
{
  "id": "sub-t-verteilung-5-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-t-verteilung-5-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "-Verteilung "
},
{
  "id": "fig-t-dichten",
  "level": "2",
  "url": "sec-parameterschaetzung.html#fig-t-dichten",
  "type": "Abbildung",
  "number": "6.1.36",
  "title": "",
  "body": " Dichten von (gepunktet), (gestrichelt) und (durchgezogen). Je weniger Freiheitsgrade, desto niedriger die Mitte und desto schwerer die Ränder.   Drei glockenförmige, symmetrische Kurven, die flacheren mit höheren Rändern   Über dem Bereich von minus 4 bis 4 stehen drei um 0 symmetrische Glockenkurven. Die durchgezogene Kurve der Standardnormalverteilung ist in der Mitte am höchsten, mit etwa 0,40, und fällt nach außen am schnellsten ab. Die gestrichelte Kurve für vier Freiheitsgrade hat die Höhe 0,375, die gepunktete für einen Freiheitsgrad die Höhe 0,32; sie liegen in der Mitte tiefer und außen höher als die Normalverteilung, die gestrichelte jenseits von etwa 1,6, die gepunktete jenseits von etwa 1,9.     "
},
{
  "id": "ex-kleine-stichprobe",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-kleine-stichprobe",
  "type": "Beispiel",
  "number": "6.1.37",
  "title": "Fehlerbalken aus fünf Messungen.",
  "body": " Fehlerbalken aus fünf Messungen   Fünf Messungen einer normalverteilten Größe ergeben Mittelwert und Stichprobenstandardabweichung . Ein Messprotokoll gibt als Fehlerbalken an, im Glauben, ein so gebildeter Balken verfehle den wahren Erwartungswert nur in rund 5 % der Fälle. Mit welcher Wahrscheinlichkeit weicht tatsächlich um mehr als von ab? Für ist .    Die Abweichung ist größer als , wenn ist mit , und ist -verteilt. Die Wahrscheinlichkeit ist also rund 11,6 %, gut zweieinhalbmal so viel wie die  % bei bekanntem .  Mit mehr Messungen wird der Unterschied kleiner: Für , also zehn Messungen, ist  %, für etwa 5,5 %. Wer die Faustregel zwei Standardfehler aus mit geschätzter Standardabweichung auf eine Handvoll Messungen anwendet, zeichnet zu schmale Fehlerbalken.   "
},
{
  "id": "sub-f-verteilung-4-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-f-verteilung-4-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "-Verteilung "
},
{
  "id": "ex-zwei-linien-streuung",
  "level": "2",
  "url": "sec-parameterschaetzung.html#ex-zwei-linien-streuung",
  "type": "Beispiel",
  "number": "6.1.38",
  "title": "Wie verlässlich ist ein Streuungsvergleich?",
  "body": " Wie verlässlich ist ein Streuungsvergleich?   An zwei Abfüllanlagen, die in Wirklichkeit gleich stark streuen, werden je drei Füllmengen gemessen. Mit welcher Wahrscheinlichkeit ist die Stichprobenvarianz der ersten Anlage mehr als viermal so groß wie die der zweiten? Nehmen Sie normalverteilte Füllmengen an, und rechnen Sie ohne die Formel der Dichte, mit .    Mit ist , also mit unabhängigen . Damit ist denn für festes ist . Das stimmt mit der Verteilungsfunktion überein.  Mit Wahrscheinlichkeit zeigt die erste Anlage also mehr als die vierfache Stichprobenvarianz der zweiten, mehr als die doppelte Standardabweichung, und ebenso oft umgekehrt, obwohl beide gleich streuen. Aus drei Messungen je Anlage lässt sich über die Streuung kaum etwas sagen. Nach ist die Standardabweichung von das -fache von , bei drei Messungen also so groß wie selbst; erst mit 51 Messungen sinkt sie auf ein Fünftel.   "
},
{
  "id": "sub-zusammenfassung-6-1-2",
  "level": "2",
  "url": "sec-parameterschaetzung.html#sub-zusammenfassung-6-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Likelihood. ML-Schätzer der Grundverteilungen. Prior, Posterior, MAP. Konjugierte Priors. Regularisierung. Verzerrung und Varianz. Konsistenz. und . "
},
{
  "id": "exercise-buch-menuefuehrung",
  "level": "2",
  "url": "sec-parameterschaetzung.html#exercise-buch-menuefuehrung",
  "type": "Übung",
  "number": "6.1.8.1",
  "title": "Eine neue Menüführung.",
  "body": " Eine neue Menüführung   Von 20 Testpersonen finden 7 eine neue Menüführung schlechter als die alte. Jede Person urteile unabhängig, mit derselben Wahrscheinlichkeit für schlechter .  Bestimmen Sie den ML-Schätzwert von .   Schätzen Sie die Chance , also das Verhältnis der Wahrscheinlichkeiten für schlechter und nicht schlechter .          Nach ist .    Nach mit , einer umkehrbaren Funktion auf : .      "
},
{
  "id": "exercise-buch-paketlaufzeiten",
  "level": "2",
  "url": "sec-parameterschaetzung.html#exercise-buch-paketlaufzeiten",
  "type": "Übung",
  "number": "6.1.8.2",
  "title": "Paketlaufzeiten.",
  "body": " Paketlaufzeiten   Vier Laufzeiten eines Netzwerkpakets betragen 3, 8, 6 und 7 Millisekunden. Nehmen Sie an, dass sie unabhängig und -verteilt sind. Bestimmen Sie die ML-Schätzwerte von und und die Stichprobenvarianz . Welcher der beiden Schätzwerte für ist erwartungstreu? Ab welchem Stichprobenumfang unterscheiden sich die beiden geschätzten Standardabweichungen um weniger als 5 %?     . Die Abweichungen sind , die Quadratsumme ist 14. Also ist und . Erwartungstreu ist nach die Stichprobenvarianz.  Die Standardabweichungen unterscheiden sich bei jeder Stichprobe um den Faktor , hier . Weniger als 5 % heißt , also : ab .   "
},
{
  "id": "exercise-buch-beta-schrittweise",
  "level": "2",
  "url": "sec-parameterschaetzung.html#exercise-buch-beta-schrittweise",
  "type": "Übung",
  "number": "6.1.8.3",
  "title": "Schrittweise aktualisieren.",
  "body": " Schrittweise aktualisieren   Der Prior für eine Erfolgswahrscheinlichkeit sei .   In vier Versuchen gibt es einen Erfolg. Bestimmen Sie den Posterior, den MAP-Schätzwert, den A-posteriori-Erwartungswert und den ML-Schätzwert.    Rechnen Sie dieselben Daten in zwei Schritten: erst die ersten beiden Versuche mit einem Erfolg, dann den Posterior als neuen Prior für die beiden letzten Versuche ohne Erfolg. Was stellen Sie fest?          Nach ist der Posterior , also , der A-posteriori-Erwartungswert und .    Nach dem ersten Schritt ist der Posterior , nach dem zweiten , derselbe wie in (a). Ob man die Daten auf einmal oder nacheinander verrechnet, ist gleich; der Posterior von heute ist der Prior von morgen.      "
},
{
  "id": "exercise-buch-ridge-lasso",
  "level": "2",
  "url": "sec-parameterschaetzung.html#exercise-buch-ridge-lasso",
  "type": "Übung",
  "number": "6.1.8.4",
  "title": "Ridge und Lasso an einer Zahl.",
  "body": " Ridge und Lasso an einer Zahl   Im Modell aus ist und .   Bestimmen Sie den Kleinste-Quadrate-Schätzwert und die Schätzwerte von Ridge und Lasso mit .    Für welches liefern Ridge und Lasso denselben Schätzwert?          Kleinste Quadrate: . Ridge: . Lasso: nach .    Solange ist, verlangt , also und damit . Beide Schätzwerte sind dann . Für kleinere schrumpft Ridge stärker, für größere Lasso; ab ist der Lasso-Schätzwert 0.      "
},
{
  "id": "exercise-buch-zwei-mittel",
  "level": "2",
  "url": "sec-parameterschaetzung.html#exercise-buch-zwei-mittel",
  "type": "Übung",
  "number": "6.1.8.5",
  "title": "Zwei Arten zu mitteln.",
  "body": " Zwei Arten zu mitteln    und seien unabhängig mit Erwartungswert und Varianz . Zeigen Sie, dass und beide erwartungstreu für sind. Welcher hat den kleineren mittleren quadratischen Fehler?     und . Bei erwartungstreuen Schätzern ist der mittlere quadratische Fehler die Varianz: und . ist besser: Bei gleich genauen Messungen gewichtet man gleich.   "
},
{
  "id": "app-lizenz-quellen",
  "level": "1",
  "url": "app-lizenz-quellen.html",
  "type": "Anhang",
  "number": "A",
  "title": "Lizenz und Quellen",
  "body": " Lizenz und Quellen  Dieses Buch beruht auf den Folien und Übungsblättern der Vorlesung Wahrscheinlichkeitstheorie von Ulrich Schlickewei an der Technischen Hochschule Ingolstadt. Dieser Anhang sagt, unter welchen Bedingungen Sie das Buch weiterverwenden dürfen und woher Beispiele, Zahlen und Aussagen stammen, die nicht vom Autor sind.   Lizenz  Text, Abbildungen und Code-Beispiele dieses Buchs stehen unter der Lizenz Creative Commons Namensnennung 4.0 International (CC BY 4.0). Eine Kurzfassung steht unter , der Lizenztext unter . Sie dürfen das Material in jedem Format vervielfältigen und weitergeben, es verändern und darauf aufbauen, auch kommerziell. Bedingung ist, dass Sie den Autor nennen, auf die Lizenz verweisen und angeben, ob Sie etwas geändert haben. Sie dürfen dabei nicht den Eindruck erwecken, der Autor unterstütze Sie oder Ihre Verwendung. Eine passende Angabe ist:   Ulrich Schlickewei, Wahrscheinlichkeitstheorie. Data Science für Technik und Wirtschaft , Technische Hochschule Ingolstadt 2026, , Lizenz CC BY 4.0, .   Haben Sie etwas geändert, ergänzen Sie die Angabe um einen Hinweis wie bearbeitet .  Zwei Dinge sind von dieser Lizenz ausgenommen. Erstens die Software, mit der die Webfassung erzeugt und angezeigt wird, vor allem PreTeXt, die Runestone-Komponenten der Code-Zellen und MathJax: Sie steht unter den Lizenzen ihrer Urheber. Zweitens das, was aus Werken anderer stammt: einzelne Zahlen und Tabellen und die Idee einzelner Beispiele. Daran beansprucht der Autor keine Rechte, und er kann auch keine vergeben. Diese Stellen sind im Text gekennzeichnet und in der folgenden Liste aufgeführt. Wenn Sie eine davon weiterverwenden, nennen Sie bitte auch die ursprüngliche Quelle.    Beispiele und Zahlen aus Lehrbüchern  Die folgenden Stellen gehen auf Lehrbücher zurück, die auch die Vorlesung benutzt. Aus der Quelle stammt jeweils, was genannt ist; alles Weitere an dem Beispiel ist für dieses Buch geschrieben.    : die Tabelle der 940 Wafer und die Idee, an ihr die Additionsregel zu zeigen, aus Montgomery und Runger .    Der Einstieg in : die Vierfeldertafel der 400 Teile und die Idee, an ihr die bedingte Wahrscheinlichkeit einzuführen, aus Montgomery und Runger .     und : der digitale Kanal mit Blöcken aus vier Bits und der Fehlerwahrscheinlichkeit je Bit samt der Tabelle der Wahrscheinlichkeiten aus Montgomery und Runger . Die Fehlerkorrektur und die Fragen zur doppelten Blocklänge sind ergänzt.     : die Stromstärke im Kupferdraht mit ihrer Dichte und die beiden Fragen nach Wahrscheinlichkeiten von Intervallen aus Montgomery und Runger . Die Prüfung der Dichte und die Frage nach genau 5 mA sind ergänzt.     : die Frage nach dem fairen Punktabzug in Teil (a) aus Meintrup .     : Die Aufgabe stammt aus den Folien der Vorlesung, die zum Thema Überbuchung auf Meintrup verweisen.     : die Situation (ein Test mit Erwartungswert 100 und Standardabweichung 15) und die Aufgabe, die Verteilung zu beschreiben, aus Meintrup . Die Fragen nach einzelnen Anteilen und nach dem besten Prozent sind ergänzt.     : angeregt durch ein Beispiel der Vorlesung nach Weitz , das Passwörter mit Pflichtzeichen zählt. Die Fassung hier ist einfacher und um die Zeiten für das Durchprobieren ergänzt.     : Das Geburtstagsproblem ist ein klassisches Beispiel; die Folien der Vorlesung verweisen dazu auf Meintrup . Die Anwendung auf Hash-Kollisionen ist für dieses Buch geschrieben.     : Minimum und Maximum zweier Würfel ist das Beispiel der Vorlesung zur gemeinsamen Verteilung; die Folien zeigen dazu eine Abbildung aus Arens u. a. .     : Die Herleitung der Betaverteilung über sortierte Zufallszahlen folgt einem Arbeitsblatt der Vorlesung, das sich auf Adhikari und Pitman stützt.     Bei drei weiteren Stellen nennen die Folien der Vorlesung keine Quelle, eine Lehrbuchvorlage ist aber möglich oder wahrscheinlich:    stammt aus den Folien; der Zuschnitt spricht für eine Lehrbuchaufgabe als Vorlage. Die Fragen nach dem Mittelwert in Teil (b) sind ergänzt.    Teil (a) von stammt aus den Folien.    Die Einführung der Poisson-Verteilung an den Fehlerstellen eines Kupferkabels in und der Übergang zur Exponentialverteilung in folgen den Folien. Die Einkleidung stammt wahrscheinlich aus Montgomery und Runger ; nachgeprüft ist das nicht.   Alle übrigen Beispiele stammen aus den Unterlagen der Vorlesung, ohne dass dort eine Quelle vermerkt ist, oder sind für dieses Buch geschrieben.    Belege  Wo eine historische oder empirische Angabe einen Beleg braucht oder das Buch ein weniger bekanntes Ergebnis ohne Beweis übernimmt, steht der Beleg an der Stelle:   der Fall Sally Clark in : Royal Statistical Society , R v Clark  , Hill , Sesardić ;    die Axiome in : Kolmogorov ;    die Fehlerschranken der Poisson-Näherung in : Le Cam , Barbour und Hall ;    die Schranke für den Abstand von hypergeometrischer und Binomialverteilung in : Holmes , zitiert nach Dümbgen, Samworth und Wellner ;    die Perzentile als Betriebsziele in : Beyer u. a. ;    die Herkunft des Wortes Regression in : Galton ;    die Portfoliotheorie in : Markowitz ;    die Wölbung von Aktienrenditen in : Cont ;    die Schätzung aus Seriennummern in : Ruggles und Brodie .   Sätze des Standardstoffs, die das Buch ohne Beweis benutzt, etwa den Satz von Fubini oder den Eindeutigkeitssatz für momenterzeugende Funktionen, haben hier keinen Einzelbeleg. Sie stehen mit Beweis in den Lehrbüchern der Analysis und der Wahrscheinlichkeitstheorie.    Abbildungen und Tabellen  Alle Abbildungen dieses Buchs sind für das Buch neu gezeichnet oder mit eigenen Programmen erzeugt; keine ist als Bild aus einem anderen Werk übernommen. Erkennbar einer Vorlage folgt eine: Der Aufbau von ist der einer Abbildung in Montgomery und Runger , die die Vorlesung zeigt. Aus demselben Buch zeigt die Vorlesung je ein Bild mit mehreren Dichten der Normal- und der Exponentialverteilung; und folgen dieser üblichen Darstellung mit eigenen Parametern. Die Tabellen der Standardnormalverteilung in sind neu berechnet.   "
},
{
  "id": "references-literatur",
  "level": "1",
  "url": "references-literatur.html",
  "type": "Literaturverzeichnis",
  "number": "",
  "title": "Literatur",
  "body": " Literatur  A. Adhikari, J. Pitman, Probability for Data Science , Online-Lehrbuch zur Vorlesung Data 140 der University of California, Berkeley, (abgerufen am 5. Oktober 2026).  T. Arens, F. Hettlich, C. Karpfinger, U. Kockelkorn, K. Lichtenegger, H. Stachel, Mathematik , 5. Auflage, Springer Spektrum, Berlin 2022.  A. D. Barbour, P. Hall, On the rate of Poisson convergence , Mathematical Proceedings of the Cambridge Philosophical Society  95 (1984), 473 480.  B. Beyer, C. Jones, J. Petoff, N. R. Murphy (Hrsg.), Site Reliability Engineering: How Google Runs Production Systems , O'Reilly, Sebastopol 2016.  R. Cont, Empirical properties of asset returns: stylized facts and statistical issues , Quantitative Finance  1 (2001), 223 236.  Court of Appeal (Criminal Division), R v Clark , [2003] EWCA Crim 1020, Urteil vom 11. April 2003, .  L. Dümbgen, R. J. Samworth, J. A. Wellner, Bounding distributional errors via density ratios , Bernoulli  27 (2021), 818 852.  F. Galton, Regression towards mediocrity in hereditary stature , Journal of the Anthropological Institute of Great Britain and Ireland  15 (1886), 246 263.  R. Hill, Multiple sudden infant deaths coincidence or beyond coincidence? , Paediatric and Perinatal Epidemiology  18 (2004), 320 326.  S. Holmes, Stein's method for birth and death chains , in: P. Diaconis, S. Holmes (Hrsg.), Stein's Method: Expository Lectures and Applications, IMS Lecture Notes Monograph Series 46, Institute of Mathematical Statistics, Beachwood 2004, 42 65 (bei Dümbgen u. a. zitiert als 45 67), .  A. Kolmogoroff (heute meist: A. N. Kolmogorov), Grundbegriffe der Wahrscheinlichkeitsrechnung , Springer, Berlin 1933.  L. Le Cam, An approximation theorem for the Poisson binomial distribution , Pacific Journal of Mathematics  10 (1960), 1181 1197.  H. Markowitz, Portfolio Selection , Journal of Finance  7 (1952), 77 91.  D. Meintrup, Angewandte Statistik: Eine Einführung mit JMP , CreateSpace Independent Publishing Platform, 2018.  D. C. Montgomery, G. C. Runger, Applied Statistics and Probability for Engineers , 7. Auflage, Wiley, Hoboken 2018.  Royal Statistical Society, Royal Statistical Society concerned by issues raised in Sally Clark case , Pressemitteilung vom 23. Oktober 2001.  R. Ruggles, H. Brodie, An Empirical Approach to Economic Intelligence in World War II , Journal of the American Statistical Association  42 (1947), 72 91.  N. Sesardić, Sudden Infant Death or Murder? A Royal Confusion About Probabilities , British Journal for the Philosophy of Science  58 (2007), 299 329.  E. Weitz, Konkrete Mathematik (nicht nur) für Informatiker , 2. Auflage, Springer Spektrum, Berlin 2021.  "
},
{
  "id": "index-stichwoerter",
  "level": "1",
  "url": "index-stichwoerter.html",
  "type": "Register",
  "number": "",
  "title": "Stichwortverzeichnis",
  "body": " Stichwortverzeichnis   "
}
]

var ptx_lunr_idx = lunr(function () {
  this.ref('id')
  this.field('title')
  this.field('body')
  this.metadataWhitelist = ['position']

  ptx_lunr_docs.forEach(function (doc) {
    this.add(doc)
  }, this)
})
